import type { JobPayload, JobPreferences } from '@cosmo/shared';
import {
  SearchResultJob,
  buildNaukriSearchUrl,
  matchesListCandidate,
  searchUrlHasPreferenceFilters,
} from '../adapters/naukriAdapter';
import { fetchPreferences } from './apiClient';
import { getCachedPreferences } from './storageManager';
import { logger } from './logger';
import { enqueueApplyJobs } from './applyQueue';
import { mergeJobFields } from './jobFields';
import {
  ensureNaukriWorkTab,
  installTabSpamGuard,
  setActiveWorkTabId,
} from './singleTab';

function wait(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function waitForTabComplete(tabId: number, timeoutMs = 25000) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const tab = await chrome.tabs.get(tabId);
    if (tab.status === 'complete') return tab;
    await wait(400);
  }
  return chrome.tabs.get(tabId);
}

async function sendToTab<T>(
  tabId: number,
  message: unknown,
  attempts = 8
): Promise<T> {
  let lastError: unknown;
  for (let i = 0; i < attempts; i++) {
    try {
      return (await chrome.tabs.sendMessage(tabId, message)) as T;
    } catch (error) {
      lastError = error;
      await wait(500);
    }
  }
  throw lastError instanceof Error
    ? lastError
    : new Error('Failed to message content script');
}

export type ScanResult = {
  ok: boolean;
  message: string;
  matched: number;
  queuedForApply: number;
  loggedIn?: boolean;
  tabId?: number;
};

export async function runScan(options: {
  persistAndSync: (
    type: 'JobDetected',
    payload: Record<string, unknown>
  ) => Promise<void>;
}): Promise<ScanResult> {
  const prefsRes = await fetchPreferences();
  const prefs: JobPreferences = prefsRes.success
    ? prefsRes.data
    : await getCachedPreferences();

  if (!prefs.titles.length && !prefs.keywords.length) {
    return {
      ok: false,
      message: 'Add at least 3 job titles and 4 keywords in preferences first.',
      matched: 0,
      queuedForApply: 0,
    };
  }
  if (prefs.titles.length < 3 || prefs.keywords.length < 4) {
    return {
      ok: false,
      message: 'Preferences need at least 3 job titles and 4 keywords.',
      matched: 0,
      queuedForApply: 0,
    };
  }

  if (!prefs.autoScanEnabled) {
    return {
      ok: false,
      message: 'Auto-scan is disabled in preferences.',
      matched: 0,
      queuedForApply: 0,
    };
  }

  const searchUrl = buildNaukriSearchUrl(prefs);
  logger.info('Starting Naukri scan', { searchUrl });

  installTabSpamGuard();
  const tab = await ensureNaukriWorkTab({ url: searchUrl, active: true });
  if (!tab.id) {
    return {
      ok: false,
      message: 'Could not open Naukri tab.',
      matched: 0,
      queuedForApply: 0,
    };
  }
  setActiveWorkTabId(tab.id);

  await waitForTabComplete(tab.id);
  await wait(2500);

  const login = await sendToTab<{
    loggedIn: boolean;
    status?: 'loggedIn' | 'loggedOut' | 'uncertain';
  }>(tab.id, {
    type: 'CHECK_LOGIN',
  });
  if (!login.loggedIn) {
    const hint =
      login.status === 'uncertain'
        ? 'Confirm you’re logged into Naukri in this browser, then Scan again.'
        : 'Log into Naukri in this browser, then Scan again.';
    return {
      ok: false,
      message: hint,
      matched: 0,
      queuedForApply: 0,
      loggedIn: false,
      tabId: tab.id,
    };
  }

  try {
    const tabInfo = await chrome.tabs.get(tab.id);
    if (!searchUrlHasPreferenceFilters(tabInfo.url || '', prefs)) {
      await chrome.tabs.update(tab.id, { url: searchUrl, active: true });
      await waitForTabComplete(tab.id);
      await wait(1500);
    }
    await sendToTab(tab.id, { type: 'APPLY_PREFERENCE_FILTERS', prefs });
    await wait(1800);
    await waitForTabComplete(tab.id);
  } catch {
    /* filters are best-effort; URL params still apply */
  }

  const scrape = await sendToTab<{ jobs: SearchResultJob[] }>(tab.id, {
    type: 'RUN_SCAN_SCRAPE',
  });

  const matched = (scrape.jobs ?? []).filter((job) =>
    matchesListCandidate(job, prefs)
  );

  for (const job of matched) {
    const payload = mergeJobFields(undefined, job, {
      status: 'detected',
      metadata: job.companySiteApply
        ? { source: 'auto_scan', companySiteApply: true }
        : { source: 'auto_scan' },
    });
    await options.persistAndSync(
      'JobDetected',
      payload as unknown as Record<string, unknown>
    );
  }

  const easyApply = matched.filter((job) => !job.companySiteApply);
  let queuedForApply = 0;
  if (prefs.autoApplyEnabled && easyApply.length > 0) {
    queuedForApply = await enqueueApplyJobs(
      easyApply.map((j) => ({
        url: j.url,
        title: j.title,
        company: j.company,
        externalJobId: j.externalJobId,
        location: j.location,
        companyLogo: j.companyLogo,
        description: j.description,
        experience: j.experienceText,
        salary: j.salaryText,
        skills: j.skills,
        rating: j.rating,
        reviews: j.reviews,
        postedAt: j.postedAt,
      }))
    );
  }

  return {
    ok: true,
    message: `Matched ${matched.length} jobs${
      queuedForApply ? `, queued ${queuedForApply} to apply` : ''
    }.`,
    matched: matched.length,
    queuedForApply,
    loggedIn: true,
    tabId: tab.id,
  };
}
