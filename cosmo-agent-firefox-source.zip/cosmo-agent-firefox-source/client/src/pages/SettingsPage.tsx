import { useQueryClient } from '@tanstack/react-query';
import { useAuthStore } from '../store/authStore';
import { PreferencesForm } from '../components/PreferencesForm';
import { ONBOARDING_QUERY_KEY } from '../lib/onboarding';

export function SettingsPage() {
  const user = useAuthStore((s) => s.user);
  const queryClient = useQueryClient();

  return (
    <div className="dash">
      <div className="panel settings-grid">
        <div>
          <p className="muted">
            Manage account details and job-search preferences used by the
            extension for scan and Easy Apply.
          </p>
        </div>

        <div>
          <strong>Signed in as</strong>
          <p className="muted">
            {user?.name} · {user?.email}
          </p>
        </div>
      </div>

      <div className="panel">
        <h2>Job preferences</h2>
        <p className="muted">
          Titles, keywords, and filters drive auto-scan and auto-apply on
          Naukri.
        </p>
        <PreferencesForm
          onSaved={() => {
            void queryClient.invalidateQueries({
              queryKey: ONBOARDING_QUERY_KEY,
            });
          }}
        />
      </div>
    </div>
  );
}
