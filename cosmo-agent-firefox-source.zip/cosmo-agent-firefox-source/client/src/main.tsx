import { StrictMode, useEffect } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { GoogleOAuthProvider } from '@react-oauth/google';
import { AppLayout } from './App';
import { AdminLayout } from './admin/AdminLayout';
import { AdminOverviewPage } from './admin/AdminOverviewPage';
import { AdminUsersPage } from './admin/AdminUsersPage';
import { AdminSubscriptionsPage } from './admin/AdminSubscriptionsPage';
import { AdminPaymentsPage } from './admin/AdminPaymentsPage';
import { AdminPlansPage } from './admin/AdminPlansPage';
import { AdminAuditPage } from './admin/AdminAuditPage';
import { AdminLoginPage } from './admin/AdminLoginPage';
import { AuthPage } from './pages/AuthPage';
import { LandingPage } from './pages/LandingPage';
import { DashboardPage } from './pages/DashboardPage';
import { ApplicationsPage } from './pages/ApplicationsPage';
import { GetStartedPage } from './pages/GetStartedPage';
import { TrackerPage } from './pages/TrackerPage';
import { SettingsPage } from './pages/SettingsPage';
import { ProfilePage } from './pages/ProfilePage';
import { LegalPage } from './pages/LegalPage';
import { NotFoundPage } from './pages/NotFoundPage';
import { googleClientId } from './lib/googleAuth';
import './styles.css';
import './admin/admin.css';

const queryClient = new QueryClient();
const googleId = googleClientId();
const CODEX_CAREER_URL = 'https://codexcareer.com';

function RedirectToCodexCareer() {
  useEffect(() => {
    window.location.replace(CODEX_CAREER_URL);
  }, []);
  return null;
}

const app = (
  <QueryClientProvider client={queryClient}>
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/login" element={<AuthPage mode="login" />} />
        <Route path="/register" element={<AuthPage mode="register" />} />
        <Route path="/privacy" element={<LegalPage kind="privacy" />} />
        <Route path="/terms" element={<LegalPage kind="terms" />} />
        <Route path="/admin/login" element={<AdminLoginPage />} />
        <Route element={<AppLayout />}>
          <Route path="/dashboard" element={<DashboardPage />} />
          <Route path="/applications" element={<ApplicationsPage />} />
          <Route path="/get-extension" element={<GetStartedPage />} />
          <Route
            path="/get-started"
            element={<Navigate to="/get-extension" replace />}
          />
          <Route path="/browse" element={<RedirectToCodexCareer />} />
          <Route path="/settings" element={<SettingsPage />} />
          <Route path="/tracker" element={<TrackerPage />} />
          <Route path="/profile" element={<ProfilePage />} />
        </Route>
        <Route path="/admin" element={<AdminLayout />}>
          <Route index element={<AdminOverviewPage />} />
          <Route path="users" element={<AdminUsersPage />} />
          <Route path="subscriptions" element={<AdminSubscriptionsPage />} />
          <Route path="payments" element={<AdminPaymentsPage />} />
          <Route path="plans" element={<AdminPlansPage />} />
          <Route path="audit" element={<AdminAuditPage />} />
        </Route>
        <Route path="*" element={<NotFoundPage />} />
      </Routes>
    </BrowserRouter>
  </QueryClientProvider>
);

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    {googleId ? (
      <GoogleOAuthProvider clientId={googleId}>{app}</GoogleOAuthProvider>
    ) : (
      app
    )}
  </StrictMode>
);
