"use strict";
(() => {
  var __defProp = Object.defineProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };

  // ../node_modules/zod/v3/external.js
  var external_exports = {};
  __export(external_exports, {
    BRAND: () => BRAND,
    DIRTY: () => DIRTY,
    EMPTY_PATH: () => EMPTY_PATH,
    INVALID: () => INVALID,
    NEVER: () => NEVER,
    OK: () => OK,
    ParseStatus: () => ParseStatus,
    Schema: () => ZodType,
    ZodAny: () => ZodAny,
    ZodArray: () => ZodArray,
    ZodBigInt: () => ZodBigInt,
    ZodBoolean: () => ZodBoolean,
    ZodBranded: () => ZodBranded,
    ZodCatch: () => ZodCatch,
    ZodDate: () => ZodDate,
    ZodDefault: () => ZodDefault,
    ZodDiscriminatedUnion: () => ZodDiscriminatedUnion,
    ZodEffects: () => ZodEffects,
    ZodEnum: () => ZodEnum,
    ZodError: () => ZodError,
    ZodFirstPartyTypeKind: () => ZodFirstPartyTypeKind,
    ZodFunction: () => ZodFunction,
    ZodIntersection: () => ZodIntersection,
    ZodIssueCode: () => ZodIssueCode,
    ZodLazy: () => ZodLazy,
    ZodLiteral: () => ZodLiteral,
    ZodMap: () => ZodMap,
    ZodNaN: () => ZodNaN,
    ZodNativeEnum: () => ZodNativeEnum,
    ZodNever: () => ZodNever,
    ZodNull: () => ZodNull,
    ZodNullable: () => ZodNullable,
    ZodNumber: () => ZodNumber,
    ZodObject: () => ZodObject,
    ZodOptional: () => ZodOptional,
    ZodParsedType: () => ZodParsedType,
    ZodPipeline: () => ZodPipeline,
    ZodPromise: () => ZodPromise,
    ZodReadonly: () => ZodReadonly,
    ZodRecord: () => ZodRecord,
    ZodSchema: () => ZodType,
    ZodSet: () => ZodSet,
    ZodString: () => ZodString,
    ZodSymbol: () => ZodSymbol,
    ZodTransformer: () => ZodEffects,
    ZodTuple: () => ZodTuple,
    ZodType: () => ZodType,
    ZodUndefined: () => ZodUndefined,
    ZodUnion: () => ZodUnion,
    ZodUnknown: () => ZodUnknown,
    ZodVoid: () => ZodVoid,
    addIssueToContext: () => addIssueToContext,
    any: () => anyType,
    array: () => arrayType,
    bigint: () => bigIntType,
    boolean: () => booleanType,
    coerce: () => coerce,
    custom: () => custom,
    date: () => dateType,
    datetimeRegex: () => datetimeRegex,
    defaultErrorMap: () => en_default,
    discriminatedUnion: () => discriminatedUnionType,
    effect: () => effectsType,
    enum: () => enumType,
    function: () => functionType,
    getErrorMap: () => getErrorMap,
    getParsedType: () => getParsedType,
    instanceof: () => instanceOfType,
    intersection: () => intersectionType,
    isAborted: () => isAborted,
    isAsync: () => isAsync,
    isDirty: () => isDirty,
    isValid: () => isValid,
    late: () => late,
    lazy: () => lazyType,
    literal: () => literalType,
    makeIssue: () => makeIssue,
    map: () => mapType,
    nan: () => nanType,
    nativeEnum: () => nativeEnumType,
    never: () => neverType,
    null: () => nullType,
    nullable: () => nullableType,
    number: () => numberType,
    object: () => objectType,
    objectUtil: () => objectUtil,
    oboolean: () => oboolean,
    onumber: () => onumber,
    optional: () => optionalType,
    ostring: () => ostring,
    pipeline: () => pipelineType,
    preprocess: () => preprocessType,
    promise: () => promiseType,
    quotelessJson: () => quotelessJson,
    record: () => recordType,
    set: () => setType,
    setErrorMap: () => setErrorMap,
    strictObject: () => strictObjectType,
    string: () => stringType,
    symbol: () => symbolType,
    transformer: () => effectsType,
    tuple: () => tupleType,
    undefined: () => undefinedType,
    union: () => unionType,
    unknown: () => unknownType,
    util: () => util,
    void: () => voidType
  });

  // ../node_modules/zod/v3/helpers/util.js
  var util;
  (function(util2) {
    util2.assertEqual = (_) => {
    };
    function assertIs(_arg) {
    }
    util2.assertIs = assertIs;
    function assertNever(_x) {
      throw new Error();
    }
    util2.assertNever = assertNever;
    util2.arrayToEnum = (items) => {
      const obj = {};
      for (const item of items) {
        obj[item] = item;
      }
      return obj;
    };
    util2.getValidEnumValues = (obj) => {
      const validKeys = util2.objectKeys(obj).filter((k) => typeof obj[obj[k]] !== "number");
      const filtered = {};
      for (const k of validKeys) {
        filtered[k] = obj[k];
      }
      return util2.objectValues(filtered);
    };
    util2.objectValues = (obj) => {
      return util2.objectKeys(obj).map(function(e) {
        return obj[e];
      });
    };
    util2.objectKeys = typeof Object.keys === "function" ? (obj) => Object.keys(obj) : (object) => {
      const keys = [];
      for (const key in object) {
        if (Object.prototype.hasOwnProperty.call(object, key)) {
          keys.push(key);
        }
      }
      return keys;
    };
    util2.find = (arr, checker) => {
      for (const item of arr) {
        if (checker(item))
          return item;
      }
      return void 0;
    };
    util2.isInteger = typeof Number.isInteger === "function" ? (val) => Number.isInteger(val) : (val) => typeof val === "number" && Number.isFinite(val) && Math.floor(val) === val;
    function joinValues(array, separator = " | ") {
      return array.map((val) => typeof val === "string" ? `'${val}'` : val).join(separator);
    }
    util2.joinValues = joinValues;
    util2.jsonStringifyReplacer = (_, value) => {
      if (typeof value === "bigint") {
        return value.toString();
      }
      return value;
    };
  })(util || (util = {}));
  var objectUtil;
  (function(objectUtil2) {
    objectUtil2.mergeShapes = (first, second) => {
      return {
        ...first,
        ...second
        // second overwrites first
      };
    };
  })(objectUtil || (objectUtil = {}));
  var ZodParsedType = util.arrayToEnum([
    "string",
    "nan",
    "number",
    "integer",
    "float",
    "boolean",
    "date",
    "bigint",
    "symbol",
    "function",
    "undefined",
    "null",
    "array",
    "object",
    "unknown",
    "promise",
    "void",
    "never",
    "map",
    "set"
  ]);
  var getParsedType = (data) => {
    const t = typeof data;
    switch (t) {
      case "undefined":
        return ZodParsedType.undefined;
      case "string":
        return ZodParsedType.string;
      case "number":
        return Number.isNaN(data) ? ZodParsedType.nan : ZodParsedType.number;
      case "boolean":
        return ZodParsedType.boolean;
      case "function":
        return ZodParsedType.function;
      case "bigint":
        return ZodParsedType.bigint;
      case "symbol":
        return ZodParsedType.symbol;
      case "object":
        if (Array.isArray(data)) {
          return ZodParsedType.array;
        }
        if (data === null) {
          return ZodParsedType.null;
        }
        if (data.then && typeof data.then === "function" && data.catch && typeof data.catch === "function") {
          return ZodParsedType.promise;
        }
        if (typeof Map !== "undefined" && data instanceof Map) {
          return ZodParsedType.map;
        }
        if (typeof Set !== "undefined" && data instanceof Set) {
          return ZodParsedType.set;
        }
        if (typeof Date !== "undefined" && data instanceof Date) {
          return ZodParsedType.date;
        }
        return ZodParsedType.object;
      default:
        return ZodParsedType.unknown;
    }
  };

  // ../node_modules/zod/v3/ZodError.js
  var ZodIssueCode = util.arrayToEnum([
    "invalid_type",
    "invalid_literal",
    "custom",
    "invalid_union",
    "invalid_union_discriminator",
    "invalid_enum_value",
    "unrecognized_keys",
    "invalid_arguments",
    "invalid_return_type",
    "invalid_date",
    "invalid_string",
    "too_small",
    "too_big",
    "invalid_intersection_types",
    "not_multiple_of",
    "not_finite"
  ]);
  var quotelessJson = (obj) => {
    const json = JSON.stringify(obj, null, 2);
    return json.replace(/"([^"]+)":/g, "$1:");
  };
  var ZodError = class _ZodError extends Error {
    get errors() {
      return this.issues;
    }
    constructor(issues) {
      super();
      this.issues = [];
      this.addIssue = (sub) => {
        this.issues = [...this.issues, sub];
      };
      this.addIssues = (subs = []) => {
        this.issues = [...this.issues, ...subs];
      };
      const actualProto = new.target.prototype;
      if (Object.setPrototypeOf) {
        Object.setPrototypeOf(this, actualProto);
      } else {
        this.__proto__ = actualProto;
      }
      this.name = "ZodError";
      this.issues = issues;
    }
    format(_mapper) {
      const mapper = _mapper || function(issue) {
        return issue.message;
      };
      const fieldErrors = { _errors: [] };
      const processError = (error) => {
        for (const issue of error.issues) {
          if (issue.code === "invalid_union") {
            issue.unionErrors.map(processError);
          } else if (issue.code === "invalid_return_type") {
            processError(issue.returnTypeError);
          } else if (issue.code === "invalid_arguments") {
            processError(issue.argumentsError);
          } else if (issue.path.length === 0) {
            fieldErrors._errors.push(mapper(issue));
          } else {
            let curr = fieldErrors;
            let i = 0;
            while (i < issue.path.length) {
              const el = issue.path[i];
              const terminal = i === issue.path.length - 1;
              if (!terminal) {
                curr[el] = curr[el] || { _errors: [] };
              } else {
                curr[el] = curr[el] || { _errors: [] };
                curr[el]._errors.push(mapper(issue));
              }
              curr = curr[el];
              i++;
            }
          }
        }
      };
      processError(this);
      return fieldErrors;
    }
    static assert(value) {
      if (!(value instanceof _ZodError)) {
        throw new Error(`Not a ZodError: ${value}`);
      }
    }
    toString() {
      return this.message;
    }
    get message() {
      return JSON.stringify(this.issues, util.jsonStringifyReplacer, 2);
    }
    get isEmpty() {
      return this.issues.length === 0;
    }
    flatten(mapper = (issue) => issue.message) {
      const fieldErrors = {};
      const formErrors = [];
      for (const sub of this.issues) {
        if (sub.path.length > 0) {
          const firstEl = sub.path[0];
          fieldErrors[firstEl] = fieldErrors[firstEl] || [];
          fieldErrors[firstEl].push(mapper(sub));
        } else {
          formErrors.push(mapper(sub));
        }
      }
      return { formErrors, fieldErrors };
    }
    get formErrors() {
      return this.flatten();
    }
  };
  ZodError.create = (issues) => {
    const error = new ZodError(issues);
    return error;
  };

  // ../node_modules/zod/v3/locales/en.js
  var errorMap = (issue, _ctx) => {
    let message;
    switch (issue.code) {
      case ZodIssueCode.invalid_type:
        if (issue.received === ZodParsedType.undefined) {
          message = "Required";
        } else {
          message = `Expected ${issue.expected}, received ${issue.received}`;
        }
        break;
      case ZodIssueCode.invalid_literal:
        message = `Invalid literal value, expected ${JSON.stringify(issue.expected, util.jsonStringifyReplacer)}`;
        break;
      case ZodIssueCode.unrecognized_keys:
        message = `Unrecognized key(s) in object: ${util.joinValues(issue.keys, ", ")}`;
        break;
      case ZodIssueCode.invalid_union:
        message = `Invalid input`;
        break;
      case ZodIssueCode.invalid_union_discriminator:
        message = `Invalid discriminator value. Expected ${util.joinValues(issue.options)}`;
        break;
      case ZodIssueCode.invalid_enum_value:
        message = `Invalid enum value. Expected ${util.joinValues(issue.options)}, received '${issue.received}'`;
        break;
      case ZodIssueCode.invalid_arguments:
        message = `Invalid function arguments`;
        break;
      case ZodIssueCode.invalid_return_type:
        message = `Invalid function return type`;
        break;
      case ZodIssueCode.invalid_date:
        message = `Invalid date`;
        break;
      case ZodIssueCode.invalid_string:
        if (typeof issue.validation === "object") {
          if ("includes" in issue.validation) {
            message = `Invalid input: must include "${issue.validation.includes}"`;
            if (typeof issue.validation.position === "number") {
              message = `${message} at one or more positions greater than or equal to ${issue.validation.position}`;
            }
          } else if ("startsWith" in issue.validation) {
            message = `Invalid input: must start with "${issue.validation.startsWith}"`;
          } else if ("endsWith" in issue.validation) {
            message = `Invalid input: must end with "${issue.validation.endsWith}"`;
          } else {
            util.assertNever(issue.validation);
          }
        } else if (issue.validation !== "regex") {
          message = `Invalid ${issue.validation}`;
        } else {
          message = "Invalid";
        }
        break;
      case ZodIssueCode.too_small:
        if (issue.type === "array")
          message = `Array must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `more than`} ${issue.minimum} element(s)`;
        else if (issue.type === "string")
          message = `String must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `over`} ${issue.minimum} character(s)`;
        else if (issue.type === "number")
          message = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
        else if (issue.type === "bigint")
          message = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
        else if (issue.type === "date")
          message = `Date must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${new Date(Number(issue.minimum))}`;
        else
          message = "Invalid input";
        break;
      case ZodIssueCode.too_big:
        if (issue.type === "array")
          message = `Array must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `less than`} ${issue.maximum} element(s)`;
        else if (issue.type === "string")
          message = `String must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `under`} ${issue.maximum} character(s)`;
        else if (issue.type === "number")
          message = `Number must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
        else if (issue.type === "bigint")
          message = `BigInt must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
        else if (issue.type === "date")
          message = `Date must be ${issue.exact ? `exactly` : issue.inclusive ? `smaller than or equal to` : `smaller than`} ${new Date(Number(issue.maximum))}`;
        else
          message = "Invalid input";
        break;
      case ZodIssueCode.custom:
        message = `Invalid input`;
        break;
      case ZodIssueCode.invalid_intersection_types:
        message = `Intersection results could not be merged`;
        break;
      case ZodIssueCode.not_multiple_of:
        message = `Number must be a multiple of ${issue.multipleOf}`;
        break;
      case ZodIssueCode.not_finite:
        message = "Number must be finite";
        break;
      default:
        message = _ctx.defaultError;
        util.assertNever(issue);
    }
    return { message };
  };
  var en_default = errorMap;

  // ../node_modules/zod/v3/errors.js
  var overrideErrorMap = en_default;
  function setErrorMap(map) {
    overrideErrorMap = map;
  }
  function getErrorMap() {
    return overrideErrorMap;
  }

  // ../node_modules/zod/v3/helpers/parseUtil.js
  var makeIssue = (params) => {
    const { data, path, errorMaps, issueData } = params;
    const fullPath = [...path, ...issueData.path || []];
    const fullIssue = {
      ...issueData,
      path: fullPath
    };
    if (issueData.message !== void 0) {
      return {
        ...issueData,
        path: fullPath,
        message: issueData.message
      };
    }
    let errorMessage = "";
    const maps = errorMaps.filter((m) => !!m).slice().reverse();
    for (const map of maps) {
      errorMessage = map(fullIssue, { data, defaultError: errorMessage }).message;
    }
    return {
      ...issueData,
      path: fullPath,
      message: errorMessage
    };
  };
  var EMPTY_PATH = [];
  function addIssueToContext(ctx, issueData) {
    const overrideMap = getErrorMap();
    const issue = makeIssue({
      issueData,
      data: ctx.data,
      path: ctx.path,
      errorMaps: [
        ctx.common.contextualErrorMap,
        // contextual error map is first priority
        ctx.schemaErrorMap,
        // then schema-bound map if available
        overrideMap,
        // then global override map
        overrideMap === en_default ? void 0 : en_default
        // then global default map
      ].filter((x) => !!x)
    });
    ctx.common.issues.push(issue);
  }
  var ParseStatus = class _ParseStatus {
    constructor() {
      this.value = "valid";
    }
    dirty() {
      if (this.value === "valid")
        this.value = "dirty";
    }
    abort() {
      if (this.value !== "aborted")
        this.value = "aborted";
    }
    static mergeArray(status, results) {
      const arrayValue = [];
      for (const s of results) {
        if (s.status === "aborted")
          return INVALID;
        if (s.status === "dirty")
          status.dirty();
        arrayValue.push(s.value);
      }
      return { status: status.value, value: arrayValue };
    }
    static async mergeObjectAsync(status, pairs) {
      const syncPairs = [];
      for (const pair of pairs) {
        const key = await pair.key;
        const value = await pair.value;
        syncPairs.push({
          key,
          value
        });
      }
      return _ParseStatus.mergeObjectSync(status, syncPairs);
    }
    static mergeObjectSync(status, pairs) {
      const finalObject = {};
      for (const pair of pairs) {
        const { key, value } = pair;
        if (key.status === "aborted")
          return INVALID;
        if (value.status === "aborted")
          return INVALID;
        if (key.status === "dirty")
          status.dirty();
        if (value.status === "dirty")
          status.dirty();
        if (key.value !== "__proto__" && (typeof value.value !== "undefined" || pair.alwaysSet)) {
          finalObject[key.value] = value.value;
        }
      }
      return { status: status.value, value: finalObject };
    }
  };
  var INVALID = Object.freeze({
    status: "aborted"
  });
  var DIRTY = (value) => ({ status: "dirty", value });
  var OK = (value) => ({ status: "valid", value });
  var isAborted = (x) => x.status === "aborted";
  var isDirty = (x) => x.status === "dirty";
  var isValid = (x) => x.status === "valid";
  var isAsync = (x) => typeof Promise !== "undefined" && x instanceof Promise;

  // ../node_modules/zod/v3/helpers/errorUtil.js
  var errorUtil;
  (function(errorUtil2) {
    errorUtil2.errToObj = (message) => typeof message === "string" ? { message } : message || {};
    errorUtil2.toString = (message) => typeof message === "string" ? message : message?.message;
  })(errorUtil || (errorUtil = {}));

  // ../node_modules/zod/v3/types.js
  var ParseInputLazyPath = class {
    constructor(parent, value, path, key) {
      this._cachedPath = [];
      this.parent = parent;
      this.data = value;
      this._path = path;
      this._key = key;
    }
    get path() {
      if (!this._cachedPath.length) {
        if (Array.isArray(this._key)) {
          this._cachedPath.push(...this._path, ...this._key);
        } else {
          this._cachedPath.push(...this._path, this._key);
        }
      }
      return this._cachedPath;
    }
  };
  var handleResult = (ctx, result) => {
    if (isValid(result)) {
      return { success: true, data: result.value };
    } else {
      if (!ctx.common.issues.length) {
        throw new Error("Validation failed but no issues detected.");
      }
      return {
        success: false,
        get error() {
          if (this._error)
            return this._error;
          const error = new ZodError(ctx.common.issues);
          this._error = error;
          return this._error;
        }
      };
    }
  };
  function processCreateParams(params) {
    if (!params)
      return {};
    const { errorMap: errorMap2, invalid_type_error, required_error, description } = params;
    if (errorMap2 && (invalid_type_error || required_error)) {
      throw new Error(`Can't use "invalid_type_error" or "required_error" in conjunction with custom error map.`);
    }
    if (errorMap2)
      return { errorMap: errorMap2, description };
    const customMap = (iss, ctx) => {
      const { message } = params;
      if (iss.code === "invalid_enum_value") {
        return { message: message ?? ctx.defaultError };
      }
      if (typeof ctx.data === "undefined") {
        return { message: message ?? required_error ?? ctx.defaultError };
      }
      if (iss.code !== "invalid_type")
        return { message: ctx.defaultError };
      return { message: message ?? invalid_type_error ?? ctx.defaultError };
    };
    return { errorMap: customMap, description };
  }
  var ZodType = class {
    get description() {
      return this._def.description;
    }
    _getType(input) {
      return getParsedType(input.data);
    }
    _getOrReturnCtx(input, ctx) {
      return ctx || {
        common: input.parent.common,
        data: input.data,
        parsedType: getParsedType(input.data),
        schemaErrorMap: this._def.errorMap,
        path: input.path,
        parent: input.parent
      };
    }
    _processInputParams(input) {
      return {
        status: new ParseStatus(),
        ctx: {
          common: input.parent.common,
          data: input.data,
          parsedType: getParsedType(input.data),
          schemaErrorMap: this._def.errorMap,
          path: input.path,
          parent: input.parent
        }
      };
    }
    _parseSync(input) {
      const result = this._parse(input);
      if (isAsync(result)) {
        throw new Error("Synchronous parse encountered promise.");
      }
      return result;
    }
    _parseAsync(input) {
      const result = this._parse(input);
      return Promise.resolve(result);
    }
    parse(data, params) {
      const result = this.safeParse(data, params);
      if (result.success)
        return result.data;
      throw result.error;
    }
    safeParse(data, params) {
      const ctx = {
        common: {
          issues: [],
          async: params?.async ?? false,
          contextualErrorMap: params?.errorMap
        },
        path: params?.path || [],
        schemaErrorMap: this._def.errorMap,
        parent: null,
        data,
        parsedType: getParsedType(data)
      };
      const result = this._parseSync({ data, path: ctx.path, parent: ctx });
      return handleResult(ctx, result);
    }
    "~validate"(data) {
      const ctx = {
        common: {
          issues: [],
          async: !!this["~standard"].async
        },
        path: [],
        schemaErrorMap: this._def.errorMap,
        parent: null,
        data,
        parsedType: getParsedType(data)
      };
      if (!this["~standard"].async) {
        try {
          const result = this._parseSync({ data, path: [], parent: ctx });
          return isValid(result) ? {
            value: result.value
          } : {
            issues: ctx.common.issues
          };
        } catch (err) {
          if (err?.message?.toLowerCase()?.includes("encountered")) {
            this["~standard"].async = true;
          }
          ctx.common = {
            issues: [],
            async: true
          };
        }
      }
      return this._parseAsync({ data, path: [], parent: ctx }).then((result) => isValid(result) ? {
        value: result.value
      } : {
        issues: ctx.common.issues
      });
    }
    async parseAsync(data, params) {
      const result = await this.safeParseAsync(data, params);
      if (result.success)
        return result.data;
      throw result.error;
    }
    async safeParseAsync(data, params) {
      const ctx = {
        common: {
          issues: [],
          contextualErrorMap: params?.errorMap,
          async: true
        },
        path: params?.path || [],
        schemaErrorMap: this._def.errorMap,
        parent: null,
        data,
        parsedType: getParsedType(data)
      };
      const maybeAsyncResult = this._parse({ data, path: ctx.path, parent: ctx });
      const result = await (isAsync(maybeAsyncResult) ? maybeAsyncResult : Promise.resolve(maybeAsyncResult));
      return handleResult(ctx, result);
    }
    refine(check, message) {
      const getIssueProperties = (val) => {
        if (typeof message === "string" || typeof message === "undefined") {
          return { message };
        } else if (typeof message === "function") {
          return message(val);
        } else {
          return message;
        }
      };
      return this._refinement((val, ctx) => {
        const result = check(val);
        const setError = () => ctx.addIssue({
          code: ZodIssueCode.custom,
          ...getIssueProperties(val)
        });
        if (typeof Promise !== "undefined" && result instanceof Promise) {
          return result.then((data) => {
            if (!data) {
              setError();
              return false;
            } else {
              return true;
            }
          });
        }
        if (!result) {
          setError();
          return false;
        } else {
          return true;
        }
      });
    }
    refinement(check, refinementData) {
      return this._refinement((val, ctx) => {
        if (!check(val)) {
          ctx.addIssue(typeof refinementData === "function" ? refinementData(val, ctx) : refinementData);
          return false;
        } else {
          return true;
        }
      });
    }
    _refinement(refinement) {
      return new ZodEffects({
        schema: this,
        typeName: ZodFirstPartyTypeKind.ZodEffects,
        effect: { type: "refinement", refinement }
      });
    }
    superRefine(refinement) {
      return this._refinement(refinement);
    }
    constructor(def) {
      this.spa = this.safeParseAsync;
      this._def = def;
      this.parse = this.parse.bind(this);
      this.safeParse = this.safeParse.bind(this);
      this.parseAsync = this.parseAsync.bind(this);
      this.safeParseAsync = this.safeParseAsync.bind(this);
      this.spa = this.spa.bind(this);
      this.refine = this.refine.bind(this);
      this.refinement = this.refinement.bind(this);
      this.superRefine = this.superRefine.bind(this);
      this.optional = this.optional.bind(this);
      this.nullable = this.nullable.bind(this);
      this.nullish = this.nullish.bind(this);
      this.array = this.array.bind(this);
      this.promise = this.promise.bind(this);
      this.or = this.or.bind(this);
      this.and = this.and.bind(this);
      this.transform = this.transform.bind(this);
      this.brand = this.brand.bind(this);
      this.default = this.default.bind(this);
      this.catch = this.catch.bind(this);
      this.describe = this.describe.bind(this);
      this.pipe = this.pipe.bind(this);
      this.readonly = this.readonly.bind(this);
      this.isNullable = this.isNullable.bind(this);
      this.isOptional = this.isOptional.bind(this);
      this["~standard"] = {
        version: 1,
        vendor: "zod",
        validate: (data) => this["~validate"](data)
      };
    }
    optional() {
      return ZodOptional.create(this, this._def);
    }
    nullable() {
      return ZodNullable.create(this, this._def);
    }
    nullish() {
      return this.nullable().optional();
    }
    array() {
      return ZodArray.create(this);
    }
    promise() {
      return ZodPromise.create(this, this._def);
    }
    or(option) {
      return ZodUnion.create([this, option], this._def);
    }
    and(incoming) {
      return ZodIntersection.create(this, incoming, this._def);
    }
    transform(transform) {
      return new ZodEffects({
        ...processCreateParams(this._def),
        schema: this,
        typeName: ZodFirstPartyTypeKind.ZodEffects,
        effect: { type: "transform", transform }
      });
    }
    default(def) {
      const defaultValueFunc = typeof def === "function" ? def : () => def;
      return new ZodDefault({
        ...processCreateParams(this._def),
        innerType: this,
        defaultValue: defaultValueFunc,
        typeName: ZodFirstPartyTypeKind.ZodDefault
      });
    }
    brand() {
      return new ZodBranded({
        typeName: ZodFirstPartyTypeKind.ZodBranded,
        type: this,
        ...processCreateParams(this._def)
      });
    }
    catch(def) {
      const catchValueFunc = typeof def === "function" ? def : () => def;
      return new ZodCatch({
        ...processCreateParams(this._def),
        innerType: this,
        catchValue: catchValueFunc,
        typeName: ZodFirstPartyTypeKind.ZodCatch
      });
    }
    describe(description) {
      const This = this.constructor;
      return new This({
        ...this._def,
        description
      });
    }
    pipe(target) {
      return ZodPipeline.create(this, target);
    }
    readonly() {
      return ZodReadonly.create(this);
    }
    isOptional() {
      return this.safeParse(void 0).success;
    }
    isNullable() {
      return this.safeParse(null).success;
    }
  };
  var cuidRegex = /^c[^\s-]{8,}$/i;
  var cuid2Regex = /^[0-9a-z]+$/;
  var ulidRegex = /^[0-9A-HJKMNP-TV-Z]{26}$/i;
  var uuidRegex = /^[0-9a-fA-F]{8}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{12}$/i;
  var nanoidRegex = /^[a-z0-9_-]{21}$/i;
  var jwtRegex = /^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]*$/;
  var durationRegex = /^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/;
  var emailRegex = /^(?!\.)(?!.*\.\.)([A-Z0-9_'+\-\.]*)[A-Z0-9_+-]@([A-Z0-9][A-Z0-9\-]*\.)+[A-Z]{2,}$/i;
  var _emojiRegex = `^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$`;
  var emojiRegex;
  var ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/;
  var ipv4CidrRegex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/(3[0-2]|[12]?[0-9])$/;
  var ipv6Regex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))$/;
  var ipv6CidrRegex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/;
  var base64Regex = /^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/;
  var base64urlRegex = /^([0-9a-zA-Z-_]{4})*(([0-9a-zA-Z-_]{2}(==)?)|([0-9a-zA-Z-_]{3}(=)?))?$/;
  var dateRegexSource = `((\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-((0[13578]|1[02])-(0[1-9]|[12]\\d|3[01])|(0[469]|11)-(0[1-9]|[12]\\d|30)|(02)-(0[1-9]|1\\d|2[0-8])))`;
  var dateRegex = new RegExp(`^${dateRegexSource}$`);
  function timeRegexSource(args) {
    let secondsRegexSource = `[0-5]\\d`;
    if (args.precision) {
      secondsRegexSource = `${secondsRegexSource}\\.\\d{${args.precision}}`;
    } else if (args.precision == null) {
      secondsRegexSource = `${secondsRegexSource}(\\.\\d+)?`;
    }
    const secondsQuantifier = args.precision ? "+" : "?";
    return `([01]\\d|2[0-3]):[0-5]\\d(:${secondsRegexSource})${secondsQuantifier}`;
  }
  function timeRegex(args) {
    return new RegExp(`^${timeRegexSource(args)}$`);
  }
  function datetimeRegex(args) {
    let regex = `${dateRegexSource}T${timeRegexSource(args)}`;
    const opts = [];
    opts.push(args.local ? `Z?` : `Z`);
    if (args.offset)
      opts.push(`([+-]\\d{2}:?\\d{2})`);
    regex = `${regex}(${opts.join("|")})`;
    return new RegExp(`^${regex}$`);
  }
  function isValidIP(ip, version) {
    if ((version === "v4" || !version) && ipv4Regex.test(ip)) {
      return true;
    }
    if ((version === "v6" || !version) && ipv6Regex.test(ip)) {
      return true;
    }
    return false;
  }
  function isValidJWT(jwt, alg) {
    if (!jwtRegex.test(jwt))
      return false;
    try {
      const [header] = jwt.split(".");
      if (!header)
        return false;
      const base64 = header.replace(/-/g, "+").replace(/_/g, "/").padEnd(header.length + (4 - header.length % 4) % 4, "=");
      const decoded = JSON.parse(atob(base64));
      if (typeof decoded !== "object" || decoded === null)
        return false;
      if ("typ" in decoded && decoded?.typ !== "JWT")
        return false;
      if (!decoded.alg)
        return false;
      if (alg && decoded.alg !== alg)
        return false;
      return true;
    } catch {
      return false;
    }
  }
  function isValidCidr(ip, version) {
    if ((version === "v4" || !version) && ipv4CidrRegex.test(ip)) {
      return true;
    }
    if ((version === "v6" || !version) && ipv6CidrRegex.test(ip)) {
      return true;
    }
    return false;
  }
  var ZodString = class _ZodString extends ZodType {
    _parse(input) {
      if (this._def.coerce) {
        input.data = String(input.data);
      }
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.string) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.string,
          received: ctx2.parsedType
        });
        return INVALID;
      }
      const status = new ParseStatus();
      let ctx = void 0;
      for (const check of this._def.checks) {
        if (check.kind === "min") {
          if (input.data.length < check.value) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              minimum: check.value,
              type: "string",
              inclusive: true,
              exact: false,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "max") {
          if (input.data.length > check.value) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              maximum: check.value,
              type: "string",
              inclusive: true,
              exact: false,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "length") {
          const tooBig = input.data.length > check.value;
          const tooSmall = input.data.length < check.value;
          if (tooBig || tooSmall) {
            ctx = this._getOrReturnCtx(input, ctx);
            if (tooBig) {
              addIssueToContext(ctx, {
                code: ZodIssueCode.too_big,
                maximum: check.value,
                type: "string",
                inclusive: true,
                exact: true,
                message: check.message
              });
            } else if (tooSmall) {
              addIssueToContext(ctx, {
                code: ZodIssueCode.too_small,
                minimum: check.value,
                type: "string",
                inclusive: true,
                exact: true,
                message: check.message
              });
            }
            status.dirty();
          }
        } else if (check.kind === "email") {
          if (!emailRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "email",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "emoji") {
          if (!emojiRegex) {
            emojiRegex = new RegExp(_emojiRegex, "u");
          }
          if (!emojiRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "emoji",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "uuid") {
          if (!uuidRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "uuid",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "nanoid") {
          if (!nanoidRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "nanoid",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "cuid") {
          if (!cuidRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "cuid",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "cuid2") {
          if (!cuid2Regex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "cuid2",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "ulid") {
          if (!ulidRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "ulid",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "url") {
          try {
            new URL(input.data);
          } catch {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "url",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "regex") {
          check.regex.lastIndex = 0;
          const testResult = check.regex.test(input.data);
          if (!testResult) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "regex",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "trim") {
          input.data = input.data.trim();
        } else if (check.kind === "includes") {
          if (!input.data.includes(check.value, check.position)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: { includes: check.value, position: check.position },
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "toLowerCase") {
          input.data = input.data.toLowerCase();
        } else if (check.kind === "toUpperCase") {
          input.data = input.data.toUpperCase();
        } else if (check.kind === "startsWith") {
          if (!input.data.startsWith(check.value)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: { startsWith: check.value },
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "endsWith") {
          if (!input.data.endsWith(check.value)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: { endsWith: check.value },
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "datetime") {
          const regex = datetimeRegex(check);
          if (!regex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: "datetime",
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "date") {
          const regex = dateRegex;
          if (!regex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: "date",
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "time") {
          const regex = timeRegex(check);
          if (!regex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: "time",
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "duration") {
          if (!durationRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "duration",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "ip") {
          if (!isValidIP(input.data, check.version)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "ip",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "jwt") {
          if (!isValidJWT(input.data, check.alg)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "jwt",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "cidr") {
          if (!isValidCidr(input.data, check.version)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "cidr",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "base64") {
          if (!base64Regex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "base64",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "base64url") {
          if (!base64urlRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "base64url",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else {
          util.assertNever(check);
        }
      }
      return { status: status.value, value: input.data };
    }
    _regex(regex, validation, message) {
      return this.refinement((data) => regex.test(data), {
        validation,
        code: ZodIssueCode.invalid_string,
        ...errorUtil.errToObj(message)
      });
    }
    _addCheck(check) {
      return new _ZodString({
        ...this._def,
        checks: [...this._def.checks, check]
      });
    }
    email(message) {
      return this._addCheck({ kind: "email", ...errorUtil.errToObj(message) });
    }
    url(message) {
      return this._addCheck({ kind: "url", ...errorUtil.errToObj(message) });
    }
    emoji(message) {
      return this._addCheck({ kind: "emoji", ...errorUtil.errToObj(message) });
    }
    uuid(message) {
      return this._addCheck({ kind: "uuid", ...errorUtil.errToObj(message) });
    }
    nanoid(message) {
      return this._addCheck({ kind: "nanoid", ...errorUtil.errToObj(message) });
    }
    cuid(message) {
      return this._addCheck({ kind: "cuid", ...errorUtil.errToObj(message) });
    }
    cuid2(message) {
      return this._addCheck({ kind: "cuid2", ...errorUtil.errToObj(message) });
    }
    ulid(message) {
      return this._addCheck({ kind: "ulid", ...errorUtil.errToObj(message) });
    }
    base64(message) {
      return this._addCheck({ kind: "base64", ...errorUtil.errToObj(message) });
    }
    base64url(message) {
      return this._addCheck({
        kind: "base64url",
        ...errorUtil.errToObj(message)
      });
    }
    jwt(options) {
      return this._addCheck({ kind: "jwt", ...errorUtil.errToObj(options) });
    }
    ip(options) {
      return this._addCheck({ kind: "ip", ...errorUtil.errToObj(options) });
    }
    cidr(options) {
      return this._addCheck({ kind: "cidr", ...errorUtil.errToObj(options) });
    }
    datetime(options) {
      if (typeof options === "string") {
        return this._addCheck({
          kind: "datetime",
          precision: null,
          offset: false,
          local: false,
          message: options
        });
      }
      return this._addCheck({
        kind: "datetime",
        precision: typeof options?.precision === "undefined" ? null : options?.precision,
        offset: options?.offset ?? false,
        local: options?.local ?? false,
        ...errorUtil.errToObj(options?.message)
      });
    }
    date(message) {
      return this._addCheck({ kind: "date", message });
    }
    time(options) {
      if (typeof options === "string") {
        return this._addCheck({
          kind: "time",
          precision: null,
          message: options
        });
      }
      return this._addCheck({
        kind: "time",
        precision: typeof options?.precision === "undefined" ? null : options?.precision,
        ...errorUtil.errToObj(options?.message)
      });
    }
    duration(message) {
      return this._addCheck({ kind: "duration", ...errorUtil.errToObj(message) });
    }
    regex(regex, message) {
      return this._addCheck({
        kind: "regex",
        regex,
        ...errorUtil.errToObj(message)
      });
    }
    includes(value, options) {
      return this._addCheck({
        kind: "includes",
        value,
        position: options?.position,
        ...errorUtil.errToObj(options?.message)
      });
    }
    startsWith(value, message) {
      return this._addCheck({
        kind: "startsWith",
        value,
        ...errorUtil.errToObj(message)
      });
    }
    endsWith(value, message) {
      return this._addCheck({
        kind: "endsWith",
        value,
        ...errorUtil.errToObj(message)
      });
    }
    min(minLength, message) {
      return this._addCheck({
        kind: "min",
        value: minLength,
        ...errorUtil.errToObj(message)
      });
    }
    max(maxLength, message) {
      return this._addCheck({
        kind: "max",
        value: maxLength,
        ...errorUtil.errToObj(message)
      });
    }
    length(len, message) {
      return this._addCheck({
        kind: "length",
        value: len,
        ...errorUtil.errToObj(message)
      });
    }
    /**
     * Equivalent to `.min(1)`
     */
    nonempty(message) {
      return this.min(1, errorUtil.errToObj(message));
    }
    trim() {
      return new _ZodString({
        ...this._def,
        checks: [...this._def.checks, { kind: "trim" }]
      });
    }
    toLowerCase() {
      return new _ZodString({
        ...this._def,
        checks: [...this._def.checks, { kind: "toLowerCase" }]
      });
    }
    toUpperCase() {
      return new _ZodString({
        ...this._def,
        checks: [...this._def.checks, { kind: "toUpperCase" }]
      });
    }
    get isDatetime() {
      return !!this._def.checks.find((ch) => ch.kind === "datetime");
    }
    get isDate() {
      return !!this._def.checks.find((ch) => ch.kind === "date");
    }
    get isTime() {
      return !!this._def.checks.find((ch) => ch.kind === "time");
    }
    get isDuration() {
      return !!this._def.checks.find((ch) => ch.kind === "duration");
    }
    get isEmail() {
      return !!this._def.checks.find((ch) => ch.kind === "email");
    }
    get isURL() {
      return !!this._def.checks.find((ch) => ch.kind === "url");
    }
    get isEmoji() {
      return !!this._def.checks.find((ch) => ch.kind === "emoji");
    }
    get isUUID() {
      return !!this._def.checks.find((ch) => ch.kind === "uuid");
    }
    get isNANOID() {
      return !!this._def.checks.find((ch) => ch.kind === "nanoid");
    }
    get isCUID() {
      return !!this._def.checks.find((ch) => ch.kind === "cuid");
    }
    get isCUID2() {
      return !!this._def.checks.find((ch) => ch.kind === "cuid2");
    }
    get isULID() {
      return !!this._def.checks.find((ch) => ch.kind === "ulid");
    }
    get isIP() {
      return !!this._def.checks.find((ch) => ch.kind === "ip");
    }
    get isCIDR() {
      return !!this._def.checks.find((ch) => ch.kind === "cidr");
    }
    get isBase64() {
      return !!this._def.checks.find((ch) => ch.kind === "base64");
    }
    get isBase64url() {
      return !!this._def.checks.find((ch) => ch.kind === "base64url");
    }
    get minLength() {
      let min = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "min") {
          if (min === null || ch.value > min)
            min = ch.value;
        }
      }
      return min;
    }
    get maxLength() {
      let max = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "max") {
          if (max === null || ch.value < max)
            max = ch.value;
        }
      }
      return max;
    }
  };
  ZodString.create = (params) => {
    return new ZodString({
      checks: [],
      typeName: ZodFirstPartyTypeKind.ZodString,
      coerce: params?.coerce ?? false,
      ...processCreateParams(params)
    });
  };
  function floatSafeRemainder(val, step) {
    const valDecCount = (val.toString().split(".")[1] || "").length;
    const stepDecCount = (step.toString().split(".")[1] || "").length;
    const decCount = valDecCount > stepDecCount ? valDecCount : stepDecCount;
    const valInt = Number.parseInt(val.toFixed(decCount).replace(".", ""));
    const stepInt = Number.parseInt(step.toFixed(decCount).replace(".", ""));
    return valInt % stepInt / 10 ** decCount;
  }
  var ZodNumber = class _ZodNumber extends ZodType {
    constructor() {
      super(...arguments);
      this.min = this.gte;
      this.max = this.lte;
      this.step = this.multipleOf;
    }
    _parse(input) {
      if (this._def.coerce) {
        input.data = Number(input.data);
      }
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.number) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.number,
          received: ctx2.parsedType
        });
        return INVALID;
      }
      let ctx = void 0;
      const status = new ParseStatus();
      for (const check of this._def.checks) {
        if (check.kind === "int") {
          if (!util.isInteger(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_type,
              expected: "integer",
              received: "float",
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "min") {
          const tooSmall = check.inclusive ? input.data < check.value : input.data <= check.value;
          if (tooSmall) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              minimum: check.value,
              type: "number",
              inclusive: check.inclusive,
              exact: false,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "max") {
          const tooBig = check.inclusive ? input.data > check.value : input.data >= check.value;
          if (tooBig) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              maximum: check.value,
              type: "number",
              inclusive: check.inclusive,
              exact: false,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "multipleOf") {
          if (floatSafeRemainder(input.data, check.value) !== 0) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.not_multiple_of,
              multipleOf: check.value,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "finite") {
          if (!Number.isFinite(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.not_finite,
              message: check.message
            });
            status.dirty();
          }
        } else {
          util.assertNever(check);
        }
      }
      return { status: status.value, value: input.data };
    }
    gte(value, message) {
      return this.setLimit("min", value, true, errorUtil.toString(message));
    }
    gt(value, message) {
      return this.setLimit("min", value, false, errorUtil.toString(message));
    }
    lte(value, message) {
      return this.setLimit("max", value, true, errorUtil.toString(message));
    }
    lt(value, message) {
      return this.setLimit("max", value, false, errorUtil.toString(message));
    }
    setLimit(kind, value, inclusive, message) {
      return new _ZodNumber({
        ...this._def,
        checks: [
          ...this._def.checks,
          {
            kind,
            value,
            inclusive,
            message: errorUtil.toString(message)
          }
        ]
      });
    }
    _addCheck(check) {
      return new _ZodNumber({
        ...this._def,
        checks: [...this._def.checks, check]
      });
    }
    int(message) {
      return this._addCheck({
        kind: "int",
        message: errorUtil.toString(message)
      });
    }
    positive(message) {
      return this._addCheck({
        kind: "min",
        value: 0,
        inclusive: false,
        message: errorUtil.toString(message)
      });
    }
    negative(message) {
      return this._addCheck({
        kind: "max",
        value: 0,
        inclusive: false,
        message: errorUtil.toString(message)
      });
    }
    nonpositive(message) {
      return this._addCheck({
        kind: "max",
        value: 0,
        inclusive: true,
        message: errorUtil.toString(message)
      });
    }
    nonnegative(message) {
      return this._addCheck({
        kind: "min",
        value: 0,
        inclusive: true,
        message: errorUtil.toString(message)
      });
    }
    multipleOf(value, message) {
      return this._addCheck({
        kind: "multipleOf",
        value,
        message: errorUtil.toString(message)
      });
    }
    finite(message) {
      return this._addCheck({
        kind: "finite",
        message: errorUtil.toString(message)
      });
    }
    safe(message) {
      return this._addCheck({
        kind: "min",
        inclusive: true,
        value: Number.MIN_SAFE_INTEGER,
        message: errorUtil.toString(message)
      })._addCheck({
        kind: "max",
        inclusive: true,
        value: Number.MAX_SAFE_INTEGER,
        message: errorUtil.toString(message)
      });
    }
    get minValue() {
      let min = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "min") {
          if (min === null || ch.value > min)
            min = ch.value;
        }
      }
      return min;
    }
    get maxValue() {
      let max = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "max") {
          if (max === null || ch.value < max)
            max = ch.value;
        }
      }
      return max;
    }
    get isInt() {
      return !!this._def.checks.find((ch) => ch.kind === "int" || ch.kind === "multipleOf" && util.isInteger(ch.value));
    }
    get isFinite() {
      let max = null;
      let min = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "finite" || ch.kind === "int" || ch.kind === "multipleOf") {
          return true;
        } else if (ch.kind === "min") {
          if (min === null || ch.value > min)
            min = ch.value;
        } else if (ch.kind === "max") {
          if (max === null || ch.value < max)
            max = ch.value;
        }
      }
      return Number.isFinite(min) && Number.isFinite(max);
    }
  };
  ZodNumber.create = (params) => {
    return new ZodNumber({
      checks: [],
      typeName: ZodFirstPartyTypeKind.ZodNumber,
      coerce: params?.coerce || false,
      ...processCreateParams(params)
    });
  };
  var ZodBigInt = class _ZodBigInt extends ZodType {
    constructor() {
      super(...arguments);
      this.min = this.gte;
      this.max = this.lte;
    }
    _parse(input) {
      if (this._def.coerce) {
        try {
          input.data = BigInt(input.data);
        } catch {
          return this._getInvalidInput(input);
        }
      }
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.bigint) {
        return this._getInvalidInput(input);
      }
      let ctx = void 0;
      const status = new ParseStatus();
      for (const check of this._def.checks) {
        if (check.kind === "min") {
          const tooSmall = check.inclusive ? input.data < check.value : input.data <= check.value;
          if (tooSmall) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              type: "bigint",
              minimum: check.value,
              inclusive: check.inclusive,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "max") {
          const tooBig = check.inclusive ? input.data > check.value : input.data >= check.value;
          if (tooBig) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              type: "bigint",
              maximum: check.value,
              inclusive: check.inclusive,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "multipleOf") {
          if (input.data % check.value !== BigInt(0)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.not_multiple_of,
              multipleOf: check.value,
              message: check.message
            });
            status.dirty();
          }
        } else {
          util.assertNever(check);
        }
      }
      return { status: status.value, value: input.data };
    }
    _getInvalidInput(input) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.bigint,
        received: ctx.parsedType
      });
      return INVALID;
    }
    gte(value, message) {
      return this.setLimit("min", value, true, errorUtil.toString(message));
    }
    gt(value, message) {
      return this.setLimit("min", value, false, errorUtil.toString(message));
    }
    lte(value, message) {
      return this.setLimit("max", value, true, errorUtil.toString(message));
    }
    lt(value, message) {
      return this.setLimit("max", value, false, errorUtil.toString(message));
    }
    setLimit(kind, value, inclusive, message) {
      return new _ZodBigInt({
        ...this._def,
        checks: [
          ...this._def.checks,
          {
            kind,
            value,
            inclusive,
            message: errorUtil.toString(message)
          }
        ]
      });
    }
    _addCheck(check) {
      return new _ZodBigInt({
        ...this._def,
        checks: [...this._def.checks, check]
      });
    }
    positive(message) {
      return this._addCheck({
        kind: "min",
        value: BigInt(0),
        inclusive: false,
        message: errorUtil.toString(message)
      });
    }
    negative(message) {
      return this._addCheck({
        kind: "max",
        value: BigInt(0),
        inclusive: false,
        message: errorUtil.toString(message)
      });
    }
    nonpositive(message) {
      return this._addCheck({
        kind: "max",
        value: BigInt(0),
        inclusive: true,
        message: errorUtil.toString(message)
      });
    }
    nonnegative(message) {
      return this._addCheck({
        kind: "min",
        value: BigInt(0),
        inclusive: true,
        message: errorUtil.toString(message)
      });
    }
    multipleOf(value, message) {
      return this._addCheck({
        kind: "multipleOf",
        value,
        message: errorUtil.toString(message)
      });
    }
    get minValue() {
      let min = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "min") {
          if (min === null || ch.value > min)
            min = ch.value;
        }
      }
      return min;
    }
    get maxValue() {
      let max = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "max") {
          if (max === null || ch.value < max)
            max = ch.value;
        }
      }
      return max;
    }
  };
  ZodBigInt.create = (params) => {
    return new ZodBigInt({
      checks: [],
      typeName: ZodFirstPartyTypeKind.ZodBigInt,
      coerce: params?.coerce ?? false,
      ...processCreateParams(params)
    });
  };
  var ZodBoolean = class extends ZodType {
    _parse(input) {
      if (this._def.coerce) {
        input.data = Boolean(input.data);
      }
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.boolean) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.boolean,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return OK(input.data);
    }
  };
  ZodBoolean.create = (params) => {
    return new ZodBoolean({
      typeName: ZodFirstPartyTypeKind.ZodBoolean,
      coerce: params?.coerce || false,
      ...processCreateParams(params)
    });
  };
  var ZodDate = class _ZodDate extends ZodType {
    _parse(input) {
      if (this._def.coerce) {
        input.data = new Date(input.data);
      }
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.date) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.date,
          received: ctx2.parsedType
        });
        return INVALID;
      }
      if (Number.isNaN(input.data.getTime())) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_date
        });
        return INVALID;
      }
      const status = new ParseStatus();
      let ctx = void 0;
      for (const check of this._def.checks) {
        if (check.kind === "min") {
          if (input.data.getTime() < check.value) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              message: check.message,
              inclusive: true,
              exact: false,
              minimum: check.value,
              type: "date"
            });
            status.dirty();
          }
        } else if (check.kind === "max") {
          if (input.data.getTime() > check.value) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              message: check.message,
              inclusive: true,
              exact: false,
              maximum: check.value,
              type: "date"
            });
            status.dirty();
          }
        } else {
          util.assertNever(check);
        }
      }
      return {
        status: status.value,
        value: new Date(input.data.getTime())
      };
    }
    _addCheck(check) {
      return new _ZodDate({
        ...this._def,
        checks: [...this._def.checks, check]
      });
    }
    min(minDate, message) {
      return this._addCheck({
        kind: "min",
        value: minDate.getTime(),
        message: errorUtil.toString(message)
      });
    }
    max(maxDate, message) {
      return this._addCheck({
        kind: "max",
        value: maxDate.getTime(),
        message: errorUtil.toString(message)
      });
    }
    get minDate() {
      let min = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "min") {
          if (min === null || ch.value > min)
            min = ch.value;
        }
      }
      return min != null ? new Date(min) : null;
    }
    get maxDate() {
      let max = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "max") {
          if (max === null || ch.value < max)
            max = ch.value;
        }
      }
      return max != null ? new Date(max) : null;
    }
  };
  ZodDate.create = (params) => {
    return new ZodDate({
      checks: [],
      coerce: params?.coerce || false,
      typeName: ZodFirstPartyTypeKind.ZodDate,
      ...processCreateParams(params)
    });
  };
  var ZodSymbol = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.symbol) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.symbol,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return OK(input.data);
    }
  };
  ZodSymbol.create = (params) => {
    return new ZodSymbol({
      typeName: ZodFirstPartyTypeKind.ZodSymbol,
      ...processCreateParams(params)
    });
  };
  var ZodUndefined = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.undefined) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.undefined,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return OK(input.data);
    }
  };
  ZodUndefined.create = (params) => {
    return new ZodUndefined({
      typeName: ZodFirstPartyTypeKind.ZodUndefined,
      ...processCreateParams(params)
    });
  };
  var ZodNull = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.null) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.null,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return OK(input.data);
    }
  };
  ZodNull.create = (params) => {
    return new ZodNull({
      typeName: ZodFirstPartyTypeKind.ZodNull,
      ...processCreateParams(params)
    });
  };
  var ZodAny = class extends ZodType {
    constructor() {
      super(...arguments);
      this._any = true;
    }
    _parse(input) {
      return OK(input.data);
    }
  };
  ZodAny.create = (params) => {
    return new ZodAny({
      typeName: ZodFirstPartyTypeKind.ZodAny,
      ...processCreateParams(params)
    });
  };
  var ZodUnknown = class extends ZodType {
    constructor() {
      super(...arguments);
      this._unknown = true;
    }
    _parse(input) {
      return OK(input.data);
    }
  };
  ZodUnknown.create = (params) => {
    return new ZodUnknown({
      typeName: ZodFirstPartyTypeKind.ZodUnknown,
      ...processCreateParams(params)
    });
  };
  var ZodNever = class extends ZodType {
    _parse(input) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.never,
        received: ctx.parsedType
      });
      return INVALID;
    }
  };
  ZodNever.create = (params) => {
    return new ZodNever({
      typeName: ZodFirstPartyTypeKind.ZodNever,
      ...processCreateParams(params)
    });
  };
  var ZodVoid = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.undefined) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.void,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return OK(input.data);
    }
  };
  ZodVoid.create = (params) => {
    return new ZodVoid({
      typeName: ZodFirstPartyTypeKind.ZodVoid,
      ...processCreateParams(params)
    });
  };
  var ZodArray = class _ZodArray extends ZodType {
    _parse(input) {
      const { ctx, status } = this._processInputParams(input);
      const def = this._def;
      if (ctx.parsedType !== ZodParsedType.array) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.array,
          received: ctx.parsedType
        });
        return INVALID;
      }
      if (def.exactLength !== null) {
        const tooBig = ctx.data.length > def.exactLength.value;
        const tooSmall = ctx.data.length < def.exactLength.value;
        if (tooBig || tooSmall) {
          addIssueToContext(ctx, {
            code: tooBig ? ZodIssueCode.too_big : ZodIssueCode.too_small,
            minimum: tooSmall ? def.exactLength.value : void 0,
            maximum: tooBig ? def.exactLength.value : void 0,
            type: "array",
            inclusive: true,
            exact: true,
            message: def.exactLength.message
          });
          status.dirty();
        }
      }
      if (def.minLength !== null) {
        if (ctx.data.length < def.minLength.value) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            minimum: def.minLength.value,
            type: "array",
            inclusive: true,
            exact: false,
            message: def.minLength.message
          });
          status.dirty();
        }
      }
      if (def.maxLength !== null) {
        if (ctx.data.length > def.maxLength.value) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            maximum: def.maxLength.value,
            type: "array",
            inclusive: true,
            exact: false,
            message: def.maxLength.message
          });
          status.dirty();
        }
      }
      if (ctx.common.async) {
        return Promise.all([...ctx.data].map((item, i) => {
          return def.type._parseAsync(new ParseInputLazyPath(ctx, item, ctx.path, i));
        })).then((result2) => {
          return ParseStatus.mergeArray(status, result2);
        });
      }
      const result = [...ctx.data].map((item, i) => {
        return def.type._parseSync(new ParseInputLazyPath(ctx, item, ctx.path, i));
      });
      return ParseStatus.mergeArray(status, result);
    }
    get element() {
      return this._def.type;
    }
    min(minLength, message) {
      return new _ZodArray({
        ...this._def,
        minLength: { value: minLength, message: errorUtil.toString(message) }
      });
    }
    max(maxLength, message) {
      return new _ZodArray({
        ...this._def,
        maxLength: { value: maxLength, message: errorUtil.toString(message) }
      });
    }
    length(len, message) {
      return new _ZodArray({
        ...this._def,
        exactLength: { value: len, message: errorUtil.toString(message) }
      });
    }
    nonempty(message) {
      return this.min(1, message);
    }
  };
  ZodArray.create = (schema, params) => {
    return new ZodArray({
      type: schema,
      minLength: null,
      maxLength: null,
      exactLength: null,
      typeName: ZodFirstPartyTypeKind.ZodArray,
      ...processCreateParams(params)
    });
  };
  function deepPartialify(schema) {
    if (schema instanceof ZodObject) {
      const newShape = {};
      for (const key in schema.shape) {
        const fieldSchema = schema.shape[key];
        newShape[key] = ZodOptional.create(deepPartialify(fieldSchema));
      }
      return new ZodObject({
        ...schema._def,
        shape: () => newShape
      });
    } else if (schema instanceof ZodArray) {
      return new ZodArray({
        ...schema._def,
        type: deepPartialify(schema.element)
      });
    } else if (schema instanceof ZodOptional) {
      return ZodOptional.create(deepPartialify(schema.unwrap()));
    } else if (schema instanceof ZodNullable) {
      return ZodNullable.create(deepPartialify(schema.unwrap()));
    } else if (schema instanceof ZodTuple) {
      return ZodTuple.create(schema.items.map((item) => deepPartialify(item)));
    } else {
      return schema;
    }
  }
  var ZodObject = class _ZodObject extends ZodType {
    constructor() {
      super(...arguments);
      this._cached = null;
      this.nonstrict = this.passthrough;
      this.augment = this.extend;
    }
    _getCached() {
      if (this._cached !== null)
        return this._cached;
      const shape = this._def.shape();
      const keys = util.objectKeys(shape);
      this._cached = { shape, keys };
      return this._cached;
    }
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.object) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.object,
          received: ctx2.parsedType
        });
        return INVALID;
      }
      const { status, ctx } = this._processInputParams(input);
      const { shape, keys: shapeKeys } = this._getCached();
      const extraKeys = [];
      if (!(this._def.catchall instanceof ZodNever && this._def.unknownKeys === "strip")) {
        for (const key in ctx.data) {
          if (!shapeKeys.includes(key)) {
            extraKeys.push(key);
          }
        }
      }
      const pairs = [];
      for (const key of shapeKeys) {
        const keyValidator = shape[key];
        const value = ctx.data[key];
        pairs.push({
          key: { status: "valid", value: key },
          value: keyValidator._parse(new ParseInputLazyPath(ctx, value, ctx.path, key)),
          alwaysSet: key in ctx.data
        });
      }
      if (this._def.catchall instanceof ZodNever) {
        const unknownKeys = this._def.unknownKeys;
        if (unknownKeys === "passthrough") {
          for (const key of extraKeys) {
            pairs.push({
              key: { status: "valid", value: key },
              value: { status: "valid", value: ctx.data[key] }
            });
          }
        } else if (unknownKeys === "strict") {
          if (extraKeys.length > 0) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.unrecognized_keys,
              keys: extraKeys
            });
            status.dirty();
          }
        } else if (unknownKeys === "strip") {
        } else {
          throw new Error(`Internal ZodObject error: invalid unknownKeys value.`);
        }
      } else {
        const catchall = this._def.catchall;
        for (const key of extraKeys) {
          const value = ctx.data[key];
          pairs.push({
            key: { status: "valid", value: key },
            value: catchall._parse(
              new ParseInputLazyPath(ctx, value, ctx.path, key)
              //, ctx.child(key), value, getParsedType(value)
            ),
            alwaysSet: key in ctx.data
          });
        }
      }
      if (ctx.common.async) {
        return Promise.resolve().then(async () => {
          const syncPairs = [];
          for (const pair of pairs) {
            const key = await pair.key;
            const value = await pair.value;
            syncPairs.push({
              key,
              value,
              alwaysSet: pair.alwaysSet
            });
          }
          return syncPairs;
        }).then((syncPairs) => {
          return ParseStatus.mergeObjectSync(status, syncPairs);
        });
      } else {
        return ParseStatus.mergeObjectSync(status, pairs);
      }
    }
    get shape() {
      return this._def.shape();
    }
    strict(message) {
      errorUtil.errToObj;
      return new _ZodObject({
        ...this._def,
        unknownKeys: "strict",
        ...message !== void 0 ? {
          errorMap: (issue, ctx) => {
            const defaultError = this._def.errorMap?.(issue, ctx).message ?? ctx.defaultError;
            if (issue.code === "unrecognized_keys")
              return {
                message: errorUtil.errToObj(message).message ?? defaultError
              };
            return {
              message: defaultError
            };
          }
        } : {}
      });
    }
    strip() {
      return new _ZodObject({
        ...this._def,
        unknownKeys: "strip"
      });
    }
    passthrough() {
      return new _ZodObject({
        ...this._def,
        unknownKeys: "passthrough"
      });
    }
    // const AugmentFactory =
    //   <Def extends ZodObjectDef>(def: Def) =>
    //   <Augmentation extends ZodRawShape>(
    //     augmentation: Augmentation
    //   ): ZodObject<
    //     extendShape<ReturnType<Def["shape"]>, Augmentation>,
    //     Def["unknownKeys"],
    //     Def["catchall"]
    //   > => {
    //     return new ZodObject({
    //       ...def,
    //       shape: () => ({
    //         ...def.shape(),
    //         ...augmentation,
    //       }),
    //     }) as any;
    //   };
    extend(augmentation) {
      return new _ZodObject({
        ...this._def,
        shape: () => ({
          ...this._def.shape(),
          ...augmentation
        })
      });
    }
    /**
     * Prior to zod@1.0.12 there was a bug in the
     * inferred type of merged objects. Please
     * upgrade if you are experiencing issues.
     */
    merge(merging) {
      const merged = new _ZodObject({
        unknownKeys: merging._def.unknownKeys,
        catchall: merging._def.catchall,
        shape: () => ({
          ...this._def.shape(),
          ...merging._def.shape()
        }),
        typeName: ZodFirstPartyTypeKind.ZodObject
      });
      return merged;
    }
    // merge<
    //   Incoming extends AnyZodObject,
    //   Augmentation extends Incoming["shape"],
    //   NewOutput extends {
    //     [k in keyof Augmentation | keyof Output]: k extends keyof Augmentation
    //       ? Augmentation[k]["_output"]
    //       : k extends keyof Output
    //       ? Output[k]
    //       : never;
    //   },
    //   NewInput extends {
    //     [k in keyof Augmentation | keyof Input]: k extends keyof Augmentation
    //       ? Augmentation[k]["_input"]
    //       : k extends keyof Input
    //       ? Input[k]
    //       : never;
    //   }
    // >(
    //   merging: Incoming
    // ): ZodObject<
    //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
    //   Incoming["_def"]["unknownKeys"],
    //   Incoming["_def"]["catchall"],
    //   NewOutput,
    //   NewInput
    // > {
    //   const merged: any = new ZodObject({
    //     unknownKeys: merging._def.unknownKeys,
    //     catchall: merging._def.catchall,
    //     shape: () =>
    //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
    //     typeName: ZodFirstPartyTypeKind.ZodObject,
    //   }) as any;
    //   return merged;
    // }
    setKey(key, schema) {
      return this.augment({ [key]: schema });
    }
    // merge<Incoming extends AnyZodObject>(
    //   merging: Incoming
    // ): //ZodObject<T & Incoming["_shape"], UnknownKeys, Catchall> = (merging) => {
    // ZodObject<
    //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
    //   Incoming["_def"]["unknownKeys"],
    //   Incoming["_def"]["catchall"]
    // > {
    //   // const mergedShape = objectUtil.mergeShapes(
    //   //   this._def.shape(),
    //   //   merging._def.shape()
    //   // );
    //   const merged: any = new ZodObject({
    //     unknownKeys: merging._def.unknownKeys,
    //     catchall: merging._def.catchall,
    //     shape: () =>
    //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
    //     typeName: ZodFirstPartyTypeKind.ZodObject,
    //   }) as any;
    //   return merged;
    // }
    catchall(index) {
      return new _ZodObject({
        ...this._def,
        catchall: index
      });
    }
    pick(mask) {
      const shape = {};
      for (const key of util.objectKeys(mask)) {
        if (mask[key] && this.shape[key]) {
          shape[key] = this.shape[key];
        }
      }
      return new _ZodObject({
        ...this._def,
        shape: () => shape
      });
    }
    omit(mask) {
      const shape = {};
      for (const key of util.objectKeys(this.shape)) {
        if (!mask[key]) {
          shape[key] = this.shape[key];
        }
      }
      return new _ZodObject({
        ...this._def,
        shape: () => shape
      });
    }
    /**
     * @deprecated
     */
    deepPartial() {
      return deepPartialify(this);
    }
    partial(mask) {
      const newShape = {};
      for (const key of util.objectKeys(this.shape)) {
        const fieldSchema = this.shape[key];
        if (mask && !mask[key]) {
          newShape[key] = fieldSchema;
        } else {
          newShape[key] = fieldSchema.optional();
        }
      }
      return new _ZodObject({
        ...this._def,
        shape: () => newShape
      });
    }
    required(mask) {
      const newShape = {};
      for (const key of util.objectKeys(this.shape)) {
        if (mask && !mask[key]) {
          newShape[key] = this.shape[key];
        } else {
          const fieldSchema = this.shape[key];
          let newField = fieldSchema;
          while (newField instanceof ZodOptional) {
            newField = newField._def.innerType;
          }
          newShape[key] = newField;
        }
      }
      return new _ZodObject({
        ...this._def,
        shape: () => newShape
      });
    }
    keyof() {
      return createZodEnum(util.objectKeys(this.shape));
    }
  };
  ZodObject.create = (shape, params) => {
    return new ZodObject({
      shape: () => shape,
      unknownKeys: "strip",
      catchall: ZodNever.create(),
      typeName: ZodFirstPartyTypeKind.ZodObject,
      ...processCreateParams(params)
    });
  };
  ZodObject.strictCreate = (shape, params) => {
    return new ZodObject({
      shape: () => shape,
      unknownKeys: "strict",
      catchall: ZodNever.create(),
      typeName: ZodFirstPartyTypeKind.ZodObject,
      ...processCreateParams(params)
    });
  };
  ZodObject.lazycreate = (shape, params) => {
    return new ZodObject({
      shape,
      unknownKeys: "strip",
      catchall: ZodNever.create(),
      typeName: ZodFirstPartyTypeKind.ZodObject,
      ...processCreateParams(params)
    });
  };
  var ZodUnion = class extends ZodType {
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      const options = this._def.options;
      function handleResults(results) {
        for (const result of results) {
          if (result.result.status === "valid") {
            return result.result;
          }
        }
        for (const result of results) {
          if (result.result.status === "dirty") {
            ctx.common.issues.push(...result.ctx.common.issues);
            return result.result;
          }
        }
        const unionErrors = results.map((result) => new ZodError(result.ctx.common.issues));
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_union,
          unionErrors
        });
        return INVALID;
      }
      if (ctx.common.async) {
        return Promise.all(options.map(async (option) => {
          const childCtx = {
            ...ctx,
            common: {
              ...ctx.common,
              issues: []
            },
            parent: null
          };
          return {
            result: await option._parseAsync({
              data: ctx.data,
              path: ctx.path,
              parent: childCtx
            }),
            ctx: childCtx
          };
        })).then(handleResults);
      } else {
        let dirty = void 0;
        const issues = [];
        for (const option of options) {
          const childCtx = {
            ...ctx,
            common: {
              ...ctx.common,
              issues: []
            },
            parent: null
          };
          const result = option._parseSync({
            data: ctx.data,
            path: ctx.path,
            parent: childCtx
          });
          if (result.status === "valid") {
            return result;
          } else if (result.status === "dirty" && !dirty) {
            dirty = { result, ctx: childCtx };
          }
          if (childCtx.common.issues.length) {
            issues.push(childCtx.common.issues);
          }
        }
        if (dirty) {
          ctx.common.issues.push(...dirty.ctx.common.issues);
          return dirty.result;
        }
        const unionErrors = issues.map((issues2) => new ZodError(issues2));
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_union,
          unionErrors
        });
        return INVALID;
      }
    }
    get options() {
      return this._def.options;
    }
  };
  ZodUnion.create = (types, params) => {
    return new ZodUnion({
      options: types,
      typeName: ZodFirstPartyTypeKind.ZodUnion,
      ...processCreateParams(params)
    });
  };
  var getDiscriminator = (type) => {
    if (type instanceof ZodLazy) {
      return getDiscriminator(type.schema);
    } else if (type instanceof ZodEffects) {
      return getDiscriminator(type.innerType());
    } else if (type instanceof ZodLiteral) {
      return [type.value];
    } else if (type instanceof ZodEnum) {
      return type.options;
    } else if (type instanceof ZodNativeEnum) {
      return util.objectValues(type.enum);
    } else if (type instanceof ZodDefault) {
      return getDiscriminator(type._def.innerType);
    } else if (type instanceof ZodUndefined) {
      return [void 0];
    } else if (type instanceof ZodNull) {
      return [null];
    } else if (type instanceof ZodOptional) {
      return [void 0, ...getDiscriminator(type.unwrap())];
    } else if (type instanceof ZodNullable) {
      return [null, ...getDiscriminator(type.unwrap())];
    } else if (type instanceof ZodBranded) {
      return getDiscriminator(type.unwrap());
    } else if (type instanceof ZodReadonly) {
      return getDiscriminator(type.unwrap());
    } else if (type instanceof ZodCatch) {
      return getDiscriminator(type._def.innerType);
    } else {
      return [];
    }
  };
  var ZodDiscriminatedUnion = class _ZodDiscriminatedUnion extends ZodType {
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.object) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.object,
          received: ctx.parsedType
        });
        return INVALID;
      }
      const discriminator = this.discriminator;
      const discriminatorValue = ctx.data[discriminator];
      const option = this.optionsMap.get(discriminatorValue);
      if (!option) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_union_discriminator,
          options: Array.from(this.optionsMap.keys()),
          path: [discriminator]
        });
        return INVALID;
      }
      if (ctx.common.async) {
        return option._parseAsync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
      } else {
        return option._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
      }
    }
    get discriminator() {
      return this._def.discriminator;
    }
    get options() {
      return this._def.options;
    }
    get optionsMap() {
      return this._def.optionsMap;
    }
    /**
     * The constructor of the discriminated union schema. Its behaviour is very similar to that of the normal z.union() constructor.
     * However, it only allows a union of objects, all of which need to share a discriminator property. This property must
     * have a different value for each object in the union.
     * @param discriminator the name of the discriminator property
     * @param types an array of object schemas
     * @param params
     */
    static create(discriminator, options, params) {
      const optionsMap = /* @__PURE__ */ new Map();
      for (const type of options) {
        const discriminatorValues = getDiscriminator(type.shape[discriminator]);
        if (!discriminatorValues.length) {
          throw new Error(`A discriminator value for key \`${discriminator}\` could not be extracted from all schema options`);
        }
        for (const value of discriminatorValues) {
          if (optionsMap.has(value)) {
            throw new Error(`Discriminator property ${String(discriminator)} has duplicate value ${String(value)}`);
          }
          optionsMap.set(value, type);
        }
      }
      return new _ZodDiscriminatedUnion({
        typeName: ZodFirstPartyTypeKind.ZodDiscriminatedUnion,
        discriminator,
        options,
        optionsMap,
        ...processCreateParams(params)
      });
    }
  };
  function mergeValues(a, b) {
    const aType = getParsedType(a);
    const bType = getParsedType(b);
    if (a === b) {
      return { valid: true, data: a };
    } else if (aType === ZodParsedType.object && bType === ZodParsedType.object) {
      const bKeys = util.objectKeys(b);
      const sharedKeys = util.objectKeys(a).filter((key) => bKeys.indexOf(key) !== -1);
      const newObj = { ...a, ...b };
      for (const key of sharedKeys) {
        const sharedValue = mergeValues(a[key], b[key]);
        if (!sharedValue.valid) {
          return { valid: false };
        }
        newObj[key] = sharedValue.data;
      }
      return { valid: true, data: newObj };
    } else if (aType === ZodParsedType.array && bType === ZodParsedType.array) {
      if (a.length !== b.length) {
        return { valid: false };
      }
      const newArray = [];
      for (let index = 0; index < a.length; index++) {
        const itemA = a[index];
        const itemB = b[index];
        const sharedValue = mergeValues(itemA, itemB);
        if (!sharedValue.valid) {
          return { valid: false };
        }
        newArray.push(sharedValue.data);
      }
      return { valid: true, data: newArray };
    } else if (aType === ZodParsedType.date && bType === ZodParsedType.date && +a === +b) {
      return { valid: true, data: a };
    } else {
      return { valid: false };
    }
  }
  var ZodIntersection = class extends ZodType {
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      const handleParsed = (parsedLeft, parsedRight) => {
        if (isAborted(parsedLeft) || isAborted(parsedRight)) {
          return INVALID;
        }
        const merged = mergeValues(parsedLeft.value, parsedRight.value);
        if (!merged.valid) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_intersection_types
          });
          return INVALID;
        }
        if (isDirty(parsedLeft) || isDirty(parsedRight)) {
          status.dirty();
        }
        return { status: status.value, value: merged.data };
      };
      if (ctx.common.async) {
        return Promise.all([
          this._def.left._parseAsync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          }),
          this._def.right._parseAsync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          })
        ]).then(([left, right]) => handleParsed(left, right));
      } else {
        return handleParsed(this._def.left._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        }), this._def.right._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        }));
      }
    }
  };
  ZodIntersection.create = (left, right, params) => {
    return new ZodIntersection({
      left,
      right,
      typeName: ZodFirstPartyTypeKind.ZodIntersection,
      ...processCreateParams(params)
    });
  };
  var ZodTuple = class _ZodTuple extends ZodType {
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.array) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.array,
          received: ctx.parsedType
        });
        return INVALID;
      }
      if (ctx.data.length < this._def.items.length) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_small,
          minimum: this._def.items.length,
          inclusive: true,
          exact: false,
          type: "array"
        });
        return INVALID;
      }
      const rest = this._def.rest;
      if (!rest && ctx.data.length > this._def.items.length) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_big,
          maximum: this._def.items.length,
          inclusive: true,
          exact: false,
          type: "array"
        });
        status.dirty();
      }
      const items = [...ctx.data].map((item, itemIndex) => {
        const schema = this._def.items[itemIndex] || this._def.rest;
        if (!schema)
          return null;
        return schema._parse(new ParseInputLazyPath(ctx, item, ctx.path, itemIndex));
      }).filter((x) => !!x);
      if (ctx.common.async) {
        return Promise.all(items).then((results) => {
          return ParseStatus.mergeArray(status, results);
        });
      } else {
        return ParseStatus.mergeArray(status, items);
      }
    }
    get items() {
      return this._def.items;
    }
    rest(rest) {
      return new _ZodTuple({
        ...this._def,
        rest
      });
    }
  };
  ZodTuple.create = (schemas, params) => {
    if (!Array.isArray(schemas)) {
      throw new Error("You must pass an array of schemas to z.tuple([ ... ])");
    }
    return new ZodTuple({
      items: schemas,
      typeName: ZodFirstPartyTypeKind.ZodTuple,
      rest: null,
      ...processCreateParams(params)
    });
  };
  var ZodRecord = class _ZodRecord extends ZodType {
    get keySchema() {
      return this._def.keyType;
    }
    get valueSchema() {
      return this._def.valueType;
    }
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.object) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.object,
          received: ctx.parsedType
        });
        return INVALID;
      }
      const pairs = [];
      const keyType = this._def.keyType;
      const valueType = this._def.valueType;
      for (const key in ctx.data) {
        pairs.push({
          key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, key)),
          value: valueType._parse(new ParseInputLazyPath(ctx, ctx.data[key], ctx.path, key)),
          alwaysSet: key in ctx.data
        });
      }
      if (ctx.common.async) {
        return ParseStatus.mergeObjectAsync(status, pairs);
      } else {
        return ParseStatus.mergeObjectSync(status, pairs);
      }
    }
    get element() {
      return this._def.valueType;
    }
    static create(first, second, third) {
      if (second instanceof ZodType) {
        return new _ZodRecord({
          keyType: first,
          valueType: second,
          typeName: ZodFirstPartyTypeKind.ZodRecord,
          ...processCreateParams(third)
        });
      }
      return new _ZodRecord({
        keyType: ZodString.create(),
        valueType: first,
        typeName: ZodFirstPartyTypeKind.ZodRecord,
        ...processCreateParams(second)
      });
    }
  };
  var ZodMap = class extends ZodType {
    get keySchema() {
      return this._def.keyType;
    }
    get valueSchema() {
      return this._def.valueType;
    }
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.map) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.map,
          received: ctx.parsedType
        });
        return INVALID;
      }
      const keyType = this._def.keyType;
      const valueType = this._def.valueType;
      const pairs = [...ctx.data.entries()].map(([key, value], index) => {
        return {
          key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, [index, "key"])),
          value: valueType._parse(new ParseInputLazyPath(ctx, value, ctx.path, [index, "value"]))
        };
      });
      if (ctx.common.async) {
        const finalMap = /* @__PURE__ */ new Map();
        return Promise.resolve().then(async () => {
          for (const pair of pairs) {
            const key = await pair.key;
            const value = await pair.value;
            if (key.status === "aborted" || value.status === "aborted") {
              return INVALID;
            }
            if (key.status === "dirty" || value.status === "dirty") {
              status.dirty();
            }
            finalMap.set(key.value, value.value);
          }
          return { status: status.value, value: finalMap };
        });
      } else {
        const finalMap = /* @__PURE__ */ new Map();
        for (const pair of pairs) {
          const key = pair.key;
          const value = pair.value;
          if (key.status === "aborted" || value.status === "aborted") {
            return INVALID;
          }
          if (key.status === "dirty" || value.status === "dirty") {
            status.dirty();
          }
          finalMap.set(key.value, value.value);
        }
        return { status: status.value, value: finalMap };
      }
    }
  };
  ZodMap.create = (keyType, valueType, params) => {
    return new ZodMap({
      valueType,
      keyType,
      typeName: ZodFirstPartyTypeKind.ZodMap,
      ...processCreateParams(params)
    });
  };
  var ZodSet = class _ZodSet extends ZodType {
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.set) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.set,
          received: ctx.parsedType
        });
        return INVALID;
      }
      const def = this._def;
      if (def.minSize !== null) {
        if (ctx.data.size < def.minSize.value) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            minimum: def.minSize.value,
            type: "set",
            inclusive: true,
            exact: false,
            message: def.minSize.message
          });
          status.dirty();
        }
      }
      if (def.maxSize !== null) {
        if (ctx.data.size > def.maxSize.value) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            maximum: def.maxSize.value,
            type: "set",
            inclusive: true,
            exact: false,
            message: def.maxSize.message
          });
          status.dirty();
        }
      }
      const valueType = this._def.valueType;
      function finalizeSet(elements2) {
        const parsedSet = /* @__PURE__ */ new Set();
        for (const element of elements2) {
          if (element.status === "aborted")
            return INVALID;
          if (element.status === "dirty")
            status.dirty();
          parsedSet.add(element.value);
        }
        return { status: status.value, value: parsedSet };
      }
      const elements = [...ctx.data.values()].map((item, i) => valueType._parse(new ParseInputLazyPath(ctx, item, ctx.path, i)));
      if (ctx.common.async) {
        return Promise.all(elements).then((elements2) => finalizeSet(elements2));
      } else {
        return finalizeSet(elements);
      }
    }
    min(minSize, message) {
      return new _ZodSet({
        ...this._def,
        minSize: { value: minSize, message: errorUtil.toString(message) }
      });
    }
    max(maxSize, message) {
      return new _ZodSet({
        ...this._def,
        maxSize: { value: maxSize, message: errorUtil.toString(message) }
      });
    }
    size(size, message) {
      return this.min(size, message).max(size, message);
    }
    nonempty(message) {
      return this.min(1, message);
    }
  };
  ZodSet.create = (valueType, params) => {
    return new ZodSet({
      valueType,
      minSize: null,
      maxSize: null,
      typeName: ZodFirstPartyTypeKind.ZodSet,
      ...processCreateParams(params)
    });
  };
  var ZodFunction = class _ZodFunction extends ZodType {
    constructor() {
      super(...arguments);
      this.validate = this.implement;
    }
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.function) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.function,
          received: ctx.parsedType
        });
        return INVALID;
      }
      function makeArgsIssue(args, error) {
        return makeIssue({
          data: args,
          path: ctx.path,
          errorMaps: [ctx.common.contextualErrorMap, ctx.schemaErrorMap, getErrorMap(), en_default].filter((x) => !!x),
          issueData: {
            code: ZodIssueCode.invalid_arguments,
            argumentsError: error
          }
        });
      }
      function makeReturnsIssue(returns, error) {
        return makeIssue({
          data: returns,
          path: ctx.path,
          errorMaps: [ctx.common.contextualErrorMap, ctx.schemaErrorMap, getErrorMap(), en_default].filter((x) => !!x),
          issueData: {
            code: ZodIssueCode.invalid_return_type,
            returnTypeError: error
          }
        });
      }
      const params = { errorMap: ctx.common.contextualErrorMap };
      const fn = ctx.data;
      if (this._def.returns instanceof ZodPromise) {
        const me = this;
        return OK(async function(...args) {
          const error = new ZodError([]);
          const parsedArgs = await me._def.args.parseAsync(args, params).catch((e) => {
            error.addIssue(makeArgsIssue(args, e));
            throw error;
          });
          const result = await Reflect.apply(fn, this, parsedArgs);
          const parsedReturns = await me._def.returns._def.type.parseAsync(result, params).catch((e) => {
            error.addIssue(makeReturnsIssue(result, e));
            throw error;
          });
          return parsedReturns;
        });
      } else {
        const me = this;
        return OK(function(...args) {
          const parsedArgs = me._def.args.safeParse(args, params);
          if (!parsedArgs.success) {
            throw new ZodError([makeArgsIssue(args, parsedArgs.error)]);
          }
          const result = Reflect.apply(fn, this, parsedArgs.data);
          const parsedReturns = me._def.returns.safeParse(result, params);
          if (!parsedReturns.success) {
            throw new ZodError([makeReturnsIssue(result, parsedReturns.error)]);
          }
          return parsedReturns.data;
        });
      }
    }
    parameters() {
      return this._def.args;
    }
    returnType() {
      return this._def.returns;
    }
    args(...items) {
      return new _ZodFunction({
        ...this._def,
        args: ZodTuple.create(items).rest(ZodUnknown.create())
      });
    }
    returns(returnType) {
      return new _ZodFunction({
        ...this._def,
        returns: returnType
      });
    }
    implement(func) {
      const validatedFunc = this.parse(func);
      return validatedFunc;
    }
    strictImplement(func) {
      const validatedFunc = this.parse(func);
      return validatedFunc;
    }
    static create(args, returns, params) {
      return new _ZodFunction({
        args: args ? args : ZodTuple.create([]).rest(ZodUnknown.create()),
        returns: returns || ZodUnknown.create(),
        typeName: ZodFirstPartyTypeKind.ZodFunction,
        ...processCreateParams(params)
      });
    }
  };
  var ZodLazy = class extends ZodType {
    get schema() {
      return this._def.getter();
    }
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      const lazySchema = this._def.getter();
      return lazySchema._parse({ data: ctx.data, path: ctx.path, parent: ctx });
    }
  };
  ZodLazy.create = (getter, params) => {
    return new ZodLazy({
      getter,
      typeName: ZodFirstPartyTypeKind.ZodLazy,
      ...processCreateParams(params)
    });
  };
  var ZodLiteral = class extends ZodType {
    _parse(input) {
      if (input.data !== this._def.value) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          received: ctx.data,
          code: ZodIssueCode.invalid_literal,
          expected: this._def.value
        });
        return INVALID;
      }
      return { status: "valid", value: input.data };
    }
    get value() {
      return this._def.value;
    }
  };
  ZodLiteral.create = (value, params) => {
    return new ZodLiteral({
      value,
      typeName: ZodFirstPartyTypeKind.ZodLiteral,
      ...processCreateParams(params)
    });
  };
  function createZodEnum(values, params) {
    return new ZodEnum({
      values,
      typeName: ZodFirstPartyTypeKind.ZodEnum,
      ...processCreateParams(params)
    });
  }
  var ZodEnum = class _ZodEnum extends ZodType {
    _parse(input) {
      if (typeof input.data !== "string") {
        const ctx = this._getOrReturnCtx(input);
        const expectedValues = this._def.values;
        addIssueToContext(ctx, {
          expected: util.joinValues(expectedValues),
          received: ctx.parsedType,
          code: ZodIssueCode.invalid_type
        });
        return INVALID;
      }
      if (!this._cache) {
        this._cache = new Set(this._def.values);
      }
      if (!this._cache.has(input.data)) {
        const ctx = this._getOrReturnCtx(input);
        const expectedValues = this._def.values;
        addIssueToContext(ctx, {
          received: ctx.data,
          code: ZodIssueCode.invalid_enum_value,
          options: expectedValues
        });
        return INVALID;
      }
      return OK(input.data);
    }
    get options() {
      return this._def.values;
    }
    get enum() {
      const enumValues = {};
      for (const val of this._def.values) {
        enumValues[val] = val;
      }
      return enumValues;
    }
    get Values() {
      const enumValues = {};
      for (const val of this._def.values) {
        enumValues[val] = val;
      }
      return enumValues;
    }
    get Enum() {
      const enumValues = {};
      for (const val of this._def.values) {
        enumValues[val] = val;
      }
      return enumValues;
    }
    extract(values, newDef = this._def) {
      return _ZodEnum.create(values, {
        ...this._def,
        ...newDef
      });
    }
    exclude(values, newDef = this._def) {
      return _ZodEnum.create(this.options.filter((opt) => !values.includes(opt)), {
        ...this._def,
        ...newDef
      });
    }
  };
  ZodEnum.create = createZodEnum;
  var ZodNativeEnum = class extends ZodType {
    _parse(input) {
      const nativeEnumValues = util.getValidEnumValues(this._def.values);
      const ctx = this._getOrReturnCtx(input);
      if (ctx.parsedType !== ZodParsedType.string && ctx.parsedType !== ZodParsedType.number) {
        const expectedValues = util.objectValues(nativeEnumValues);
        addIssueToContext(ctx, {
          expected: util.joinValues(expectedValues),
          received: ctx.parsedType,
          code: ZodIssueCode.invalid_type
        });
        return INVALID;
      }
      if (!this._cache) {
        this._cache = new Set(util.getValidEnumValues(this._def.values));
      }
      if (!this._cache.has(input.data)) {
        const expectedValues = util.objectValues(nativeEnumValues);
        addIssueToContext(ctx, {
          received: ctx.data,
          code: ZodIssueCode.invalid_enum_value,
          options: expectedValues
        });
        return INVALID;
      }
      return OK(input.data);
    }
    get enum() {
      return this._def.values;
    }
  };
  ZodNativeEnum.create = (values, params) => {
    return new ZodNativeEnum({
      values,
      typeName: ZodFirstPartyTypeKind.ZodNativeEnum,
      ...processCreateParams(params)
    });
  };
  var ZodPromise = class extends ZodType {
    unwrap() {
      return this._def.type;
    }
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.promise && ctx.common.async === false) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.promise,
          received: ctx.parsedType
        });
        return INVALID;
      }
      const promisified = ctx.parsedType === ZodParsedType.promise ? ctx.data : Promise.resolve(ctx.data);
      return OK(promisified.then((data) => {
        return this._def.type.parseAsync(data, {
          path: ctx.path,
          errorMap: ctx.common.contextualErrorMap
        });
      }));
    }
  };
  ZodPromise.create = (schema, params) => {
    return new ZodPromise({
      type: schema,
      typeName: ZodFirstPartyTypeKind.ZodPromise,
      ...processCreateParams(params)
    });
  };
  var ZodEffects = class extends ZodType {
    innerType() {
      return this._def.schema;
    }
    sourceType() {
      return this._def.schema._def.typeName === ZodFirstPartyTypeKind.ZodEffects ? this._def.schema.sourceType() : this._def.schema;
    }
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      const effect = this._def.effect || null;
      const checkCtx = {
        addIssue: (arg) => {
          addIssueToContext(ctx, arg);
          if (arg.fatal) {
            status.abort();
          } else {
            status.dirty();
          }
        },
        get path() {
          return ctx.path;
        }
      };
      checkCtx.addIssue = checkCtx.addIssue.bind(checkCtx);
      if (effect.type === "preprocess") {
        const processed = effect.transform(ctx.data, checkCtx);
        if (ctx.common.async) {
          return Promise.resolve(processed).then(async (processed2) => {
            if (status.value === "aborted")
              return INVALID;
            const result = await this._def.schema._parseAsync({
              data: processed2,
              path: ctx.path,
              parent: ctx
            });
            if (result.status === "aborted")
              return INVALID;
            if (result.status === "dirty")
              return DIRTY(result.value);
            if (status.value === "dirty")
              return DIRTY(result.value);
            return result;
          });
        } else {
          if (status.value === "aborted")
            return INVALID;
          const result = this._def.schema._parseSync({
            data: processed,
            path: ctx.path,
            parent: ctx
          });
          if (result.status === "aborted")
            return INVALID;
          if (result.status === "dirty")
            return DIRTY(result.value);
          if (status.value === "dirty")
            return DIRTY(result.value);
          return result;
        }
      }
      if (effect.type === "refinement") {
        const executeRefinement = (acc) => {
          const result = effect.refinement(acc, checkCtx);
          if (ctx.common.async) {
            return Promise.resolve(result);
          }
          if (result instanceof Promise) {
            throw new Error("Async refinement encountered during synchronous parse operation. Use .parseAsync instead.");
          }
          return acc;
        };
        if (ctx.common.async === false) {
          const inner = this._def.schema._parseSync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          });
          if (inner.status === "aborted")
            return INVALID;
          if (inner.status === "dirty")
            status.dirty();
          executeRefinement(inner.value);
          return { status: status.value, value: inner.value };
        } else {
          return this._def.schema._parseAsync({ data: ctx.data, path: ctx.path, parent: ctx }).then((inner) => {
            if (inner.status === "aborted")
              return INVALID;
            if (inner.status === "dirty")
              status.dirty();
            return executeRefinement(inner.value).then(() => {
              return { status: status.value, value: inner.value };
            });
          });
        }
      }
      if (effect.type === "transform") {
        if (ctx.common.async === false) {
          const base = this._def.schema._parseSync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          });
          if (!isValid(base))
            return INVALID;
          const result = effect.transform(base.value, checkCtx);
          if (result instanceof Promise) {
            throw new Error(`Asynchronous transform encountered during synchronous parse operation. Use .parseAsync instead.`);
          }
          return { status: status.value, value: result };
        } else {
          return this._def.schema._parseAsync({ data: ctx.data, path: ctx.path, parent: ctx }).then((base) => {
            if (!isValid(base))
              return INVALID;
            return Promise.resolve(effect.transform(base.value, checkCtx)).then((result) => ({
              status: status.value,
              value: result
            }));
          });
        }
      }
      util.assertNever(effect);
    }
  };
  ZodEffects.create = (schema, effect, params) => {
    return new ZodEffects({
      schema,
      typeName: ZodFirstPartyTypeKind.ZodEffects,
      effect,
      ...processCreateParams(params)
    });
  };
  ZodEffects.createWithPreprocess = (preprocess, schema, params) => {
    return new ZodEffects({
      schema,
      effect: { type: "preprocess", transform: preprocess },
      typeName: ZodFirstPartyTypeKind.ZodEffects,
      ...processCreateParams(params)
    });
  };
  var ZodOptional = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType === ZodParsedType.undefined) {
        return OK(void 0);
      }
      return this._def.innerType._parse(input);
    }
    unwrap() {
      return this._def.innerType;
    }
  };
  ZodOptional.create = (type, params) => {
    return new ZodOptional({
      innerType: type,
      typeName: ZodFirstPartyTypeKind.ZodOptional,
      ...processCreateParams(params)
    });
  };
  var ZodNullable = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType === ZodParsedType.null) {
        return OK(null);
      }
      return this._def.innerType._parse(input);
    }
    unwrap() {
      return this._def.innerType;
    }
  };
  ZodNullable.create = (type, params) => {
    return new ZodNullable({
      innerType: type,
      typeName: ZodFirstPartyTypeKind.ZodNullable,
      ...processCreateParams(params)
    });
  };
  var ZodDefault = class extends ZodType {
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      let data = ctx.data;
      if (ctx.parsedType === ZodParsedType.undefined) {
        data = this._def.defaultValue();
      }
      return this._def.innerType._parse({
        data,
        path: ctx.path,
        parent: ctx
      });
    }
    removeDefault() {
      return this._def.innerType;
    }
  };
  ZodDefault.create = (type, params) => {
    return new ZodDefault({
      innerType: type,
      typeName: ZodFirstPartyTypeKind.ZodDefault,
      defaultValue: typeof params.default === "function" ? params.default : () => params.default,
      ...processCreateParams(params)
    });
  };
  var ZodCatch = class extends ZodType {
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      const newCtx = {
        ...ctx,
        common: {
          ...ctx.common,
          issues: []
        }
      };
      const result = this._def.innerType._parse({
        data: newCtx.data,
        path: newCtx.path,
        parent: {
          ...newCtx
        }
      });
      if (isAsync(result)) {
        return result.then((result2) => {
          return {
            status: "valid",
            value: result2.status === "valid" ? result2.value : this._def.catchValue({
              get error() {
                return new ZodError(newCtx.common.issues);
              },
              input: newCtx.data
            })
          };
        });
      } else {
        return {
          status: "valid",
          value: result.status === "valid" ? result.value : this._def.catchValue({
            get error() {
              return new ZodError(newCtx.common.issues);
            },
            input: newCtx.data
          })
        };
      }
    }
    removeCatch() {
      return this._def.innerType;
    }
  };
  ZodCatch.create = (type, params) => {
    return new ZodCatch({
      innerType: type,
      typeName: ZodFirstPartyTypeKind.ZodCatch,
      catchValue: typeof params.catch === "function" ? params.catch : () => params.catch,
      ...processCreateParams(params)
    });
  };
  var ZodNaN = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.nan) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.nan,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return { status: "valid", value: input.data };
    }
  };
  ZodNaN.create = (params) => {
    return new ZodNaN({
      typeName: ZodFirstPartyTypeKind.ZodNaN,
      ...processCreateParams(params)
    });
  };
  var BRAND = Symbol("zod_brand");
  var ZodBranded = class extends ZodType {
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      const data = ctx.data;
      return this._def.type._parse({
        data,
        path: ctx.path,
        parent: ctx
      });
    }
    unwrap() {
      return this._def.type;
    }
  };
  var ZodPipeline = class _ZodPipeline extends ZodType {
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      if (ctx.common.async) {
        const handleAsync = async () => {
          const inResult = await this._def.in._parseAsync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          });
          if (inResult.status === "aborted")
            return INVALID;
          if (inResult.status === "dirty") {
            status.dirty();
            return DIRTY(inResult.value);
          } else {
            return this._def.out._parseAsync({
              data: inResult.value,
              path: ctx.path,
              parent: ctx
            });
          }
        };
        return handleAsync();
      } else {
        const inResult = this._def.in._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
        if (inResult.status === "aborted")
          return INVALID;
        if (inResult.status === "dirty") {
          status.dirty();
          return {
            status: "dirty",
            value: inResult.value
          };
        } else {
          return this._def.out._parseSync({
            data: inResult.value,
            path: ctx.path,
            parent: ctx
          });
        }
      }
    }
    static create(a, b) {
      return new _ZodPipeline({
        in: a,
        out: b,
        typeName: ZodFirstPartyTypeKind.ZodPipeline
      });
    }
  };
  var ZodReadonly = class extends ZodType {
    _parse(input) {
      const result = this._def.innerType._parse(input);
      const freeze = (data) => {
        if (isValid(data)) {
          data.value = Object.freeze(data.value);
        }
        return data;
      };
      return isAsync(result) ? result.then((data) => freeze(data)) : freeze(result);
    }
    unwrap() {
      return this._def.innerType;
    }
  };
  ZodReadonly.create = (type, params) => {
    return new ZodReadonly({
      innerType: type,
      typeName: ZodFirstPartyTypeKind.ZodReadonly,
      ...processCreateParams(params)
    });
  };
  function cleanParams(params, data) {
    const p = typeof params === "function" ? params(data) : typeof params === "string" ? { message: params } : params;
    const p2 = typeof p === "string" ? { message: p } : p;
    return p2;
  }
  function custom(check, _params = {}, fatal) {
    if (check)
      return ZodAny.create().superRefine((data, ctx) => {
        const r = check(data);
        if (r instanceof Promise) {
          return r.then((r2) => {
            if (!r2) {
              const params = cleanParams(_params, data);
              const _fatal = params.fatal ?? fatal ?? true;
              ctx.addIssue({ code: "custom", ...params, fatal: _fatal });
            }
          });
        }
        if (!r) {
          const params = cleanParams(_params, data);
          const _fatal = params.fatal ?? fatal ?? true;
          ctx.addIssue({ code: "custom", ...params, fatal: _fatal });
        }
        return;
      });
    return ZodAny.create();
  }
  var late = {
    object: ZodObject.lazycreate
  };
  var ZodFirstPartyTypeKind;
  (function(ZodFirstPartyTypeKind2) {
    ZodFirstPartyTypeKind2["ZodString"] = "ZodString";
    ZodFirstPartyTypeKind2["ZodNumber"] = "ZodNumber";
    ZodFirstPartyTypeKind2["ZodNaN"] = "ZodNaN";
    ZodFirstPartyTypeKind2["ZodBigInt"] = "ZodBigInt";
    ZodFirstPartyTypeKind2["ZodBoolean"] = "ZodBoolean";
    ZodFirstPartyTypeKind2["ZodDate"] = "ZodDate";
    ZodFirstPartyTypeKind2["ZodSymbol"] = "ZodSymbol";
    ZodFirstPartyTypeKind2["ZodUndefined"] = "ZodUndefined";
    ZodFirstPartyTypeKind2["ZodNull"] = "ZodNull";
    ZodFirstPartyTypeKind2["ZodAny"] = "ZodAny";
    ZodFirstPartyTypeKind2["ZodUnknown"] = "ZodUnknown";
    ZodFirstPartyTypeKind2["ZodNever"] = "ZodNever";
    ZodFirstPartyTypeKind2["ZodVoid"] = "ZodVoid";
    ZodFirstPartyTypeKind2["ZodArray"] = "ZodArray";
    ZodFirstPartyTypeKind2["ZodObject"] = "ZodObject";
    ZodFirstPartyTypeKind2["ZodUnion"] = "ZodUnion";
    ZodFirstPartyTypeKind2["ZodDiscriminatedUnion"] = "ZodDiscriminatedUnion";
    ZodFirstPartyTypeKind2["ZodIntersection"] = "ZodIntersection";
    ZodFirstPartyTypeKind2["ZodTuple"] = "ZodTuple";
    ZodFirstPartyTypeKind2["ZodRecord"] = "ZodRecord";
    ZodFirstPartyTypeKind2["ZodMap"] = "ZodMap";
    ZodFirstPartyTypeKind2["ZodSet"] = "ZodSet";
    ZodFirstPartyTypeKind2["ZodFunction"] = "ZodFunction";
    ZodFirstPartyTypeKind2["ZodLazy"] = "ZodLazy";
    ZodFirstPartyTypeKind2["ZodLiteral"] = "ZodLiteral";
    ZodFirstPartyTypeKind2["ZodEnum"] = "ZodEnum";
    ZodFirstPartyTypeKind2["ZodEffects"] = "ZodEffects";
    ZodFirstPartyTypeKind2["ZodNativeEnum"] = "ZodNativeEnum";
    ZodFirstPartyTypeKind2["ZodOptional"] = "ZodOptional";
    ZodFirstPartyTypeKind2["ZodNullable"] = "ZodNullable";
    ZodFirstPartyTypeKind2["ZodDefault"] = "ZodDefault";
    ZodFirstPartyTypeKind2["ZodCatch"] = "ZodCatch";
    ZodFirstPartyTypeKind2["ZodPromise"] = "ZodPromise";
    ZodFirstPartyTypeKind2["ZodBranded"] = "ZodBranded";
    ZodFirstPartyTypeKind2["ZodPipeline"] = "ZodPipeline";
    ZodFirstPartyTypeKind2["ZodReadonly"] = "ZodReadonly";
  })(ZodFirstPartyTypeKind || (ZodFirstPartyTypeKind = {}));
  var instanceOfType = (cls, params = {
    message: `Input not instance of ${cls.name}`
  }) => custom((data) => data instanceof cls, params);
  var stringType = ZodString.create;
  var numberType = ZodNumber.create;
  var nanType = ZodNaN.create;
  var bigIntType = ZodBigInt.create;
  var booleanType = ZodBoolean.create;
  var dateType = ZodDate.create;
  var symbolType = ZodSymbol.create;
  var undefinedType = ZodUndefined.create;
  var nullType = ZodNull.create;
  var anyType = ZodAny.create;
  var unknownType = ZodUnknown.create;
  var neverType = ZodNever.create;
  var voidType = ZodVoid.create;
  var arrayType = ZodArray.create;
  var objectType = ZodObject.create;
  var strictObjectType = ZodObject.strictCreate;
  var unionType = ZodUnion.create;
  var discriminatedUnionType = ZodDiscriminatedUnion.create;
  var intersectionType = ZodIntersection.create;
  var tupleType = ZodTuple.create;
  var recordType = ZodRecord.create;
  var mapType = ZodMap.create;
  var setType = ZodSet.create;
  var functionType = ZodFunction.create;
  var lazyType = ZodLazy.create;
  var literalType = ZodLiteral.create;
  var enumType = ZodEnum.create;
  var nativeEnumType = ZodNativeEnum.create;
  var promiseType = ZodPromise.create;
  var effectsType = ZodEffects.create;
  var optionalType = ZodOptional.create;
  var nullableType = ZodNullable.create;
  var preprocessType = ZodEffects.createWithPreprocess;
  var pipelineType = ZodPipeline.create;
  var ostring = () => stringType().optional();
  var onumber = () => numberType().optional();
  var oboolean = () => booleanType().optional();
  var coerce = {
    string: (arg) => ZodString.create({ ...arg, coerce: true }),
    number: (arg) => ZodNumber.create({ ...arg, coerce: true }),
    boolean: (arg) => ZodBoolean.create({
      ...arg,
      coerce: true
    }),
    bigint: (arg) => ZodBigInt.create({ ...arg, coerce: true }),
    date: (arg) => ZodDate.create({ ...arg, coerce: true })
  };
  var NEVER = INVALID;

  // ../shared/src/events.ts
  var eventTypeSchema = external_exports.enum([
    "ExtensionConnected",
    "LoginDetected",
    "JobDetected",
    "ApplicationRecorded",
    "SyncStarted",
    "SyncCompleted",
    "SyncFailed",
    "NotificationCreated"
  ]);
  var syncStatusSchema = external_exports.enum(["pending", "syncing", "synced", "failed"]);
  var platformSchema = external_exports.enum([
    "naukri",
    "linkedin",
    "foundit",
    "indeed",
    "wellfound",
    "internshala",
    "unknown"
  ]);
  var jobPayloadSchema = external_exports.object({
    platform: platformSchema,
    externalJobId: external_exports.string().optional(),
    title: external_exports.string().min(1),
    company: external_exports.string().min(1),
    location: external_exports.string().optional(),
    url: external_exports.string().url().optional(),
    companyLogo: external_exports.string().min(1).optional(),
    description: external_exports.string().max(12e3).optional(),
    experience: external_exports.string().optional(),
    salary: external_exports.string().optional(),
    skills: external_exports.array(external_exports.string()).max(60).optional(),
    rating: external_exports.string().optional(),
    reviews: external_exports.string().optional(),
    postedAt: external_exports.string().optional(),
    openings: external_exports.string().optional(),
    applicants: external_exports.string().optional(),
    highlights: external_exports.array(external_exports.string()).max(20).optional(),
    role: external_exports.string().optional(),
    industry: external_exports.string().optional(),
    department: external_exports.string().optional(),
    employmentType: external_exports.string().optional(),
    roleCategory: external_exports.string().optional(),
    education: external_exports.string().optional(),
    aboutCompany: external_exports.string().max(4e3).optional(),
    appliedAt: external_exports.string().datetime().optional(),
    status: external_exports.enum(["detected", "applied", "viewed", "saved"]).default("detected"),
    metadata: external_exports.record(external_exports.unknown()).optional()
  });
  var eventEnvelopeSchema = external_exports.object({
    eventId: external_exports.string().uuid(),
    timestamp: external_exports.string().datetime(),
    type: eventTypeSchema,
    payload: external_exports.record(external_exports.unknown()),
    retryCount: external_exports.number().int().nonnegative().default(0),
    syncStatus: syncStatusSchema.default("pending")
  });
  var syncEventsRequestSchema = external_exports.object({
    events: external_exports.array(eventEnvelopeSchema).min(1).max(100)
  });

  // ../shared/src/models.ts
  var registerSchema = external_exports.object({
    email: external_exports.string().email(),
    password: external_exports.string().min(8),
    name: external_exports.string().min(1).max(120)
  });
  var loginSchema = external_exports.object({
    email: external_exports.string().email(),
    password: external_exports.string().min(1)
  });
  var googleAuthSchema = external_exports.object({
    code: external_exports.string().min(1)
  });
  var planTierSchema = external_exports.enum(["free", "pro", "max"]);
  var userRoleSchema = external_exports.enum(["user", "admin"]);
  var userStatusSchema = external_exports.enum(["active", "suspended"]);
  var userSchema = external_exports.object({
    id: external_exports.string(),
    email: external_exports.string().email(),
    name: external_exports.string(),
    role: userRoleSchema.optional(),
    status: userStatusSchema.optional(),
    plan: planTierSchema.optional(),
    planExpiresAt: external_exports.string().datetime().optional(),
    createdAt: external_exports.string().datetime().optional(),
    extensionConnectedAt: external_exports.string().datetime().optional()
  });
  var paidPlanSchema = external_exports.enum(["pro", "max"]);
  var createBillingOrderSchema = external_exports.object({
    plan: paidPlanSchema
  });
  var verifyBillingPaymentSchema = external_exports.object({
    razorpay_order_id: external_exports.string().min(1),
    razorpay_payment_id: external_exports.string().min(1),
    razorpay_signature: external_exports.string().min(1),
    plan: paidPlanSchema
  });
  var createSubscriptionSchema = external_exports.object({
    plan: paidPlanSchema
  });
  var verifySubscriptionSchema = external_exports.object({
    razorpay_payment_id: external_exports.string().min(1),
    razorpay_subscription_id: external_exports.string().min(1),
    razorpay_signature: external_exports.string().min(1),
    plan: paidPlanSchema
  });
  var cancelSubscriptionSchema = external_exports.object({
    immediate: external_exports.boolean().optional().default(false)
  });
  var subscriptionStatusSchema = external_exports.enum([
    "created",
    "authenticated",
    "active",
    "pending",
    "halted",
    "cancelled",
    "completed",
    "expired"
  ]);
  var workModeSchema = external_exports.enum(["any", "office", "hybrid", "remote"]);
  var jobPreferencesSchema = external_exports.object({
    titles: external_exports.array(external_exports.string().min(1).max(120)).max(20).default([]),
    keywords: external_exports.array(external_exports.string().min(1).max(80)).max(30).default([]),
    locations: external_exports.array(external_exports.string().min(1).max(120)).max(20).default([]),
    experienceMin: external_exports.number().int().min(0).max(50).default(0),
    experienceMax: external_exports.number().int().min(0).max(50).default(30),
    minSalaryLpa: external_exports.number().min(0).max(500).optional(),
    workMode: workModeSchema.default("any"),
    autoScanEnabled: external_exports.boolean().default(true),
    autoApplyEnabled: external_exports.boolean().default(false)
  });
  var onboardingStatusSchema = external_exports.object({
    accountCreated: external_exports.boolean(),
    extensionConnected: external_exports.boolean(),
    preferencesCompleted: external_exports.boolean(),
    hasApplications: external_exports.boolean(),
    extensionConnectedAt: external_exports.string().datetime().optional()
  });
  var authTokensSchema = external_exports.object({
    accessToken: external_exports.string(),
    refreshToken: external_exports.string(),
    user: userSchema
  });
  var refreshTokenSchema = external_exports.object({
    refreshToken: external_exports.string().min(1)
  });
  var applicationStatusSchema = external_exports.enum([
    "detected",
    "applied",
    "viewed",
    "saved",
    "interview",
    "offer",
    "rejected"
  ]);
  var applicationMetadataSchema = external_exports.object({
    source: external_exports.enum(["manual", "auto_scan", "auto_apply"]).optional(),
    skipReason: external_exports.string().optional(),
    skipped: external_exports.boolean().optional(),
    companySiteApply: external_exports.boolean().optional()
  }).passthrough();
  var applicationSchema = external_exports.object({
    id: external_exports.string(),
    eventId: external_exports.string(),
    userId: external_exports.string(),
    platform: platformSchema,
    externalJobId: external_exports.string().optional(),
    title: external_exports.string(),
    company: external_exports.string(),
    location: external_exports.string().optional(),
    url: external_exports.string().optional(),
    companyLogo: external_exports.string().optional(),
    description: external_exports.string().optional(),
    experience: external_exports.string().optional(),
    salary: external_exports.string().optional(),
    skills: external_exports.array(external_exports.string()).optional(),
    rating: external_exports.string().optional(),
    reviews: external_exports.string().optional(),
    postedAt: external_exports.string().optional(),
    openings: external_exports.string().optional(),
    applicants: external_exports.string().optional(),
    highlights: external_exports.array(external_exports.string()).optional(),
    role: external_exports.string().optional(),
    industry: external_exports.string().optional(),
    department: external_exports.string().optional(),
    employmentType: external_exports.string().optional(),
    roleCategory: external_exports.string().optional(),
    education: external_exports.string().optional(),
    aboutCompany: external_exports.string().optional(),
    status: applicationStatusSchema,
    appliedAt: external_exports.string().datetime().optional(),
    metadata: applicationMetadataSchema.optional(),
    createdAt: external_exports.string().datetime(),
    updatedAt: external_exports.string().datetime()
  });

  // ../shared/src/admin.ts
  var adminUsersQuerySchema = external_exports.object({
    q: external_exports.string().optional(),
    plan: planTierSchema.optional(),
    role: external_exports.enum(["user", "admin"]).optional(),
    status: external_exports.enum(["active", "suspended"]).optional(),
    page: external_exports.coerce.number().int().min(1).default(1),
    limit: external_exports.coerce.number().int().min(1).max(100).default(20)
  });
  var adminPatchUserSchema = external_exports.object({
    name: external_exports.string().min(1).max(120).optional(),
    email: external_exports.string().email().optional(),
    role: external_exports.enum(["user", "admin"]).optional(),
    status: external_exports.enum(["active", "suspended"]).optional()
  });
  var adminSetPlanSchema = external_exports.object({
    action: external_exports.enum(["grant", "extend", "revoke"]),
    plan: paidPlanSchema.optional(),
    days: external_exports.number().int().min(1).max(3650).optional()
  });
  var adminSubscriptionsQuerySchema = external_exports.object({
    status: external_exports.string().optional(),
    tier: paidPlanSchema.optional(),
    page: external_exports.coerce.number().int().min(1).default(1),
    limit: external_exports.coerce.number().int().min(1).max(100).default(20)
  });
  var adminExtendSubscriptionSchema = external_exports.object({
    days: external_exports.number().int().min(1).max(3650)
  });
  var adminPaymentsQuerySchema = external_exports.object({
    status: external_exports.enum(["created", "paid", "failed"]).optional(),
    plan: paidPlanSchema.optional(),
    from: external_exports.string().datetime().optional(),
    to: external_exports.string().datetime().optional(),
    page: external_exports.coerce.number().int().min(1).default(1),
    limit: external_exports.coerce.number().int().min(1).max(100).default(20)
  });
  var adminUpdatePlanSchema = external_exports.object({
    name: external_exports.string().min(1).max(80).optional(),
    description: external_exports.string().max(500).optional(),
    amountPaise: external_exports.number().int().min(0).optional(),
    active: external_exports.boolean().optional(),
    limits: external_exports.object({
      monthlyApplies: external_exports.number().int().min(0),
      monthlyScans: external_exports.number().int().min(0),
      appliesPerHour: external_exports.number().int().min(0),
      appliesPerDay: external_exports.number().int().min(0)
    }).optional()
  });
  var adminAuditQuerySchema = external_exports.object({
    page: external_exports.coerce.number().int().min(1).default(1),
    limit: external_exports.coerce.number().int().min(1).max(100).default(40)
  });
  var adminMetricsQuerySchema = external_exports.object({
    /** Preset window or calendar month/year. `days` kept for backward compatibility. */
    range: external_exports.enum(["7d", "30d", "90d", "month", "year"]).optional(),
    days: external_exports.coerce.number().int().min(7).max(90).optional(),
    year: external_exports.coerce.number().int().min(2020).max(2100).optional(),
    month: external_exports.coerce.number().int().min(1).max(12).optional()
  });

  // ../shared/src/api.ts
  var apiErrorSchema = external_exports.object({
    success: external_exports.literal(false),
    message: external_exports.string(),
    data: external_exports.null(),
    error: external_exports.object({
      code: external_exports.string().optional(),
      details: external_exports.unknown().optional()
    }).nullable()
  });

  // ../shared/src/applySafety.ts
  var CONSENT_VERSION = 1;
  var SESSION_BREAK_MS = 2 * 60 * 1e3;
  var STEALTH_MAX_MS = 20 * 60 * 1e3;
  var STEALTH_COOLDOWN_MS = 30 * 60 * 1e3;
  var BLOCK_COOLDOWN_MS = 60 * 60 * 1e3;
  function formatBreakCountdown(remainingMs) {
    const totalSec = Math.max(0, Math.ceil(remainingMs / 1e3));
    const min = Math.floor(totalSec / 60);
    const sec = totalSec % 60;
    return `${min}:${String(sec).padStart(2, "0")}`;
  }

  // ../shared/src/jobMeta.ts
  var EMBEDDED_LABEL_RE = /,?\s*(?:Industry Type|Department|Employment Type|Role Category|Education|Posted|Applicants?|Openings?)\s*:/i;
  function clean(value) {
    const t = value?.replace(/\s+/g, " ").trim();
    return t || void 0;
  }
  function stripEmbeddedLabels(value) {
    const t = clean(value);
    if (!t) return void 0;
    const match = t.match(EMBEDDED_LABEL_RE);
    if (match?.index != null && match.index > 0) {
      return clean(t.slice(0, match.index).replace(/,\s*$/, ""));
    }
    return t;
  }
  function splitExperienceSalary(combined) {
    const raw = clean(combined);
    if (!raw) return {};
    const glued = raw.match(
      /^(.+?(?:years?|yrs?))((?:Not\s*Disclosed)|(?:₹|[\d][\d,.]*(?:\s*-\s*[\d,.]+)?\s*(?:L(?:acs?|PA|akh)?|Cr(?:ore)?(?:\s*PA)?)))/i
    );
    if (glued) {
      return { experience: clean(glued[1]), salary: clean(glued[2]) };
    }
    return { experience: raw };
  }
  function splitPostedApplicants(combined) {
    const raw = clean(combined);
    if (!raw) return {};
    const applicants = clean(raw.match(/Applicants?\s*:\s*([^\n|]+)/i)?.[1]);
    let postedAt = clean(
      raw.match(/Posted\s*:\s*([^\n|]+)/i)?.[1] || raw.match(
        /(\d+\s*(?:day|days|hour|hours|minute|minutes|week|weeks|month|months)\s*ago)/i
      )?.[1]
    );
    if (postedAt && /Applicants?\s*:/i.test(postedAt)) {
      postedAt = clean(postedAt.replace(/Applicants?\s*:\s*.+$/i, ""));
    }
    if (postedAt || applicants) {
      return { postedAt, applicants };
    }
    return { postedAt: raw };
  }
  function sanitizeJobMetaFields(fields) {
    let experience = fields.experience ?? void 0;
    let salary = fields.salary ?? void 0;
    if (experience && !salary) {
      const split = splitExperienceSalary(experience);
      experience = split.experience ?? experience;
      salary = split.salary;
    }
    let postedAt = fields.postedAt ?? void 0;
    let applicants = fields.applicants ?? void 0;
    if (postedAt && /Applicants?\s*:/i.test(postedAt)) {
      const split = splitPostedApplicants(postedAt);
      postedAt = split.postedAt ?? postedAt;
      applicants = applicants ?? split.applicants;
    }
    return {
      experience: stripEmbeddedLabels(experience),
      salary: stripEmbeddedLabels(salary),
      postedAt: stripEmbeddedLabels(postedAt),
      openings: stripEmbeddedLabels(fields.openings),
      applicants: stripEmbeddedLabels(applicants),
      role: stripEmbeddedLabels(fields.role),
      industry: stripEmbeddedLabels(fields.industry),
      department: stripEmbeddedLabels(fields.department),
      employmentType: stripEmbeddedLabels(fields.employmentType),
      roleCategory: stripEmbeddedLabels(fields.roleCategory),
      education: stripEmbeddedLabels(fields.education)
    };
  }

  // src/adapters/types.ts
  function queryFirst(selectors, root = document) {
    for (const selector of selectors) {
      const el = root.querySelector(selector);
      if (el) return el;
    }
    return null;
  }
  function textOf(selectors, root = document) {
    const el = queryFirst(selectors, root);
    const text = el?.textContent?.trim();
    return text || void 0;
  }

  // src/adapters/naukriAdapter.ts
  var naukriSelectors = {
    title: [
      "h1.jd-header-title",
      ".jd-header .styles_jd-header-title__",
      '[class*="jd-header-title"]',
      "h1"
    ],
    company: [
      '[class*="jd-header-comp-name"] a',
      ".jd-header-comp-name a",
      ".jd-header-comp-name",
      '[class*="jd-header-comp-name"]',
      "a.comp-name"
    ],
    location: [
      ".loc span",
      ".location",
      '[class*="location"]',
      ".styles_jhc__location__"
    ],
    applySuccess: [
      ".apply-message",
      '[class*="apply-message"]',
      ".already-applied",
      '[class*="already-applied"]',
      '[class*="apply-success"]',
      '[class*="applied-success"]',
      ".apply-status-message"
    ],
    loggedIn: [
      ".nI-gNb-drawer__icon",
      ".nI-gNb-drawer",
      ".nI-gNb-icon-and-drawer",
      ".nI-gNb-info__subtxt",
      ".nI-gNb-info__name",
      "img.nI-gNb-icon-img",
      '[data-ga-track*="profile"]',
      '[data-ga-track*="Profile"]',
      ".user-name",
      '[class*="user-name"]',
      'a[href*="my.naukri.com"]',
      'a[href*="mnjuser"]',
      'a[href*="/mnj/"]',
      'a[href*="logout"]'
    ],
    // Visible Login/Register controls only — never #login_Layer alone
    // (Naukri often keeps that node in the DOM, hidden, after login).
    loggedOut: [
      "a.nI-gNb-lg-rg__login",
      "a.nI-gNb-lg-rg__register"
    ],
    easyApply: [
      "button.styles_apply-button__uJI3A",
      "button.apply-button",
      '[class*="apply-button"]',
      "button#apply-button"
    ],
    searchCards: [
      ".srp-jobtuple-wrapper",
      ".cust-job-tuple",
      "article.jobTuple",
      '[class*="jobTuple"]',
      ".styles_job-listing-container__"
    ]
  };
  var SESSION_COOKIE_NAME_HINTS = [
    /^_t_ds$/i,
    /^naukri/i,
    /^ak_bmsc$/i,
    /^BM_/i,
    /session/i,
    /^_clsk$/i,
    /^UNID$/i
  ];
  function hasNaukriSessionCookieHint(cookieString = typeof document !== "undefined" ? document.cookie : "") {
    if (!cookieString.trim()) return false;
    return cookieString.split(";").some((part) => {
      const name = part.split("=")[0]?.trim() ?? "";
      return name.length > 0 && SESSION_COOKIE_NAME_HINTS.some((re) => re.test(name));
    });
  }
  function jobIdFromUrl(url) {
    const match = url.match(/(\d{8,})(?:\?|#|$)/);
    return match?.[1];
  }
  function cleanText(value) {
    const t = value?.replace(/\s+/g, " ").trim();
    return t || void 0;
  }
  function cleanCompany(value) {
    return cleanText(value)?.replace(/\s*Reviews?.*$/i, "").trim() || "Unknown";
  }
  function isElementVisible(el) {
    if (!el || !(el instanceof HTMLElement)) return false;
    if (el.hidden || el.getAttribute("aria-hidden") === "true") return false;
    const inline = el.getAttribute("style") || "";
    if (/display\s*:\s*none/i.test(inline) || /visibility\s*:\s*hidden/i.test(inline)) {
      return false;
    }
    const view = el.ownerDocument?.defaultView;
    if (view?.getComputedStyle) {
      try {
        const cs = view.getComputedStyle(el);
        if (cs.display === "none" || cs.visibility === "hidden" || cs.opacity === "0") {
          return false;
        }
      } catch {
      }
    }
    return true;
  }
  function hasLoggedInSignal(doc) {
    if (queryFirst(naukriSelectors.loggedIn, doc)) return true;
    const avatars = Array.from(
      doc.querySelectorAll(
        '.nI-gNb-header img, .nI-gNb-gnb img, header img, [class*="drawer"] img'
      )
    );
    for (const img of avatars) {
      const src = (img.getAttribute("src") || "").toLowerCase();
      if (src.includes("profile") || src.includes("photo") || src.includes("avatar") || src.includes("ni-gnb") || /\/user|\/u\//i.test(src)) {
        return true;
      }
    }
    const nameEls = Array.from(
      doc.querySelectorAll(
        '.nI-gNb-info__subtxt, .nI-gNb-info__name, .nI-gNb-drawer span, [class*="userName"]'
      )
    );
    for (const el of nameEls) {
      const text = cleanText(el.textContent) || "";
      if (text && !/^login$/i.test(text) && !/^register$/i.test(text) && text.length >= 2 && isElementVisible(el)) {
        return true;
      }
    }
    return false;
  }
  function hasVisibleLoggedOutSignal(doc) {
    for (const selector of naukriSelectors.loggedOut) {
      const el = doc.querySelector(selector);
      if (el && isElementVisible(el)) return true;
    }
    return false;
  }
  function resolveLoginStatus(doc) {
    if (hasLoggedInSignal(doc)) return "loggedIn";
    if (hasVisibleLoggedOutSignal(doc)) return "loggedOut";
    return "uncertain";
  }
  function absoluteUrl(src) {
    if (!src || src.startsWith("data:")) return void 0;
    try {
      return new URL(src, "https://www.naukri.com").href;
    } catch {
      return void 0;
    }
  }
  function firstMatchingText(doc, selectors) {
    for (const selector of selectors) {
      const el = doc.querySelector(selector);
      const text = cleanText(el?.textContent);
      if (text) return text;
    }
    return void 0;
  }
  function uniqueStrings(values, max) {
    const seen = /* @__PURE__ */ new Set();
    const out = [];
    for (const value of values) {
      const cleaned = cleanText(value);
      if (!cleaned) continue;
      const key = cleaned.toLowerCase();
      if (seen.has(key)) continue;
      seen.add(key);
      out.push(cleaned);
      if (out.length >= max) break;
    }
    return out;
  }
  function labeledDetail(doc, labels) {
    const wanted = labels.map((l) => l.toLowerCase());
    const nodes = Array.from(
      doc.querySelectorAll(
        '[class*="details"], [class*="other-details"], [class*="job-details"], [class*="JD"], label, dt, .label, [class*="label"]'
      )
    );
    for (const node of nodes) {
      const labelText = cleanText(node.textContent)?.toLowerCase() || "";
      const matched = wanted.find((w) => labelText === w || labelText.startsWith(`${w}:`));
      if (!matched) continue;
      if (labelText.includes(":")) {
        const after = stripEmbeddedLabels(
          cleanText(node.textContent)?.split(":").slice(1).join(":")
        );
        if (after && after.length > 1) return after;
      }
      const sibling = node.nextElementSibling ?? node.parentElement?.querySelector(
        'span, a, [class*="value"], dd'
      );
      const siblingText = stripEmbeddedLabels(cleanText(sibling?.textContent));
      if (siblingText && siblingText.toLowerCase() !== matched) return siblingText;
    }
    const body = doc.body?.innerText || "";
    for (const label of labels) {
      const re = new RegExp(
        `${label}\\s*[:\\n]\\s*([^\\n]{2,120})`,
        "i"
      );
      const match = body.match(re);
      const value = stripEmbeddedLabels(cleanText(match?.[1]));
      if (value && !wanted.includes(value.toLowerCase())) return value;
    }
    return void 0;
  }
  function sectionByHeading(doc, heading, maxLen = 4e3) {
    const headings = Array.from(
      doc.querySelectorAll('h2, h3, h4, strong, [class*="title"], [class*="heading"]')
    );
    for (const h of headings) {
      const title = cleanText(h.textContent) || "";
      if (!heading.test(title)) continue;
      const parts = [];
      let el = h.nextElementSibling;
      let hops = 0;
      while (el && hops < 12) {
        const tag = el.tagName.toLowerCase();
        const text = cleanText(el.textContent);
        if ((tag === "h2" || tag === "h3" || tag === "h4") && text && text.length < 80) {
          break;
        }
        if (text) parts.push(text);
        el = el.nextElementSibling;
        hops += 1;
      }
      if (!parts.length) {
        const parent = h.parentElement;
        const block = cleanText(parent?.textContent)?.replace(title, "").trim();
        if (block) parts.push(block);
      }
      const joined = cleanText(parts.join("\n"));
      if (joined) return joined.slice(0, maxLen);
    }
    const body = doc.body?.innerText || "";
    const match = body.match(
      new RegExp(
        `${heading.source}[\\s\\S]{0,40}?\\n([\\s\\S]{20,2500}?)(?=\\n(?:Role|Industry|Department|Employment|Education|Key Skills|About company|Report this job|Job highlights|Preferred)|$)`,
        "i"
      )
    );
    return cleanText(match?.[1])?.slice(0, maxLen);
  }
  function parseHeaderStats(doc) {
    const blob = firstMatchingText(doc, [
      '[class*="stat"]',
      '[class*="posted"]',
      '[class*="jhc__"]',
      ".jd-header"
    ]) || cleanText(
      Array.from(doc.querySelectorAll('[class*="stat"], [class*="posted-by"]')).map((el) => el.textContent).join(" | ")
    ) || "";
    const bodySlice = (doc.body?.innerText || "").slice(0, 2500);
    const source = `${blob}
${bodySlice}`;
    const postedAt = cleanText(source.match(/Posted\s*:\s*([^\n|]+)/i)?.[1]) || cleanText(source.match(/(\d+\s*(?:day|days|hour|hours|minute|minutes)\s*ago)/i)?.[1]);
    const openings = cleanText(source.match(/Openings?\s*:\s*([^\n|]+)/i)?.[1]);
    const applicants = cleanText(source.match(/Applicants?\s*:\s*([^\n|]+)/i)?.[1]);
    return { postedAt, openings, applicants };
  }
  function parseRatingReviews(doc) {
    const ratingNode = doc.querySelector(
      '.rating .main-2, [class*="rating"] .main-2, [class*="amb-rating"], [class*="rating"]'
    );
    let rating = cleanText(ratingNode?.textContent)?.match(/(\d+(?:\.\d+)?)/)?.[1];
    const headerComp = doc.querySelector(
      '[class*="jd-header-comp-name"], .jd-header-comp-name, [class*="comp-name"]'
    );
    const headerText = cleanText(headerComp?.textContent) || "";
    const reviewsMatch = headerText.match(/([\d,.]+[kKmM]?\+?)\s*Reviews?/i);
    const reviews = reviewsMatch ? `${reviewsMatch[1]} Reviews` : cleanText(
      doc.querySelector('[class*="reviews"], a[href*="reviews"]')?.textContent
    );
    if (!rating) {
      rating = headerText.match(/^(\d+(?:\.\d+)?)/)?.[1];
    }
    return { rating, reviews };
  }
  function scrapeHighlights(doc) {
    const roots = Array.from(
      doc.querySelectorAll(
        '[class*="highlight"], [class*="job-highlight"], [class*="styles_highlight"]'
      )
    );
    const items = [];
    for (const root of roots) {
      const lis = root.querySelectorAll('li, p, [class*="chip"], span');
      for (const li of Array.from(lis)) {
        const text = cleanText(li.textContent);
        if (text && text.length > 12 && !/^job highlights$/i.test(text) && !/^keyskills$/i.test(text)) {
          items.push(text);
        }
      }
    }
    if (!items.length) {
      const body = doc.body?.innerText || "";
      const block = body.match(
        /Job highlights\s*([\s\S]{20,900}?)(?=\n(?:Job match|Keyskills|Location|Work Experience|Job description|Role)|$)/i
      )?.[1];
      if (block) {
        for (const line of block.split("\n")) {
          const text = cleanText(line);
          if (text && text.length > 12) items.push(text);
        }
      }
    }
    return uniqueStrings(items, 12);
  }
  function scrapeSkills(doc) {
    const fromChips = Array.from(
      doc.querySelectorAll(
        '[class*="key-skill"] a, [class*="key-skill"] span, [class*="chip"] span, .chip, [class*="skills"] a, [class*="tag-li"]'
      )
    ).map((el) => cleanText(el.textContent));
    const filtered = fromChips.filter((s) => {
      if (!s) return false;
      if (/^skills?$/i.test(s)) return false;
      if (/preferred keyskills/i.test(s)) return false;
      if (/highlighted with/i.test(s)) return false;
      if (s.length > 60) return false;
      return true;
    });
    return uniqueStrings(filtered, 40);
  }
  function scrapeFullDescription(doc) {
    const sections = [
      sectionByHeading(doc, /^role\s*&\s*responsibilities$/i, 5e3),
      sectionByHeading(doc, /^preferred candidate profile$/i, 4e3),
      sectionByHeading(doc, /^job description$/i, 6e3)
    ].filter(Boolean);
    if (sections.length) {
      return uniqueStrings(sections, 6).join("\n\n").slice(0, 1e4);
    }
    const selectors = [
      '[class*="job-desc"]',
      '[class*="styles_job-desc"]',
      "#job-description",
      '[class*="description"]',
      ".dang-inner-html"
    ];
    for (const selector of selectors) {
      const el = doc.querySelector(selector);
      const text = cleanText(el?.textContent);
      if (text && text.length > 80) return text.slice(0, 1e4);
    }
    return void 0;
  }
  function scrapeAboutCompany(doc) {
    return sectionByHeading(doc, /^about (the )?company$/i, 3500) || cleanText(
      doc.querySelector(
        '[class*="about-company"], [class*="comp-detail"], [class*="company-info"]'
      )?.textContent
    )?.slice(0, 3500);
  }
  var COMPANY_SITE_APPLY_RE = /apply\s+(on|to)\s+(the\s+)?company(\s+web)?\s*site|company[- ]site|apply\s+on\s+company\s+website|external\s+apply|apply\s+externally|continue\s+to\s+company/i;
  function isCompanySiteApplyLabel(label) {
    return COMPANY_SITE_APPLY_RE.test(label.replace(/\s+/g, " ").trim());
  }
  function detectCompanySiteApply(root) {
    const scope = root instanceof Document ? root.querySelector(
      '[class*="jd-header"], [class*="styles_jhc"], [class*="apply-button"], .jd-header, header'
    ) ?? root.body ?? root.documentElement : root;
    const controls = Array.from(
      scope.querySelectorAll('button, a, [role="button"], [class*="apply"]')
    );
    let sawCompanySite = false;
    let sawEasyApply = false;
    for (const el of controls) {
      const label = cleanText(el.textContent) || "";
      if (!label || label.length > 80) continue;
      if (isCompanySiteApplyLabel(label)) {
        sawCompanySite = true;
        continue;
      }
      const lower = label.toLowerCase();
      if (lower === "apply" || lower.includes("easy apply") || lower.includes("apply") && !/login|register|company|external|site|website/.test(lower)) {
        sawEasyApply = true;
      }
    }
    if (sawCompanySite && !sawEasyApply) return true;
    if (!(root instanceof Document)) {
      const blob = cleanText(root.innerText?.slice(0, 1500));
      if (blob && /apply\s+(on|to)\s+(the\s+)?company(\s+web)?\s*site/i.test(blob) && !/\beasy apply\b/i.test(blob) && !/(^|\n)\s*apply\s*(\n|$)/i.test(blob)) {
        return true;
      }
    }
    return false;
  }
  var NaukriAdapter = class {
    platform = "naukri";
    matches(url) {
      try {
        const u = new URL(url);
        if (u.hostname !== "www.naukri.com" && u.hostname !== "naukri.com") {
          return false;
        }
        return u.pathname.includes("/job-listings") || u.pathname.includes("/jobdescription") || /-\d+$/.test(u.pathname) || u.pathname.includes("/jobs") || /-jobs(?:\/|$)/.test(u.pathname);
      } catch {
        return false;
      }
    }
    isSearchResultsPage(url = window.location.href) {
      try {
        const u = new URL(url);
        return /-jobs(?:\/|$)/.test(u.pathname) || u.pathname.includes("/jobs-in-") || u.searchParams.has("k");
      } catch {
        return false;
      }
    }
    getLoginStatus(doc = document) {
      return resolveLoginStatus(doc);
    }
    isLoggedIn(doc = document) {
      return resolveLoginStatus(doc) === "loggedIn";
    }
    readJob(doc = document) {
      const title = textOf(naukriSelectors.title, doc);
      const company = textOf(naukriSelectors.company, doc);
      if (!title || !company) return null;
      const location = textOf(naukriSelectors.location, doc) || firstMatchingText(doc, [
        ".locWdth",
        '[class*="location"] span',
        '[class*="jhc__location"]'
      ]);
      const href = doc.location?.href ?? "";
      const externalJobId = doc.querySelector("[data-job-id]")?.getAttribute("data-job-id") ?? jobIdFromUrl(href);
      const logoEl = doc.querySelector(
        'img.logoImage, img[alt="companyLogo"], img[alt*="Company Logo" i], [class*="jd-header"] img, [class*="company-logo"] img, [class*="comp-logo"] img'
      ) ?? null;
      const companyLogo = absoluteUrl(logoEl?.getAttribute("src") || logoEl?.src);
      const experience = firstMatchingText(doc, [
        ".expwdth",
        '[class*="jhc__exp"]',
        '[class*="experience"] span',
        '[title*="experience" i]'
      ]) || void 0;
      const salary = firstMatchingText(doc, [
        ".sal",
        '[class*="jhc__salary"]',
        '[class*="salary"] span',
        '[title*="salary" i]'
      ]) || void 0;
      const { rating, reviews } = parseRatingReviews(doc);
      const { postedAt, openings, applicants } = parseHeaderStats(doc);
      const highlights = scrapeHighlights(doc);
      const skills = scrapeSkills(doc);
      const description = scrapeFullDescription(doc);
      const aboutCompany = scrapeAboutCompany(doc);
      const role = labeledDetail(doc, ["Role"]);
      const industry = labeledDetail(doc, ["Industry Type", "Industry"]);
      const department = labeledDetail(doc, ["Department"]);
      const employmentType = labeledDetail(doc, ["Employment Type"]);
      const roleCategory = labeledDetail(doc, ["Role Category"]);
      const education = labeledDetail(doc, ["Education"]) || sectionByHeading(doc, /^education$/i, 500);
      const roleClean = role && !/^role category$/i.test(role) && !/technology \/ it -/i.test(role) ? role : role && !/category/i.test(role) ? role : void 0;
      const sanitized = sanitizeJobMetaFields({
        experience: cleanText(experience),
        salary: cleanText(salary),
        postedAt,
        openings,
        applicants,
        role: roleClean || (role && !/category/i.test(role) ? role : void 0),
        industry,
        department,
        employmentType,
        roleCategory,
        education
      });
      return {
        platform: this.platform,
        title: cleanText(title) || title,
        company: cleanCompany(company),
        location: cleanText(location),
        externalJobId,
        url: href,
        companyLogo,
        description,
        experience: sanitized.experience,
        salary: sanitized.salary,
        skills: skills.length ? skills : void 0,
        rating,
        reviews,
        postedAt: sanitized.postedAt,
        openings: sanitized.openings,
        applicants: sanitized.applicants,
        highlights: highlights.length ? highlights : void 0,
        role: sanitized.role,
        industry: sanitized.industry,
        department: sanitized.department,
        employmentType: sanitized.employmentType,
        roleCategory: sanitized.roleCategory,
        education: sanitized.education,
        aboutCompany,
        status: "detected"
      };
    }
    readSearchResults(doc = document) {
      const cards = Array.from(
        doc.querySelectorAll(
          ".srp-jobtuple-wrapper, .cust-job-tuple, article.jobTuple, div.row[data-job-id], .tuple-title-wrapper, a.title"
        )
      );
      const seen = /* @__PURE__ */ new Set();
      const results = [];
      for (const card of cards) {
        const root = card.closest(
          '.srp-jobtuple-wrapper, .cust-job-tuple, article.jobTuple, div.row[data-job-id], [class*="jobTuple"]'
        ) ?? card;
        const titleEl = root.querySelector("a.title") ?? (card.tagName === "A" ? card : null);
        const title = cleanText(titleEl?.textContent);
        const href = titleEl?.href;
        if (!title || !href || !href.includes("job-listings")) continue;
        if (seen.has(href)) continue;
        seen.add(href);
        const company = cleanCompany(
          root.querySelector('a.comp-name, .comp-name, [class*="comp-name"]')?.textContent
        ) || "Unknown";
        const location = cleanText(
          root.querySelector('.locWdth, .location, [class*="location"]')?.textContent
        ) || void 0;
        const experienceText = cleanText(
          root.querySelector('.expwdth, .experience, [class*="experience"]')?.textContent
        ) || void 0;
        const salaryText = cleanText(
          root.querySelector('.sal, .salary, [class*="salary"]')?.textContent
        ) || void 0;
        const description = cleanText(root.querySelector('.job-desc, [class*="job-desc"]')?.textContent)?.slice(
          0,
          600
        ) || void 0;
        const logoEl = root.querySelector(
          'img.logoImage, img[alt="companyLogo"], .imagewrap img'
        );
        const companyLogo = absoluteUrl(logoEl?.src);
        const rating = cleanText(root.querySelector(".rating .main-2")?.textContent) || void 0;
        const reviews = cleanText(
          root.querySelector('[class*="review"], a[href*="reviews"]')?.textContent
        ) || void 0;
        const postedAt = cleanText(
          root.querySelector(
            '.job-post-day, [class*="job-post-day"], [class*="posted"]'
          )?.textContent
        ) || void 0;
        const skills = Array.from(root.querySelectorAll('.tag-li, .tag, [class*="skill"] span')).map((el) => cleanText(el.textContent)).filter((s) => Boolean(s)).slice(0, 12);
        if (detectCompanySiteApply(root)) {
          continue;
        }
        results.push({
          title,
          company,
          location,
          url: href.split("?")[0],
          externalJobId: root.getAttribute("data-job-id") ?? jobIdFromUrl(href),
          experienceText,
          salaryText,
          companyLogo,
          description,
          skills: skills.length ? skills : void 0,
          rating,
          reviews,
          postedAt,
          companySiteApply: false
        });
      }
      return results;
    }
    /** Job detail page only offers apply on the company website. */
    isCompanySiteApply(doc = document) {
      return detectCompanySiteApply(doc);
    }
    /** True when Naukri says this job was applied earlier (not a fresh apply). */
    isAlreadyApplied(doc = document) {
      const text = (doc.body?.innerText || "").toLowerCase();
      return /you have already applied/.test(text) || /already applied for this job/.test(text) || /already applied to this/.test(text);
    }
    detectApplicationStatus(doc = document) {
      const href = doc.location?.href ?? "";
      if (/\/myapply\/saveApply/i.test(href) || /\/myapply\//i.test(href) || /appliedSuccessfully|applySuccess/i.test(href)) {
        return "applied";
      }
      if (queryFirst(naukriSelectors.applySuccess, doc)) {
        return "applied";
      }
      const text = (doc.body?.innerText || "").toLowerCase();
      if (/you have successfully applied/.test(text) || /successfully applied to/.test(text) || /application (has been )?submitted/.test(text) || /you have already applied/.test(text) || /already applied for this job/.test(text) || /already applied to this/.test(text)) {
        return "applied";
      }
      return null;
    }
    findEasyApplyButton(doc = document) {
      if (this.isCompanySiteApply(doc)) return null;
      const buttons = Array.from(
        doc.querySelectorAll('button, a, [role="button"]')
      );
      for (const btn of buttons) {
        const label = (btn.textContent || "").trim().toLowerCase();
        if (!label) continue;
        if (isCompanySiteApplyLabel(label)) continue;
        if (/company site|external/.test(label)) continue;
        if (label === "apply" || label.includes("easy apply") || label.includes("apply") && !label.includes("login")) {
          if (btn.className.toLowerCase().includes("apply") || label.includes("apply")) {
            return btn;
          }
        }
      }
      return queryFirst(naukriSelectors.easyApply, doc);
    }
    /**
     * Naukri often opens a chat/Q&A drawer or shows incomplete-info banners
     * that require the user to answer before apply can succeed.
     */
    detectNeedsUserQuestions(doc = document) {
      if (this.detectApplicationStatus(doc) === "applied") {
        return null;
      }
      const text = (doc.body?.innerText || "").toLowerCase();
      if (/incomplete information/.test(text) || /answer all mandatory questions/.test(text) || /mandatory questions when reapplying/.test(text) || /please answer all mandatory/.test(text) || /application was not accepted/.test(text)) {
        return "Naukri needs mandatory questions answered";
      }
      const questionUi = doc.querySelector(
        [
          '[class*="questionnaire"]',
          '[class*="screening"]',
          '[class*="chatbot"]',
          '[class*="botContainer"]',
          '[class*="apply-form"]',
          '[class*="applyForm"]',
          '[class*="sa-container"]',
          'iframe[src*="chat"]',
          '[data-testid*="question"]'
        ].join(", ")
      );
      if (questionUi) {
        const visible = questionUi.offsetParent !== null || questionUi.getClientRects().length > 0;
        if (visible) {
          return "Naukri opened an apply questionnaire";
        }
      }
      const drawers = Array.from(
        doc.querySelectorAll(
          '[class*="drawer"], [class*="modal"], [role="dialog"], [class*="sidebar"]'
        )
      );
      for (const drawer of drawers) {
        if (drawer.offsetParent === null) continue;
        const inputs = drawer.querySelectorAll(
          'input[type="radio"], input[type="checkbox"], input[type="text"], textarea, select'
        );
        const asks = /question|experience|notice period|current ctc|expected ctc|are you/i.test(
          drawer.innerText || ""
        );
        if (inputs.length >= 2 && asks) {
          return "Naukri is asking apply questions \u2014 please answer them";
        }
      }
      return null;
    }
    hasBlockingApplyFlow(doc = document) {
      const block = this.detectNaukriBlockPage(doc);
      if (block) return block;
      const text = (doc.body?.innerText || "").toLowerCase();
      if (text.includes("login to apply") || text.includes("register to apply")) {
        return "Naukri login required";
      }
      return this.detectNeedsUserQuestions(doc);
    }
    detectNaukriBlockPage(doc = document) {
      const title = (doc.title || "").toLowerCase();
      const text = (doc.body?.innerText || "").slice(0, 8e3).toLowerCase();
      const blockPatterns = [
        /captcha/,
        /verify you are human/,
        /unusual activity/,
        /access denied/,
        /security check/,
        /challenge-page/,
        /robot check/,
        /temporarily blocked/,
        /suspicious activity/
      ];
      if (blockPatterns.some((p) => p.test(title) || p.test(text))) {
        return "Naukri verification or block page detected";
      }
      const challengeSelectors = [
        'iframe[src*="captcha"]',
        'iframe[src*="challenge"]',
        '[class*="captcha"]',
        '[id*="captcha"]',
        "#challenge-form",
        ".cf-browser-verification",
        '[data-testid*="captcha"]'
      ].join(", ");
      const challenge = doc.querySelector(challengeSelectors);
      if (challenge) {
        const el = challenge;
        if (el.offsetParent !== null || el.getClientRects().length > 0) {
          return "Naukri verification or block page detected";
        }
      }
      return null;
    }
    clickNextSearchPage(doc = document) {
      const nodes = Array.from(
        doc.querySelectorAll(
          'a, button, [role="button"], [class*="pagination"] a, [class*="Pagination"] a'
        )
      );
      const next = nodes.find((el) => {
        const text = (el.textContent || "").replace(/\s+/g, " ").trim();
        const aria = (el.getAttribute("aria-label") || "").toLowerCase();
        const title = (el.getAttribute("title") || "").toLowerCase();
        if (/^next$/i.test(text) || /^›$|^>$/.test(text)) return true;
        if (aria.includes("next") || title.includes("next")) return true;
        if (/^next\b/i.test(text) && text.length < 12) return true;
        return false;
      });
      if (!next) {
        return { ok: false, reason: "Next page control not found" };
      }
      const disabled = next.getAttribute("disabled") != null || next.getAttribute("aria-disabled") === "true" || /disabled|inactive/i.test(next.className);
      if (disabled) {
        return { ok: false, reason: "Already on the last page" };
      }
      next.click();
      return { ok: true };
    }
    /** Bump Naukri search URL to the next results page when Next click fails. */
    nextSearchPageUrl(currentUrl) {
      try {
        const u = new URL(currentUrl);
        const pageQ = u.searchParams.get("page");
        if (pageQ && /^\d+$/.test(pageQ)) {
          u.searchParams.set("page", String(Number(pageQ) + 1));
          return u.toString();
        }
        const m = u.pathname.match(/^(.*?)(?:-(\d+))?$/);
        if (m) {
          const base = m[1];
          const n = m[2] ? Number(m[2]) : 1;
          u.pathname = `${base}-${n + 1}`;
          return u.toString();
        }
        return null;
      } catch {
        return null;
      }
    }
  };

  // src/adapters/index.ts
  var StubAdapter = class {
    constructor(platform, hostIncludes) {
      this.platform = platform;
      this.hostIncludes = hostIncludes;
    }
    matches(url) {
      return url.includes(this.hostIncludes);
    }
    isLoggedIn() {
      return false;
    }
    readJob() {
      return null;
    }
    detectApplicationStatus() {
      return null;
    }
  };
  var adapters = [
    new NaukriAdapter(),
    new StubAdapter("linkedin", "linkedin.com"),
    new StubAdapter("foundit", "foundit.in"),
    new StubAdapter("indeed", "indeed.com"),
    new StubAdapter("wellfound", "wellfound.com"),
    new StubAdapter("internshala", "internshala.com")
  ];
  function resolveAdapter(url) {
    return adapters.find((a) => a.matches(url)) ?? null;
  }

  // src/core/logger.ts
  var logger = {
    debug: (message, meta) => console.debug("[Cosmo]", message, meta ?? ""),
    info: (message, meta) => console.info("[Cosmo]", message, meta ?? ""),
    warn: (message, meta) => console.warn("[Cosmo]", message, meta ?? ""),
    error: (message, meta) => console.error("[Cosmo]", message, meta ?? "")
  };

  // src/core/copilotState.ts
  var STATE_KEY = "copilotState";
  var DEFAULT_COPILOT_STATE = {
    running: false,
    paused: false,
    runInBackground: false,
    needsLogin: false,
    loginPauseReason: null,
    keyword: "",
    matched: 0,
    applied: 0,
    skipped: 0,
    appliesThisSession: 0,
    stealthAppliesThisSession: 0,
    stealthStartedAt: null,
    sessionBreakUntil: null,
    sessionBreakRemainingMs: null,
    paceLabel: null,
    paceRemainingMs: null,
    sessionComplete: null,
    alert: null,
    toast: null,
    scannedJobs: []
  };
  async function getCopilotState() {
    const data = await chrome.storage.local.get(STATE_KEY);
    return {
      ...DEFAULT_COPILOT_STATE,
      ...data[STATE_KEY] ?? {},
      scannedJobs: data[STATE_KEY]?.scannedJobs ?? []
    };
  }
  function countsFromJobs(jobs) {
    let applied = 0;
    let skipped = 0;
    for (const job of jobs) {
      if (job.status === "applied") applied += 1;
      else if (job.status === "skipped" || job.status === "already_applied") {
        skipped += 1;
      }
    }
    return { matched: jobs.length, applied, skipped };
  }
  var stateWriteChain = Promise.resolve();
  async function commitCopilotState(updater) {
    const run = async () => {
      const current = await getCopilotState();
      const partial = updater(current);
      const next = { ...current, ...partial };
      if (partial.scannedJobs) {
        Object.assign(next, countsFromJobs(partial.scannedJobs));
      }
      await chrome.storage.local.set({ [STATE_KEY]: next });
      return next;
    };
    const result = stateWriteChain.then(run, run);
    stateWriteChain = result.then(
      () => void 0,
      () => void 0
    );
    return result;
  }
  async function setCopilotState(partial) {
    return commitCopilotState(() => partial);
  }
  async function clearCopilotToast() {
    await setCopilotState({ toast: null });
  }

  // src/shared/cosmosLogo.ts
  function cosmosLogoSvg(size = 24, className = "cosmos-logo") {
    return `<svg class="${className}" width="${size}" height="${size}" viewBox="0 0 24 24" role="img" aria-label="Cosmo" fill="none">
  <path fill="currentColor" d="M12 8.145c1.715 0 3.107-1.375 3.107-3.072S13.717 2 12 2 8.893 3.375 8.893 5.072 10.283 8.145 12 8.145M12 22c1.715 0 3.107-1.375 3.107-3.072s-1.39-3.073-3.107-3.073-3.107 1.376-3.107 3.073S10.283 22 12 22M6.004 11.646c1.716 0 3.107-1.375 3.107-3.072S7.721 5.5 6.004 5.5 2.897 6.877 2.897 8.575s1.39 3.072 3.107 3.072M17.996 18.492c1.715 0 3.107-1.375 3.107-3.072s-1.39-3.073-3.107-3.073-3.107 1.376-3.107 3.073 1.39 3.072 3.107 3.072M17.996 11.646c1.715 0 3.107-1.374 3.107-3.072s-1.39-3.072-3.107-3.072-3.107 1.374-3.107 3.072 1.39 3.072 3.107 3.072M6.004 18.492c1.716 0 3.107-1.375 3.107-3.073s-1.39-3.072-3.107-3.072-3.107 1.378-3.107 3.074 1.39 3.072 3.107 3.072z"></path>
</svg>`;
  }

  // src/shared/actionIcons.ts
  var PAUSE_SVG = `
<svg viewBox="0 0 24 24" aria-hidden="true" class="cosmo-fi-icon cosmo-fi-pause">
  <rect x="6" y="5" width="4" height="14" rx="1.5" fill="currentColor"/>
  <rect x="14" y="5" width="4" height="14" rx="1.5" fill="currentColor"/>
</svg>`;
  var PLAY_SVG = `
<svg viewBox="0 0 24 24" aria-hidden="true" class="cosmo-fi-icon cosmo-fi-play">
  <path fill="currentColor" d="M8.2 5.4c-.7-.4-1.5.1-1.5.9v11.4c0 .8.8 1.3 1.5.9l9.6-5.7c.7-.4.7-1.4 0-1.8L8.2 5.4z"/>
</svg>`;
  var STOP_SVG = `
<svg viewBox="0 0 24 24" aria-hidden="true" class="cosmo-fi-icon cosmo-fi-stop">
  <rect x="6.2" y="6.2" width="11.6" height="11.6" rx="2.8" fill="currentColor"/>
</svg>`;
  var MINIMIZE_SVG = `
<svg viewBox="0 0 24 24" aria-hidden="true" class="cosmo-fi-icon cosmo-fi-minimize">
  <rect x="5" y="11" width="14" height="2.2" rx="1.1" fill="currentColor"/>
</svg>`;
  function mountPauseIcon(host) {
    host.innerHTML = PAUSE_SVG;
  }
  function mountPlayIcon(host) {
    host.innerHTML = PLAY_SVG;
  }
  function mountStopIcon(host) {
    host.innerHTML = STOP_SVG;
  }
  function mountMinimizeIcon(host) {
    host.innerHTML = MINIMIZE_SVG;
  }
  function runningVideoHtml(src) {
    return `
    <span class="run-anim run-anim--video" aria-hidden="true">
      <video src="${src}" autoplay muted loop playsinline preload="auto"></video>
    </span>
    <span class="run-label">Running<span class="run-dots" aria-hidden="true"><i>.</i><i>.</i><i>.</i></span></span>
  `;
  }

  // src/content/copilotPanel.ts
  var ROOT_ID = "cosmo-copilot-root";
  var naukri = new NaukriAdapter();
  var NAUKRI_LOGIN_URL = "https://www.naukri.com/nlogin/login";
  function statusLabel(status, skipReason) {
    switch (status) {
      case "pending":
        return "Queued";
      case "applying":
        return "Opening";
      case "applied":
        return "Applied";
      case "already_applied":
        return "Already";
      case "skipped":
        return /company site/i.test(skipReason || "") ? "Manual" : "Skipped";
      default:
        return status;
    }
  }
  function mountCopilotPanel() {
    if (document.getElementById(ROOT_ID)) return;
    const root = document.createElement("div");
    root.id = ROOT_ID;
    root.innerHTML = `
    <style>
      #${ROOT_ID} {
        all: initial;
        position: fixed;
        inset: 0;
        z-index: 2147483646;
        pointer-events: none;
        font-family: "IBM Plex Sans", "Segoe UI", system-ui, sans-serif;
        --cosmo-bg: #f4f4f5;
        --cosmo-panel: #ffffff;
        --cosmo-elevated: #f4f4f5;
        --cosmo-line: #e4e4e7;
        --cosmo-text: #18181b;
        --cosmo-muted: #71717a;
        --cosmo-accent: #18181b;
        --cosmo-accent-ink: #ffffff;
        --cosmo-dim: rgba(24,24,27,.06);
        --cosmo-warn: #b45309;
        --cosmo-danger: #b91c1c;
        --cosmo-success: #15803d;
        --cosmo-skip: #a16207;
      }
      #${ROOT_ID} * { box-sizing: border-box; font-family: inherit; }
      #${ROOT_ID} .cosmo-dock {
        pointer-events: auto;
        position: fixed;
        left: 16px;
        bottom: 16px;
        width: 400px;
      }
      #${ROOT_ID} .cosmo-panel {
        width: 100%;
        max-height: min(600px, calc(100vh - 32px));
        display: grid;
        grid-template-rows: auto auto auto auto auto auto minmax(0, 1fr) auto;
        grid-template-areas:
          "head"
          "stats"
          "meta"
          "safety"
          "now"
          "notice"
          "jobs"
          "footer";
        background: var(--cosmo-panel);
        color: var(--cosmo-text);
        border: 1px solid var(--cosmo-line);
        border-radius: 16px;
        box-shadow:
          0 18px 40px rgba(24,24,27,.14),
          0 0 0 1px rgba(24,24,27,.04);
        overflow: hidden;
        animation: cosmo-panel-in .28s ease-out;
      }
      #${ROOT_ID} .cosmo-head { grid-area: head; }
      #${ROOT_ID} .cosmo-stats { grid-area: stats; }
      #${ROOT_ID} .cosmo-meta { grid-area: meta; }
      #${ROOT_ID} .cosmo-safety { grid-area: safety; }
      #${ROOT_ID} .cosmo-now { grid-area: now; }
      #${ROOT_ID} .cosmo-notice { grid-area: notice; }
      #${ROOT_ID} .cosmo-section { grid-area: jobs; }
      #${ROOT_ID} .cosmo-footer { grid-area: footer; }
      @keyframes cosmo-panel-in {
        from { opacity: 0; transform: translateY(10px) scale(.98); }
        to { opacity: 1; transform: none; }
      }
      #${ROOT_ID} .cosmo-head {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
        padding: 10px 12px 8px;
      }
      #${ROOT_ID} .cosmo-brand {
        display: flex;
        align-items: center;
        gap: 8px;
        min-width: 0;
        flex: 1 1 auto;
        cursor: grab;
        user-select: none;
        touch-action: none;
      }
      #${ROOT_ID} .cosmo-brand:active {
        cursor: grabbing;
      }
      #${ROOT_ID}.is-dragging .cosmo-brand {
        cursor: grabbing;
      }
      #${ROOT_ID}.is-dragging .cosmo-panel {
        box-shadow:
          0 22px 48px rgba(24,24,27,.22),
          0 0 0 1px rgba(24,24,27,.06);
      }
      #${ROOT_ID} .cosmo-brand .cosmo-cosmos-logo {
        width: 22px;
        height: 22px;
        flex-shrink: 0;
        color: var(--cosmo-text);
        transform-box: fill-box;
        transform-origin: center;
        transition: color .2s ease;
      }
      #${ROOT_ID}.is-running .cosmo-brand .cosmo-cosmos-logo {
        animation: cosmo-logo-spin 1.6s ease-in-out infinite;
      }
      #${ROOT_ID}.is-paused .cosmo-brand .cosmo-cosmos-logo {
        color: var(--cosmo-text);
        animation: none;
      }
      #${ROOT_ID}:not(.is-running) .cosmo-brand:hover .cosmo-cosmos-logo {
        animation: cosmo-logo-hover 1.2s ease-in-out infinite;
      }
      @keyframes cosmo-logo-spin {
        0%, 100% { transform: scale(1) rotate(0deg); }
        50% { transform: scale(1.08) rotate(180deg); }
      }
      @keyframes cosmo-logo-hover {
        0% { transform: scale(1) rotate(0deg); }
        50% { transform: scale(1.2) rotate(180deg); }
        100% { transform: scale(1) rotate(360deg); }
      }
      #${ROOT_ID} .cosmo-brand-copy {
        display: grid;
        gap: 1px;
        min-width: 0;
        flex: 1 1 auto;
      }
      #${ROOT_ID} .cosmo-brand-text {
        font-weight: 750;
        font-size: 12px;
        letter-spacing: 0.04em;
        line-height: 1.15;
        color: #18181b;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
      #${ROOT_ID} .cosmo-brand-sub {
        font-size: 10px;
        color: var(--cosmo-muted);
        letter-spacing: 0.02em;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
      #${ROOT_ID} .cosmo-actions {
        display: flex;
        gap: 4px;
        align-items: center;
        flex-shrink: 0;
        max-width: 58%;
      }
      #${ROOT_ID} .cosmo-actions-run {
        display: flex;
        gap: 4px;
        align-items: center;
        min-width: 0;
      }
      #${ROOT_ID} button {
        border: 0;
        border-radius: 9px;
        padding: 6px 9px;
        font-size: 11px;
        font-weight: 650;
        cursor: pointer;
        transition: transform .12s ease, filter .12s ease, background .15s ease;
      }
      #${ROOT_ID} button:disabled {
        opacity: .45;
        cursor: not-allowed;
        transform: none !important;
      }
      #${ROOT_ID} button:not(:disabled):hover { filter: brightness(1.06); }
      #${ROOT_ID} button:not(:disabled):active { transform: translateY(1px); }
      #${ROOT_ID} .btn-start {
        background: #16a34a;
        color: #ffffff;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 5px;
        min-width: 0;
        padding: 6px 10px;
      }
      #${ROOT_ID} .btn-start:disabled {
        background: #86efac;
        color: #14532d;
        opacity: 1;
      }
      #${ROOT_ID} .btn-start.is-running {
        background: #16a34a;
        color: #ffffff;
      }
      #${ROOT_ID} .btn-start .run-anim {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 22px;
        height: 22px;
        flex-shrink: 0;
        overflow: hidden;
        border-radius: 50%;
        background: #ffffff;
      }
      #${ROOT_ID} .btn-start .run-anim svg {
        width: 16px;
        height: 16px;
        display: block;
        animation: cosmo-runner-cycle 0.45s ease-in-out infinite;
      }
      #${ROOT_ID} .btn-start .run-anim--video {
        width: 22px;
        height: 22px;
      }
      #${ROOT_ID} .btn-start .run-anim--video video {
        width: 22px;
        height: 22px;
        object-fit: contain;
        display: block;
        background: #ffffff;
        border-radius: 50%;
      }
      #${ROOT_ID} .btn-start .run-label {
        display: inline-flex;
        align-items: baseline;
      }
      #${ROOT_ID} .btn-start .run-dots {
        display: inline-flex;
        width: 1.1em;
        letter-spacing: 0.02em;
      }
      #${ROOT_ID} .btn-start .run-dots i {
        font-style: normal;
        opacity: 0;
        animation: cosmo-run-dot 1.2s infinite;
      }
      #${ROOT_ID} .btn-start .run-dots i:nth-child(1) { animation-delay: 0s; }
      #${ROOT_ID} .btn-start .run-dots i:nth-child(2) { animation-delay: 0.2s; }
      #${ROOT_ID} .btn-start .run-dots i:nth-child(3) { animation-delay: 0.4s; }
      @keyframes cosmo-runner-cycle {
        0% { transform: translateX(0) translateY(0) rotate(-8deg); }
        50% { transform: translateX(1.5px) translateY(-1.5px) rotate(8deg); }
        100% { transform: translateX(0) translateY(0) rotate(-8deg); }
      }
      @keyframes cosmo-run-dot {
        0%, 20% { opacity: 0; }
        40%, 100% { opacity: 1; }
      }
      #${ROOT_ID} .btn-pause,
      #${ROOT_ID} .btn-stop {
        width: 32px;
        min-width: 32px;
        height: 32px;
        padding: 0;
        display: inline-grid;
        place-items: center;
        line-height: 0;
        border: 0 !important;
        box-shadow: none;
        outline: none;
        -webkit-appearance: none;
        appearance: none;
        background: transparent !important;
      }
      #${ROOT_ID} .btn-pause {
        color: #b45309;
      }
      #${ROOT_ID} .btn-stop {
        color: #b91c1c;
      }
      #${ROOT_ID} .btn-pause:not(:disabled):hover {
        background: rgba(251, 191, 36, 0.22) !important;
      }
      #${ROOT_ID} .btn-stop:not(:disabled):hover {
        background: rgba(248, 113, 113, 0.18) !important;
      }
      #${ROOT_ID} .btn-pause .cosmo-fi-icon,
      #${ROOT_ID} .btn-stop .cosmo-fi-icon {
        width: 18px;
        height: 18px;
        display: block;
        fill: currentColor;
      }
      #${ROOT_ID} .cosmo-fi-icon {
        width: 18px;
        height: 18px;
        display: block;
        transition: transform .2s ease;
      }
      #${ROOT_ID} .btn-pause:not(:disabled):hover .cosmo-fi-icon,
      #${ROOT_ID} .btn-stop:not(:disabled):hover .cosmo-fi-icon,
      #${ROOT_ID} .btn-icon:not(:disabled):hover .cosmo-fi-icon {
        transform: scale(1.12);
        animation: cosmo-fi-bob .55s ease-in-out infinite;
      }
      @keyframes cosmo-fi-bob {
        0%, 100% { transform: scale(1.08) translateY(0); }
        50% { transform: scale(1.14) translateY(-1px); }
      }
      #${ROOT_ID} .btn-icon {
        width: 32px;
        height: 32px;
        padding: 0;
        display: inline-grid;
        place-items: center;
        background: transparent !important;
        color: #1e3a8a;
        border: 0 !important;
        box-shadow: none;
        border-radius: 9px;
        font-size: 18px;
        font-weight: 700;
        line-height: 1;
        transition: color .15s ease, background .15s ease;
      }
      #${ROOT_ID} .btn-icon:hover {
        color: #1e3a8a;
        background: rgba(147, 197, 253, 0.28) !important;
      }
      #${ROOT_ID} .cosmo-stats {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 6px;
        padding: 0 12px 8px;
      }
      #${ROOT_ID} .stat {
        background: #f4f4f5;
        border: 1px solid #e4e4e7;
        border-radius: 10px;
        padding: 7px 6px 6px;
        text-align: center;
      }
      #${ROOT_ID} .stat-n {
        display: block;
        font-size: 16px;
        font-weight: 750;
        font-variant-numeric: tabular-nums;
        line-height: 1.1;
        color: var(--cosmo-text);
      }
      #${ROOT_ID} .stat-l {
        display: block;
        margin-top: 2px;
        font-size: 10px;
        font-weight: 600;
        letter-spacing: 0.04em;
        text-transform: uppercase;
        color: var(--cosmo-muted);
      }
      #${ROOT_ID} .stat--applied .stat-n { color: var(--cosmo-success); }
      #${ROOT_ID} .stat--skipped .stat-n { color: var(--cosmo-skip); }
      #${ROOT_ID} .cosmo-meta {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 8px;
        padding: 0 12px 8px;
        font-size: 11px;
        color: var(--cosmo-muted);
      }
      #${ROOT_ID} .toggle {
        display: inline-flex;
        align-items: center;
        gap: 7px;
        cursor: pointer;
        user-select: none;
      }
      #${ROOT_ID} .toggle input {
        accent-color: var(--cosmo-accent);
        width: 13px;
        height: 13px;
      }
      #${ROOT_ID} .cosmo-now {
        display: none;
        margin: 0 12px 8px;
        padding: 8px 10px;
        border-radius: 10px;
        background: var(--cosmo-dim);
        border: 1px solid var(--cosmo-line);
        font-size: 12px;
        line-height: 1.35;
        color: var(--cosmo-text);
      }
      #${ROOT_ID} .cosmo-now.show { display: block; }
      #${ROOT_ID} .cosmo-now strong {
        display: block;
        font-size: 10px;
        letter-spacing: 0.05em;
        text-transform: uppercase;
        color: var(--cosmo-muted);
        margin-bottom: 2px;
        font-weight: 700;
      }
      #${ROOT_ID} .cosmo-section {
        min-height: 0;
        display: grid;
        grid-template-rows: auto minmax(0, 1fr);
        border-top: 1px solid var(--cosmo-line);
        overflow: hidden;
      }
      #${ROOT_ID} .cosmo-section-head {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 8px 12px 6px;
        font-size: 10px;
        font-weight: 700;
        letter-spacing: 0.06em;
        text-transform: uppercase;
        color: var(--cosmo-muted);
        background: var(--cosmo-panel);
        position: relative;
        z-index: 1;
      }
      #${ROOT_ID} .cosmo-jobs {
        overflow: auto;
        padding: 0 8px 8px;
        display: grid;
        gap: 5px;
        align-content: start;
        min-height: 0;
        max-height: 220px;
        scrollbar-width: thin;
        scrollbar-color: #d4d4d8 transparent;
      }
      #${ROOT_ID} .job-row {
        display: grid;
        grid-template-columns: minmax(0, 1fr) max-content;
        gap: 8px;
        align-items: center;
        padding: 8px 9px;
        border-radius: 10px;
        background: #fafafa;
        border: 1px solid #ececef;
        font-size: 12px;
        line-height: 1.3;
        transition: background .15s ease, border-color .15s ease, box-shadow .15s ease;
      }
      #${ROOT_ID} .job-row:hover {
        background: #f4f4f5;
        border-color: #e4e4e7;
      }
      #${ROOT_ID} .job-row.applying {
        background: #eff6ff;
        border-color: #93c5fd;
        box-shadow:
          0 0 0 2px rgba(37,99,235,.12),
          0 6px 16px rgba(37,99,235,.1);
        animation: cosmo-job-pulse 1.8s ease-in-out infinite;
      }
      #${ROOT_ID} .job-row.applying .job-title {
        color: #1e3a8a;
      }
      @keyframes cosmo-job-pulse {
        0%, 100% { box-shadow: 0 0 0 2px rgba(37,99,235,.12), 0 6px 16px rgba(37,99,235,.08); }
        50% { box-shadow: 0 0 0 3px rgba(37,99,235,.22), 0 8px 18px rgba(37,99,235,.14); }
      }
      #${ROOT_ID} .job-title {
        font-weight: 650;
        font-size: 12px;
        color: var(--cosmo-text);
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      #${ROOT_ID} .job-company {
        margin-top: 1px;
        color: var(--cosmo-muted);
        font-size: 11px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      #${ROOT_ID} .job-badge {
        font-size: 10px;
        font-weight: 700;
        letter-spacing: 0.02em;
        padding: 3px 7px;
        border-radius: 999px;
        white-space: nowrap;
        flex-shrink: 0;
        min-width: max-content;
        max-width: none;
        overflow: visible;
        background: var(--cosmo-elevated);
        color: var(--cosmo-muted);
      }
      #${ROOT_ID} .job-badge.pending {
        background: rgba(124, 58, 237, 0.12);
        color: #6d28d9;
      }
      #${ROOT_ID} .job-badge.applied { background: rgba(22,163,74,.14); color: var(--cosmo-success); }
      #${ROOT_ID} .job-badge.skipped,
      #${ROOT_ID} .job-badge.already_applied { background: rgba(202,138,4,.16); color: var(--cosmo-skip); }
      #${ROOT_ID} .job-badge.applying {
        background: #2563eb;
        color: #ffffff;
        box-shadow: 0 0 0 1px rgba(37,99,235,.25);
      }
      #${ROOT_ID} .cosmo-notice {
        display: none;
        margin: 0 12px 8px;
        padding: 8px 10px;
        font-size: 12px;
        line-height: 1.4;
        background: var(--cosmo-elevated);
        color: var(--cosmo-text);
        border: 1px solid var(--cosmo-line);
        border-radius: 10px;
      }
      #${ROOT_ID} .cosmo-notice.show { display: block; }
      #${ROOT_ID} .cosmo-notice.flash {
        animation: cosmo-copilot-flash 1s ease-in-out 4;
      }
      #${ROOT_ID} .cosmo-notice.is-alert { font-weight: 650; }
      #${ROOT_ID} .cosmo-safety {
        margin: 0 12px 8px;
        padding: 7px 9px;
        font-size: 11px;
        font-weight: 650;
        color: #1e3a8a;
        line-height: 1.35;
        background: #eff6ff;
        border: 1px solid #bfdbfe;
        border-radius: 10px;
        box-shadow: 0 0 0 1px rgba(37,99,235,.06);
      }
      #${ROOT_ID} .cosmo-safety.is-active {
        animation: cosmo-safety-glow 2s ease-in-out infinite;
      }
      @keyframes cosmo-safety-glow {
        0%, 100% { border-color: #bfdbfe; box-shadow: 0 0 0 1px rgba(37,99,235,.06); }
        50% { border-color: #93c5fd; box-shadow: 0 0 0 2px rgba(37,99,235,.14); }
      }
      @keyframes cosmo-copilot-flash {
        0%, 100% { filter: brightness(1); }
        50% { filter: brightness(1.25); }
      }
      #${ROOT_ID} .cosmo-empty {
        color: var(--cosmo-muted);
        font-size: 12px;
        padding: 12px 10px;
        text-align: center;
        line-height: 1.45;
      }
      #${ROOT_ID} .cosmo-footer {
        border-top: 1px solid var(--cosmo-line);
        padding: 10px 12px 12px;
        text-align: center;
      }
      #${ROOT_ID} .cosmo-footer a {
        display: inline-flex;
        flex-direction: column;
        align-items: center;
        gap: 4px;
        color: var(--cosmo-muted);
        font-size: 10px;
        font-weight: 500;
        letter-spacing: 0.02em;
        text-decoration: none;
        text-transform: lowercase;
        transition: color .15s ease;
      }
      #${ROOT_ID} .cosmo-footer a:hover {
        color: var(--cosmo-text);
      }
      #${ROOT_ID} .cosmo-footer img {
        display: block;
        width: 132px;
        height: auto;
      }
      #${ROOT_ID}.collapsed .cosmo-dock {
        width: auto;
      }
      #${ROOT_ID}.collapsed .cosmo-panel {
        width: auto;
        max-height: none;
        grid-template-rows: auto;
        grid-template-areas: "head";
        animation: none;
        border-radius: 18px;
      }
      #${ROOT_ID}.collapsed .cosmo-actions-run,
      #${ROOT_ID}.collapsed .cosmo-brand-copy,
      #${ROOT_ID}.collapsed .cosmo-stats,
      #${ROOT_ID}.collapsed .cosmo-meta,
      #${ROOT_ID}.collapsed .cosmo-safety,
      #${ROOT_ID}.collapsed .cosmo-now,
      #${ROOT_ID}.collapsed .cosmo-section,
      #${ROOT_ID}.collapsed .cosmo-footer,
      #${ROOT_ID}.collapsed .cosmo-notice,
      #${ROOT_ID}.collapsed .cosmo-modal,
      #${ROOT_ID}.collapsed #cosmo-minimize { display: none !important; }
      #${ROOT_ID}.collapsed .cosmo-head {
        padding: 14px 16px;
        gap: 0;
        cursor: grab;
        user-select: none;
        touch-action: none;
      }
      #${ROOT_ID}.collapsed .cosmo-head:active {
        cursor: grabbing;
      }
      #${ROOT_ID}.collapsed .cosmo-actions {
        display: none !important;
      }
      #${ROOT_ID}.collapsed .cosmo-brand {
        pointer-events: none;
      }
      #${ROOT_ID}.collapsed .cosmo-brand .cosmo-cosmos-logo {
        color: #18181b;
        width: 42px;
        height: 42px;
        transition: transform 0.2s ease;
      }
      #${ROOT_ID}.collapsed .cosmo-head:hover .cosmo-cosmos-logo {
        animation: cosmo-logo-hover 1s ease-in-out infinite;
      }
      #${ROOT_ID}.collapsed.is-dragging .cosmo-head {
        cursor: grabbing;
      }
      #${ROOT_ID} .cosmo-modal {
        display: none;
        position: absolute;
        left: 0;
        right: 0;
        bottom: calc(100% + 10px);
        z-index: 2;
        background: transparent;
        padding: 0;
        pointer-events: none;
      }
      #${ROOT_ID} .cosmo-modal.show { display: block; }
      #${ROOT_ID} .cosmo-modal-card {
        width: 100%;
        background: var(--cosmo-bg);
        color: var(--cosmo-text);
        border: 1px solid var(--cosmo-line);
        border-radius: 14px;
        padding: 16px;
        box-shadow: 0 16px 40px rgba(24,24,27,.16);
        display: grid;
        gap: 10px;
        pointer-events: auto;
      }
      #${ROOT_ID} .cosmo-modal-card h3 {
        margin: 0;
        font-size: 15px;
        font-weight: 700;
      }
      #${ROOT_ID} .cosmo-modal-card p {
        margin: 0;
        font-size: 13px;
        color: var(--cosmo-muted);
        line-height: 1.4;
      }
      #${ROOT_ID} .cosmo-modal-actions { display: grid; gap: 8px; }
      #${ROOT_ID} .btn-login {
        background: var(--cosmo-accent);
        color: var(--cosmo-accent-ink);
        width: 100%;
        padding: 10px 12px;
      }
      #${ROOT_ID} .btn-resume-login {
        background: var(--cosmo-elevated);
        color: var(--cosmo-text);
        border: 1px solid var(--cosmo-line) !important;
        width: 100%;
        padding: 10px 12px;
      }
      #${ROOT_ID} .cosmo-toast-host {
        pointer-events: none;
        position: fixed;
        top: 16px;
        right: 16px;
        left: auto;
        bottom: auto;
        z-index: 2147483647;
        display: grid;
        gap: 8px;
        width: min(420px, calc(100vw - 32px));
      }
      #${ROOT_ID} .cosmo-toast {
        pointer-events: auto;
        display: grid;
        grid-template-columns: auto 1fr auto;
        gap: 10px;
        align-items: start;
        padding: 12px 12px 12px 14px;
        border-radius: 12px;
        background: var(--cosmo-panel);
        color: var(--cosmo-text);
        border: 1px solid var(--cosmo-line);
        box-shadow:
          0 16px 36px rgba(24,24,27,.16),
          0 0 0 1px rgba(24,24,27,.04);
        animation: cosmo-toast-in .28s ease-out;
      }
      #${ROOT_ID} .cosmo-toast.is-out {
        animation: cosmo-toast-out .22s ease-in forwards;
      }
      @keyframes cosmo-toast-in {
        from { opacity: 0; transform: translateY(-8px) translateX(8px); }
        to { opacity: 1; transform: none; }
      }
      @keyframes cosmo-toast-out {
        to { opacity: 0; transform: translateY(-6px) translateX(6px); }
      }
      #${ROOT_ID} .cosmo-toast-icon {
        width: 28px;
        height: 28px;
        border-radius: 50%;
        display: grid;
        place-items: center;
        background: rgba(22,163,74,.12);
        color: var(--cosmo-success);
        font-size: 14px;
        font-weight: 800;
        line-height: 1;
        margin-top: 1px;
      }
      #${ROOT_ID} .cosmo-toast.is-pace .cosmo-toast-icon {
        background: rgba(202,138,4,.14);
        color: #b45309;
        font-size: 13px;
      }
      #${ROOT_ID} .cosmo-toast.is-pace {
        border-color: #fcd34d;
        background: #fffbeb;
      }
      #${ROOT_ID} .cosmo-toast-countdown {
        font-variant-numeric: tabular-nums;
        font-weight: 750;
        color: #b45309;
        font-size: 13px;
        line-height: 1.2;
        margin-top: 1px;
        min-width: 2.4em;
        text-align: right;
      }
      #${ROOT_ID} .cosmo-toast-copy {
        min-width: 0;
      }
      #${ROOT_ID} .cosmo-toast-title {
        margin: 0;
        font-size: 13px;
        font-weight: 750;
        color: var(--cosmo-text);
        line-height: 1.25;
      }
      #${ROOT_ID} .cosmo-toast-msg {
        margin: 3px 0 0;
        font-size: 12px;
        color: var(--cosmo-muted);
        line-height: 1.35;
        overflow: hidden;
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
      }
      #${ROOT_ID} .cosmo-toast-close {
        width: 24px;
        height: 24px;
        padding: 0;
        border-radius: 7px;
        background: transparent;
        color: var(--cosmo-muted);
        border: 0 !important;
        font-size: 14px;
        line-height: 1;
      }
      #${ROOT_ID} .cosmo-toast-close:hover {
        color: var(--cosmo-text);
        background: rgba(24,24,27,.06);
      }
      #${ROOT_ID}.collapsed .cosmo-toast-host { display: grid !important; }
    </style>
    <div class="cosmo-toast-host" id="cosmo-toast-host" aria-live="polite"></div>
    <div class="cosmo-dock">
    <div class="cosmo-panel">
      <div class="cosmo-head">
        <div class="cosmo-brand">
          ${cosmosLogoSvg(22, "cosmo-cosmos-logo")}
          <div class="cosmo-brand-copy">
            <span class="cosmo-brand-text">COSMO CO-PILOT</span>
            <span class="cosmo-brand-sub" id="cosmo-status-label">Idle \u2014 press Start</span>
          </div>
        </div>
        <div class="cosmo-actions">
          <div class="cosmo-actions-run">
            <button type="button" class="btn-start" id="cosmo-start">Start</button>
            <button type="button" class="btn-pause" id="cosmo-pause" title="Pause" aria-label="Pause"></button>
            <button type="button" class="btn-stop" id="cosmo-stop" title="Stop" aria-label="Stop"></button>
          </div>
          <button
            type="button"
            class="btn-icon"
            id="cosmo-minimize"
            title="Minimize"
            aria-label="Minimize co-pilot"
          ></button>
        </div>
      </div>
      <div class="cosmo-stats" id="cosmo-stats" aria-label="Session stats">
        <div class="stat">
          <span class="stat-n" id="stat-matched">0</span>
          <span class="stat-l">Matched</span>
        </div>
        <div class="stat stat--applied">
          <span class="stat-n" id="stat-applied">0</span>
          <span class="stat-l">Applied</span>
        </div>
        <div class="stat stat--skipped">
          <span class="stat-n" id="stat-skipped">0</span>
          <span class="stat-l">Skipped</span>
        </div>
      </div>
      <div class="cosmo-meta">
        <span id="cosmo-keyword"></span>
      </div>
      <p class="cosmo-safety" id="cosmo-safety" aria-live="polite"></p>
      <div class="cosmo-now" id="cosmo-now"></div>
      <p class="cosmo-notice" id="cosmo-notice"></p>
      <section class="cosmo-section">
        <div class="cosmo-section-head">
          <span>Scanned jobs</span>
          <span id="cosmo-jobs-count">0</span>
        </div>
        <div class="cosmo-jobs" id="cosmo-jobs">
          <div class="cosmo-empty">Matched jobs will appear here as Cosmo scans the list.</div>
        </div>
      </section>
      <footer class="cosmo-footer">
        <a href="https://codexcareer.com/" target="_blank" rel="noreferrer" aria-label="powered by codexcareer">
          <img src="${chrome.runtime.getURL("assets/codexcareer-logo.png")}" alt="codexcareer" width="132" height="43" />
          <span>powered by codexcareer</span>
        </a>
      </footer>
    </div>
    <div class="cosmo-modal" id="cosmo-done-modal" role="dialog" aria-modal="true">
      <div class="cosmo-modal-card">
        <h3 id="cosmo-done-title">Applies done</h3>
        <p id="cosmo-done-body">
          Session finished. Continue to the next page of jobs, or close and review on your dashboard.
        </p>
        <div class="cosmo-modal-actions">
          <button type="button" class="btn-resume-login" id="cosmo-done-next">
            Next page jobs
          </button>
          <button type="button" class="btn-login" id="cosmo-done-close">
            Close \u2014 view dashboard
          </button>
        </div>
      </div>
    </div>
    <div class="cosmo-modal" id="cosmo-consent-modal" role="dialog" aria-modal="true">
      <div class="cosmo-modal-card">
        <h3>Start co-pilot session</h3>
        <p>
          Cosmo will open Naukri in your browser and submit Easy Apply using your
          logged-in Naukri account. You remain responsible for applications. This
          is an assisted co-pilot \u2014 not unattended bulk apply.
        </p>
        <label class="toggle" style="margin: 10px 0 14px; display:flex; gap:8px; align-items:flex-start;">
          <input type="checkbox" id="cosmo-consent-check" />
          <span>I understand applies use my Naukri account</span>
        </label>
        <div class="cosmo-modal-actions">
          <button type="button" class="btn-resume-login" id="cosmo-consent-start" disabled>
            Start session
          </button>
          <button type="button" class="btn-login" id="cosmo-consent-cancel">
            Cancel
          </button>
        </div>
      </div>
    </div>
    <div class="cosmo-modal" id="cosmo-login-modal" role="dialog" aria-modal="false">
      <div class="cosmo-modal-card">
        <h3 id="cosmo-login-title">Log in to Naukri to continue</h3>
        <p id="cosmo-login-help">
          Opens Naukri login in a new tab. After you sign in, return here and
          press Continue \u2014 Cosmo will refresh this page and resume.
        </p>
        <div class="cosmo-modal-actions">
          <button type="button" class="btn-login" id="cosmo-open-login">
            Open login in new tab
          </button>
          <button type="button" class="btn-resume-login" id="cosmo-logged-in">
            Confirm you&apos;re logged in
          </button>
        </div>
      </div>
    </div>
    </div>
  `;
    document.documentElement.appendChild(root);
    const jobsEl = root.querySelector("#cosmo-jobs");
    const jobsCountEl = root.querySelector("#cosmo-jobs-count");
    const matchedEl = root.querySelector("#stat-matched");
    const appliedEl = root.querySelector("#stat-applied");
    const skippedEl = root.querySelector("#stat-skipped");
    const statusLabelEl = root.querySelector("#cosmo-status-label");
    const keywordEl = root.querySelector("#cosmo-keyword");
    const nowEl = root.querySelector("#cosmo-now");
    const noticeEl = root.querySelector("#cosmo-notice");
    const toastHost = root.querySelector("#cosmo-toast-host");
    const loginModal = root.querySelector("#cosmo-login-modal");
    const consentModal = root.querySelector("#cosmo-consent-modal");
    const doneModal = root.querySelector("#cosmo-done-modal");
    const doneTitle = root.querySelector("#cosmo-done-title");
    const doneBody = root.querySelector("#cosmo-done-body");
    const doneNextBtn = root.querySelector("#cosmo-done-next");
    const doneCloseBtn = root.querySelector("#cosmo-done-close");
    const consentCheck = root.querySelector("#cosmo-consent-check");
    const consentStartBtn = root.querySelector("#cosmo-consent-start");
    const consentCancelBtn = root.querySelector("#cosmo-consent-cancel");
    const safetyEl = root.querySelector("#cosmo-safety");
    const startBtn = root.querySelector("#cosmo-start");
    const pauseBtn = root.querySelector("#cosmo-pause");
    const stopBtn = root.querySelector("#cosmo-stop");
    const openLoginBtn = root.querySelector("#cosmo-open-login");
    const loggedInBtn = root.querySelector("#cosmo-logged-in");
    const loginHelp = root.querySelector("#cosmo-login-help");
    const loginTitle = root.querySelector("#cosmo-login-title");
    const minimizeBtn = root.querySelector("#cosmo-minimize");
    let pauseIconMode = null;
    let startIconMode = null;
    const runningMp4 = chrome.runtime.getURL("assets/running.mp4");
    mountPauseIcon(pauseBtn);
    mountStopIcon(stopBtn);
    mountMinimizeIcon(minimizeBtn);
    const RESUME_AFTER_LOGIN_KEY = "cosmo_resume_after_login";
    const RETURN_URL_KEY = "cosmo_return_after_login";
    const COLLAPSED_KEY = "cosmo_copilot_collapsed";
    const DOCK_POS_KEY = "cosmo_copilot_dock_pos";
    const dockEl = root.querySelector(".cosmo-dock");
    const headEl = root.querySelector(".cosmo-head");
    function clampDockPosition(left, top) {
      const width = dockEl.offsetWidth || 64;
      const height = dockEl.offsetHeight || 64;
      const maxLeft = Math.max(8, window.innerWidth - width - 8);
      const maxTop = Math.max(8, window.innerHeight - height - 8);
      return {
        left: Math.min(Math.max(8, left), maxLeft),
        top: Math.min(Math.max(8, top), maxTop)
      };
    }
    function applyDockPosition(left, top) {
      const next = clampDockPosition(left, top);
      dockEl.style.left = `${next.left}px`;
      dockEl.style.top = `${next.top}px`;
      dockEl.style.right = "auto";
      dockEl.style.bottom = "auto";
      return next;
    }
    function saveDockPosition(left, top) {
      try {
        sessionStorage.setItem(
          DOCK_POS_KEY,
          JSON.stringify({ left, top })
        );
      } catch {
      }
    }
    function restoreDockPosition() {
      try {
        const raw = sessionStorage.getItem(DOCK_POS_KEY);
        if (!raw) return;
        const parsed = JSON.parse(raw);
        if (typeof parsed.left === "number" && typeof parsed.top === "number") {
          applyDockPosition(parsed.left, parsed.top);
        }
      } catch {
      }
    }
    restoreDockPosition();
    window.addEventListener("resize", () => {
      const left = parseFloat(dockEl.style.left || "");
      const top = parseFloat(dockEl.style.top || "");
      if (Number.isFinite(left) && Number.isFinite(top)) {
        applyDockPosition(left, top);
      }
    });
    let dragMoved = false;
    let dragging = false;
    let dragOffsetX = 0;
    let dragOffsetY = 0;
    let dragStartX = 0;
    let dragStartY = 0;
    function beginDockDrag(event, captureEl) {
      if (event.button !== 0) return;
      if (event.target.closest("button, input, a, label")) {
        return;
      }
      dragging = true;
      dragMoved = false;
      dragStartX = event.clientX;
      dragStartY = event.clientY;
      const rect = dockEl.getBoundingClientRect();
      dragOffsetX = event.clientX - rect.left;
      dragOffsetY = event.clientY - rect.top;
      root.classList.add("is-dragging");
      captureEl.setPointerCapture(event.pointerId);
      event.preventDefault();
    }
    headEl.addEventListener("pointerdown", (event) => {
      if (root.classList.contains("collapsed")) {
        beginDockDrag(event, headEl);
        return;
      }
      if (!event.target.closest(".cosmo-brand")) return;
      beginDockDrag(event, headEl);
    });
    headEl.addEventListener("pointermove", (event) => {
      if (!dragging) return;
      const dx = event.clientX - dragStartX;
      const dy = event.clientY - dragStartY;
      if (Math.abs(dx) > 4 || Math.abs(dy) > 4) dragMoved = true;
      const next = applyDockPosition(
        event.clientX - dragOffsetX,
        event.clientY - dragOffsetY
      );
      saveDockPosition(next.left, next.top);
    });
    function endDrag(event) {
      if (!dragging) return;
      dragging = false;
      root.classList.remove("is-dragging");
      try {
        headEl.releasePointerCapture(event.pointerId);
      } catch {
      }
    }
    headEl.addEventListener("pointerup", endDrag);
    headEl.addEventListener("pointercancel", endDrag);
    let lastFlashedAlertAt = "";
    let lastToastId = "";
    let toastHideTimer = null;
    let paceToastEl = null;
    let lastPaceLabel = "";
    function dismissToast(el, clearState = true) {
      el.classList.add("is-out");
      window.setTimeout(() => {
        el.remove();
        if (paceToastEl === el) {
          paceToastEl = null;
          lastPaceLabel = "";
        }
        if (clearState && !toastHost.querySelector(".cosmo-toast:not(.is-pace)")) {
          void clearCopilotToast();
        }
      }, 220);
    }
    function showToast(toast) {
      if (!toast?.id || toast.id === lastToastId) return;
      lastToastId = toast.id;
      Array.from(toastHost.querySelectorAll(".cosmo-toast:not(.is-pace)")).forEach(
        (n) => n.remove()
      );
      const el = document.createElement("div");
      el.className = "cosmo-toast";
      el.setAttribute("role", "status");
      el.innerHTML = `
      <div class="cosmo-toast-icon" aria-hidden="true">\u2713</div>
      <div class="cosmo-toast-copy">
        <p class="cosmo-toast-title">${escapeHtml(toast.title)}</p>
        <p class="cosmo-toast-msg">${escapeHtml(toast.message)}</p>
      </div>
      <button type="button" class="cosmo-toast-close" aria-label="Dismiss">\xD7</button>
    `;
      const closeBtn = el.querySelector(".cosmo-toast-close");
      closeBtn.addEventListener("click", () => dismissToast(el));
      toastHost.appendChild(el);
      if (toastHideTimer) clearTimeout(toastHideTimer);
      toastHideTimer = setTimeout(() => {
        if (el.isConnected) dismissToast(el);
      }, 4200);
    }
    function showPaceToast(label, remainingMs, jobTitle) {
      const countdown = formatBreakCountdown(remainingMs);
      if (!paceToastEl || !paceToastEl.isConnected || lastPaceLabel !== label) {
        lastPaceLabel = label;
        if (paceToastEl?.isConnected) paceToastEl.remove();
        const el = document.createElement("div");
        el.className = "cosmo-toast is-pace";
        el.setAttribute("role", "status");
        el.innerHTML = `
        <div class="cosmo-toast-icon" aria-hidden="true">\u23F1</div>
        <div class="cosmo-toast-copy">
          <p class="cosmo-toast-title">Slowing down</p>
          <p class="cosmo-toast-msg" data-pace-msg></p>
        </div>
        <span class="cosmo-toast-countdown" data-pace-cd></span>
      `;
        toastHost.prepend(el);
        paceToastEl = el;
      }
      const msgEl = paceToastEl.querySelector("[data-pace-msg]");
      const cdEl = paceToastEl.querySelector("[data-pace-cd]");
      msgEl.textContent = jobTitle ? `${label} \xB7 ${jobTitle}` : label;
      cdEl.textContent = countdown;
    }
    function hidePaceToast() {
      if (!paceToastEl) return;
      const el = paceToastEl;
      paceToastEl = null;
      lastPaceLabel = "";
      if (el.isConnected) dismissToast(el, false);
    }
    function setCollapsed(collapsed) {
      root.classList.toggle("collapsed", collapsed);
      minimizeBtn.title = "Minimize";
      minimizeBtn.setAttribute("aria-label", "Minimize co-pilot");
      if (!minimizeBtn.querySelector(".cosmo-fi-minimize")) {
        mountMinimizeIcon(minimizeBtn);
      }
      headEl.setAttribute(
        "title",
        collapsed ? "Drag to move \xB7 Click to open Cosmo Co-Pilot" : "Drag the Cosmo logo/title to move"
      );
      try {
        sessionStorage.setItem(COLLAPSED_KEY, collapsed ? "1" : "0");
      } catch {
      }
      requestAnimationFrame(() => {
        const left = parseFloat(dockEl.style.left || "");
        const top = parseFloat(dockEl.style.top || "");
        if (Number.isFinite(left) && Number.isFinite(top)) {
          const next = applyDockPosition(left, top);
          saveDockPosition(next.left, next.top);
        }
      });
    }
    try {
      if (sessionStorage.getItem(COLLAPSED_KEY) === "1") {
        setCollapsed(true);
      }
    } catch {
    }
    function showLoginModal(show) {
      loginModal.classList.toggle("show", show);
    }
    function applyLoginModalCopy(reason) {
      if (reason === "uncertain") {
        loginTitle.textContent = "Confirm you\u2019re logged in";
        loginHelp.textContent = "We couldn\u2019t confirm your Naukri session yet. If you\u2019re already signed in, press Confirm. Otherwise open login in a new tab first.";
        loggedInBtn.textContent = "Confirm you\u2019re logged in";
      } else {
        loginTitle.textContent = "Log in to Naukri to continue";
        loginHelp.textContent = "Opens Naukri login in a new tab. After you sign in, return here and press Confirm \u2014 Cosmo will refresh this page and resume.";
        loggedInBtn.textContent = "Confirm you\u2019re logged in";
      }
    }
    function showConsentModal(show) {
      consentModal.classList.toggle("show", show);
      if (show) {
        consentCheck.checked = false;
        consentStartBtn.disabled = true;
      }
    }
    function showDoneModal(show, summary) {
      doneModal.classList.toggle("show", show);
      if (show && summary) {
        doneTitle.textContent = summary.applied > 0 ? "Applies done" : "Session finished";
        doneBody.textContent = summary.applied > 0 ? `Applied to ${summary.applied} job(s) (matched ${summary.matched}, skipped ${summary.skipped}). Go to the next page of jobs, or close and review on your Cosmo dashboard.` : `Matched ${summary.matched}, skipped ${summary.skipped}. Continue to the next page, or close and visit your Cosmo dashboard.`;
      }
    }
    function loadSafetyStrip(_state) {
      chrome.runtime.sendMessage({ type: "GET_APPLY_QUOTA" }, (res) => {
        if (chrome.runtime.lastError || !res?.ok || !res.quota) {
          safetyEl.textContent = "Assisted";
          return;
        }
        const q = res.quota;
        safetyEl.textContent = `Assisted \xB7 ${q.hourUsed}/${q.hourLimit} this hour \xB7 ${q.dayUsed}/${q.dayLimit} today \xB7 ${q.monthUsed}/${q.monthLimit} this month`;
      });
    }
    function renderJobs(jobs) {
      jobsCountEl.textContent = String(jobs.length);
      if (!jobs.length) {
        jobsEl.innerHTML = '<div class="cosmo-empty">Matched jobs will appear here as Cosmo scans the list.</div>';
        return;
      }
      const order = {
        applying: 0,
        pending: 1,
        applied: 2,
        already_applied: 3,
        skipped: 4
      };
      const sorted = [...jobs].sort(
        (a, b) => (order[a.status] ?? 9) - (order[b.status] ?? 9)
      );
      jobsEl.innerHTML = sorted.slice(0, 50).map((j) => {
        return `
      <div class="job-row ${j.status}" data-job-id="${escapeHtml(j.id)}" title="${escapeHtml(j.skipReason || `${j.title} \xB7 ${j.company}`)}">
        <div>
          <div class="job-title">${escapeHtml(j.title)}</div>
          <div class="job-company">${escapeHtml(j.company)}</div>
        </div>
        <span class="job-badge ${j.status}">${statusLabel(j.status, j.skipReason)}</span>
      </div>`;
      }).join("");
      const currentEl = jobsEl.querySelector(".job-row.applying");
      currentEl?.scrollIntoView({ block: "nearest", behavior: "smooth" });
    }
    function render(state) {
      matchedEl.textContent = String(state.matched || 0);
      appliedEl.textContent = String(state.applied || 0);
      skippedEl.textContent = String(state.skipped || 0);
      keywordEl.textContent = state.keyword ? `\u201C${state.keyword}\u201D` : "";
      root.classList.toggle("is-running", Boolean(state.running && !state.paused));
      root.classList.toggle("is-paused", Boolean(state.running && state.paused));
      if (state.sessionBreakUntil && Date.parse(state.sessionBreakUntil) > Date.now()) {
        statusLabelEl.textContent = `Break \u2014 resumes in ${formatBreakCountdown(
          state.sessionBreakRemainingMs ?? 0
        )}`;
      } else if (state.paceLabel && (state.paceRemainingMs ?? 0) > 0) {
        statusLabelEl.textContent = `${state.paceLabel} \u2014 ${formatBreakCountdown(
          state.paceRemainingMs ?? 0
        )}`;
      } else if (state.paused) {
        statusLabelEl.textContent = state.needsLogin ? state.loginPauseReason === "uncertain" ? "Paused \u2014 confirm login" : "Paused \u2014 login needed" : "Paused";
      } else if (state.running) {
        statusLabelEl.textContent = "Browsing Naukri\u2026";
      } else {
        statusLabelEl.textContent = "Idle \u2014 press Start";
      }
      const pacing = Boolean(state.paceLabel) && (state.paceRemainingMs ?? 0) > 0;
      if (pacing) {
        showPaceToast(
          state.paceLabel || "Slowing down",
          state.paceRemainingMs ?? 0,
          state.currentTitle
        );
      } else {
        hidePaceToast();
      }
      if (state.running && state.currentTitle && !pacing) {
        nowEl.classList.add("show");
        nowEl.innerHTML = `<strong>Now</strong>${escapeHtml(state.currentTitle)}`;
      } else {
        nowEl.classList.remove("show");
        nowEl.textContent = "";
      }
      const isActivelyRunning = Boolean(state.running && !state.paused);
      startBtn.style.display = "";
      startBtn.classList.toggle("is-running", isActivelyRunning);
      const nextStartMode = isActivelyRunning ? "running" : state.running ? "paused" : "idle";
      if (startIconMode !== nextStartMode) {
        startIconMode = nextStartMode;
        if (nextStartMode === "running") {
          startBtn.innerHTML = runningVideoHtml(runningMp4);
          const video = startBtn.querySelector("video");
          if (video) {
            video.src = runningMp4;
            video.muted = true;
            video.loop = true;
            video.playsInline = true;
            void video.play().catch(() => void 0);
          }
        } else {
          startBtn.textContent = nextStartMode === "paused" ? "Paused" : "Start";
        }
      }
      startBtn.disabled = Boolean(state.running) || Boolean(
        state.sessionBreakUntil && Date.parse(state.sessionBreakUntil) > Date.now()
      );
      if (!stopBtn.querySelector(".cosmo-fi-stop")) {
        mountStopIcon(stopBtn);
      }
      const nextPauseMode = !state.running ? "idle" : state.paused ? "play" : "pause";
      if (pauseIconMode !== nextPauseMode) {
        pauseIconMode = nextPauseMode;
        if (nextPauseMode === "play") {
          mountPlayIcon(pauseBtn);
        } else {
          mountPauseIcon(pauseBtn);
        }
      }
      if (state.paused) {
        pauseBtn.title = "Resume";
        pauseBtn.setAttribute("aria-label", "Resume");
      } else {
        pauseBtn.title = "Pause";
        pauseBtn.setAttribute("aria-label", "Pause");
      }
      pauseBtn.disabled = !state.running || Boolean(
        state.sessionBreakUntil && Date.parse(state.sessionBreakUntil) > Date.now()
      );
      stopBtn.disabled = !state.running;
      renderJobs(state.scannedJobs ?? []);
      safetyEl.classList.toggle("is-active", Boolean(state.running));
      if (state.sessionComplete) {
        showDoneModal(true, state.sessionComplete);
        if (root.classList.contains("collapsed")) {
          setCollapsed(false);
        }
      } else {
        showDoneModal(false);
      }
      if (state.toast?.id) {
        showToast(state.toast);
      }
      const alert = state.alert;
      const waitingOnLogin = state.needsLogin || state.paused && (alert?.kind === "login" || /log into naukri|not logged into naukri|naukri login|login to continue|confirm you.?re logged/i.test(
        state.lastMessage || ""
      ));
      const waitingOnQuestions = state.paused && !waitingOnLogin && (alert?.kind === "questions" || /question/i.test(state.lastMessage || ""));
      const planLimit = alert?.kind === "plan_limit" || /plan apply limit|monthly apply limit/i.test(
        alert?.message || state.lastMessage || ""
      );
      const rateLimit = alert?.kind === "rate_limit" || /hourly safety limit|daily safety limit/i.test(
        alert?.message || state.lastMessage || ""
      );
      const blocked = alert?.kind === "blocked" || /verification|block page|captcha/i.test(alert?.message || "");
      if (waitingOnLogin) {
        applyLoginModalCopy(state.loginPauseReason);
      }
      showLoginModal(Boolean(waitingOnLogin));
      const onSessionBreak = Boolean(state.sessionBreakUntil) && Date.parse(state.sessionBreakUntil) > Date.now();
      const showNotice = onSessionBreak || waitingOnLogin || waitingOnQuestions || planLimit || rateLimit || blocked || Boolean(alert?.message) && (state.paused || alert?.kind === "plan_limit" || alert?.kind === "rate_limit" || alert?.kind === "blocked" || alert?.level === "error");
      if (showNotice) {
        noticeEl.classList.add("show", "is-alert");
        noticeEl.textContent = onSessionBreak ? `Taking a 2-minute break \u2014 safer pacing. Resumes in ${formatBreakCountdown(
          state.sessionBreakRemainingMs ?? 0
        )}.` : alert?.message || (waitingOnLogin ? state.loginPauseReason === "uncertain" ? "Confirm you\u2019re logged into Naukri, then press Confirm." : "Log into Naukri in the new tab, then press Confirm here." : waitingOnQuestions ? "Answer Naukri\u2019s questions and save. Cosmo continues when apply succeeds, or press Resume." : noticeEl.textContent);
        const flashKey = alert?.at || noticeEl.textContent;
        if (flashKey && flashKey !== lastFlashedAlertAt) {
          lastFlashedAlertAt = flashKey;
          noticeEl.classList.remove("flash");
          void noticeEl.offsetWidth;
          noticeEl.classList.add("flash");
          if (root.classList.contains("collapsed")) {
            setCollapsed(false);
          }
        }
      } else {
        noticeEl.classList.remove("show", "is-alert", "flash");
        noticeEl.textContent = "";
      }
    }
    async function refresh() {
      const state = await getCopilotState();
      render(state);
      loadSafetyStrip(state);
    }
    async function resumeAfterLoginIfNeeded() {
      try {
        if (sessionStorage.getItem(RESUME_AFTER_LOGIN_KEY) !== "1") return;
        sessionStorage.removeItem(RESUME_AFTER_LOGIN_KEY);
        const returnUrl = sessionStorage.getItem(RETURN_URL_KEY);
        sessionStorage.removeItem(RETURN_URL_KEY);
        const onLoginPage = /\/nlogin\//i.test(window.location.pathname);
        if (returnUrl && onLoginPage) {
          sessionStorage.setItem(RESUME_AFTER_LOGIN_KEY, "1");
          window.location.href = returnUrl;
          return;
        }
        await wait(900);
        const status = naukri.getLoginStatus(document);
        if (status !== "loggedIn") {
          applyLoginModalCopy(status === "loggedOut" ? "loggedOut" : "uncertain");
          showLoginModal(true);
          loginHelp.textContent = status === "uncertain" ? "Still can\u2019t confirm login. Finish signing in, then press Confirm again." : "Still not logged in. Finish login in the other tab, then press Confirm again.";
          return;
        }
        showLoginModal(false);
        chrome.runtime.sendMessage({ type: "COPILOT_RESUME" }, () => void refresh());
      } catch {
      }
    }
    function wait(ms) {
      return new Promise((resolve) => setTimeout(resolve, ms));
    }
    consentCheck.addEventListener("change", () => {
      consentStartBtn.disabled = !consentCheck.checked;
    });
    consentCancelBtn.addEventListener("click", () => showConsentModal(false));
    consentStartBtn.addEventListener("click", () => {
      if (!consentCheck.checked) return;
      showConsentModal(false);
      chrome.runtime.sendMessage(
        {
          type: "COPILOT_START",
          consentAccepted: true,
          consentVersion: CONSENT_VERSION
        },
        () => void refresh()
      );
    });
    doneNextBtn.addEventListener("click", () => {
      showDoneModal(false);
      noticeEl.classList.add("show", "is-alert");
      noticeEl.textContent = "Taking a short read pause, then opening the next page of jobs\u2026";
      chrome.runtime.sendMessage({ type: "COPILOT_NEXT_PAGE" }, (res) => {
        if (res?.ok === false && res?.message) {
          noticeEl.textContent = res.message;
        }
        void refresh();
      });
    });
    doneCloseBtn.addEventListener("click", () => {
      showDoneModal(false);
      chrome.runtime.sendMessage({ type: "COPILOT_SESSION_CLOSE" }, () => {
        noticeEl.classList.add("show", "is-alert");
        noticeEl.textContent = "Visit your Cosmo dashboard to review applications.";
        setCollapsed(true);
        void refresh();
      });
    });
    startBtn.addEventListener("click", () => {
      chrome.runtime.sendMessage({ type: "GET_SAFETY_STATUS" }, (res) => {
        if (res?.blocked) {
          noticeEl.classList.add("show", "is-alert");
          noticeEl.textContent = "Naukri verification cooldown active \u2014 wait before starting a new session.";
          return;
        }
        showConsentModal(true);
      });
    });
    pauseBtn.addEventListener("click", async () => {
      const state = await getCopilotState();
      chrome.runtime.sendMessage(
        { type: state.paused ? "COPILOT_RESUME" : "COPILOT_PAUSE" },
        () => void refresh()
      );
    });
    stopBtn.addEventListener("click", () => {
      chrome.runtime.sendMessage({ type: "COPILOT_STOP" }, () => void refresh());
    });
    minimizeBtn.addEventListener("click", () => {
      setCollapsed(true);
    });
    root.querySelector(".cosmo-head")?.addEventListener("click", (event) => {
      if (!root.classList.contains("collapsed")) return;
      if (event.target.closest("button")) return;
      if (dragMoved) {
        dragMoved = false;
        return;
      }
      setCollapsed(false);
    });
    openLoginBtn.addEventListener("click", () => {
      const returnUrl = window.location.href;
      const loginUrl = `${NAUKRI_LOGIN_URL}?URL=${encodeURIComponent(returnUrl)}`;
      chrome.runtime.sendMessage(
        {
          type: "OPEN_NAUKRI_LOGIN",
          loginUrl,
          returnUrl
        },
        (res) => {
          if (chrome.runtime.lastError || !res?.ok) {
            window.open(loginUrl, "_blank", "noopener,noreferrer");
          }
          loginHelp.textContent = "Login tab opened. Sign in there \u2014 when you close it, Cosmo re-checks login. Or press Confirm here.";
        }
      );
    });
    loggedInBtn.addEventListener("click", () => {
      loggedInBtn.disabled = true;
      loggedInBtn.textContent = "Checking\u2026";
      try {
        sessionStorage.setItem(RESUME_AFTER_LOGIN_KEY, "1");
        sessionStorage.setItem(RETURN_URL_KEY, window.location.href);
      } catch {
      }
      window.location.reload();
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local") return;
      if (changes[STATE_KEY]) {
        void refresh();
      }
    });
    window.addEventListener("pageshow", () => {
      void refresh();
    });
    chrome.runtime.onMessage.addListener((message) => {
      if (message?.type === "COPILOT_REFRESH" || message?.type === "SHOW_LOGIN_PROMPT" || message?.type === "LOGIN_REVERIFIED" || message?.type === "COPILOT_ALERT" || message?.type === "COPILOT_TOAST" || message?.type === "COPILOT_COLLAPSE") {
        if (message?.type === "COPILOT_TOAST" && message.toast) {
          showToast(message.toast);
        }
        if (message?.type === "COPILOT_COLLAPSE") {
          setCollapsed(true);
        }
        if (message?.type === "SHOW_LOGIN_PROMPT") {
          const reason = message.reason === "loggedOut" || message.reason === "uncertain" ? message.reason : "uncertain";
          applyLoginModalCopy(reason);
          showLoginModal(true);
        }
        if (message?.type === "LOGIN_REVERIFIED" && message.loggedIn) {
          showLoginModal(false);
        }
        void refresh();
      }
    });
    void refresh();
    void resumeAfterLoginIfNeeded();
  }
  function escapeHtml(value) {
    return value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }

  // src/content/index.ts
  var naukri2 = new NaukriAdapter();
  var lastFingerprint = "";
  var applyClickBound = false;
  function fingerprint(job) {
    return `${job.title}|${job.company}|${job.url ?? ""}|${job.status ?? ""}`;
  }
  function emitJob(adapter = resolveAdapter(window.location.href)) {
    if (!adapter) return;
    const job = adapter.readJob(document);
    if (!job?.title || !job.company) return;
    const status = adapter.detectApplicationStatus(document) ?? job.status ?? "detected";
    const payload = {
      ...job,
      platform: adapter.platform,
      title: job.title,
      company: job.company,
      url: job.url ?? window.location.href,
      status,
      appliedAt: status === "applied" ? (/* @__PURE__ */ new Date()).toISOString() : void 0,
      metadata: { ...job.metadata ?? {}, source: "manual" }
    };
    const fp = fingerprint(payload);
    if (fp === lastFingerprint) return;
    lastFingerprint = fp;
    const messageType = status === "applied" ? "APPLICATION_RECORDED" : "JOB_DETECTED";
    chrome.runtime.sendMessage({ type: messageType, payload }, () => {
      if (chrome.runtime.lastError) {
        logger.warn("Failed to send message", {
          error: chrome.runtime.lastError.message
        });
      }
    });
  }
  function bindApplyClickCapture() {
    if (applyClickBound) return;
    applyClickBound = true;
    document.addEventListener(
      "click",
      (e) => {
        const target = e.target;
        if (!target) return;
        const applyBtn = target.closest(
          'button, a, [role="button"]'
        );
        const label = applyBtn?.textContent?.toLowerCase() ?? "";
        if (!label.includes("apply")) return;
        setTimeout(() => {
          const current = resolveAdapter(window.location.href);
          if (!current) return;
          const job = current.readJob(document);
          if (!job?.title || !job.company) return;
          const payload = {
            ...job,
            platform: current.platform,
            title: job.title,
            company: job.company,
            url: window.location.href,
            status: "applied",
            appliedAt: (/* @__PURE__ */ new Date()).toISOString(),
            metadata: { ...job.metadata ?? {}, source: "manual" }
          };
          lastFingerprint = fingerprint(payload);
          chrome.runtime.sendMessage({
            type: "APPLICATION_RECORDED",
            payload
          });
        }, 1500);
      },
      true
    );
  }
  function onPossibleNavigation() {
    emitJob();
  }
  function patchHistory() {
    const wrap = (method) => {
      const original = history[method].bind(history);
      history[method] = function(...args) {
        const result = original(...args);
        onPossibleNavigation();
        return result;
      };
    };
    wrap("pushState");
    wrap("replaceState");
    window.addEventListener("popstate", onPossibleNavigation);
  }
  async function runEasyApply() {
    const blockReason = naukri2.detectNaukriBlockPage(document);
    if (blockReason) {
      return { ok: false, blocked: true, reason: blockReason };
    }
    const loginStatus = naukri2.getLoginStatus(document);
    if (loginStatus !== "loggedIn") {
      return {
        ok: false,
        skipped: true,
        reason: loginStatus === "uncertain" ? "Confirm you\u2019re logged into Naukri" : "Naukri login required",
        job: naukri2.readJob(document) ?? void 0
      };
    }
    const job = naukri2.readJob(document) ?? void 0;
    if (naukri2.detectApplicationStatus(document) === "applied") {
      return {
        ok: true,
        alreadyApplied: naukri2.isAlreadyApplied(document),
        job
      };
    }
    if (naukri2.isCompanySiteApply(document)) {
      return {
        ok: false,
        skipped: true,
        reason: "Apply on company site \u2014 skipped",
        job
      };
    }
    const loginBlock = (() => {
      const text = (document.body?.innerText || "").toLowerCase();
      if (text.includes("login to apply") || text.includes("register to apply")) {
        return "Naukri login required";
      }
      return null;
    })();
    if (loginBlock) {
      return { ok: false, skipped: true, reason: loginBlock, job };
    }
    const questionsBefore = naukri2.detectNeedsUserQuestions(document);
    if (questionsBefore) {
      return {
        ok: false,
        needsUserInput: true,
        reason: questionsBefore,
        job
      };
    }
    const btn = naukri2.findEasyApplyButton(document);
    if (!btn) {
      return {
        ok: false,
        skipped: true,
        reason: "Easy Apply button not found",
        job
      };
    }
    const label = (btn.textContent || "").toLowerCase();
    if (/company site|external/.test(label)) {
      return {
        ok: false,
        skipped: true,
        reason: "External / company-site apply",
        job
      };
    }
    btn.click();
    await new Promise((r) => setTimeout(r, 2200));
    if (naukri2.detectApplicationStatus(document) === "applied") {
      return {
        ok: true,
        alreadyApplied: naukri2.isAlreadyApplied(document),
        job: naukri2.readJob(document) ?? job
      };
    }
    const questionsAfter = naukri2.detectNeedsUserQuestions(document);
    if (questionsAfter) {
      return {
        ok: false,
        needsUserInput: true,
        reason: questionsAfter,
        job: naukri2.readJob(document) ?? job
      };
    }
    const loginAfter = (() => {
      const text = (document.body?.innerText || "").toLowerCase();
      if (text.includes("login to apply") || text.includes("register to apply")) {
        return "Naukri login required";
      }
      return null;
    })();
    if (loginAfter) {
      return {
        ok: false,
        skipped: true,
        reason: loginAfter,
        job: naukri2.readJob(document) ?? job
      };
    }
    if (naukri2.detectApplicationStatus(document) === "applied") {
      return {
        ok: true,
        alreadyApplied: naukri2.isAlreadyApplied(document),
        job: naukri2.readJob(document) ?? job
      };
    }
    const afterLabel = (btn.textContent || "").toLowerCase();
    if (/applied|applied successfully/.test(afterLabel) || btn.hasAttribute("disabled")) {
      return {
        ok: true,
        alreadyApplied: naukri2.isAlreadyApplied(document),
        job: naukri2.readJob(document) ?? job
      };
    }
    return {
      ok: true,
      alreadyApplied: naukri2.isAlreadyApplied(document),
      job: naukri2.readJob(document) ?? job
    };
  }
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    (async () => {
      switch (message?.type) {
        case "CHECK_LOGIN": {
          await new Promise((r) => setTimeout(r, 300));
          const status = naukri2.getLoginStatus(document);
          const cookieHint = hasNaukriSessionCookieHint(document.cookie);
          sendResponse({
            status,
            loggedIn: status === "loggedIn",
            cookieHint
          });
          break;
        }
        case "SHOW_LOGIN_PROMPT": {
          sendResponse({ ok: true, reason: message?.reason ?? null });
          break;
        }
        case "CLICK_NEXT_PAGE": {
          const clicked = naukri2.clickNextSearchPage(document);
          if (clicked.ok) {
            sendResponse(clicked);
            break;
          }
          const nextUrl = naukri2.nextSearchPageUrl(window.location.href);
          if (nextUrl) {
            window.location.href = nextUrl;
            sendResponse({ ok: true, via: "url" });
            break;
          }
          sendResponse(clicked);
          break;
        }
        case "CHECK_BLOCK_PAGE": {
          const reason = naukri2.detectNaukriBlockPage(document);
          sendResponse({ blocked: Boolean(reason), reason: reason ?? void 0 });
          break;
        }
        case "CHECK_APPLY_STATUS": {
          sendResponse({
            applied: naukri2.detectApplicationStatus(document) === "applied",
            needsQuestions: Boolean(naukri2.detectNeedsUserQuestions(document)),
            href: window.location.href
          });
          break;
        }
        case "READ_JOB_DETAIL": {
          const job = naukri2.readJob(document);
          sendResponse({
            job: job ?? null,
            companySiteApply: naukri2.isCompanySiteApply(document)
          });
          break;
        }
        case "RUN_SCAN_SCRAPE": {
          const jobs = naukri2.readSearchResults(document);
          logger.info("Scan scrape complete", { count: jobs.length });
          sendResponse({ jobs });
          break;
        }
        case "SCROLL_SEARCH_RESULTS": {
          const before = document.querySelectorAll(
            ".srp-jobtuple-wrapper, .cust-job-tuple, article.jobTuple, div.row[data-job-id]"
          ).length;
          const step = Math.max(480, Math.floor(window.innerHeight * 0.85));
          window.scrollBy({ top: step, behavior: "smooth" });
          await new Promise((r) => setTimeout(r, 1200));
          window.scrollBy({ top: Math.floor(step * 0.4), behavior: "smooth" });
          await new Promise((r) => setTimeout(r, 900));
          const after = document.querySelectorAll(
            ".srp-jobtuple-wrapper, .cust-job-tuple, article.jobTuple, div.row[data-job-id]"
          ).length;
          sendResponse({ ok: true, before, after });
          break;
        }
        case "RUN_EASY_APPLY": {
          const result = await runEasyApply();
          sendResponse(result);
          break;
        }
        default:
          sendResponse({ ok: false });
      }
    })();
    return true;
  });
  patchHistory();
  bindApplyClickCapture();
  mountCopilotPanel();
  emitJob();
  var observer = new MutationObserver(() => {
    emitJob();
  });
  observer.observe(document.documentElement, {
    childList: true,
    subtree: true
  });
})();
//# sourceMappingURL=content.js.map
