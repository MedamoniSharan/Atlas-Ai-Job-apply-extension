"use strict";
(() => {
  // src/core/allowedApiBases.ts
  var PRODUCTION_API_BASE = "https://atlas-ai-job-apply-extension-1.onrender.com";

  // src/content/webAuthBridge.ts
  var MESSAGE_SOURCE = "cosmo-web";
  var MESSAGE_TYPE = "COSMO_AUTH_SYNC";
  var LEGACY_MESSAGE_SOURCE = "atlas-web";
  var LEGACY_MESSAGE_TYPE = "ATLAS_AUTH_SYNC";
  var STORAGE_KEY = "cosmo-auth";
  var LEGACY_STORAGE_KEY = "atlas-auth";
  var DEFAULT_API = PRODUCTION_API_BASE;
  function sendToBackground(message) {
    chrome.runtime.sendMessage(message, () => {
      void chrome.runtime.lastError;
    });
  }
  function syncTokens(accessToken, refreshToken, apiBaseUrl) {
    if (!accessToken || !refreshToken) {
      sendToBackground({ type: "SYNC_AUTH_FROM_WEB", cleared: true });
      return;
    }
    sendToBackground({
      type: "SYNC_AUTH_FROM_WEB",
      accessToken,
      refreshToken,
      apiBaseUrl: apiBaseUrl || DEFAULT_API
    });
  }
  function readPersistedAuth() {
    try {
      let raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) {
        raw = localStorage.getItem(LEGACY_STORAGE_KEY);
        if (raw) {
          localStorage.setItem(STORAGE_KEY, raw);
          localStorage.removeItem(LEGACY_STORAGE_KEY);
        }
      }
      if (!raw) return { accessToken: null, refreshToken: null };
      const parsed = JSON.parse(raw);
      return {
        accessToken: parsed.state?.accessToken ?? null,
        refreshToken: parsed.state?.refreshToken ?? null
      };
    } catch {
      return { accessToken: null, refreshToken: null };
    }
  }
  function syncFromLocalStorage() {
    const { accessToken, refreshToken } = readPersistedAuth();
    syncTokens(accessToken, refreshToken);
  }
  function isAuthSyncMessage(data) {
    if (!data) return false;
    const sourceOk = data.source === MESSAGE_SOURCE || data.source === LEGACY_MESSAGE_SOURCE;
    const typeOk = data.type === MESSAGE_TYPE || data.type === LEGACY_MESSAGE_TYPE;
    return sourceOk && typeOk;
  }
  window.addEventListener("message", (event) => {
    if (event.source !== window || event.origin !== window.location.origin) {
      return;
    }
    const data = event.data;
    if (!isAuthSyncMessage(data)) {
      return;
    }
    syncTokens(data.accessToken, data.refreshToken, data.apiBaseUrl);
  });
  syncFromLocalStorage();
})();
//# sourceMappingURL=webBridge.js.map
