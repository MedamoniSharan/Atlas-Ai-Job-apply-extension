"use strict";
(() => {
  var __defProp = Object.defineProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };

  // ../node_modules/uuid/dist/esm-browser/stringify.js
  var byteToHex = [];
  for (let i = 0; i < 256; ++i) {
    byteToHex.push((i + 256).toString(16).slice(1));
  }
  function unsafeStringify(arr, offset = 0) {
    return (byteToHex[arr[offset + 0]] + byteToHex[arr[offset + 1]] + byteToHex[arr[offset + 2]] + byteToHex[arr[offset + 3]] + "-" + byteToHex[arr[offset + 4]] + byteToHex[arr[offset + 5]] + "-" + byteToHex[arr[offset + 6]] + byteToHex[arr[offset + 7]] + "-" + byteToHex[arr[offset + 8]] + byteToHex[arr[offset + 9]] + "-" + byteToHex[arr[offset + 10]] + byteToHex[arr[offset + 11]] + byteToHex[arr[offset + 12]] + byteToHex[arr[offset + 13]] + byteToHex[arr[offset + 14]] + byteToHex[arr[offset + 15]]).toLowerCase();
  }

  // ../node_modules/uuid/dist/esm-browser/rng.js
  var getRandomValues;
  var rnds8 = new Uint8Array(16);
  function rng() {
    if (!getRandomValues) {
      if (typeof crypto === "undefined" || !crypto.getRandomValues) {
        throw new Error("crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported");
      }
      getRandomValues = crypto.getRandomValues.bind(crypto);
    }
    return getRandomValues(rnds8);
  }

  // ../node_modules/uuid/dist/esm-browser/native.js
  var randomUUID = typeof crypto !== "undefined" && crypto.randomUUID && crypto.randomUUID.bind(crypto);
  var native_default = { randomUUID };

  // ../node_modules/uuid/dist/esm-browser/v4.js
  function v4(options, buf, offset) {
    if (native_default.randomUUID && !buf && !options) {
      return native_default.randomUUID();
    }
    options = options || {};
    const rnds = options.random ?? options.rng?.() ?? rng();
    if (rnds.length < 16) {
      throw new Error("Random bytes length must be >= 16");
    }
    rnds[6] = rnds[6] & 15 | 64;
    rnds[8] = rnds[8] & 63 | 128;
    if (buf) {
      offset = offset || 0;
      if (offset < 0 || offset + 16 > buf.length) {
        throw new RangeError(`UUID byte range ${offset}:${offset + 15} is out of buffer bounds`);
      }
      for (let i = 0; i < 16; ++i) {
        buf[offset + i] = rnds[i];
      }
      return buf;
    }
    return unsafeStringify(rnds);
  }
  var v4_default = v4;

  // ../node_modules/zod/v3/external.js
  var external_exports = {};
  __export(external_exports, {
    BRAND: () => BRAND,
    DIRTY: () => DIRTY,
    EMPTY_PATH: () => EMPTY_PATH,
    INVALID: () => INVALID,
    NEVER: () => NEVER,
    OK: () => OK,
    ParseStatus: () => ParseStatus,
    Schema: () => ZodType,
    ZodAny: () => ZodAny,
    ZodArray: () => ZodArray,
    ZodBigInt: () => ZodBigInt,
    ZodBoolean: () => ZodBoolean,
    ZodBranded: () => ZodBranded,
    ZodCatch: () => ZodCatch,
    ZodDate: () => ZodDate,
    ZodDefault: () => ZodDefault,
    ZodDiscriminatedUnion: () => ZodDiscriminatedUnion,
    ZodEffects: () => ZodEffects,
    ZodEnum: () => ZodEnum,
    ZodError: () => ZodError,
    ZodFirstPartyTypeKind: () => ZodFirstPartyTypeKind,
    ZodFunction: () => ZodFunction,
    ZodIntersection: () => ZodIntersection,
    ZodIssueCode: () => ZodIssueCode,
    ZodLazy: () => ZodLazy,
    ZodLiteral: () => ZodLiteral,
    ZodMap: () => ZodMap,
    ZodNaN: () => ZodNaN,
    ZodNativeEnum: () => ZodNativeEnum,
    ZodNever: () => ZodNever,
    ZodNull: () => ZodNull,
    ZodNullable: () => ZodNullable,
    ZodNumber: () => ZodNumber,
    ZodObject: () => ZodObject,
    ZodOptional: () => ZodOptional,
    ZodParsedType: () => ZodParsedType,
    ZodPipeline: () => ZodPipeline,
    ZodPromise: () => ZodPromise,
    ZodReadonly: () => ZodReadonly,
    ZodRecord: () => ZodRecord,
    ZodSchema: () => ZodType,
    ZodSet: () => ZodSet,
    ZodString: () => ZodString,
    ZodSymbol: () => ZodSymbol,
    ZodTransformer: () => ZodEffects,
    ZodTuple: () => ZodTuple,
    ZodType: () => ZodType,
    ZodUndefined: () => ZodUndefined,
    ZodUnion: () => ZodUnion,
    ZodUnknown: () => ZodUnknown,
    ZodVoid: () => ZodVoid,
    addIssueToContext: () => addIssueToContext,
    any: () => anyType,
    array: () => arrayType,
    bigint: () => bigIntType,
    boolean: () => booleanType,
    coerce: () => coerce,
    custom: () => custom,
    date: () => dateType,
    datetimeRegex: () => datetimeRegex,
    defaultErrorMap: () => en_default,
    discriminatedUnion: () => discriminatedUnionType,
    effect: () => effectsType,
    enum: () => enumType,
    function: () => functionType,
    getErrorMap: () => getErrorMap,
    getParsedType: () => getParsedType,
    instanceof: () => instanceOfType,
    intersection: () => intersectionType,
    isAborted: () => isAborted,
    isAsync: () => isAsync,
    isDirty: () => isDirty,
    isValid: () => isValid,
    late: () => late,
    lazy: () => lazyType,
    literal: () => literalType,
    makeIssue: () => makeIssue,
    map: () => mapType,
    nan: () => nanType,
    nativeEnum: () => nativeEnumType,
    never: () => neverType,
    null: () => nullType,
    nullable: () => nullableType,
    number: () => numberType,
    object: () => objectType,
    objectUtil: () => objectUtil,
    oboolean: () => oboolean,
    onumber: () => onumber,
    optional: () => optionalType,
    ostring: () => ostring,
    pipeline: () => pipelineType,
    preprocess: () => preprocessType,
    promise: () => promiseType,
    quotelessJson: () => quotelessJson,
    record: () => recordType,
    set: () => setType,
    setErrorMap: () => setErrorMap,
    strictObject: () => strictObjectType,
    string: () => stringType,
    symbol: () => symbolType,
    transformer: () => effectsType,
    tuple: () => tupleType,
    undefined: () => undefinedType,
    union: () => unionType,
    unknown: () => unknownType,
    util: () => util,
    void: () => voidType
  });

  // ../node_modules/zod/v3/helpers/util.js
  var util;
  (function(util2) {
    util2.assertEqual = (_) => {
    };
    function assertIs(_arg) {
    }
    util2.assertIs = assertIs;
    function assertNever(_x) {
      throw new Error();
    }
    util2.assertNever = assertNever;
    util2.arrayToEnum = (items) => {
      const obj = {};
      for (const item of items) {
        obj[item] = item;
      }
      return obj;
    };
    util2.getValidEnumValues = (obj) => {
      const validKeys = util2.objectKeys(obj).filter((k) => typeof obj[obj[k]] !== "number");
      const filtered = {};
      for (const k of validKeys) {
        filtered[k] = obj[k];
      }
      return util2.objectValues(filtered);
    };
    util2.objectValues = (obj) => {
      return util2.objectKeys(obj).map(function(e) {
        return obj[e];
      });
    };
    util2.objectKeys = typeof Object.keys === "function" ? (obj) => Object.keys(obj) : (object) => {
      const keys = [];
      for (const key in object) {
        if (Object.prototype.hasOwnProperty.call(object, key)) {
          keys.push(key);
        }
      }
      return keys;
    };
    util2.find = (arr, checker) => {
      for (const item of arr) {
        if (checker(item))
          return item;
      }
      return void 0;
    };
    util2.isInteger = typeof Number.isInteger === "function" ? (val) => Number.isInteger(val) : (val) => typeof val === "number" && Number.isFinite(val) && Math.floor(val) === val;
    function joinValues(array, separator = " | ") {
      return array.map((val) => typeof val === "string" ? `'${val}'` : val).join(separator);
    }
    util2.joinValues = joinValues;
    util2.jsonStringifyReplacer = (_, value) => {
      if (typeof value === "bigint") {
        return value.toString();
      }
      return value;
    };
  })(util || (util = {}));
  var objectUtil;
  (function(objectUtil2) {
    objectUtil2.mergeShapes = (first, second) => {
      return {
        ...first,
        ...second
        // second overwrites first
      };
    };
  })(objectUtil || (objectUtil = {}));
  var ZodParsedType = util.arrayToEnum([
    "string",
    "nan",
    "number",
    "integer",
    "float",
    "boolean",
    "date",
    "bigint",
    "symbol",
    "function",
    "undefined",
    "null",
    "array",
    "object",
    "unknown",
    "promise",
    "void",
    "never",
    "map",
    "set"
  ]);
  var getParsedType = (data) => {
    const t = typeof data;
    switch (t) {
      case "undefined":
        return ZodParsedType.undefined;
      case "string":
        return ZodParsedType.string;
      case "number":
        return Number.isNaN(data) ? ZodParsedType.nan : ZodParsedType.number;
      case "boolean":
        return ZodParsedType.boolean;
      case "function":
        return ZodParsedType.function;
      case "bigint":
        return ZodParsedType.bigint;
      case "symbol":
        return ZodParsedType.symbol;
      case "object":
        if (Array.isArray(data)) {
          return ZodParsedType.array;
        }
        if (data === null) {
          return ZodParsedType.null;
        }
        if (data.then && typeof data.then === "function" && data.catch && typeof data.catch === "function") {
          return ZodParsedType.promise;
        }
        if (typeof Map !== "undefined" && data instanceof Map) {
          return ZodParsedType.map;
        }
        if (typeof Set !== "undefined" && data instanceof Set) {
          return ZodParsedType.set;
        }
        if (typeof Date !== "undefined" && data instanceof Date) {
          return ZodParsedType.date;
        }
        return ZodParsedType.object;
      default:
        return ZodParsedType.unknown;
    }
  };

  // ../node_modules/zod/v3/ZodError.js
  var ZodIssueCode = util.arrayToEnum([
    "invalid_type",
    "invalid_literal",
    "custom",
    "invalid_union",
    "invalid_union_discriminator",
    "invalid_enum_value",
    "unrecognized_keys",
    "invalid_arguments",
    "invalid_return_type",
    "invalid_date",
    "invalid_string",
    "too_small",
    "too_big",
    "invalid_intersection_types",
    "not_multiple_of",
    "not_finite"
  ]);
  var quotelessJson = (obj) => {
    const json = JSON.stringify(obj, null, 2);
    return json.replace(/"([^"]+)":/g, "$1:");
  };
  var ZodError = class _ZodError extends Error {
    get errors() {
      return this.issues;
    }
    constructor(issues) {
      super();
      this.issues = [];
      this.addIssue = (sub) => {
        this.issues = [...this.issues, sub];
      };
      this.addIssues = (subs = []) => {
        this.issues = [...this.issues, ...subs];
      };
      const actualProto = new.target.prototype;
      if (Object.setPrototypeOf) {
        Object.setPrototypeOf(this, actualProto);
      } else {
        this.__proto__ = actualProto;
      }
      this.name = "ZodError";
      this.issues = issues;
    }
    format(_mapper) {
      const mapper = _mapper || function(issue) {
        return issue.message;
      };
      const fieldErrors = { _errors: [] };
      const processError = (error) => {
        for (const issue of error.issues) {
          if (issue.code === "invalid_union") {
            issue.unionErrors.map(processError);
          } else if (issue.code === "invalid_return_type") {
            processError(issue.returnTypeError);
          } else if (issue.code === "invalid_arguments") {
            processError(issue.argumentsError);
          } else if (issue.path.length === 0) {
            fieldErrors._errors.push(mapper(issue));
          } else {
            let curr = fieldErrors;
            let i = 0;
            while (i < issue.path.length) {
              const el = issue.path[i];
              const terminal = i === issue.path.length - 1;
              if (!terminal) {
                curr[el] = curr[el] || { _errors: [] };
              } else {
                curr[el] = curr[el] || { _errors: [] };
                curr[el]._errors.push(mapper(issue));
              }
              curr = curr[el];
              i++;
            }
          }
        }
      };
      processError(this);
      return fieldErrors;
    }
    static assert(value) {
      if (!(value instanceof _ZodError)) {
        throw new Error(`Not a ZodError: ${value}`);
      }
    }
    toString() {
      return this.message;
    }
    get message() {
      return JSON.stringify(this.issues, util.jsonStringifyReplacer, 2);
    }
    get isEmpty() {
      return this.issues.length === 0;
    }
    flatten(mapper = (issue) => issue.message) {
      const fieldErrors = {};
      const formErrors = [];
      for (const sub of this.issues) {
        if (sub.path.length > 0) {
          const firstEl = sub.path[0];
          fieldErrors[firstEl] = fieldErrors[firstEl] || [];
          fieldErrors[firstEl].push(mapper(sub));
        } else {
          formErrors.push(mapper(sub));
        }
      }
      return { formErrors, fieldErrors };
    }
    get formErrors() {
      return this.flatten();
    }
  };
  ZodError.create = (issues) => {
    const error = new ZodError(issues);
    return error;
  };

  // ../node_modules/zod/v3/locales/en.js
  var errorMap = (issue, _ctx) => {
    let message;
    switch (issue.code) {
      case ZodIssueCode.invalid_type:
        if (issue.received === ZodParsedType.undefined) {
          message = "Required";
        } else {
          message = `Expected ${issue.expected}, received ${issue.received}`;
        }
        break;
      case ZodIssueCode.invalid_literal:
        message = `Invalid literal value, expected ${JSON.stringify(issue.expected, util.jsonStringifyReplacer)}`;
        break;
      case ZodIssueCode.unrecognized_keys:
        message = `Unrecognized key(s) in object: ${util.joinValues(issue.keys, ", ")}`;
        break;
      case ZodIssueCode.invalid_union:
        message = `Invalid input`;
        break;
      case ZodIssueCode.invalid_union_discriminator:
        message = `Invalid discriminator value. Expected ${util.joinValues(issue.options)}`;
        break;
      case ZodIssueCode.invalid_enum_value:
        message = `Invalid enum value. Expected ${util.joinValues(issue.options)}, received '${issue.received}'`;
        break;
      case ZodIssueCode.invalid_arguments:
        message = `Invalid function arguments`;
        break;
      case ZodIssueCode.invalid_return_type:
        message = `Invalid function return type`;
        break;
      case ZodIssueCode.invalid_date:
        message = `Invalid date`;
        break;
      case ZodIssueCode.invalid_string:
        if (typeof issue.validation === "object") {
          if ("includes" in issue.validation) {
            message = `Invalid input: must include "${issue.validation.includes}"`;
            if (typeof issue.validation.position === "number") {
              message = `${message} at one or more positions greater than or equal to ${issue.validation.position}`;
            }
          } else if ("startsWith" in issue.validation) {
            message = `Invalid input: must start with "${issue.validation.startsWith}"`;
          } else if ("endsWith" in issue.validation) {
            message = `Invalid input: must end with "${issue.validation.endsWith}"`;
          } else {
            util.assertNever(issue.validation);
          }
        } else if (issue.validation !== "regex") {
          message = `Invalid ${issue.validation}`;
        } else {
          message = "Invalid";
        }
        break;
      case ZodIssueCode.too_small:
        if (issue.type === "array")
          message = `Array must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `more than`} ${issue.minimum} element(s)`;
        else if (issue.type === "string")
          message = `String must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `over`} ${issue.minimum} character(s)`;
        else if (issue.type === "number")
          message = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
        else if (issue.type === "bigint")
          message = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
        else if (issue.type === "date")
          message = `Date must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${new Date(Number(issue.minimum))}`;
        else
          message = "Invalid input";
        break;
      case ZodIssueCode.too_big:
        if (issue.type === "array")
          message = `Array must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `less than`} ${issue.maximum} element(s)`;
        else if (issue.type === "string")
          message = `String must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `under`} ${issue.maximum} character(s)`;
        else if (issue.type === "number")
          message = `Number must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
        else if (issue.type === "bigint")
          message = `BigInt must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
        else if (issue.type === "date")
          message = `Date must be ${issue.exact ? `exactly` : issue.inclusive ? `smaller than or equal to` : `smaller than`} ${new Date(Number(issue.maximum))}`;
        else
          message = "Invalid input";
        break;
      case ZodIssueCode.custom:
        message = `Invalid input`;
        break;
      case ZodIssueCode.invalid_intersection_types:
        message = `Intersection results could not be merged`;
        break;
      case ZodIssueCode.not_multiple_of:
        message = `Number must be a multiple of ${issue.multipleOf}`;
        break;
      case ZodIssueCode.not_finite:
        message = "Number must be finite";
        break;
      default:
        message = _ctx.defaultError;
        util.assertNever(issue);
    }
    return { message };
  };
  var en_default = errorMap;

  // ../node_modules/zod/v3/errors.js
  var overrideErrorMap = en_default;
  function setErrorMap(map) {
    overrideErrorMap = map;
  }
  function getErrorMap() {
    return overrideErrorMap;
  }

  // ../node_modules/zod/v3/helpers/parseUtil.js
  var makeIssue = (params) => {
    const { data, path, errorMaps, issueData } = params;
    const fullPath = [...path, ...issueData.path || []];
    const fullIssue = {
      ...issueData,
      path: fullPath
    };
    if (issueData.message !== void 0) {
      return {
        ...issueData,
        path: fullPath,
        message: issueData.message
      };
    }
    let errorMessage = "";
    const maps = errorMaps.filter((m) => !!m).slice().reverse();
    for (const map of maps) {
      errorMessage = map(fullIssue, { data, defaultError: errorMessage }).message;
    }
    return {
      ...issueData,
      path: fullPath,
      message: errorMessage
    };
  };
  var EMPTY_PATH = [];
  function addIssueToContext(ctx, issueData) {
    const overrideMap = getErrorMap();
    const issue = makeIssue({
      issueData,
      data: ctx.data,
      path: ctx.path,
      errorMaps: [
        ctx.common.contextualErrorMap,
        // contextual error map is first priority
        ctx.schemaErrorMap,
        // then schema-bound map if available
        overrideMap,
        // then global override map
        overrideMap === en_default ? void 0 : en_default
        // then global default map
      ].filter((x) => !!x)
    });
    ctx.common.issues.push(issue);
  }
  var ParseStatus = class _ParseStatus {
    constructor() {
      this.value = "valid";
    }
    dirty() {
      if (this.value === "valid")
        this.value = "dirty";
    }
    abort() {
      if (this.value !== "aborted")
        this.value = "aborted";
    }
    static mergeArray(status, results) {
      const arrayValue = [];
      for (const s of results) {
        if (s.status === "aborted")
          return INVALID;
        if (s.status === "dirty")
          status.dirty();
        arrayValue.push(s.value);
      }
      return { status: status.value, value: arrayValue };
    }
    static async mergeObjectAsync(status, pairs) {
      const syncPairs = [];
      for (const pair of pairs) {
        const key = await pair.key;
        const value = await pair.value;
        syncPairs.push({
          key,
          value
        });
      }
      return _ParseStatus.mergeObjectSync(status, syncPairs);
    }
    static mergeObjectSync(status, pairs) {
      const finalObject = {};
      for (const pair of pairs) {
        const { key, value } = pair;
        if (key.status === "aborted")
          return INVALID;
        if (value.status === "aborted")
          return INVALID;
        if (key.status === "dirty")
          status.dirty();
        if (value.status === "dirty")
          status.dirty();
        if (key.value !== "__proto__" && (typeof value.value !== "undefined" || pair.alwaysSet)) {
          finalObject[key.value] = value.value;
        }
      }
      return { status: status.value, value: finalObject };
    }
  };
  var INVALID = Object.freeze({
    status: "aborted"
  });
  var DIRTY = (value) => ({ status: "dirty", value });
  var OK = (value) => ({ status: "valid", value });
  var isAborted = (x) => x.status === "aborted";
  var isDirty = (x) => x.status === "dirty";
  var isValid = (x) => x.status === "valid";
  var isAsync = (x) => typeof Promise !== "undefined" && x instanceof Promise;

  // ../node_modules/zod/v3/helpers/errorUtil.js
  var errorUtil;
  (function(errorUtil2) {
    errorUtil2.errToObj = (message) => typeof message === "string" ? { message } : message || {};
    errorUtil2.toString = (message) => typeof message === "string" ? message : message?.message;
  })(errorUtil || (errorUtil = {}));

  // ../node_modules/zod/v3/types.js
  var ParseInputLazyPath = class {
    constructor(parent, value, path, key) {
      this._cachedPath = [];
      this.parent = parent;
      this.data = value;
      this._path = path;
      this._key = key;
    }
    get path() {
      if (!this._cachedPath.length) {
        if (Array.isArray(this._key)) {
          this._cachedPath.push(...this._path, ...this._key);
        } else {
          this._cachedPath.push(...this._path, this._key);
        }
      }
      return this._cachedPath;
    }
  };
  var handleResult = (ctx, result) => {
    if (isValid(result)) {
      return { success: true, data: result.value };
    } else {
      if (!ctx.common.issues.length) {
        throw new Error("Validation failed but no issues detected.");
      }
      return {
        success: false,
        get error() {
          if (this._error)
            return this._error;
          const error = new ZodError(ctx.common.issues);
          this._error = error;
          return this._error;
        }
      };
    }
  };
  function processCreateParams(params) {
    if (!params)
      return {};
    const { errorMap: errorMap2, invalid_type_error, required_error, description } = params;
    if (errorMap2 && (invalid_type_error || required_error)) {
      throw new Error(`Can't use "invalid_type_error" or "required_error" in conjunction with custom error map.`);
    }
    if (errorMap2)
      return { errorMap: errorMap2, description };
    const customMap = (iss, ctx) => {
      const { message } = params;
      if (iss.code === "invalid_enum_value") {
        return { message: message ?? ctx.defaultError };
      }
      if (typeof ctx.data === "undefined") {
        return { message: message ?? required_error ?? ctx.defaultError };
      }
      if (iss.code !== "invalid_type")
        return { message: ctx.defaultError };
      return { message: message ?? invalid_type_error ?? ctx.defaultError };
    };
    return { errorMap: customMap, description };
  }
  var ZodType = class {
    get description() {
      return this._def.description;
    }
    _getType(input) {
      return getParsedType(input.data);
    }
    _getOrReturnCtx(input, ctx) {
      return ctx || {
        common: input.parent.common,
        data: input.data,
        parsedType: getParsedType(input.data),
        schemaErrorMap: this._def.errorMap,
        path: input.path,
        parent: input.parent
      };
    }
    _processInputParams(input) {
      return {
        status: new ParseStatus(),
        ctx: {
          common: input.parent.common,
          data: input.data,
          parsedType: getParsedType(input.data),
          schemaErrorMap: this._def.errorMap,
          path: input.path,
          parent: input.parent
        }
      };
    }
    _parseSync(input) {
      const result = this._parse(input);
      if (isAsync(result)) {
        throw new Error("Synchronous parse encountered promise.");
      }
      return result;
    }
    _parseAsync(input) {
      const result = this._parse(input);
      return Promise.resolve(result);
    }
    parse(data, params) {
      const result = this.safeParse(data, params);
      if (result.success)
        return result.data;
      throw result.error;
    }
    safeParse(data, params) {
      const ctx = {
        common: {
          issues: [],
          async: params?.async ?? false,
          contextualErrorMap: params?.errorMap
        },
        path: params?.path || [],
        schemaErrorMap: this._def.errorMap,
        parent: null,
        data,
        parsedType: getParsedType(data)
      };
      const result = this._parseSync({ data, path: ctx.path, parent: ctx });
      return handleResult(ctx, result);
    }
    "~validate"(data) {
      const ctx = {
        common: {
          issues: [],
          async: !!this["~standard"].async
        },
        path: [],
        schemaErrorMap: this._def.errorMap,
        parent: null,
        data,
        parsedType: getParsedType(data)
      };
      if (!this["~standard"].async) {
        try {
          const result = this._parseSync({ data, path: [], parent: ctx });
          return isValid(result) ? {
            value: result.value
          } : {
            issues: ctx.common.issues
          };
        } catch (err) {
          if (err?.message?.toLowerCase()?.includes("encountered")) {
            this["~standard"].async = true;
          }
          ctx.common = {
            issues: [],
            async: true
          };
        }
      }
      return this._parseAsync({ data, path: [], parent: ctx }).then((result) => isValid(result) ? {
        value: result.value
      } : {
        issues: ctx.common.issues
      });
    }
    async parseAsync(data, params) {
      const result = await this.safeParseAsync(data, params);
      if (result.success)
        return result.data;
      throw result.error;
    }
    async safeParseAsync(data, params) {
      const ctx = {
        common: {
          issues: [],
          contextualErrorMap: params?.errorMap,
          async: true
        },
        path: params?.path || [],
        schemaErrorMap: this._def.errorMap,
        parent: null,
        data,
        parsedType: getParsedType(data)
      };
      const maybeAsyncResult = this._parse({ data, path: ctx.path, parent: ctx });
      const result = await (isAsync(maybeAsyncResult) ? maybeAsyncResult : Promise.resolve(maybeAsyncResult));
      return handleResult(ctx, result);
    }
    refine(check, message) {
      const getIssueProperties = (val) => {
        if (typeof message === "string" || typeof message === "undefined") {
          return { message };
        } else if (typeof message === "function") {
          return message(val);
        } else {
          return message;
        }
      };
      return this._refinement((val, ctx) => {
        const result = check(val);
        const setError = () => ctx.addIssue({
          code: ZodIssueCode.custom,
          ...getIssueProperties(val)
        });
        if (typeof Promise !== "undefined" && result instanceof Promise) {
          return result.then((data) => {
            if (!data) {
              setError();
              return false;
            } else {
              return true;
            }
          });
        }
        if (!result) {
          setError();
          return false;
        } else {
          return true;
        }
      });
    }
    refinement(check, refinementData) {
      return this._refinement((val, ctx) => {
        if (!check(val)) {
          ctx.addIssue(typeof refinementData === "function" ? refinementData(val, ctx) : refinementData);
          return false;
        } else {
          return true;
        }
      });
    }
    _refinement(refinement) {
      return new ZodEffects({
        schema: this,
        typeName: ZodFirstPartyTypeKind.ZodEffects,
        effect: { type: "refinement", refinement }
      });
    }
    superRefine(refinement) {
      return this._refinement(refinement);
    }
    constructor(def) {
      this.spa = this.safeParseAsync;
      this._def = def;
      this.parse = this.parse.bind(this);
      this.safeParse = this.safeParse.bind(this);
      this.parseAsync = this.parseAsync.bind(this);
      this.safeParseAsync = this.safeParseAsync.bind(this);
      this.spa = this.spa.bind(this);
      this.refine = this.refine.bind(this);
      this.refinement = this.refinement.bind(this);
      this.superRefine = this.superRefine.bind(this);
      this.optional = this.optional.bind(this);
      this.nullable = this.nullable.bind(this);
      this.nullish = this.nullish.bind(this);
      this.array = this.array.bind(this);
      this.promise = this.promise.bind(this);
      this.or = this.or.bind(this);
      this.and = this.and.bind(this);
      this.transform = this.transform.bind(this);
      this.brand = this.brand.bind(this);
      this.default = this.default.bind(this);
      this.catch = this.catch.bind(this);
      this.describe = this.describe.bind(this);
      this.pipe = this.pipe.bind(this);
      this.readonly = this.readonly.bind(this);
      this.isNullable = this.isNullable.bind(this);
      this.isOptional = this.isOptional.bind(this);
      this["~standard"] = {
        version: 1,
        vendor: "zod",
        validate: (data) => this["~validate"](data)
      };
    }
    optional() {
      return ZodOptional.create(this, this._def);
    }
    nullable() {
      return ZodNullable.create(this, this._def);
    }
    nullish() {
      return this.nullable().optional();
    }
    array() {
      return ZodArray.create(this);
    }
    promise() {
      return ZodPromise.create(this, this._def);
    }
    or(option) {
      return ZodUnion.create([this, option], this._def);
    }
    and(incoming) {
      return ZodIntersection.create(this, incoming, this._def);
    }
    transform(transform) {
      return new ZodEffects({
        ...processCreateParams(this._def),
        schema: this,
        typeName: ZodFirstPartyTypeKind.ZodEffects,
        effect: { type: "transform", transform }
      });
    }
    default(def) {
      const defaultValueFunc = typeof def === "function" ? def : () => def;
      return new ZodDefault({
        ...processCreateParams(this._def),
        innerType: this,
        defaultValue: defaultValueFunc,
        typeName: ZodFirstPartyTypeKind.ZodDefault
      });
    }
    brand() {
      return new ZodBranded({
        typeName: ZodFirstPartyTypeKind.ZodBranded,
        type: this,
        ...processCreateParams(this._def)
      });
    }
    catch(def) {
      const catchValueFunc = typeof def === "function" ? def : () => def;
      return new ZodCatch({
        ...processCreateParams(this._def),
        innerType: this,
        catchValue: catchValueFunc,
        typeName: ZodFirstPartyTypeKind.ZodCatch
      });
    }
    describe(description) {
      const This = this.constructor;
      return new This({
        ...this._def,
        description
      });
    }
    pipe(target) {
      return ZodPipeline.create(this, target);
    }
    readonly() {
      return ZodReadonly.create(this);
    }
    isOptional() {
      return this.safeParse(void 0).success;
    }
    isNullable() {
      return this.safeParse(null).success;
    }
  };
  var cuidRegex = /^c[^\s-]{8,}$/i;
  var cuid2Regex = /^[0-9a-z]+$/;
  var ulidRegex = /^[0-9A-HJKMNP-TV-Z]{26}$/i;
  var uuidRegex = /^[0-9a-fA-F]{8}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{12}$/i;
  var nanoidRegex = /^[a-z0-9_-]{21}$/i;
  var jwtRegex = /^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]*$/;
  var durationRegex = /^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/;
  var emailRegex = /^(?!\.)(?!.*\.\.)([A-Z0-9_'+\-\.]*)[A-Z0-9_+-]@([A-Z0-9][A-Z0-9\-]*\.)+[A-Z]{2,}$/i;
  var _emojiRegex = `^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$`;
  var emojiRegex;
  var ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/;
  var ipv4CidrRegex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/(3[0-2]|[12]?[0-9])$/;
  var ipv6Regex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))$/;
  var ipv6CidrRegex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/;
  var base64Regex = /^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/;
  var base64urlRegex = /^([0-9a-zA-Z-_]{4})*(([0-9a-zA-Z-_]{2}(==)?)|([0-9a-zA-Z-_]{3}(=)?))?$/;
  var dateRegexSource = `((\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-((0[13578]|1[02])-(0[1-9]|[12]\\d|3[01])|(0[469]|11)-(0[1-9]|[12]\\d|30)|(02)-(0[1-9]|1\\d|2[0-8])))`;
  var dateRegex = new RegExp(`^${dateRegexSource}$`);
  function timeRegexSource(args) {
    let secondsRegexSource = `[0-5]\\d`;
    if (args.precision) {
      secondsRegexSource = `${secondsRegexSource}\\.\\d{${args.precision}}`;
    } else if (args.precision == null) {
      secondsRegexSource = `${secondsRegexSource}(\\.\\d+)?`;
    }
    const secondsQuantifier = args.precision ? "+" : "?";
    return `([01]\\d|2[0-3]):[0-5]\\d(:${secondsRegexSource})${secondsQuantifier}`;
  }
  function timeRegex(args) {
    return new RegExp(`^${timeRegexSource(args)}$`);
  }
  function datetimeRegex(args) {
    let regex = `${dateRegexSource}T${timeRegexSource(args)}`;
    const opts = [];
    opts.push(args.local ? `Z?` : `Z`);
    if (args.offset)
      opts.push(`([+-]\\d{2}:?\\d{2})`);
    regex = `${regex}(${opts.join("|")})`;
    return new RegExp(`^${regex}$`);
  }
  function isValidIP(ip, version) {
    if ((version === "v4" || !version) && ipv4Regex.test(ip)) {
      return true;
    }
    if ((version === "v6" || !version) && ipv6Regex.test(ip)) {
      return true;
    }
    return false;
  }
  function isValidJWT(jwt, alg) {
    if (!jwtRegex.test(jwt))
      return false;
    try {
      const [header] = jwt.split(".");
      if (!header)
        return false;
      const base64 = header.replace(/-/g, "+").replace(/_/g, "/").padEnd(header.length + (4 - header.length % 4) % 4, "=");
      const decoded = JSON.parse(atob(base64));
      if (typeof decoded !== "object" || decoded === null)
        return false;
      if ("typ" in decoded && decoded?.typ !== "JWT")
        return false;
      if (!decoded.alg)
        return false;
      if (alg && decoded.alg !== alg)
        return false;
      return true;
    } catch {
      return false;
    }
  }
  function isValidCidr(ip, version) {
    if ((version === "v4" || !version) && ipv4CidrRegex.test(ip)) {
      return true;
    }
    if ((version === "v6" || !version) && ipv6CidrRegex.test(ip)) {
      return true;
    }
    return false;
  }
  var ZodString = class _ZodString extends ZodType {
    _parse(input) {
      if (this._def.coerce) {
        input.data = String(input.data);
      }
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.string) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.string,
          received: ctx2.parsedType
        });
        return INVALID;
      }
      const status = new ParseStatus();
      let ctx = void 0;
      for (const check of this._def.checks) {
        if (check.kind === "min") {
          if (input.data.length < check.value) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              minimum: check.value,
              type: "string",
              inclusive: true,
              exact: false,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "max") {
          if (input.data.length > check.value) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              maximum: check.value,
              type: "string",
              inclusive: true,
              exact: false,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "length") {
          const tooBig = input.data.length > check.value;
          const tooSmall = input.data.length < check.value;
          if (tooBig || tooSmall) {
            ctx = this._getOrReturnCtx(input, ctx);
            if (tooBig) {
              addIssueToContext(ctx, {
                code: ZodIssueCode.too_big,
                maximum: check.value,
                type: "string",
                inclusive: true,
                exact: true,
                message: check.message
              });
            } else if (tooSmall) {
              addIssueToContext(ctx, {
                code: ZodIssueCode.too_small,
                minimum: check.value,
                type: "string",
                inclusive: true,
                exact: true,
                message: check.message
              });
            }
            status.dirty();
          }
        } else if (check.kind === "email") {
          if (!emailRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "email",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "emoji") {
          if (!emojiRegex) {
            emojiRegex = new RegExp(_emojiRegex, "u");
          }
          if (!emojiRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "emoji",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "uuid") {
          if (!uuidRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "uuid",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "nanoid") {
          if (!nanoidRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "nanoid",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "cuid") {
          if (!cuidRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "cuid",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "cuid2") {
          if (!cuid2Regex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "cuid2",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "ulid") {
          if (!ulidRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "ulid",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "url") {
          try {
            new URL(input.data);
          } catch {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "url",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "regex") {
          check.regex.lastIndex = 0;
          const testResult = check.regex.test(input.data);
          if (!testResult) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "regex",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "trim") {
          input.data = input.data.trim();
        } else if (check.kind === "includes") {
          if (!input.data.includes(check.value, check.position)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: { includes: check.value, position: check.position },
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "toLowerCase") {
          input.data = input.data.toLowerCase();
        } else if (check.kind === "toUpperCase") {
          input.data = input.data.toUpperCase();
        } else if (check.kind === "startsWith") {
          if (!input.data.startsWith(check.value)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: { startsWith: check.value },
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "endsWith") {
          if (!input.data.endsWith(check.value)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: { endsWith: check.value },
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "datetime") {
          const regex = datetimeRegex(check);
          if (!regex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: "datetime",
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "date") {
          const regex = dateRegex;
          if (!regex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: "date",
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "time") {
          const regex = timeRegex(check);
          if (!regex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: "time",
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "duration") {
          if (!durationRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "duration",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "ip") {
          if (!isValidIP(input.data, check.version)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "ip",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "jwt") {
          if (!isValidJWT(input.data, check.alg)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "jwt",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "cidr") {
          if (!isValidCidr(input.data, check.version)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "cidr",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "base64") {
          if (!base64Regex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "base64",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "base64url") {
          if (!base64urlRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "base64url",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else {
          util.assertNever(check);
        }
      }
      return { status: status.value, value: input.data };
    }
    _regex(regex, validation, message) {
      return this.refinement((data) => regex.test(data), {
        validation,
        code: ZodIssueCode.invalid_string,
        ...errorUtil.errToObj(message)
      });
    }
    _addCheck(check) {
      return new _ZodString({
        ...this._def,
        checks: [...this._def.checks, check]
      });
    }
    email(message) {
      return this._addCheck({ kind: "email", ...errorUtil.errToObj(message) });
    }
    url(message) {
      return this._addCheck({ kind: "url", ...errorUtil.errToObj(message) });
    }
    emoji(message) {
      return this._addCheck({ kind: "emoji", ...errorUtil.errToObj(message) });
    }
    uuid(message) {
      return this._addCheck({ kind: "uuid", ...errorUtil.errToObj(message) });
    }
    nanoid(message) {
      return this._addCheck({ kind: "nanoid", ...errorUtil.errToObj(message) });
    }
    cuid(message) {
      return this._addCheck({ kind: "cuid", ...errorUtil.errToObj(message) });
    }
    cuid2(message) {
      return this._addCheck({ kind: "cuid2", ...errorUtil.errToObj(message) });
    }
    ulid(message) {
      return this._addCheck({ kind: "ulid", ...errorUtil.errToObj(message) });
    }
    base64(message) {
      return this._addCheck({ kind: "base64", ...errorUtil.errToObj(message) });
    }
    base64url(message) {
      return this._addCheck({
        kind: "base64url",
        ...errorUtil.errToObj(message)
      });
    }
    jwt(options) {
      return this._addCheck({ kind: "jwt", ...errorUtil.errToObj(options) });
    }
    ip(options) {
      return this._addCheck({ kind: "ip", ...errorUtil.errToObj(options) });
    }
    cidr(options) {
      return this._addCheck({ kind: "cidr", ...errorUtil.errToObj(options) });
    }
    datetime(options) {
      if (typeof options === "string") {
        return this._addCheck({
          kind: "datetime",
          precision: null,
          offset: false,
          local: false,
          message: options
        });
      }
      return this._addCheck({
        kind: "datetime",
        precision: typeof options?.precision === "undefined" ? null : options?.precision,
        offset: options?.offset ?? false,
        local: options?.local ?? false,
        ...errorUtil.errToObj(options?.message)
      });
    }
    date(message) {
      return this._addCheck({ kind: "date", message });
    }
    time(options) {
      if (typeof options === "string") {
        return this._addCheck({
          kind: "time",
          precision: null,
          message: options
        });
      }
      return this._addCheck({
        kind: "time",
        precision: typeof options?.precision === "undefined" ? null : options?.precision,
        ...errorUtil.errToObj(options?.message)
      });
    }
    duration(message) {
      return this._addCheck({ kind: "duration", ...errorUtil.errToObj(message) });
    }
    regex(regex, message) {
      return this._addCheck({
        kind: "regex",
        regex,
        ...errorUtil.errToObj(message)
      });
    }
    includes(value, options) {
      return this._addCheck({
        kind: "includes",
        value,
        position: options?.position,
        ...errorUtil.errToObj(options?.message)
      });
    }
    startsWith(value, message) {
      return this._addCheck({
        kind: "startsWith",
        value,
        ...errorUtil.errToObj(message)
      });
    }
    endsWith(value, message) {
      return this._addCheck({
        kind: "endsWith",
        value,
        ...errorUtil.errToObj(message)
      });
    }
    min(minLength, message) {
      return this._addCheck({
        kind: "min",
        value: minLength,
        ...errorUtil.errToObj(message)
      });
    }
    max(maxLength, message) {
      return this._addCheck({
        kind: "max",
        value: maxLength,
        ...errorUtil.errToObj(message)
      });
    }
    length(len, message) {
      return this._addCheck({
        kind: "length",
        value: len,
        ...errorUtil.errToObj(message)
      });
    }
    /**
     * Equivalent to `.min(1)`
     */
    nonempty(message) {
      return this.min(1, errorUtil.errToObj(message));
    }
    trim() {
      return new _ZodString({
        ...this._def,
        checks: [...this._def.checks, { kind: "trim" }]
      });
    }
    toLowerCase() {
      return new _ZodString({
        ...this._def,
        checks: [...this._def.checks, { kind: "toLowerCase" }]
      });
    }
    toUpperCase() {
      return new _ZodString({
        ...this._def,
        checks: [...this._def.checks, { kind: "toUpperCase" }]
      });
    }
    get isDatetime() {
      return !!this._def.checks.find((ch) => ch.kind === "datetime");
    }
    get isDate() {
      return !!this._def.checks.find((ch) => ch.kind === "date");
    }
    get isTime() {
      return !!this._def.checks.find((ch) => ch.kind === "time");
    }
    get isDuration() {
      return !!this._def.checks.find((ch) => ch.kind === "duration");
    }
    get isEmail() {
      return !!this._def.checks.find((ch) => ch.kind === "email");
    }
    get isURL() {
      return !!this._def.checks.find((ch) => ch.kind === "url");
    }
    get isEmoji() {
      return !!this._def.checks.find((ch) => ch.kind === "emoji");
    }
    get isUUID() {
      return !!this._def.checks.find((ch) => ch.kind === "uuid");
    }
    get isNANOID() {
      return !!this._def.checks.find((ch) => ch.kind === "nanoid");
    }
    get isCUID() {
      return !!this._def.checks.find((ch) => ch.kind === "cuid");
    }
    get isCUID2() {
      return !!this._def.checks.find((ch) => ch.kind === "cuid2");
    }
    get isULID() {
      return !!this._def.checks.find((ch) => ch.kind === "ulid");
    }
    get isIP() {
      return !!this._def.checks.find((ch) => ch.kind === "ip");
    }
    get isCIDR() {
      return !!this._def.checks.find((ch) => ch.kind === "cidr");
    }
    get isBase64() {
      return !!this._def.checks.find((ch) => ch.kind === "base64");
    }
    get isBase64url() {
      return !!this._def.checks.find((ch) => ch.kind === "base64url");
    }
    get minLength() {
      let min = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "min") {
          if (min === null || ch.value > min)
            min = ch.value;
        }
      }
      return min;
    }
    get maxLength() {
      let max = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "max") {
          if (max === null || ch.value < max)
            max = ch.value;
        }
      }
      return max;
    }
  };
  ZodString.create = (params) => {
    return new ZodString({
      checks: [],
      typeName: ZodFirstPartyTypeKind.ZodString,
      coerce: params?.coerce ?? false,
      ...processCreateParams(params)
    });
  };
  function floatSafeRemainder(val, step) {
    const valDecCount = (val.toString().split(".")[1] || "").length;
    const stepDecCount = (step.toString().split(".")[1] || "").length;
    const decCount = valDecCount > stepDecCount ? valDecCount : stepDecCount;
    const valInt = Number.parseInt(val.toFixed(decCount).replace(".", ""));
    const stepInt = Number.parseInt(step.toFixed(decCount).replace(".", ""));
    return valInt % stepInt / 10 ** decCount;
  }
  var ZodNumber = class _ZodNumber extends ZodType {
    constructor() {
      super(...arguments);
      this.min = this.gte;
      this.max = this.lte;
      this.step = this.multipleOf;
    }
    _parse(input) {
      if (this._def.coerce) {
        input.data = Number(input.data);
      }
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.number) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.number,
          received: ctx2.parsedType
        });
        return INVALID;
      }
      let ctx = void 0;
      const status = new ParseStatus();
      for (const check of this._def.checks) {
        if (check.kind === "int") {
          if (!util.isInteger(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_type,
              expected: "integer",
              received: "float",
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "min") {
          const tooSmall = check.inclusive ? input.data < check.value : input.data <= check.value;
          if (tooSmall) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              minimum: check.value,
              type: "number",
              inclusive: check.inclusive,
              exact: false,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "max") {
          const tooBig = check.inclusive ? input.data > check.value : input.data >= check.value;
          if (tooBig) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              maximum: check.value,
              type: "number",
              inclusive: check.inclusive,
              exact: false,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "multipleOf") {
          if (floatSafeRemainder(input.data, check.value) !== 0) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.not_multiple_of,
              multipleOf: check.value,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "finite") {
          if (!Number.isFinite(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.not_finite,
              message: check.message
            });
            status.dirty();
          }
        } else {
          util.assertNever(check);
        }
      }
      return { status: status.value, value: input.data };
    }
    gte(value, message) {
      return this.setLimit("min", value, true, errorUtil.toString(message));
    }
    gt(value, message) {
      return this.setLimit("min", value, false, errorUtil.toString(message));
    }
    lte(value, message) {
      return this.setLimit("max", value, true, errorUtil.toString(message));
    }
    lt(value, message) {
      return this.setLimit("max", value, false, errorUtil.toString(message));
    }
    setLimit(kind, value, inclusive, message) {
      return new _ZodNumber({
        ...this._def,
        checks: [
          ...this._def.checks,
          {
            kind,
            value,
            inclusive,
            message: errorUtil.toString(message)
          }
        ]
      });
    }
    _addCheck(check) {
      return new _ZodNumber({
        ...this._def,
        checks: [...this._def.checks, check]
      });
    }
    int(message) {
      return this._addCheck({
        kind: "int",
        message: errorUtil.toString(message)
      });
    }
    positive(message) {
      return this._addCheck({
        kind: "min",
        value: 0,
        inclusive: false,
        message: errorUtil.toString(message)
      });
    }
    negative(message) {
      return this._addCheck({
        kind: "max",
        value: 0,
        inclusive: false,
        message: errorUtil.toString(message)
      });
    }
    nonpositive(message) {
      return this._addCheck({
        kind: "max",
        value: 0,
        inclusive: true,
        message: errorUtil.toString(message)
      });
    }
    nonnegative(message) {
      return this._addCheck({
        kind: "min",
        value: 0,
        inclusive: true,
        message: errorUtil.toString(message)
      });
    }
    multipleOf(value, message) {
      return this._addCheck({
        kind: "multipleOf",
        value,
        message: errorUtil.toString(message)
      });
    }
    finite(message) {
      return this._addCheck({
        kind: "finite",
        message: errorUtil.toString(message)
      });
    }
    safe(message) {
      return this._addCheck({
        kind: "min",
        inclusive: true,
        value: Number.MIN_SAFE_INTEGER,
        message: errorUtil.toString(message)
      })._addCheck({
        kind: "max",
        inclusive: true,
        value: Number.MAX_SAFE_INTEGER,
        message: errorUtil.toString(message)
      });
    }
    get minValue() {
      let min = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "min") {
          if (min === null || ch.value > min)
            min = ch.value;
        }
      }
      return min;
    }
    get maxValue() {
      let max = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "max") {
          if (max === null || ch.value < max)
            max = ch.value;
        }
      }
      return max;
    }
    get isInt() {
      return !!this._def.checks.find((ch) => ch.kind === "int" || ch.kind === "multipleOf" && util.isInteger(ch.value));
    }
    get isFinite() {
      let max = null;
      let min = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "finite" || ch.kind === "int" || ch.kind === "multipleOf") {
          return true;
        } else if (ch.kind === "min") {
          if (min === null || ch.value > min)
            min = ch.value;
        } else if (ch.kind === "max") {
          if (max === null || ch.value < max)
            max = ch.value;
        }
      }
      return Number.isFinite(min) && Number.isFinite(max);
    }
  };
  ZodNumber.create = (params) => {
    return new ZodNumber({
      checks: [],
      typeName: ZodFirstPartyTypeKind.ZodNumber,
      coerce: params?.coerce || false,
      ...processCreateParams(params)
    });
  };
  var ZodBigInt = class _ZodBigInt extends ZodType {
    constructor() {
      super(...arguments);
      this.min = this.gte;
      this.max = this.lte;
    }
    _parse(input) {
      if (this._def.coerce) {
        try {
          input.data = BigInt(input.data);
        } catch {
          return this._getInvalidInput(input);
        }
      }
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.bigint) {
        return this._getInvalidInput(input);
      }
      let ctx = void 0;
      const status = new ParseStatus();
      for (const check of this._def.checks) {
        if (check.kind === "min") {
          const tooSmall = check.inclusive ? input.data < check.value : input.data <= check.value;
          if (tooSmall) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              type: "bigint",
              minimum: check.value,
              inclusive: check.inclusive,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "max") {
          const tooBig = check.inclusive ? input.data > check.value : input.data >= check.value;
          if (tooBig) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              type: "bigint",
              maximum: check.value,
              inclusive: check.inclusive,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "multipleOf") {
          if (input.data % check.value !== BigInt(0)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.not_multiple_of,
              multipleOf: check.value,
              message: check.message
            });
            status.dirty();
          }
        } else {
          util.assertNever(check);
        }
      }
      return { status: status.value, value: input.data };
    }
    _getInvalidInput(input) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.bigint,
        received: ctx.parsedType
      });
      return INVALID;
    }
    gte(value, message) {
      return this.setLimit("min", value, true, errorUtil.toString(message));
    }
    gt(value, message) {
      return this.setLimit("min", value, false, errorUtil.toString(message));
    }
    lte(value, message) {
      return this.setLimit("max", value, true, errorUtil.toString(message));
    }
    lt(value, message) {
      return this.setLimit("max", value, false, errorUtil.toString(message));
    }
    setLimit(kind, value, inclusive, message) {
      return new _ZodBigInt({
        ...this._def,
        checks: [
          ...this._def.checks,
          {
            kind,
            value,
            inclusive,
            message: errorUtil.toString(message)
          }
        ]
      });
    }
    _addCheck(check) {
      return new _ZodBigInt({
        ...this._def,
        checks: [...this._def.checks, check]
      });
    }
    positive(message) {
      return this._addCheck({
        kind: "min",
        value: BigInt(0),
        inclusive: false,
        message: errorUtil.toString(message)
      });
    }
    negative(message) {
      return this._addCheck({
        kind: "max",
        value: BigInt(0),
        inclusive: false,
        message: errorUtil.toString(message)
      });
    }
    nonpositive(message) {
      return this._addCheck({
        kind: "max",
        value: BigInt(0),
        inclusive: true,
        message: errorUtil.toString(message)
      });
    }
    nonnegative(message) {
      return this._addCheck({
        kind: "min",
        value: BigInt(0),
        inclusive: true,
        message: errorUtil.toString(message)
      });
    }
    multipleOf(value, message) {
      return this._addCheck({
        kind: "multipleOf",
        value,
        message: errorUtil.toString(message)
      });
    }
    get minValue() {
      let min = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "min") {
          if (min === null || ch.value > min)
            min = ch.value;
        }
      }
      return min;
    }
    get maxValue() {
      let max = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "max") {
          if (max === null || ch.value < max)
            max = ch.value;
        }
      }
      return max;
    }
  };
  ZodBigInt.create = (params) => {
    return new ZodBigInt({
      checks: [],
      typeName: ZodFirstPartyTypeKind.ZodBigInt,
      coerce: params?.coerce ?? false,
      ...processCreateParams(params)
    });
  };
  var ZodBoolean = class extends ZodType {
    _parse(input) {
      if (this._def.coerce) {
        input.data = Boolean(input.data);
      }
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.boolean) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.boolean,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return OK(input.data);
    }
  };
  ZodBoolean.create = (params) => {
    return new ZodBoolean({
      typeName: ZodFirstPartyTypeKind.ZodBoolean,
      coerce: params?.coerce || false,
      ...processCreateParams(params)
    });
  };
  var ZodDate = class _ZodDate extends ZodType {
    _parse(input) {
      if (this._def.coerce) {
        input.data = new Date(input.data);
      }
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.date) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.date,
          received: ctx2.parsedType
        });
        return INVALID;
      }
      if (Number.isNaN(input.data.getTime())) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_date
        });
        return INVALID;
      }
      const status = new ParseStatus();
      let ctx = void 0;
      for (const check of this._def.checks) {
        if (check.kind === "min") {
          if (input.data.getTime() < check.value) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              message: check.message,
              inclusive: true,
              exact: false,
              minimum: check.value,
              type: "date"
            });
            status.dirty();
          }
        } else if (check.kind === "max") {
          if (input.data.getTime() > check.value) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              message: check.message,
              inclusive: true,
              exact: false,
              maximum: check.value,
              type: "date"
            });
            status.dirty();
          }
        } else {
          util.assertNever(check);
        }
      }
      return {
        status: status.value,
        value: new Date(input.data.getTime())
      };
    }
    _addCheck(check) {
      return new _ZodDate({
        ...this._def,
        checks: [...this._def.checks, check]
      });
    }
    min(minDate, message) {
      return this._addCheck({
        kind: "min",
        value: minDate.getTime(),
        message: errorUtil.toString(message)
      });
    }
    max(maxDate, message) {
      return this._addCheck({
        kind: "max",
        value: maxDate.getTime(),
        message: errorUtil.toString(message)
      });
    }
    get minDate() {
      let min = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "min") {
          if (min === null || ch.value > min)
            min = ch.value;
        }
      }
      return min != null ? new Date(min) : null;
    }
    get maxDate() {
      let max = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "max") {
          if (max === null || ch.value < max)
            max = ch.value;
        }
      }
      return max != null ? new Date(max) : null;
    }
  };
  ZodDate.create = (params) => {
    return new ZodDate({
      checks: [],
      coerce: params?.coerce || false,
      typeName: ZodFirstPartyTypeKind.ZodDate,
      ...processCreateParams(params)
    });
  };
  var ZodSymbol = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.symbol) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.symbol,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return OK(input.data);
    }
  };
  ZodSymbol.create = (params) => {
    return new ZodSymbol({
      typeName: ZodFirstPartyTypeKind.ZodSymbol,
      ...processCreateParams(params)
    });
  };
  var ZodUndefined = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.undefined) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.undefined,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return OK(input.data);
    }
  };
  ZodUndefined.create = (params) => {
    return new ZodUndefined({
      typeName: ZodFirstPartyTypeKind.ZodUndefined,
      ...processCreateParams(params)
    });
  };
  var ZodNull = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.null) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.null,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return OK(input.data);
    }
  };
  ZodNull.create = (params) => {
    return new ZodNull({
      typeName: ZodFirstPartyTypeKind.ZodNull,
      ...processCreateParams(params)
    });
  };
  var ZodAny = class extends ZodType {
    constructor() {
      super(...arguments);
      this._any = true;
    }
    _parse(input) {
      return OK(input.data);
    }
  };
  ZodAny.create = (params) => {
    return new ZodAny({
      typeName: ZodFirstPartyTypeKind.ZodAny,
      ...processCreateParams(params)
    });
  };
  var ZodUnknown = class extends ZodType {
    constructor() {
      super(...arguments);
      this._unknown = true;
    }
    _parse(input) {
      return OK(input.data);
    }
  };
  ZodUnknown.create = (params) => {
    return new ZodUnknown({
      typeName: ZodFirstPartyTypeKind.ZodUnknown,
      ...processCreateParams(params)
    });
  };
  var ZodNever = class extends ZodType {
    _parse(input) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.never,
        received: ctx.parsedType
      });
      return INVALID;
    }
  };
  ZodNever.create = (params) => {
    return new ZodNever({
      typeName: ZodFirstPartyTypeKind.ZodNever,
      ...processCreateParams(params)
    });
  };
  var ZodVoid = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.undefined) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.void,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return OK(input.data);
    }
  };
  ZodVoid.create = (params) => {
    return new ZodVoid({
      typeName: ZodFirstPartyTypeKind.ZodVoid,
      ...processCreateParams(params)
    });
  };
  var ZodArray = class _ZodArray extends ZodType {
    _parse(input) {
      const { ctx, status } = this._processInputParams(input);
      const def = this._def;
      if (ctx.parsedType !== ZodParsedType.array) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.array,
          received: ctx.parsedType
        });
        return INVALID;
      }
      if (def.exactLength !== null) {
        const tooBig = ctx.data.length > def.exactLength.value;
        const tooSmall = ctx.data.length < def.exactLength.value;
        if (tooBig || tooSmall) {
          addIssueToContext(ctx, {
            code: tooBig ? ZodIssueCode.too_big : ZodIssueCode.too_small,
            minimum: tooSmall ? def.exactLength.value : void 0,
            maximum: tooBig ? def.exactLength.value : void 0,
            type: "array",
            inclusive: true,
            exact: true,
            message: def.exactLength.message
          });
          status.dirty();
        }
      }
      if (def.minLength !== null) {
        if (ctx.data.length < def.minLength.value) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            minimum: def.minLength.value,
            type: "array",
            inclusive: true,
            exact: false,
            message: def.minLength.message
          });
          status.dirty();
        }
      }
      if (def.maxLength !== null) {
        if (ctx.data.length > def.maxLength.value) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            maximum: def.maxLength.value,
            type: "array",
            inclusive: true,
            exact: false,
            message: def.maxLength.message
          });
          status.dirty();
        }
      }
      if (ctx.common.async) {
        return Promise.all([...ctx.data].map((item, i) => {
          return def.type._parseAsync(new ParseInputLazyPath(ctx, item, ctx.path, i));
        })).then((result2) => {
          return ParseStatus.mergeArray(status, result2);
        });
      }
      const result = [...ctx.data].map((item, i) => {
        return def.type._parseSync(new ParseInputLazyPath(ctx, item, ctx.path, i));
      });
      return ParseStatus.mergeArray(status, result);
    }
    get element() {
      return this._def.type;
    }
    min(minLength, message) {
      return new _ZodArray({
        ...this._def,
        minLength: { value: minLength, message: errorUtil.toString(message) }
      });
    }
    max(maxLength, message) {
      return new _ZodArray({
        ...this._def,
        maxLength: { value: maxLength, message: errorUtil.toString(message) }
      });
    }
    length(len, message) {
      return new _ZodArray({
        ...this._def,
        exactLength: { value: len, message: errorUtil.toString(message) }
      });
    }
    nonempty(message) {
      return this.min(1, message);
    }
  };
  ZodArray.create = (schema, params) => {
    return new ZodArray({
      type: schema,
      minLength: null,
      maxLength: null,
      exactLength: null,
      typeName: ZodFirstPartyTypeKind.ZodArray,
      ...processCreateParams(params)
    });
  };
  function deepPartialify(schema) {
    if (schema instanceof ZodObject) {
      const newShape = {};
      for (const key in schema.shape) {
        const fieldSchema = schema.shape[key];
        newShape[key] = ZodOptional.create(deepPartialify(fieldSchema));
      }
      return new ZodObject({
        ...schema._def,
        shape: () => newShape
      });
    } else if (schema instanceof ZodArray) {
      return new ZodArray({
        ...schema._def,
        type: deepPartialify(schema.element)
      });
    } else if (schema instanceof ZodOptional) {
      return ZodOptional.create(deepPartialify(schema.unwrap()));
    } else if (schema instanceof ZodNullable) {
      return ZodNullable.create(deepPartialify(schema.unwrap()));
    } else if (schema instanceof ZodTuple) {
      return ZodTuple.create(schema.items.map((item) => deepPartialify(item)));
    } else {
      return schema;
    }
  }
  var ZodObject = class _ZodObject extends ZodType {
    constructor() {
      super(...arguments);
      this._cached = null;
      this.nonstrict = this.passthrough;
      this.augment = this.extend;
    }
    _getCached() {
      if (this._cached !== null)
        return this._cached;
      const shape = this._def.shape();
      const keys = util.objectKeys(shape);
      this._cached = { shape, keys };
      return this._cached;
    }
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.object) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.object,
          received: ctx2.parsedType
        });
        return INVALID;
      }
      const { status, ctx } = this._processInputParams(input);
      const { shape, keys: shapeKeys } = this._getCached();
      const extraKeys = [];
      if (!(this._def.catchall instanceof ZodNever && this._def.unknownKeys === "strip")) {
        for (const key in ctx.data) {
          if (!shapeKeys.includes(key)) {
            extraKeys.push(key);
          }
        }
      }
      const pairs = [];
      for (const key of shapeKeys) {
        const keyValidator = shape[key];
        const value = ctx.data[key];
        pairs.push({
          key: { status: "valid", value: key },
          value: keyValidator._parse(new ParseInputLazyPath(ctx, value, ctx.path, key)),
          alwaysSet: key in ctx.data
        });
      }
      if (this._def.catchall instanceof ZodNever) {
        const unknownKeys = this._def.unknownKeys;
        if (unknownKeys === "passthrough") {
          for (const key of extraKeys) {
            pairs.push({
              key: { status: "valid", value: key },
              value: { status: "valid", value: ctx.data[key] }
            });
          }
        } else if (unknownKeys === "strict") {
          if (extraKeys.length > 0) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.unrecognized_keys,
              keys: extraKeys
            });
            status.dirty();
          }
        } else if (unknownKeys === "strip") {
        } else {
          throw new Error(`Internal ZodObject error: invalid unknownKeys value.`);
        }
      } else {
        const catchall = this._def.catchall;
        for (const key of extraKeys) {
          const value = ctx.data[key];
          pairs.push({
            key: { status: "valid", value: key },
            value: catchall._parse(
              new ParseInputLazyPath(ctx, value, ctx.path, key)
              //, ctx.child(key), value, getParsedType(value)
            ),
            alwaysSet: key in ctx.data
          });
        }
      }
      if (ctx.common.async) {
        return Promise.resolve().then(async () => {
          const syncPairs = [];
          for (const pair of pairs) {
            const key = await pair.key;
            const value = await pair.value;
            syncPairs.push({
              key,
              value,
              alwaysSet: pair.alwaysSet
            });
          }
          return syncPairs;
        }).then((syncPairs) => {
          return ParseStatus.mergeObjectSync(status, syncPairs);
        });
      } else {
        return ParseStatus.mergeObjectSync(status, pairs);
      }
    }
    get shape() {
      return this._def.shape();
    }
    strict(message) {
      errorUtil.errToObj;
      return new _ZodObject({
        ...this._def,
        unknownKeys: "strict",
        ...message !== void 0 ? {
          errorMap: (issue, ctx) => {
            const defaultError = this._def.errorMap?.(issue, ctx).message ?? ctx.defaultError;
            if (issue.code === "unrecognized_keys")
              return {
                message: errorUtil.errToObj(message).message ?? defaultError
              };
            return {
              message: defaultError
            };
          }
        } : {}
      });
    }
    strip() {
      return new _ZodObject({
        ...this._def,
        unknownKeys: "strip"
      });
    }
    passthrough() {
      return new _ZodObject({
        ...this._def,
        unknownKeys: "passthrough"
      });
    }
    // const AugmentFactory =
    //   <Def extends ZodObjectDef>(def: Def) =>
    //   <Augmentation extends ZodRawShape>(
    //     augmentation: Augmentation
    //   ): ZodObject<
    //     extendShape<ReturnType<Def["shape"]>, Augmentation>,
    //     Def["unknownKeys"],
    //     Def["catchall"]
    //   > => {
    //     return new ZodObject({
    //       ...def,
    //       shape: () => ({
    //         ...def.shape(),
    //         ...augmentation,
    //       }),
    //     }) as any;
    //   };
    extend(augmentation) {
      return new _ZodObject({
        ...this._def,
        shape: () => ({
          ...this._def.shape(),
          ...augmentation
        })
      });
    }
    /**
     * Prior to zod@1.0.12 there was a bug in the
     * inferred type of merged objects. Please
     * upgrade if you are experiencing issues.
     */
    merge(merging) {
      const merged = new _ZodObject({
        unknownKeys: merging._def.unknownKeys,
        catchall: merging._def.catchall,
        shape: () => ({
          ...this._def.shape(),
          ...merging._def.shape()
        }),
        typeName: ZodFirstPartyTypeKind.ZodObject
      });
      return merged;
    }
    // merge<
    //   Incoming extends AnyZodObject,
    //   Augmentation extends Incoming["shape"],
    //   NewOutput extends {
    //     [k in keyof Augmentation | keyof Output]: k extends keyof Augmentation
    //       ? Augmentation[k]["_output"]
    //       : k extends keyof Output
    //       ? Output[k]
    //       : never;
    //   },
    //   NewInput extends {
    //     [k in keyof Augmentation | keyof Input]: k extends keyof Augmentation
    //       ? Augmentation[k]["_input"]
    //       : k extends keyof Input
    //       ? Input[k]
    //       : never;
    //   }
    // >(
    //   merging: Incoming
    // ): ZodObject<
    //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
    //   Incoming["_def"]["unknownKeys"],
    //   Incoming["_def"]["catchall"],
    //   NewOutput,
    //   NewInput
    // > {
    //   const merged: any = new ZodObject({
    //     unknownKeys: merging._def.unknownKeys,
    //     catchall: merging._def.catchall,
    //     shape: () =>
    //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
    //     typeName: ZodFirstPartyTypeKind.ZodObject,
    //   }) as any;
    //   return merged;
    // }
    setKey(key, schema) {
      return this.augment({ [key]: schema });
    }
    // merge<Incoming extends AnyZodObject>(
    //   merging: Incoming
    // ): //ZodObject<T & Incoming["_shape"], UnknownKeys, Catchall> = (merging) => {
    // ZodObject<
    //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
    //   Incoming["_def"]["unknownKeys"],
    //   Incoming["_def"]["catchall"]
    // > {
    //   // const mergedShape = objectUtil.mergeShapes(
    //   //   this._def.shape(),
    //   //   merging._def.shape()
    //   // );
    //   const merged: any = new ZodObject({
    //     unknownKeys: merging._def.unknownKeys,
    //     catchall: merging._def.catchall,
    //     shape: () =>
    //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
    //     typeName: ZodFirstPartyTypeKind.ZodObject,
    //   }) as any;
    //   return merged;
    // }
    catchall(index) {
      return new _ZodObject({
        ...this._def,
        catchall: index
      });
    }
    pick(mask) {
      const shape = {};
      for (const key of util.objectKeys(mask)) {
        if (mask[key] && this.shape[key]) {
          shape[key] = this.shape[key];
        }
      }
      return new _ZodObject({
        ...this._def,
        shape: () => shape
      });
    }
    omit(mask) {
      const shape = {};
      for (const key of util.objectKeys(this.shape)) {
        if (!mask[key]) {
          shape[key] = this.shape[key];
        }
      }
      return new _ZodObject({
        ...this._def,
        shape: () => shape
      });
    }
    /**
     * @deprecated
     */
    deepPartial() {
      return deepPartialify(this);
    }
    partial(mask) {
      const newShape = {};
      for (const key of util.objectKeys(this.shape)) {
        const fieldSchema = this.shape[key];
        if (mask && !mask[key]) {
          newShape[key] = fieldSchema;
        } else {
          newShape[key] = fieldSchema.optional();
        }
      }
      return new _ZodObject({
        ...this._def,
        shape: () => newShape
      });
    }
    required(mask) {
      const newShape = {};
      for (const key of util.objectKeys(this.shape)) {
        if (mask && !mask[key]) {
          newShape[key] = this.shape[key];
        } else {
          const fieldSchema = this.shape[key];
          let newField = fieldSchema;
          while (newField instanceof ZodOptional) {
            newField = newField._def.innerType;
          }
          newShape[key] = newField;
        }
      }
      return new _ZodObject({
        ...this._def,
        shape: () => newShape
      });
    }
    keyof() {
      return createZodEnum(util.objectKeys(this.shape));
    }
  };
  ZodObject.create = (shape, params) => {
    return new ZodObject({
      shape: () => shape,
      unknownKeys: "strip",
      catchall: ZodNever.create(),
      typeName: ZodFirstPartyTypeKind.ZodObject,
      ...processCreateParams(params)
    });
  };
  ZodObject.strictCreate = (shape, params) => {
    return new ZodObject({
      shape: () => shape,
      unknownKeys: "strict",
      catchall: ZodNever.create(),
      typeName: ZodFirstPartyTypeKind.ZodObject,
      ...processCreateParams(params)
    });
  };
  ZodObject.lazycreate = (shape, params) => {
    return new ZodObject({
      shape,
      unknownKeys: "strip",
      catchall: ZodNever.create(),
      typeName: ZodFirstPartyTypeKind.ZodObject,
      ...processCreateParams(params)
    });
  };
  var ZodUnion = class extends ZodType {
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      const options = this._def.options;
      function handleResults(results) {
        for (const result of results) {
          if (result.result.status === "valid") {
            return result.result;
          }
        }
        for (const result of results) {
          if (result.result.status === "dirty") {
            ctx.common.issues.push(...result.ctx.common.issues);
            return result.result;
          }
        }
        const unionErrors = results.map((result) => new ZodError(result.ctx.common.issues));
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_union,
          unionErrors
        });
        return INVALID;
      }
      if (ctx.common.async) {
        return Promise.all(options.map(async (option) => {
          const childCtx = {
            ...ctx,
            common: {
              ...ctx.common,
              issues: []
            },
            parent: null
          };
          return {
            result: await option._parseAsync({
              data: ctx.data,
              path: ctx.path,
              parent: childCtx
            }),
            ctx: childCtx
          };
        })).then(handleResults);
      } else {
        let dirty = void 0;
        const issues = [];
        for (const option of options) {
          const childCtx = {
            ...ctx,
            common: {
              ...ctx.common,
              issues: []
            },
            parent: null
          };
          const result = option._parseSync({
            data: ctx.data,
            path: ctx.path,
            parent: childCtx
          });
          if (result.status === "valid") {
            return result;
          } else if (result.status === "dirty" && !dirty) {
            dirty = { result, ctx: childCtx };
          }
          if (childCtx.common.issues.length) {
            issues.push(childCtx.common.issues);
          }
        }
        if (dirty) {
          ctx.common.issues.push(...dirty.ctx.common.issues);
          return dirty.result;
        }
        const unionErrors = issues.map((issues2) => new ZodError(issues2));
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_union,
          unionErrors
        });
        return INVALID;
      }
    }
    get options() {
      return this._def.options;
    }
  };
  ZodUnion.create = (types, params) => {
    return new ZodUnion({
      options: types,
      typeName: ZodFirstPartyTypeKind.ZodUnion,
      ...processCreateParams(params)
    });
  };
  var getDiscriminator = (type) => {
    if (type instanceof ZodLazy) {
      return getDiscriminator(type.schema);
    } else if (type instanceof ZodEffects) {
      return getDiscriminator(type.innerType());
    } else if (type instanceof ZodLiteral) {
      return [type.value];
    } else if (type instanceof ZodEnum) {
      return type.options;
    } else if (type instanceof ZodNativeEnum) {
      return util.objectValues(type.enum);
    } else if (type instanceof ZodDefault) {
      return getDiscriminator(type._def.innerType);
    } else if (type instanceof ZodUndefined) {
      return [void 0];
    } else if (type instanceof ZodNull) {
      return [null];
    } else if (type instanceof ZodOptional) {
      return [void 0, ...getDiscriminator(type.unwrap())];
    } else if (type instanceof ZodNullable) {
      return [null, ...getDiscriminator(type.unwrap())];
    } else if (type instanceof ZodBranded) {
      return getDiscriminator(type.unwrap());
    } else if (type instanceof ZodReadonly) {
      return getDiscriminator(type.unwrap());
    } else if (type instanceof ZodCatch) {
      return getDiscriminator(type._def.innerType);
    } else {
      return [];
    }
  };
  var ZodDiscriminatedUnion = class _ZodDiscriminatedUnion extends ZodType {
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.object) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.object,
          received: ctx.parsedType
        });
        return INVALID;
      }
      const discriminator = this.discriminator;
      const discriminatorValue = ctx.data[discriminator];
      const option = this.optionsMap.get(discriminatorValue);
      if (!option) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_union_discriminator,
          options: Array.from(this.optionsMap.keys()),
          path: [discriminator]
        });
        return INVALID;
      }
      if (ctx.common.async) {
        return option._parseAsync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
      } else {
        return option._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
      }
    }
    get discriminator() {
      return this._def.discriminator;
    }
    get options() {
      return this._def.options;
    }
    get optionsMap() {
      return this._def.optionsMap;
    }
    /**
     * The constructor of the discriminated union schema. Its behaviour is very similar to that of the normal z.union() constructor.
     * However, it only allows a union of objects, all of which need to share a discriminator property. This property must
     * have a different value for each object in the union.
     * @param discriminator the name of the discriminator property
     * @param types an array of object schemas
     * @param params
     */
    static create(discriminator, options, params) {
      const optionsMap = /* @__PURE__ */ new Map();
      for (const type of options) {
        const discriminatorValues = getDiscriminator(type.shape[discriminator]);
        if (!discriminatorValues.length) {
          throw new Error(`A discriminator value for key \`${discriminator}\` could not be extracted from all schema options`);
        }
        for (const value of discriminatorValues) {
          if (optionsMap.has(value)) {
            throw new Error(`Discriminator property ${String(discriminator)} has duplicate value ${String(value)}`);
          }
          optionsMap.set(value, type);
        }
      }
      return new _ZodDiscriminatedUnion({
        typeName: ZodFirstPartyTypeKind.ZodDiscriminatedUnion,
        discriminator,
        options,
        optionsMap,
        ...processCreateParams(params)
      });
    }
  };
  function mergeValues(a, b) {
    const aType = getParsedType(a);
    const bType = getParsedType(b);
    if (a === b) {
      return { valid: true, data: a };
    } else if (aType === ZodParsedType.object && bType === ZodParsedType.object) {
      const bKeys = util.objectKeys(b);
      const sharedKeys = util.objectKeys(a).filter((key) => bKeys.indexOf(key) !== -1);
      const newObj = { ...a, ...b };
      for (const key of sharedKeys) {
        const sharedValue = mergeValues(a[key], b[key]);
        if (!sharedValue.valid) {
          return { valid: false };
        }
        newObj[key] = sharedValue.data;
      }
      return { valid: true, data: newObj };
    } else if (aType === ZodParsedType.array && bType === ZodParsedType.array) {
      if (a.length !== b.length) {
        return { valid: false };
      }
      const newArray = [];
      for (let index = 0; index < a.length; index++) {
        const itemA = a[index];
        const itemB = b[index];
        const sharedValue = mergeValues(itemA, itemB);
        if (!sharedValue.valid) {
          return { valid: false };
        }
        newArray.push(sharedValue.data);
      }
      return { valid: true, data: newArray };
    } else if (aType === ZodParsedType.date && bType === ZodParsedType.date && +a === +b) {
      return { valid: true, data: a };
    } else {
      return { valid: false };
    }
  }
  var ZodIntersection = class extends ZodType {
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      const handleParsed = (parsedLeft, parsedRight) => {
        if (isAborted(parsedLeft) || isAborted(parsedRight)) {
          return INVALID;
        }
        const merged = mergeValues(parsedLeft.value, parsedRight.value);
        if (!merged.valid) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_intersection_types
          });
          return INVALID;
        }
        if (isDirty(parsedLeft) || isDirty(parsedRight)) {
          status.dirty();
        }
        return { status: status.value, value: merged.data };
      };
      if (ctx.common.async) {
        return Promise.all([
          this._def.left._parseAsync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          }),
          this._def.right._parseAsync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          })
        ]).then(([left, right]) => handleParsed(left, right));
      } else {
        return handleParsed(this._def.left._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        }), this._def.right._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        }));
      }
    }
  };
  ZodIntersection.create = (left, right, params) => {
    return new ZodIntersection({
      left,
      right,
      typeName: ZodFirstPartyTypeKind.ZodIntersection,
      ...processCreateParams(params)
    });
  };
  var ZodTuple = class _ZodTuple extends ZodType {
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.array) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.array,
          received: ctx.parsedType
        });
        return INVALID;
      }
      if (ctx.data.length < this._def.items.length) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_small,
          minimum: this._def.items.length,
          inclusive: true,
          exact: false,
          type: "array"
        });
        return INVALID;
      }
      const rest = this._def.rest;
      if (!rest && ctx.data.length > this._def.items.length) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_big,
          maximum: this._def.items.length,
          inclusive: true,
          exact: false,
          type: "array"
        });
        status.dirty();
      }
      const items = [...ctx.data].map((item, itemIndex) => {
        const schema = this._def.items[itemIndex] || this._def.rest;
        if (!schema)
          return null;
        return schema._parse(new ParseInputLazyPath(ctx, item, ctx.path, itemIndex));
      }).filter((x) => !!x);
      if (ctx.common.async) {
        return Promise.all(items).then((results) => {
          return ParseStatus.mergeArray(status, results);
        });
      } else {
        return ParseStatus.mergeArray(status, items);
      }
    }
    get items() {
      return this._def.items;
    }
    rest(rest) {
      return new _ZodTuple({
        ...this._def,
        rest
      });
    }
  };
  ZodTuple.create = (schemas, params) => {
    if (!Array.isArray(schemas)) {
      throw new Error("You must pass an array of schemas to z.tuple([ ... ])");
    }
    return new ZodTuple({
      items: schemas,
      typeName: ZodFirstPartyTypeKind.ZodTuple,
      rest: null,
      ...processCreateParams(params)
    });
  };
  var ZodRecord = class _ZodRecord extends ZodType {
    get keySchema() {
      return this._def.keyType;
    }
    get valueSchema() {
      return this._def.valueType;
    }
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.object) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.object,
          received: ctx.parsedType
        });
        return INVALID;
      }
      const pairs = [];
      const keyType = this._def.keyType;
      const valueType = this._def.valueType;
      for (const key in ctx.data) {
        pairs.push({
          key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, key)),
          value: valueType._parse(new ParseInputLazyPath(ctx, ctx.data[key], ctx.path, key)),
          alwaysSet: key in ctx.data
        });
      }
      if (ctx.common.async) {
        return ParseStatus.mergeObjectAsync(status, pairs);
      } else {
        return ParseStatus.mergeObjectSync(status, pairs);
      }
    }
    get element() {
      return this._def.valueType;
    }
    static create(first, second, third) {
      if (second instanceof ZodType) {
        return new _ZodRecord({
          keyType: first,
          valueType: second,
          typeName: ZodFirstPartyTypeKind.ZodRecord,
          ...processCreateParams(third)
        });
      }
      return new _ZodRecord({
        keyType: ZodString.create(),
        valueType: first,
        typeName: ZodFirstPartyTypeKind.ZodRecord,
        ...processCreateParams(second)
      });
    }
  };
  var ZodMap = class extends ZodType {
    get keySchema() {
      return this._def.keyType;
    }
    get valueSchema() {
      return this._def.valueType;
    }
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.map) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.map,
          received: ctx.parsedType
        });
        return INVALID;
      }
      const keyType = this._def.keyType;
      const valueType = this._def.valueType;
      const pairs = [...ctx.data.entries()].map(([key, value], index) => {
        return {
          key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, [index, "key"])),
          value: valueType._parse(new ParseInputLazyPath(ctx, value, ctx.path, [index, "value"]))
        };
      });
      if (ctx.common.async) {
        const finalMap = /* @__PURE__ */ new Map();
        return Promise.resolve().then(async () => {
          for (const pair of pairs) {
            const key = await pair.key;
            const value = await pair.value;
            if (key.status === "aborted" || value.status === "aborted") {
              return INVALID;
            }
            if (key.status === "dirty" || value.status === "dirty") {
              status.dirty();
            }
            finalMap.set(key.value, value.value);
          }
          return { status: status.value, value: finalMap };
        });
      } else {
        const finalMap = /* @__PURE__ */ new Map();
        for (const pair of pairs) {
          const key = pair.key;
          const value = pair.value;
          if (key.status === "aborted" || value.status === "aborted") {
            return INVALID;
          }
          if (key.status === "dirty" || value.status === "dirty") {
            status.dirty();
          }
          finalMap.set(key.value, value.value);
        }
        return { status: status.value, value: finalMap };
      }
    }
  };
  ZodMap.create = (keyType, valueType, params) => {
    return new ZodMap({
      valueType,
      keyType,
      typeName: ZodFirstPartyTypeKind.ZodMap,
      ...processCreateParams(params)
    });
  };
  var ZodSet = class _ZodSet extends ZodType {
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.set) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.set,
          received: ctx.parsedType
        });
        return INVALID;
      }
      const def = this._def;
      if (def.minSize !== null) {
        if (ctx.data.size < def.minSize.value) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            minimum: def.minSize.value,
            type: "set",
            inclusive: true,
            exact: false,
            message: def.minSize.message
          });
          status.dirty();
        }
      }
      if (def.maxSize !== null) {
        if (ctx.data.size > def.maxSize.value) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            maximum: def.maxSize.value,
            type: "set",
            inclusive: true,
            exact: false,
            message: def.maxSize.message
          });
          status.dirty();
        }
      }
      const valueType = this._def.valueType;
      function finalizeSet(elements2) {
        const parsedSet = /* @__PURE__ */ new Set();
        for (const element of elements2) {
          if (element.status === "aborted")
            return INVALID;
          if (element.status === "dirty")
            status.dirty();
          parsedSet.add(element.value);
        }
        return { status: status.value, value: parsedSet };
      }
      const elements = [...ctx.data.values()].map((item, i) => valueType._parse(new ParseInputLazyPath(ctx, item, ctx.path, i)));
      if (ctx.common.async) {
        return Promise.all(elements).then((elements2) => finalizeSet(elements2));
      } else {
        return finalizeSet(elements);
      }
    }
    min(minSize, message) {
      return new _ZodSet({
        ...this._def,
        minSize: { value: minSize, message: errorUtil.toString(message) }
      });
    }
    max(maxSize, message) {
      return new _ZodSet({
        ...this._def,
        maxSize: { value: maxSize, message: errorUtil.toString(message) }
      });
    }
    size(size, message) {
      return this.min(size, message).max(size, message);
    }
    nonempty(message) {
      return this.min(1, message);
    }
  };
  ZodSet.create = (valueType, params) => {
    return new ZodSet({
      valueType,
      minSize: null,
      maxSize: null,
      typeName: ZodFirstPartyTypeKind.ZodSet,
      ...processCreateParams(params)
    });
  };
  var ZodFunction = class _ZodFunction extends ZodType {
    constructor() {
      super(...arguments);
      this.validate = this.implement;
    }
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.function) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.function,
          received: ctx.parsedType
        });
        return INVALID;
      }
      function makeArgsIssue(args, error) {
        return makeIssue({
          data: args,
          path: ctx.path,
          errorMaps: [ctx.common.contextualErrorMap, ctx.schemaErrorMap, getErrorMap(), en_default].filter((x) => !!x),
          issueData: {
            code: ZodIssueCode.invalid_arguments,
            argumentsError: error
          }
        });
      }
      function makeReturnsIssue(returns, error) {
        return makeIssue({
          data: returns,
          path: ctx.path,
          errorMaps: [ctx.common.contextualErrorMap, ctx.schemaErrorMap, getErrorMap(), en_default].filter((x) => !!x),
          issueData: {
            code: ZodIssueCode.invalid_return_type,
            returnTypeError: error
          }
        });
      }
      const params = { errorMap: ctx.common.contextualErrorMap };
      const fn = ctx.data;
      if (this._def.returns instanceof ZodPromise) {
        const me = this;
        return OK(async function(...args) {
          const error = new ZodError([]);
          const parsedArgs = await me._def.args.parseAsync(args, params).catch((e) => {
            error.addIssue(makeArgsIssue(args, e));
            throw error;
          });
          const result = await Reflect.apply(fn, this, parsedArgs);
          const parsedReturns = await me._def.returns._def.type.parseAsync(result, params).catch((e) => {
            error.addIssue(makeReturnsIssue(result, e));
            throw error;
          });
          return parsedReturns;
        });
      } else {
        const me = this;
        return OK(function(...args) {
          const parsedArgs = me._def.args.safeParse(args, params);
          if (!parsedArgs.success) {
            throw new ZodError([makeArgsIssue(args, parsedArgs.error)]);
          }
          const result = Reflect.apply(fn, this, parsedArgs.data);
          const parsedReturns = me._def.returns.safeParse(result, params);
          if (!parsedReturns.success) {
            throw new ZodError([makeReturnsIssue(result, parsedReturns.error)]);
          }
          return parsedReturns.data;
        });
      }
    }
    parameters() {
      return this._def.args;
    }
    returnType() {
      return this._def.returns;
    }
    args(...items) {
      return new _ZodFunction({
        ...this._def,
        args: ZodTuple.create(items).rest(ZodUnknown.create())
      });
    }
    returns(returnType) {
      return new _ZodFunction({
        ...this._def,
        returns: returnType
      });
    }
    implement(func) {
      const validatedFunc = this.parse(func);
      return validatedFunc;
    }
    strictImplement(func) {
      const validatedFunc = this.parse(func);
      return validatedFunc;
    }
    static create(args, returns, params) {
      return new _ZodFunction({
        args: args ? args : ZodTuple.create([]).rest(ZodUnknown.create()),
        returns: returns || ZodUnknown.create(),
        typeName: ZodFirstPartyTypeKind.ZodFunction,
        ...processCreateParams(params)
      });
    }
  };
  var ZodLazy = class extends ZodType {
    get schema() {
      return this._def.getter();
    }
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      const lazySchema = this._def.getter();
      return lazySchema._parse({ data: ctx.data, path: ctx.path, parent: ctx });
    }
  };
  ZodLazy.create = (getter, params) => {
    return new ZodLazy({
      getter,
      typeName: ZodFirstPartyTypeKind.ZodLazy,
      ...processCreateParams(params)
    });
  };
  var ZodLiteral = class extends ZodType {
    _parse(input) {
      if (input.data !== this._def.value) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          received: ctx.data,
          code: ZodIssueCode.invalid_literal,
          expected: this._def.value
        });
        return INVALID;
      }
      return { status: "valid", value: input.data };
    }
    get value() {
      return this._def.value;
    }
  };
  ZodLiteral.create = (value, params) => {
    return new ZodLiteral({
      value,
      typeName: ZodFirstPartyTypeKind.ZodLiteral,
      ...processCreateParams(params)
    });
  };
  function createZodEnum(values, params) {
    return new ZodEnum({
      values,
      typeName: ZodFirstPartyTypeKind.ZodEnum,
      ...processCreateParams(params)
    });
  }
  var ZodEnum = class _ZodEnum extends ZodType {
    _parse(input) {
      if (typeof input.data !== "string") {
        const ctx = this._getOrReturnCtx(input);
        const expectedValues = this._def.values;
        addIssueToContext(ctx, {
          expected: util.joinValues(expectedValues),
          received: ctx.parsedType,
          code: ZodIssueCode.invalid_type
        });
        return INVALID;
      }
      if (!this._cache) {
        this._cache = new Set(this._def.values);
      }
      if (!this._cache.has(input.data)) {
        const ctx = this._getOrReturnCtx(input);
        const expectedValues = this._def.values;
        addIssueToContext(ctx, {
          received: ctx.data,
          code: ZodIssueCode.invalid_enum_value,
          options: expectedValues
        });
        return INVALID;
      }
      return OK(input.data);
    }
    get options() {
      return this._def.values;
    }
    get enum() {
      const enumValues = {};
      for (const val of this._def.values) {
        enumValues[val] = val;
      }
      return enumValues;
    }
    get Values() {
      const enumValues = {};
      for (const val of this._def.values) {
        enumValues[val] = val;
      }
      return enumValues;
    }
    get Enum() {
      const enumValues = {};
      for (const val of this._def.values) {
        enumValues[val] = val;
      }
      return enumValues;
    }
    extract(values, newDef = this._def) {
      return _ZodEnum.create(values, {
        ...this._def,
        ...newDef
      });
    }
    exclude(values, newDef = this._def) {
      return _ZodEnum.create(this.options.filter((opt) => !values.includes(opt)), {
        ...this._def,
        ...newDef
      });
    }
  };
  ZodEnum.create = createZodEnum;
  var ZodNativeEnum = class extends ZodType {
    _parse(input) {
      const nativeEnumValues = util.getValidEnumValues(this._def.values);
      const ctx = this._getOrReturnCtx(input);
      if (ctx.parsedType !== ZodParsedType.string && ctx.parsedType !== ZodParsedType.number) {
        const expectedValues = util.objectValues(nativeEnumValues);
        addIssueToContext(ctx, {
          expected: util.joinValues(expectedValues),
          received: ctx.parsedType,
          code: ZodIssueCode.invalid_type
        });
        return INVALID;
      }
      if (!this._cache) {
        this._cache = new Set(util.getValidEnumValues(this._def.values));
      }
      if (!this._cache.has(input.data)) {
        const expectedValues = util.objectValues(nativeEnumValues);
        addIssueToContext(ctx, {
          received: ctx.data,
          code: ZodIssueCode.invalid_enum_value,
          options: expectedValues
        });
        return INVALID;
      }
      return OK(input.data);
    }
    get enum() {
      return this._def.values;
    }
  };
  ZodNativeEnum.create = (values, params) => {
    return new ZodNativeEnum({
      values,
      typeName: ZodFirstPartyTypeKind.ZodNativeEnum,
      ...processCreateParams(params)
    });
  };
  var ZodPromise = class extends ZodType {
    unwrap() {
      return this._def.type;
    }
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.promise && ctx.common.async === false) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.promise,
          received: ctx.parsedType
        });
        return INVALID;
      }
      const promisified = ctx.parsedType === ZodParsedType.promise ? ctx.data : Promise.resolve(ctx.data);
      return OK(promisified.then((data) => {
        return this._def.type.parseAsync(data, {
          path: ctx.path,
          errorMap: ctx.common.contextualErrorMap
        });
      }));
    }
  };
  ZodPromise.create = (schema, params) => {
    return new ZodPromise({
      type: schema,
      typeName: ZodFirstPartyTypeKind.ZodPromise,
      ...processCreateParams(params)
    });
  };
  var ZodEffects = class extends ZodType {
    innerType() {
      return this._def.schema;
    }
    sourceType() {
      return this._def.schema._def.typeName === ZodFirstPartyTypeKind.ZodEffects ? this._def.schema.sourceType() : this._def.schema;
    }
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      const effect = this._def.effect || null;
      const checkCtx = {
        addIssue: (arg) => {
          addIssueToContext(ctx, arg);
          if (arg.fatal) {
            status.abort();
          } else {
            status.dirty();
          }
        },
        get path() {
          return ctx.path;
        }
      };
      checkCtx.addIssue = checkCtx.addIssue.bind(checkCtx);
      if (effect.type === "preprocess") {
        const processed = effect.transform(ctx.data, checkCtx);
        if (ctx.common.async) {
          return Promise.resolve(processed).then(async (processed2) => {
            if (status.value === "aborted")
              return INVALID;
            const result = await this._def.schema._parseAsync({
              data: processed2,
              path: ctx.path,
              parent: ctx
            });
            if (result.status === "aborted")
              return INVALID;
            if (result.status === "dirty")
              return DIRTY(result.value);
            if (status.value === "dirty")
              return DIRTY(result.value);
            return result;
          });
        } else {
          if (status.value === "aborted")
            return INVALID;
          const result = this._def.schema._parseSync({
            data: processed,
            path: ctx.path,
            parent: ctx
          });
          if (result.status === "aborted")
            return INVALID;
          if (result.status === "dirty")
            return DIRTY(result.value);
          if (status.value === "dirty")
            return DIRTY(result.value);
          return result;
        }
      }
      if (effect.type === "refinement") {
        const executeRefinement = (acc) => {
          const result = effect.refinement(acc, checkCtx);
          if (ctx.common.async) {
            return Promise.resolve(result);
          }
          if (result instanceof Promise) {
            throw new Error("Async refinement encountered during synchronous parse operation. Use .parseAsync instead.");
          }
          return acc;
        };
        if (ctx.common.async === false) {
          const inner = this._def.schema._parseSync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          });
          if (inner.status === "aborted")
            return INVALID;
          if (inner.status === "dirty")
            status.dirty();
          executeRefinement(inner.value);
          return { status: status.value, value: inner.value };
        } else {
          return this._def.schema._parseAsync({ data: ctx.data, path: ctx.path, parent: ctx }).then((inner) => {
            if (inner.status === "aborted")
              return INVALID;
            if (inner.status === "dirty")
              status.dirty();
            return executeRefinement(inner.value).then(() => {
              return { status: status.value, value: inner.value };
            });
          });
        }
      }
      if (effect.type === "transform") {
        if (ctx.common.async === false) {
          const base = this._def.schema._parseSync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          });
          if (!isValid(base))
            return INVALID;
          const result = effect.transform(base.value, checkCtx);
          if (result instanceof Promise) {
            throw new Error(`Asynchronous transform encountered during synchronous parse operation. Use .parseAsync instead.`);
          }
          return { status: status.value, value: result };
        } else {
          return this._def.schema._parseAsync({ data: ctx.data, path: ctx.path, parent: ctx }).then((base) => {
            if (!isValid(base))
              return INVALID;
            return Promise.resolve(effect.transform(base.value, checkCtx)).then((result) => ({
              status: status.value,
              value: result
            }));
          });
        }
      }
      util.assertNever(effect);
    }
  };
  ZodEffects.create = (schema, effect, params) => {
    return new ZodEffects({
      schema,
      typeName: ZodFirstPartyTypeKind.ZodEffects,
      effect,
      ...processCreateParams(params)
    });
  };
  ZodEffects.createWithPreprocess = (preprocess, schema, params) => {
    return new ZodEffects({
      schema,
      effect: { type: "preprocess", transform: preprocess },
      typeName: ZodFirstPartyTypeKind.ZodEffects,
      ...processCreateParams(params)
    });
  };
  var ZodOptional = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType === ZodParsedType.undefined) {
        return OK(void 0);
      }
      return this._def.innerType._parse(input);
    }
    unwrap() {
      return this._def.innerType;
    }
  };
  ZodOptional.create = (type, params) => {
    return new ZodOptional({
      innerType: type,
      typeName: ZodFirstPartyTypeKind.ZodOptional,
      ...processCreateParams(params)
    });
  };
  var ZodNullable = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType === ZodParsedType.null) {
        return OK(null);
      }
      return this._def.innerType._parse(input);
    }
    unwrap() {
      return this._def.innerType;
    }
  };
  ZodNullable.create = (type, params) => {
    return new ZodNullable({
      innerType: type,
      typeName: ZodFirstPartyTypeKind.ZodNullable,
      ...processCreateParams(params)
    });
  };
  var ZodDefault = class extends ZodType {
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      let data = ctx.data;
      if (ctx.parsedType === ZodParsedType.undefined) {
        data = this._def.defaultValue();
      }
      return this._def.innerType._parse({
        data,
        path: ctx.path,
        parent: ctx
      });
    }
    removeDefault() {
      return this._def.innerType;
    }
  };
  ZodDefault.create = (type, params) => {
    return new ZodDefault({
      innerType: type,
      typeName: ZodFirstPartyTypeKind.ZodDefault,
      defaultValue: typeof params.default === "function" ? params.default : () => params.default,
      ...processCreateParams(params)
    });
  };
  var ZodCatch = class extends ZodType {
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      const newCtx = {
        ...ctx,
        common: {
          ...ctx.common,
          issues: []
        }
      };
      const result = this._def.innerType._parse({
        data: newCtx.data,
        path: newCtx.path,
        parent: {
          ...newCtx
        }
      });
      if (isAsync(result)) {
        return result.then((result2) => {
          return {
            status: "valid",
            value: result2.status === "valid" ? result2.value : this._def.catchValue({
              get error() {
                return new ZodError(newCtx.common.issues);
              },
              input: newCtx.data
            })
          };
        });
      } else {
        return {
          status: "valid",
          value: result.status === "valid" ? result.value : this._def.catchValue({
            get error() {
              return new ZodError(newCtx.common.issues);
            },
            input: newCtx.data
          })
        };
      }
    }
    removeCatch() {
      return this._def.innerType;
    }
  };
  ZodCatch.create = (type, params) => {
    return new ZodCatch({
      innerType: type,
      typeName: ZodFirstPartyTypeKind.ZodCatch,
      catchValue: typeof params.catch === "function" ? params.catch : () => params.catch,
      ...processCreateParams(params)
    });
  };
  var ZodNaN = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.nan) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.nan,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return { status: "valid", value: input.data };
    }
  };
  ZodNaN.create = (params) => {
    return new ZodNaN({
      typeName: ZodFirstPartyTypeKind.ZodNaN,
      ...processCreateParams(params)
    });
  };
  var BRAND = Symbol("zod_brand");
  var ZodBranded = class extends ZodType {
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      const data = ctx.data;
      return this._def.type._parse({
        data,
        path: ctx.path,
        parent: ctx
      });
    }
    unwrap() {
      return this._def.type;
    }
  };
  var ZodPipeline = class _ZodPipeline extends ZodType {
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      if (ctx.common.async) {
        const handleAsync = async () => {
          const inResult = await this._def.in._parseAsync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          });
          if (inResult.status === "aborted")
            return INVALID;
          if (inResult.status === "dirty") {
            status.dirty();
            return DIRTY(inResult.value);
          } else {
            return this._def.out._parseAsync({
              data: inResult.value,
              path: ctx.path,
              parent: ctx
            });
          }
        };
        return handleAsync();
      } else {
        const inResult = this._def.in._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
        if (inResult.status === "aborted")
          return INVALID;
        if (inResult.status === "dirty") {
          status.dirty();
          return {
            status: "dirty",
            value: inResult.value
          };
        } else {
          return this._def.out._parseSync({
            data: inResult.value,
            path: ctx.path,
            parent: ctx
          });
        }
      }
    }
    static create(a, b) {
      return new _ZodPipeline({
        in: a,
        out: b,
        typeName: ZodFirstPartyTypeKind.ZodPipeline
      });
    }
  };
  var ZodReadonly = class extends ZodType {
    _parse(input) {
      const result = this._def.innerType._parse(input);
      const freeze = (data) => {
        if (isValid(data)) {
          data.value = Object.freeze(data.value);
        }
        return data;
      };
      return isAsync(result) ? result.then((data) => freeze(data)) : freeze(result);
    }
    unwrap() {
      return this._def.innerType;
    }
  };
  ZodReadonly.create = (type, params) => {
    return new ZodReadonly({
      innerType: type,
      typeName: ZodFirstPartyTypeKind.ZodReadonly,
      ...processCreateParams(params)
    });
  };
  function cleanParams(params, data) {
    const p = typeof params === "function" ? params(data) : typeof params === "string" ? { message: params } : params;
    const p2 = typeof p === "string" ? { message: p } : p;
    return p2;
  }
  function custom(check, _params = {}, fatal) {
    if (check)
      return ZodAny.create().superRefine((data, ctx) => {
        const r = check(data);
        if (r instanceof Promise) {
          return r.then((r2) => {
            if (!r2) {
              const params = cleanParams(_params, data);
              const _fatal = params.fatal ?? fatal ?? true;
              ctx.addIssue({ code: "custom", ...params, fatal: _fatal });
            }
          });
        }
        if (!r) {
          const params = cleanParams(_params, data);
          const _fatal = params.fatal ?? fatal ?? true;
          ctx.addIssue({ code: "custom", ...params, fatal: _fatal });
        }
        return;
      });
    return ZodAny.create();
  }
  var late = {
    object: ZodObject.lazycreate
  };
  var ZodFirstPartyTypeKind;
  (function(ZodFirstPartyTypeKind2) {
    ZodFirstPartyTypeKind2["ZodString"] = "ZodString";
    ZodFirstPartyTypeKind2["ZodNumber"] = "ZodNumber";
    ZodFirstPartyTypeKind2["ZodNaN"] = "ZodNaN";
    ZodFirstPartyTypeKind2["ZodBigInt"] = "ZodBigInt";
    ZodFirstPartyTypeKind2["ZodBoolean"] = "ZodBoolean";
    ZodFirstPartyTypeKind2["ZodDate"] = "ZodDate";
    ZodFirstPartyTypeKind2["ZodSymbol"] = "ZodSymbol";
    ZodFirstPartyTypeKind2["ZodUndefined"] = "ZodUndefined";
    ZodFirstPartyTypeKind2["ZodNull"] = "ZodNull";
    ZodFirstPartyTypeKind2["ZodAny"] = "ZodAny";
    ZodFirstPartyTypeKind2["ZodUnknown"] = "ZodUnknown";
    ZodFirstPartyTypeKind2["ZodNever"] = "ZodNever";
    ZodFirstPartyTypeKind2["ZodVoid"] = "ZodVoid";
    ZodFirstPartyTypeKind2["ZodArray"] = "ZodArray";
    ZodFirstPartyTypeKind2["ZodObject"] = "ZodObject";
    ZodFirstPartyTypeKind2["ZodUnion"] = "ZodUnion";
    ZodFirstPartyTypeKind2["ZodDiscriminatedUnion"] = "ZodDiscriminatedUnion";
    ZodFirstPartyTypeKind2["ZodIntersection"] = "ZodIntersection";
    ZodFirstPartyTypeKind2["ZodTuple"] = "ZodTuple";
    ZodFirstPartyTypeKind2["ZodRecord"] = "ZodRecord";
    ZodFirstPartyTypeKind2["ZodMap"] = "ZodMap";
    ZodFirstPartyTypeKind2["ZodSet"] = "ZodSet";
    ZodFirstPartyTypeKind2["ZodFunction"] = "ZodFunction";
    ZodFirstPartyTypeKind2["ZodLazy"] = "ZodLazy";
    ZodFirstPartyTypeKind2["ZodLiteral"] = "ZodLiteral";
    ZodFirstPartyTypeKind2["ZodEnum"] = "ZodEnum";
    ZodFirstPartyTypeKind2["ZodEffects"] = "ZodEffects";
    ZodFirstPartyTypeKind2["ZodNativeEnum"] = "ZodNativeEnum";
    ZodFirstPartyTypeKind2["ZodOptional"] = "ZodOptional";
    ZodFirstPartyTypeKind2["ZodNullable"] = "ZodNullable";
    ZodFirstPartyTypeKind2["ZodDefault"] = "ZodDefault";
    ZodFirstPartyTypeKind2["ZodCatch"] = "ZodCatch";
    ZodFirstPartyTypeKind2["ZodPromise"] = "ZodPromise";
    ZodFirstPartyTypeKind2["ZodBranded"] = "ZodBranded";
    ZodFirstPartyTypeKind2["ZodPipeline"] = "ZodPipeline";
    ZodFirstPartyTypeKind2["ZodReadonly"] = "ZodReadonly";
  })(ZodFirstPartyTypeKind || (ZodFirstPartyTypeKind = {}));
  var instanceOfType = (cls, params = {
    message: `Input not instance of ${cls.name}`
  }) => custom((data) => data instanceof cls, params);
  var stringType = ZodString.create;
  var numberType = ZodNumber.create;
  var nanType = ZodNaN.create;
  var bigIntType = ZodBigInt.create;
  var booleanType = ZodBoolean.create;
  var dateType = ZodDate.create;
  var symbolType = ZodSymbol.create;
  var undefinedType = ZodUndefined.create;
  var nullType = ZodNull.create;
  var anyType = ZodAny.create;
  var unknownType = ZodUnknown.create;
  var neverType = ZodNever.create;
  var voidType = ZodVoid.create;
  var arrayType = ZodArray.create;
  var objectType = ZodObject.create;
  var strictObjectType = ZodObject.strictCreate;
  var unionType = ZodUnion.create;
  var discriminatedUnionType = ZodDiscriminatedUnion.create;
  var intersectionType = ZodIntersection.create;
  var tupleType = ZodTuple.create;
  var recordType = ZodRecord.create;
  var mapType = ZodMap.create;
  var setType = ZodSet.create;
  var functionType = ZodFunction.create;
  var lazyType = ZodLazy.create;
  var literalType = ZodLiteral.create;
  var enumType = ZodEnum.create;
  var nativeEnumType = ZodNativeEnum.create;
  var promiseType = ZodPromise.create;
  var effectsType = ZodEffects.create;
  var optionalType = ZodOptional.create;
  var nullableType = ZodNullable.create;
  var preprocessType = ZodEffects.createWithPreprocess;
  var pipelineType = ZodPipeline.create;
  var ostring = () => stringType().optional();
  var onumber = () => numberType().optional();
  var oboolean = () => booleanType().optional();
  var coerce = {
    string: (arg) => ZodString.create({ ...arg, coerce: true }),
    number: (arg) => ZodNumber.create({ ...arg, coerce: true }),
    boolean: (arg) => ZodBoolean.create({
      ...arg,
      coerce: true
    }),
    bigint: (arg) => ZodBigInt.create({ ...arg, coerce: true }),
    date: (arg) => ZodDate.create({ ...arg, coerce: true })
  };
  var NEVER = INVALID;

  // ../shared/src/events.ts
  var eventTypeSchema = external_exports.enum([
    "ExtensionConnected",
    "LoginDetected",
    "JobDetected",
    "ApplicationRecorded",
    "SyncStarted",
    "SyncCompleted",
    "SyncFailed",
    "NotificationCreated"
  ]);
  var syncStatusSchema = external_exports.enum(["pending", "syncing", "synced", "failed"]);
  var platformSchema = external_exports.enum([
    "naukri",
    "linkedin",
    "foundit",
    "indeed",
    "wellfound",
    "internshala",
    "unknown"
  ]);
  var jobPayloadSchema = external_exports.object({
    platform: platformSchema,
    externalJobId: external_exports.string().optional(),
    title: external_exports.string().min(1),
    company: external_exports.string().min(1),
    location: external_exports.string().optional(),
    url: external_exports.string().url().optional(),
    companyLogo: external_exports.string().min(1).optional(),
    description: external_exports.string().max(12e3).optional(),
    experience: external_exports.string().optional(),
    salary: external_exports.string().optional(),
    skills: external_exports.array(external_exports.string()).max(60).optional(),
    rating: external_exports.string().optional(),
    reviews: external_exports.string().optional(),
    postedAt: external_exports.string().optional(),
    openings: external_exports.string().optional(),
    applicants: external_exports.string().optional(),
    highlights: external_exports.array(external_exports.string()).max(20).optional(),
    role: external_exports.string().optional(),
    industry: external_exports.string().optional(),
    department: external_exports.string().optional(),
    employmentType: external_exports.string().optional(),
    roleCategory: external_exports.string().optional(),
    education: external_exports.string().optional(),
    aboutCompany: external_exports.string().max(4e3).optional(),
    appliedAt: external_exports.string().datetime().optional(),
    status: external_exports.enum(["detected", "applied", "viewed", "saved"]).default("detected"),
    metadata: external_exports.record(external_exports.unknown()).optional()
  });
  var eventEnvelopeSchema = external_exports.object({
    eventId: external_exports.string().uuid(),
    timestamp: external_exports.string().datetime(),
    type: eventTypeSchema,
    payload: external_exports.record(external_exports.unknown()),
    retryCount: external_exports.number().int().nonnegative().default(0),
    syncStatus: syncStatusSchema.default("pending")
  });
  var syncEventsRequestSchema = external_exports.object({
    events: external_exports.array(eventEnvelopeSchema).min(1).max(100)
  });

  // ../shared/src/models.ts
  var registerSchema = external_exports.object({
    email: external_exports.string().email(),
    password: external_exports.string().min(8),
    name: external_exports.string().min(1).max(120)
  });
  var loginSchema = external_exports.object({
    email: external_exports.string().email(),
    password: external_exports.string().min(1)
  });
  var googleAuthSchema = external_exports.object({
    code: external_exports.string().min(1)
  });
  var planTierSchema = external_exports.enum(["free", "pro", "max"]);
  var userRoleSchema = external_exports.enum(["user", "admin"]);
  var userStatusSchema = external_exports.enum(["active", "suspended"]);
  var userSchema = external_exports.object({
    id: external_exports.string(),
    email: external_exports.string().email(),
    name: external_exports.string(),
    role: userRoleSchema.optional(),
    status: userStatusSchema.optional(),
    plan: planTierSchema.optional(),
    planExpiresAt: external_exports.string().datetime().optional(),
    createdAt: external_exports.string().datetime().optional(),
    extensionConnectedAt: external_exports.string().datetime().optional()
  });
  var paidPlanSchema = external_exports.enum(["pro", "max"]);
  var createBillingOrderSchema = external_exports.object({
    plan: paidPlanSchema
  });
  var verifyBillingPaymentSchema = external_exports.object({
    razorpay_order_id: external_exports.string().min(1),
    razorpay_payment_id: external_exports.string().min(1),
    razorpay_signature: external_exports.string().min(1),
    plan: paidPlanSchema
  });
  var createSubscriptionSchema = external_exports.object({
    plan: paidPlanSchema
  });
  var verifySubscriptionSchema = external_exports.object({
    razorpay_payment_id: external_exports.string().min(1),
    razorpay_subscription_id: external_exports.string().min(1),
    razorpay_signature: external_exports.string().min(1),
    plan: paidPlanSchema
  });
  var cancelSubscriptionSchema = external_exports.object({
    immediate: external_exports.boolean().optional().default(false)
  });
  var subscriptionStatusSchema = external_exports.enum([
    "created",
    "authenticated",
    "active",
    "pending",
    "halted",
    "cancelled",
    "completed",
    "expired"
  ]);
  var workModeSchema = external_exports.enum(["any", "office", "hybrid", "remote"]);
  var jobPreferencesSchema = external_exports.object({
    titles: external_exports.array(external_exports.string().min(1).max(120)).max(20).default([]),
    keywords: external_exports.array(external_exports.string().min(1).max(80)).max(30).default([]),
    locations: external_exports.array(external_exports.string().min(1).max(120)).max(20).default([]),
    experienceMin: external_exports.number().int().min(0).max(50).default(0),
    experienceMax: external_exports.number().int().min(0).max(50).default(30),
    minSalaryLpa: external_exports.number().min(0).max(500).optional(),
    workMode: workModeSchema.default("any"),
    autoScanEnabled: external_exports.boolean().default(true),
    autoApplyEnabled: external_exports.boolean().default(false)
  });
  var MIN_PREF_TITLES = 3;
  var MIN_PREF_KEYWORDS = 4;
  var jobPreferencesUpdateSchema = jobPreferencesSchema.superRefine(
    (prefs, ctx) => {
      if (prefs.titles.length < MIN_PREF_TITLES) {
        ctx.addIssue({
          code: external_exports.ZodIssueCode.custom,
          path: ["titles"],
          message: `Add at least ${MIN_PREF_TITLES} job titles`
        });
      }
      if (prefs.keywords.length < MIN_PREF_KEYWORDS) {
        ctx.addIssue({
          code: external_exports.ZodIssueCode.custom,
          path: ["keywords"],
          message: `Add at least ${MIN_PREF_KEYWORDS} keywords`
        });
      }
    }
  );
  var onboardingStatusSchema = external_exports.object({
    accountCreated: external_exports.boolean(),
    extensionConnected: external_exports.boolean(),
    preferencesCompleted: external_exports.boolean(),
    hasApplications: external_exports.boolean(),
    extensionConnectedAt: external_exports.string().datetime().optional()
  });
  var authTokensSchema = external_exports.object({
    accessToken: external_exports.string(),
    refreshToken: external_exports.string(),
    user: userSchema
  });
  var refreshTokenSchema = external_exports.object({
    refreshToken: external_exports.string().min(1)
  });
  var applicationStatusSchema = external_exports.enum([
    "detected",
    "applied",
    "viewed",
    "saved",
    "interview",
    "offer",
    "rejected"
  ]);
  var applicationMetadataSchema = external_exports.object({
    source: external_exports.enum(["manual", "auto_scan", "auto_apply"]).optional(),
    skipReason: external_exports.string().optional(),
    skipped: external_exports.boolean().optional(),
    companySiteApply: external_exports.boolean().optional()
  }).passthrough();
  var applicationSchema = external_exports.object({
    id: external_exports.string(),
    eventId: external_exports.string(),
    userId: external_exports.string(),
    platform: platformSchema,
    externalJobId: external_exports.string().optional(),
    title: external_exports.string(),
    company: external_exports.string(),
    location: external_exports.string().optional(),
    url: external_exports.string().optional(),
    companyLogo: external_exports.string().optional(),
    description: external_exports.string().optional(),
    experience: external_exports.string().optional(),
    salary: external_exports.string().optional(),
    skills: external_exports.array(external_exports.string()).optional(),
    rating: external_exports.string().optional(),
    reviews: external_exports.string().optional(),
    postedAt: external_exports.string().optional(),
    openings: external_exports.string().optional(),
    applicants: external_exports.string().optional(),
    highlights: external_exports.array(external_exports.string()).optional(),
    role: external_exports.string().optional(),
    industry: external_exports.string().optional(),
    department: external_exports.string().optional(),
    employmentType: external_exports.string().optional(),
    roleCategory: external_exports.string().optional(),
    education: external_exports.string().optional(),
    aboutCompany: external_exports.string().optional(),
    status: applicationStatusSchema,
    appliedAt: external_exports.string().datetime().optional(),
    metadata: applicationMetadataSchema.optional(),
    createdAt: external_exports.string().datetime(),
    updatedAt: external_exports.string().datetime()
  });

  // ../shared/src/admin.ts
  var adminUsersQuerySchema = external_exports.object({
    q: external_exports.string().optional(),
    plan: planTierSchema.optional(),
    role: external_exports.enum(["user", "admin"]).optional(),
    status: external_exports.enum(["active", "suspended"]).optional(),
    page: external_exports.coerce.number().int().min(1).default(1),
    limit: external_exports.coerce.number().int().min(1).max(100).default(20)
  });
  var adminPatchUserSchema = external_exports.object({
    name: external_exports.string().min(1).max(120).optional(),
    email: external_exports.string().email().optional(),
    role: external_exports.enum(["user", "admin"]).optional(),
    status: external_exports.enum(["active", "suspended"]).optional()
  });
  var adminSetPlanSchema = external_exports.object({
    action: external_exports.enum(["grant", "extend", "revoke"]),
    plan: paidPlanSchema.optional(),
    days: external_exports.number().int().min(1).max(3650).optional()
  });
  var adminSubscriptionsQuerySchema = external_exports.object({
    status: external_exports.string().optional(),
    tier: paidPlanSchema.optional(),
    page: external_exports.coerce.number().int().min(1).default(1),
    limit: external_exports.coerce.number().int().min(1).max(100).default(20)
  });
  var adminExtendSubscriptionSchema = external_exports.object({
    days: external_exports.number().int().min(1).max(3650)
  });
  var adminPaymentsQuerySchema = external_exports.object({
    status: external_exports.enum(["created", "paid", "failed"]).optional(),
    plan: paidPlanSchema.optional(),
    from: external_exports.string().datetime().optional(),
    to: external_exports.string().datetime().optional(),
    page: external_exports.coerce.number().int().min(1).default(1),
    limit: external_exports.coerce.number().int().min(1).max(100).default(20)
  });
  var adminUpdatePlanSchema = external_exports.object({
    name: external_exports.string().min(1).max(80).optional(),
    description: external_exports.string().max(500).optional(),
    amountPaise: external_exports.number().int().min(0).optional(),
    active: external_exports.boolean().optional(),
    limits: external_exports.object({
      monthlyApplies: external_exports.number().int().min(0),
      monthlyScans: external_exports.number().int().min(0),
      appliesPerHour: external_exports.number().int().min(0),
      appliesPerDay: external_exports.number().int().min(0)
    }).optional()
  });
  var adminAuditQuerySchema = external_exports.object({
    page: external_exports.coerce.number().int().min(1).default(1),
    limit: external_exports.coerce.number().int().min(1).max(100).default(40)
  });
  var adminMetricsQuerySchema = external_exports.object({
    /** Preset window or calendar month/year. `days` kept for backward compatibility. */
    range: external_exports.enum(["7d", "30d", "90d", "month", "year"]).optional(),
    days: external_exports.coerce.number().int().min(7).max(90).optional(),
    year: external_exports.coerce.number().int().min(2020).max(2100).optional(),
    month: external_exports.coerce.number().int().min(1).max(12).optional()
  });

  // ../shared/src/api.ts
  var apiErrorSchema = external_exports.object({
    success: external_exports.literal(false),
    message: external_exports.string(),
    data: external_exports.null(),
    error: external_exports.object({
      code: external_exports.string().optional(),
      details: external_exports.unknown().optional()
    }).nullable()
  });

  // ../shared/src/applySafety.ts
  var CONSENT_VERSION = 1;
  var SESSION_BREAK_AFTER_APPLIES = 15;
  var SESSION_BREAK_MS = 2 * 60 * 1e3;
  var STEALTH_MAX_APPLIES = 10;
  var STEALTH_MAX_MS = 20 * 60 * 1e3;
  var STEALTH_COOLDOWN_MS = 30 * 60 * 1e3;
  var BLOCK_COOLDOWN_MS = 60 * 60 * 1e3;
  var PACE_RANGES = {
    assisted: {
      nav: { min: 2500, max: 4800 },
      scroll: { min: 1600, max: 3200 },
      dwell: { min: 3200, max: 6500 },
      betweenJobs: { min: 5500, max: 11e3 },
      read: { min: 15e3, max: 26e3 }
    },
    stealth: {
      nav: { min: 3200, max: 6e3 },
      scroll: { min: 2200, max: 4200 },
      dwell: { min: 4500, max: 8500 },
      betweenJobs: { min: 8e3, max: 15e3 },
      read: { min: 2e4, max: 35e3 }
    }
  };
  function jitter(min, max) {
    return min + Math.floor(Math.random() * (max - min + 1));
  }
  function paceDelayMs(mode, phase) {
    const range = PACE_RANGES[mode][phase];
    return jitter(range.min, range.max);
  }
  function shouldTakeReadPause(appliesThisSession) {
    if (appliesThisSession <= 0) return false;
    if (appliesThisSession % 5 === 0) return Math.random() < 0.6;
    if (appliesThisSession % 4 === 0) return Math.random() < 0.35;
    return false;
  }
  function shouldTakeSessionBreak(appliesThisSession) {
    return appliesThisSession > 0 && appliesThisSession % SESSION_BREAK_AFTER_APPLIES === 0;
  }

  // ../shared/src/jobMeta.ts
  var EMBEDDED_LABEL_RE = /,?\s*(?:Industry Type|Department|Employment Type|Role Category|Education|Posted|Applicants?|Openings?)\s*:/i;
  function clean(value) {
    const t = value?.replace(/\s+/g, " ").trim();
    return t || void 0;
  }
  function stripEmbeddedLabels(value) {
    const t = clean(value);
    if (!t) return void 0;
    const match = t.match(EMBEDDED_LABEL_RE);
    if (match?.index != null && match.index > 0) {
      return clean(t.slice(0, match.index).replace(/,\s*$/, ""));
    }
    return t;
  }
  function splitExperienceSalary(combined) {
    const raw = clean(combined);
    if (!raw) return {};
    const glued = raw.match(
      /^(.+?(?:years?|yrs?))((?:Not\s*Disclosed)|(?:₹|[\d][\d,.]*(?:\s*-\s*[\d,.]+)?\s*(?:L(?:acs?|PA|akh)?|Cr(?:ore)?(?:\s*PA)?)))/i
    );
    if (glued) {
      return { experience: clean(glued[1]), salary: clean(glued[2]) };
    }
    return { experience: raw };
  }
  function splitPostedApplicants(combined) {
    const raw = clean(combined);
    if (!raw) return {};
    const applicants = clean(raw.match(/Applicants?\s*:\s*([^\n|]+)/i)?.[1]);
    let postedAt = clean(
      raw.match(/Posted\s*:\s*([^\n|]+)/i)?.[1] || raw.match(
        /(\d+\s*(?:day|days|hour|hours|minute|minutes|week|weeks|month|months)\s*ago)/i
      )?.[1]
    );
    if (postedAt && /Applicants?\s*:/i.test(postedAt)) {
      postedAt = clean(postedAt.replace(/Applicants?\s*:\s*.+$/i, ""));
    }
    if (postedAt || applicants) {
      return { postedAt, applicants };
    }
    return { postedAt: raw };
  }
  function sanitizeJobMetaFields(fields) {
    let experience = fields.experience ?? void 0;
    let salary = fields.salary ?? void 0;
    if (experience && !salary) {
      const split = splitExperienceSalary(experience);
      experience = split.experience ?? experience;
      salary = split.salary;
    }
    let postedAt = fields.postedAt ?? void 0;
    let applicants = fields.applicants ?? void 0;
    if (postedAt && /Applicants?\s*:/i.test(postedAt)) {
      const split = splitPostedApplicants(postedAt);
      postedAt = split.postedAt ?? postedAt;
      applicants = applicants ?? split.applicants;
    }
    return {
      experience: stripEmbeddedLabels(experience),
      salary: stripEmbeddedLabels(salary),
      postedAt: stripEmbeddedLabels(postedAt),
      openings: stripEmbeddedLabels(fields.openings),
      applicants: stripEmbeddedLabels(applicants),
      role: stripEmbeddedLabels(fields.role),
      industry: stripEmbeddedLabels(fields.industry),
      department: stripEmbeddedLabels(fields.department),
      employmentType: stripEmbeddedLabels(fields.employmentType),
      roleCategory: stripEmbeddedLabels(fields.roleCategory),
      education: stripEmbeddedLabels(fields.education)
    };
  }

  // ../shared/src/scanSessions.ts
  var scanSessionStatusSchema = external_exports.enum([
    "running",
    "completed",
    "stopped",
    "failed"
  ]);
  var scanSessionUpsertSchema = external_exports.object({
    sessionId: external_exports.string().uuid(),
    platform: platformSchema.default("naukri"),
    keyword: external_exports.string().max(200).default(""),
    startedAt: external_exports.string().datetime(),
    endedAt: external_exports.string().datetime().optional(),
    status: scanSessionStatusSchema.default("running"),
    /** Unique job cards seen on the search list, matched or not. */
    scanned: external_exports.number().int().nonnegative().default(0),
    matched: external_exports.number().int().nonnegative().default(0),
    applied: external_exports.number().int().nonnegative().default(0),
    skipped: external_exports.number().int().nonnegative().default(0),
    pagesScanned: external_exports.number().int().nonnegative().default(0)
  });
  var scanStatsQuerySchema = external_exports.object({
    days: external_exports.coerce.number().int().min(1).max(365).default(30),
    limit: external_exports.coerce.number().int().min(1).max(50).default(10)
  });

  // src/core/defaults.ts
  var DEFAULT_JOB_PREFERENCES = {
    titles: [],
    keywords: [],
    locations: [],
    experienceMin: 0,
    experienceMax: 30,
    workMode: "any",
    autoScanEnabled: true,
    autoApplyEnabled: false
  };

  // src/core/allowedApiBases.ts
  var PRODUCTION_API_BASE = "https://atlas-ai-job-apply-extension-1.onrender.com";
  var BUILTIN = [
    PRODUCTION_API_BASE,
    "http://localhost:4000",
    "http://127.0.0.1:4000"
  ];
  function injectedOrigins() {
    try {
      const raw = true ? "https://atlas-ai-job-apply-extension-1.onrender.com,http://localhost:4000,http://127.0.0.1:4000" : "";
      return raw.split(",").map((s) => s.trim().replace(/\/$/, "")).filter(Boolean);
    } catch {
      return [];
    }
  }
  function injectedWebOrigins() {
    try {
      const raw = true ? "http://localhost:5173,http://127.0.0.1:5173" : "";
      return raw.split(",").map((s) => s.trim().replace(/\/$/, "")).filter(Boolean);
    } catch {
      return [];
    }
  }
  function normalizeApiBase(url) {
    return url.trim().replace(/\/$/, "");
  }
  function isAllowedApiBase(url) {
    const normalized = normalizeApiBase(url);
    if (!normalized) return false;
    try {
      const parsed = new URL(normalized);
      if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
        return false;
      }
    } catch {
      return false;
    }
    const allow = /* @__PURE__ */ new Set([...BUILTIN, ...injectedOrigins()]);
    return allow.has(normalized);
  }
  function resolveApiBase(url, fallback) {
    const candidate = normalizeApiBase(url || fallback);
    if (isAllowedApiBase(candidate)) return candidate;
    const safeFallback = normalizeApiBase(fallback);
    if (isAllowedApiBase(safeFallback)) return safeFallback;
    return BUILTIN[0];
  }
  var LOCAL_WEB_BASE = "http://localhost:5173";
  function isLocalOrigin(url) {
    return /localhost|127\.0\.0\.1/.test(url);
  }
  function resolveWebBase(apiBaseUrl) {
    const injected = injectedWebOrigins();
    if (isLocalOrigin(apiBaseUrl)) {
      return injected.find((origin) => isLocalOrigin(origin)) || LOCAL_WEB_BASE;
    }
    return injected.find((origin) => !isLocalOrigin(origin)) || injected[0] || LOCAL_WEB_BASE;
  }
  function googleLoginUrl(apiBaseUrl) {
    const web = resolveWebBase(apiBaseUrl).replace(/\/$/, "");
    return `${web}/login?next=${encodeURIComponent("/dashboard")}`;
  }

  // src/core/storageManager.ts
  var DEFAULT_API = PRODUCTION_API_BASE;
  var KEYS = {
    accessToken: "accessToken",
    refreshToken: "refreshToken",
    apiBaseUrl: "apiBaseUrl",
    queue: "eventQueue",
    preferences: "preferences",
    applyQueue: "applyQueue"
  };
  async function getAuthState() {
    const data = await chrome.storage.local.get([
      KEYS.accessToken,
      KEYS.refreshToken,
      KEYS.apiBaseUrl
    ]);
    return {
      accessToken: data[KEYS.accessToken] ?? null,
      refreshToken: data[KEYS.refreshToken] ?? null,
      apiBaseUrl: resolveApiBase(
        data[KEYS.apiBaseUrl] ?? void 0,
        DEFAULT_API
      )
    };
  }
  async function setAuthState(partial) {
    const next = { ...partial };
    if (partial.apiBaseUrl !== void 0) {
      next.apiBaseUrl = resolveApiBase(partial.apiBaseUrl, DEFAULT_API);
    }
    await chrome.storage.local.set(next);
  }
  async function clearAuth() {
    await chrome.storage.local.remove([
      KEYS.accessToken,
      KEYS.refreshToken
    ]);
  }
  async function getCachedPreferences() {
    const data = await chrome.storage.local.get(KEYS.preferences);
    return {
      ...DEFAULT_JOB_PREFERENCES,
      ...data[KEYS.preferences] ?? {}
    };
  }
  async function setCachedPreferences(prefs) {
    await chrome.storage.local.set({ [KEYS.preferences]: prefs });
  }
  async function getApplyQueue() {
    const data = await chrome.storage.local.get(KEYS.applyQueue);
    return data[KEYS.applyQueue] ?? [];
  }
  async function setApplyQueue(items) {
    await chrome.storage.local.set({ [KEYS.applyQueue]: items });
  }

  // src/core/logger.ts
  var logger = {
    debug: (message, meta) => console.debug("[Cosmo]", message, meta ?? ""),
    info: (message, meta) => console.info("[Cosmo]", message, meta ?? ""),
    warn: (message, meta) => console.warn("[Cosmo]", message, meta ?? ""),
    error: (message, meta) => console.error("[Cosmo]", message, meta ?? "")
  };

  // src/core/queueManager.ts
  async function getQueue() {
    const data = await chrome.storage.local.get(KEYS.queue);
    return data[KEYS.queue] ?? [];
  }
  async function enqueue(event) {
    const queue = await getQueue();
    if (queue.some((e) => e.eventId === event.eventId)) {
      logger.debug("Skipping duplicate queue event", { eventId: event.eventId });
      return;
    }
    queue.push(event);
    await chrome.storage.local.set({ [KEYS.queue]: queue });
    logger.info("Event queued", { eventId: event.eventId, type: event.type });
  }
  async function removeFromQueue(eventIds) {
    const queue = await getQueue();
    const remaining = queue.filter((e) => !eventIds.includes(e.eventId));
    await chrome.storage.local.set({ [KEYS.queue]: remaining });
  }
  async function updateRetry(eventId, retryCount) {
    const queue = await getQueue();
    const next = queue.map(
      (e) => e.eventId === eventId ? { ...e, retryCount, syncStatus: "failed" } : e
    );
    await chrome.storage.local.set({ [KEYS.queue]: next });
  }
  function backoffMs(retryCount) {
    const base = 2e3;
    const max = 5 * 60 * 1e3;
    return Math.min(max, base * Math.pow(2, retryCount));
  }

  // src/core/apiClient.ts
  function isAuthFailure(status, body) {
    if (status === 401) return true;
    const code = body?.success === false ? body.error?.code : void 0;
    return code === "TOKEN_INVALID" || code === "UNAUTHORIZED";
  }
  async function request(path, options = {}, auth = true, didRetry = false) {
    const { accessToken, apiBaseUrl } = await getAuthState();
    const headers = {
      "Content-Type": "application/json",
      ...options.headers
    };
    if (auth && accessToken) {
      headers.Authorization = `Bearer ${accessToken}`;
    }
    const res = await fetch(`${apiBaseUrl}${path}`, {
      ...options,
      headers
    });
    let body = null;
    try {
      body = await res.json();
    } catch {
      body = {
        success: false,
        message: "Invalid server response",
        data: null,
        error: { code: "BAD_RESPONSE" }
      };
    }
    if (auth && isAuthFailure(res.status, body)) {
      if (!didRetry) {
        const refreshed = await refreshAccessToken();
        if (refreshed) {
          return request(path, options, auth, true);
        }
      }
      await clearAuth();
      logger.warn("Session cleared after auth failure", { path });
    }
    return body;
  }
  async function login(email, password) {
    const result = await request(
      "/api/v1/auth/login",
      {
        method: "POST",
        body: JSON.stringify({ email, password })
      },
      false
    );
    if (result.success) {
      await setAuthState({
        accessToken: result.data.accessToken,
        refreshToken: result.data.refreshToken
      });
    }
    return result;
  }
  async function refreshAccessToken() {
    const { refreshToken, apiBaseUrl } = await getAuthState();
    if (!refreshToken) {
      await clearAuth();
      return false;
    }
    try {
      const res = await fetch(`${apiBaseUrl}/api/v1/auth/refresh`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ refreshToken })
      });
      const result = await res.json();
      if (!res.ok || !result.success) {
        await clearAuth();
        return false;
      }
      await setAuthState({
        accessToken: result.data.accessToken,
        refreshToken: result.data.refreshToken
      });
      return true;
    } catch (error) {
      logger.warn("Token refresh failed", {
        error: error instanceof Error ? error.message : String(error)
      });
      await clearAuth();
      return false;
    }
  }
  async function syncEvents(events) {
    const body = { events };
    return request("/api/v1/events/sync", {
      method: "POST",
      body: JSON.stringify(body)
    });
  }
  async function postScanSession(input) {
    return request("/api/v1/scan-sessions", {
      method: "POST",
      body: JSON.stringify(input)
    });
  }
  async function fetchPreferences() {
    const result = await request("/api/v1/preferences");
    if (result.success) {
      await setCachedPreferences(result.data);
    }
    return result;
  }
  async function lookupAppliedJobs(input) {
    return request(
      "/api/v1/applications/lookup",
      {
        method: "POST",
        body: JSON.stringify({
          externalJobIds: input.externalJobIds ?? [],
          urls: input.urls ?? []
        })
      }
    );
  }
  async function savePreferences(prefs) {
    const result = await request("/api/v1/preferences", {
      method: "PUT",
      body: JSON.stringify(prefs)
    });
    if (result.success) {
      await setCachedPreferences(result.data.preferences);
      return {
        success: true,
        message: result.message,
        data: result.data.preferences,
        error: null
      };
    }
    return result;
  }
  async function healthCheck() {
    try {
      const result = await request(
        "/api/v1/health",
        {},
        false
      );
      return result.success && result.data.status === "ok";
    } catch (error) {
      logger.warn("Health check failed", {
        error: error instanceof Error ? error.message : String(error)
      });
      return false;
    }
  }
  async function fetchBillingMe() {
    return request("/api/v1/billing/me");
  }

  // src/core/errorHandler.ts
  function handleError(error, context) {
    const message = error instanceof Error ? error.message : "Unexpected extension error";
    logger.error(context, {
      error: message,
      stack: error instanceof Error ? error.stack : void 0
    });
    return message;
  }

  // src/core/eventBus.ts
  var EventBus = class {
    handlers = /* @__PURE__ */ new Map();
    on(event, handler) {
      if (!this.handlers.has(event)) {
        this.handlers.set(event, /* @__PURE__ */ new Set());
      }
      this.handlers.get(event).add(handler);
      return () => this.handlers.get(event)?.delete(handler);
    }
    async emit(event, payload) {
      const set = this.handlers.get(event);
      if (!set) return;
      for (const handler of set) {
        await handler(payload);
      }
    }
  };
  var eventBus = new EventBus();

  // src/core/applySafetyQuota.ts
  var CACHE_MS = 15e3;
  var cache = null;
  function toSnapshot(data) {
    const monthUsed = Math.max(0, data.appliesUsed);
    const monthLimit = Math.max(0, data.appliesLimit);
    const hourUsed = Math.max(0, data.appliesHourUsed);
    const hourLimit = Math.max(0, data.appliesHourLimit);
    const dayUsed = Math.max(0, data.appliesDayUsed);
    const dayLimit = Math.max(0, data.appliesDayLimit);
    return {
      plan: data.plan,
      monthUsed,
      monthLimit,
      monthRemaining: Math.max(0, monthLimit - monthUsed),
      hourUsed,
      hourLimit,
      hourRemaining: Math.max(0, hourLimit - hourUsed),
      dayUsed,
      dayLimit,
      dayRemaining: Math.max(0, dayLimit - dayUsed)
    };
  }
  async function getApplyQuotaSnapshot(force = false) {
    if (!force && cache && Date.now() - cache.at < CACHE_MS) {
      return cache.quota;
    }
    const result = await fetchBillingMe();
    if (!result.success) {
      if (cache) return cache.quota;
      throw new Error(result.message || "Could not load apply limits");
    }
    const quota = toSnapshot(result.data);
    cache = { quota, at: Date.now() };
    return quota;
  }
  function noteLocalApplySuccess() {
    if (!cache) return;
    const q = cache.quota;
    cache = {
      at: cache.at,
      quota: {
        ...q,
        monthUsed: q.monthUsed + 1,
        monthRemaining: Math.max(0, q.monthRemaining - 1),
        hourUsed: q.hourUsed + 1,
        hourRemaining: Math.max(0, q.hourRemaining - 1),
        dayUsed: q.dayUsed + 1,
        dayRemaining: Math.max(0, q.dayRemaining - 1)
      }
    };
  }
  function rollbackLocalApplySuccess() {
    if (!cache) return;
    const q = cache.quota;
    cache = {
      at: cache.at,
      quota: {
        ...q,
        monthUsed: Math.max(0, q.monthUsed - 1),
        monthRemaining: Math.min(q.monthLimit, q.monthRemaining + 1),
        hourUsed: Math.max(0, q.hourUsed - 1),
        hourRemaining: Math.min(q.hourLimit, q.hourRemaining + 1),
        dayUsed: Math.max(0, q.dayUsed - 1),
        dayRemaining: Math.min(q.dayLimit, q.dayRemaining + 1)
      }
    };
  }
  function getApplyQuotaBlock(quota) {
    if (quota.hourRemaining <= 0) return "hour";
    if (quota.dayRemaining <= 0) return "day";
    if (quota.monthRemaining <= 0) return "month";
    return null;
  }
  function quotaBlockMessage(quota, reason) {
    switch (reason) {
      case "hour":
        return `Hourly safety limit reached (${quota.hourUsed}/${quota.hourLimit} this hour on ${quota.plan}).`;
      case "day":
        return `Daily safety limit reached (${quota.dayUsed}/${quota.dayLimit} today on ${quota.plan}).`;
      case "month":
        return `Monthly apply limit reached (${quota.monthUsed}/${quota.monthLimit} this month). Upgrade in Cosmo to continue.`;
    }
  }

  // src/core/copilotState.ts
  var LOG_KEY = "copilotLogs";
  var STATE_KEY = "copilotState";
  var MAX_LOGS = 80;
  var MAX_SCANNED = 120;
  var DEFAULT_COPILOT_STATE = {
    running: false,
    paused: false,
    runInBackground: false,
    needsLogin: false,
    loginUserConfirmed: false,
    loginPauseReason: null,
    keyword: "",
    sessionId: null,
    sessionStartedAt: null,
    pagesScanned: 0,
    scanned: 0,
    matched: 0,
    applied: 0,
    skipped: 0,
    appliesThisSession: 0,
    stealthAppliesThisSession: 0,
    stealthStartedAt: null,
    sessionBreakUntil: null,
    sessionBreakRemainingMs: null,
    paceLabel: null,
    paceRemainingMs: null,
    sessionComplete: null,
    alert: null,
    toast: null,
    scannedJobs: []
  };
  async function getCopilotState() {
    const data = await chrome.storage.local.get(STATE_KEY);
    return {
      ...DEFAULT_COPILOT_STATE,
      ...data[STATE_KEY] ?? {},
      scannedJobs: data[STATE_KEY]?.scannedJobs ?? []
    };
  }
  function countsFromJobs(jobs) {
    let applied = 0;
    let skipped = 0;
    for (const job of jobs) {
      if (job.status === "applied") applied += 1;
      else if (job.status === "skipped" || job.status === "already_applied") {
        skipped += 1;
      }
    }
    return { matched: jobs.length, applied, skipped };
  }
  var stateWriteChain = Promise.resolve();
  async function commitCopilotState(updater) {
    const run = async () => {
      const current = await getCopilotState();
      const partial = updater(current);
      const next = { ...current, ...partial };
      if (partial.scannedJobs) {
        Object.assign(next, countsFromJobs(partial.scannedJobs));
      }
      await chrome.storage.local.set({ [STATE_KEY]: next });
      return next;
    };
    const result = stateWriteChain.then(run, run);
    stateWriteChain = result.then(
      () => void 0,
      () => void 0
    );
    return result;
  }
  async function setCopilotState(partial) {
    return commitCopilotState(() => partial);
  }
  function jobKey(job) {
    return job.externalJobId || job.url;
  }
  async function upsertScannedJobs(jobs, status = "pending") {
    const next = await commitCopilotState((state) => {
      const byId = new Map(state.scannedJobs.map((j) => [j.id, j]));
      for (const job of jobs) {
        if (!byId.has(job.id)) {
          byId.set(job.id, { ...job, status });
        }
      }
      return { scannedJobs: [...byId.values()].slice(0, MAX_SCANNED) };
    });
    return next.scannedJobs;
  }
  async function noteJobsScanned(jobs, scannedKeys) {
    let added = 0;
    for (const job of jobs) {
      const id = jobKey(job);
      if (!id || scannedKeys.has(id)) continue;
      scannedKeys.add(id);
      added += 1;
    }
    if (added <= 0) {
      const state = await getCopilotState();
      return state.scanned;
    }
    const next = await commitCopilotState((state) => ({
      scanned: state.scanned + added
    }));
    return next.scanned;
  }
  async function notePageScanned() {
    const next = await commitCopilotState((state) => ({
      pagesScanned: (state.pagesScanned ?? 0) + 1
    }));
    return next.pagesScanned;
  }
  async function updateScannedJob(id, patch) {
    await commitCopilotState((state) => ({
      scannedJobs: state.scannedJobs.map(
        (j) => j.id === id ? { ...j, ...patch } : j
      )
    }));
  }
  async function getCopilotLogs() {
    const data = await chrome.storage.local.get(LOG_KEY);
    return data[LOG_KEY] ?? [];
  }
  async function appendCopilotLog(message, level = "info") {
    const entry = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      at: (/* @__PURE__ */ new Date()).toISOString(),
      level,
      message
    };
    const logs = await getCopilotLogs();
    const next = [entry, ...logs].slice(0, MAX_LOGS);
    await chrome.storage.local.set({ [LOG_KEY]: next });
    await setCopilotState({ lastMessage: message });
    if (level === "warn" || level === "error") {
      const kind = classifyAlert(message);
      if (kind) {
        await raiseCopilotAlert(message, level === "error" ? "error" : "warn", kind);
      }
    }
    return entry;
  }
  function classifyAlert(message) {
    const m = message.toLowerCase();
    if (/hourly safety limit|hourly apply limit/.test(m)) return "rate_limit";
    if (/daily safety limit|daily apply limit/.test(m)) return "rate_limit";
    if (/plan apply limit|monthly apply limit/.test(m)) return "plan_limit";
    if (/naukri asked for verification|blocked|captcha|unusual activity/.test(m)) {
      return "blocked";
    }
    if (/log into naukri|not logged into naukri|naukri login|confirm you.?re logged/i.test(m)) {
      return "login";
    }
    if (/asking questions|waiting on naukri questions|questions still open/.test(m)) {
      return "questions";
    }
    if (/co-pilot error|still not logged|stopping co-pilot/.test(m)) return "error";
    if (levelLooksImportant(m)) return "generic";
    return null;
  }
  function levelLooksImportant(message) {
    return /limit reached|failed|unavailable|stopped/.test(message);
  }
  async function syncActionBadge(alert) {
    try {
      if (!alert) {
        await chrome.action.setBadgeText({ text: "" });
        return;
      }
      const text = alert.kind === "plan_limit" ? "MAX" : alert.kind === "rate_limit" ? "CAP" : alert.kind === "blocked" ? "BLK" : alert.kind === "login" ? "IN" : alert.level === "error" ? "!" : "\u26A0";
      await chrome.action.setBadgeText({ text });
      await chrome.action.setBadgeBackgroundColor({
        color: alert.level === "error" ? "#b42318" : "#b45309"
      });
      await chrome.action.setTitle({
        title: `Cosmo \u2014 ${alert.message}`
      });
    } catch {
    }
  }
  async function raiseCopilotAlert(message, level = "warn", kind = "generic") {
    const alert = {
      message,
      level,
      kind,
      at: (/* @__PURE__ */ new Date()).toISOString()
    };
    await setCopilotState({ alert });
    await syncActionBadge(alert);
    await broadcastCopilotToNaukriTabs({ type: "COPILOT_ALERT", alert });
    return alert;
  }
  async function raiseCopilotToast(title, message) {
    const toast = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      title,
      message,
      at: (/* @__PURE__ */ new Date()).toISOString()
    };
    await setCopilotState({ toast });
    await broadcastCopilotToNaukriTabs({ type: "COPILOT_TOAST", toast });
    return toast;
  }
  async function clearCopilotAlert() {
    await setCopilotState({ alert: null });
    await syncActionBadge(null);
    try {
      await chrome.action.setTitle({ title: "Cosmo" });
    } catch {
    }
  }
  async function clearCopilotLogs() {
    await chrome.storage.local.set({ [LOG_KEY]: [] });
  }
  async function broadcastCopilotToNaukriTabs(message) {
    const tabs = await chrome.tabs.query({
      url: ["https://www.naukri.com/*", "https://naukri.com/*"]
    });
    await Promise.all(
      tabs.map(async (tab) => {
        if (!tab.id) return;
        try {
          await chrome.tabs.sendMessage(tab.id, message);
        } catch {
        }
      })
    );
  }

  // src/adapters/types.ts
  function queryFirst(selectors, root = document) {
    for (const selector of selectors) {
      const el = root.querySelector(selector);
      if (el) return el;
    }
    return null;
  }
  function textOf(selectors, root = document) {
    const el = queryFirst(selectors, root);
    const text = el?.textContent?.trim();
    return text || void 0;
  }

  // src/adapters/naukriAdapter.ts
  var naukriSelectors = {
    title: [
      "h1.jd-header-title",
      ".jd-header .styles_jd-header-title__",
      '[class*="jd-header-title"]',
      "h1"
    ],
    company: [
      '[class*="jd-header-comp-name"] a',
      ".jd-header-comp-name a",
      ".jd-header-comp-name",
      '[class*="jd-header-comp-name"]',
      "a.comp-name"
    ],
    location: [
      ".loc span",
      ".location",
      '[class*="location"]',
      ".styles_jhc__location__"
    ],
    applySuccess: [
      ".apply-message",
      '[class*="apply-message"]',
      ".already-applied",
      '[class*="already-applied"]',
      '[class*="apply-success"]',
      '[class*="applied-success"]',
      ".apply-status-message"
    ],
    loggedIn: [
      ".nI-gNb-drawer__icon",
      ".nI-gNb-drawer",
      ".nI-gNb-icon-and-drawer",
      ".nI-gNb-info__subtxt",
      ".nI-gNb-info__name",
      "img.nI-gNb-icon-img",
      '[data-ga-track*="profile"]',
      '[data-ga-track*="Profile"]',
      ".user-name",
      '[class*="user-name"]',
      'a[href*="my.naukri.com"]',
      'a[href*="mnjuser"]',
      'a[href*="/mnj/"]',
      'a[href*="logout"]',
      // Newer Naukri header / account chrome
      ".nI-gNb-notification",
      '[class*="nI-gNb-notification"]',
      '[class*="ni-gnb-notification"]',
      '[aria-label*="notification" i]',
      '[aria-label*="Notifications" i]',
      '[aria-label*="profile" i]',
      '[aria-label*="View profile" i]',
      '[title*="View profile" i]',
      'a[href*="recruit"][href*="profile"]',
      ".view-profile-wrapper",
      '[class*="user-account"]',
      '[class*="UserAccount"]',
      '[class*="profile-menu"]',
      '[class*="ProfileMenu"]'
    ],
    // Visible Login/Register controls only — never #login_Layer alone
    // (Naukri often keeps that node in the DOM, hidden, after login).
    loggedOut: [
      "a.nI-gNb-lg-rg__login",
      "a.nI-gNb-lg-rg__register"
    ],
    easyApply: [
      "button.styles_apply-button__uJI3A",
      "button.apply-button",
      '[class*="apply-button"]',
      "button#apply-button"
    ],
    searchCards: [
      ".srp-jobtuple-wrapper",
      ".cust-job-tuple",
      "article.jobTuple",
      '[class*="jobTuple"]',
      ".styles_job-listing-container__"
    ]
  };
  function jobIdFromUrl(url) {
    const match = url.match(/(\d{8,})(?:\?|#|$)/);
    return match?.[1];
  }
  function cleanText(value) {
    const t = value?.replace(/\s+/g, " ").trim();
    return t || void 0;
  }
  function cleanCompany(value) {
    return cleanText(value)?.replace(/\s*Reviews?.*$/i, "").trim() || "Unknown";
  }
  function isElementVisible(el) {
    if (!el || !(el instanceof HTMLElement)) return false;
    if (el.hidden || el.getAttribute("aria-hidden") === "true") return false;
    const inline = el.getAttribute("style") || "";
    if (/display\s*:\s*none/i.test(inline) || /visibility\s*:\s*hidden/i.test(inline)) {
      return false;
    }
    const view = el.ownerDocument?.defaultView;
    if (view?.getComputedStyle) {
      try {
        const cs = view.getComputedStyle(el);
        if (cs.display === "none" || cs.visibility === "hidden" || cs.opacity === "0") {
          return false;
        }
      } catch {
      }
    }
    return true;
  }
  function hasLoggedInSignal(doc) {
    if (queryFirst(naukriSelectors.loggedIn, doc)) return true;
    const avatars = Array.from(
      doc.querySelectorAll(
        '.nI-gNb-header img, .nI-gNb-gnb img, header img, [class*="drawer"] img, [class*="ni-gnb"] img, [class*="nI-gNb"] img'
      )
    );
    for (const img of avatars) {
      const src = (img.getAttribute("src") || "").toLowerCase();
      const alt = (img.getAttribute("alt") || "").toLowerCase();
      if (src.includes("profile") || src.includes("photo") || src.includes("avatar") || src.includes("ni-gnb") || src.includes("naukimg.com") && (src.includes("/user") || src.includes("/np/")) || alt.includes("profile") || /\/user|\/u\//i.test(src)) {
        if (isElementVisible(img)) return true;
      }
    }
    const nameEls = Array.from(
      doc.querySelectorAll(
        '.nI-gNb-info__subtxt, .nI-gNb-info__name, .nI-gNb-drawer span, [class*="userName"], [class*="user-name"], [class*="UserName"]'
      )
    );
    for (const el of nameEls) {
      const text = cleanText(el.textContent) || "";
      if (text && !/^login$/i.test(text) && !/^register$/i.test(text) && text.length >= 2 && isElementVisible(el)) {
        return true;
      }
    }
    const accountChrome = Array.from(
      doc.querySelectorAll(
        'header [class*="badge"], header [class*=" Bell"], header [class*="bell"], [class*="nI-gNb"] [class*="count"], [class*="ni-gnb"] [class*="count"]'
      )
    );
    for (const el of accountChrome) {
      if (isElementVisible(el)) return true;
    }
    return false;
  }
  function hasVisibleLoggedOutSignal(doc) {
    for (const selector of naukriSelectors.loggedOut) {
      const el = doc.querySelector(selector);
      if (el && isElementVisible(el)) return true;
    }
    const headerLinks = Array.from(
      doc.querySelectorAll('header a, .nI-gNb-header a, [class*="nI-gNb-lg-rg"] a')
    );
    for (const el of headerLinks) {
      const text = cleanText(el.textContent) || "";
      if ((/^login$/i.test(text) || /^register$/i.test(text)) && isElementVisible(el)) {
        return true;
      }
    }
    return false;
  }
  function resolveLoginStatus(doc) {
    if (hasLoggedInSignal(doc)) return "loggedIn";
    if (hasVisibleLoggedOutSignal(doc)) return "loggedOut";
    return "uncertain";
  }
  function absoluteUrl(src) {
    if (!src || src.startsWith("data:")) return void 0;
    try {
      return new URL(src, "https://www.naukri.com").href;
    } catch {
      return void 0;
    }
  }
  function firstMatchingText(doc, selectors) {
    for (const selector of selectors) {
      const el = doc.querySelector(selector);
      const text = cleanText(el?.textContent);
      if (text) return text;
    }
    return void 0;
  }
  function uniqueStrings(values, max) {
    const seen = /* @__PURE__ */ new Set();
    const out = [];
    for (const value of values) {
      const cleaned = cleanText(value);
      if (!cleaned) continue;
      const key = cleaned.toLowerCase();
      if (seen.has(key)) continue;
      seen.add(key);
      out.push(cleaned);
      if (out.length >= max) break;
    }
    return out;
  }
  function labeledDetail(doc, labels) {
    const wanted = labels.map((l) => l.toLowerCase());
    const nodes = Array.from(
      doc.querySelectorAll(
        '[class*="details"], [class*="other-details"], [class*="job-details"], [class*="JD"], label, dt, .label, [class*="label"]'
      )
    );
    for (const node of nodes) {
      const labelText = cleanText(node.textContent)?.toLowerCase() || "";
      const matched = wanted.find((w) => labelText === w || labelText.startsWith(`${w}:`));
      if (!matched) continue;
      if (labelText.includes(":")) {
        const after = stripEmbeddedLabels(
          cleanText(node.textContent)?.split(":").slice(1).join(":")
        );
        if (after && after.length > 1) return after;
      }
      const sibling = node.nextElementSibling ?? node.parentElement?.querySelector(
        'span, a, [class*="value"], dd'
      );
      const siblingText = stripEmbeddedLabels(cleanText(sibling?.textContent));
      if (siblingText && siblingText.toLowerCase() !== matched) return siblingText;
    }
    const body = doc.body?.innerText || "";
    for (const label of labels) {
      const re = new RegExp(
        `${label}\\s*[:\\n]\\s*([^\\n]{2,120})`,
        "i"
      );
      const match = body.match(re);
      const value = stripEmbeddedLabels(cleanText(match?.[1]));
      if (value && !wanted.includes(value.toLowerCase())) return value;
    }
    return void 0;
  }
  function sectionByHeading(doc, heading, maxLen = 4e3) {
    const headings = Array.from(
      doc.querySelectorAll('h2, h3, h4, strong, [class*="title"], [class*="heading"]')
    );
    for (const h of headings) {
      const title = cleanText(h.textContent) || "";
      if (!heading.test(title)) continue;
      const parts = [];
      let el = h.nextElementSibling;
      let hops = 0;
      while (el && hops < 12) {
        const tag = el.tagName.toLowerCase();
        const text = cleanText(el.textContent);
        if ((tag === "h2" || tag === "h3" || tag === "h4") && text && text.length < 80) {
          break;
        }
        if (text) parts.push(text);
        el = el.nextElementSibling;
        hops += 1;
      }
      if (!parts.length) {
        const parent = h.parentElement;
        const block = cleanText(parent?.textContent)?.replace(title, "").trim();
        if (block) parts.push(block);
      }
      const joined = cleanText(parts.join("\n"));
      if (joined) return joined.slice(0, maxLen);
    }
    const body = doc.body?.innerText || "";
    const match = body.match(
      new RegExp(
        `${heading.source}[\\s\\S]{0,40}?\\n([\\s\\S]{20,2500}?)(?=\\n(?:Role|Industry|Department|Employment|Education|Key Skills|About company|Report this job|Job highlights|Preferred)|$)`,
        "i"
      )
    );
    return cleanText(match?.[1])?.slice(0, maxLen);
  }
  function parseHeaderStats(doc) {
    const blob = firstMatchingText(doc, [
      '[class*="stat"]',
      '[class*="posted"]',
      '[class*="jhc__"]',
      ".jd-header"
    ]) || cleanText(
      Array.from(doc.querySelectorAll('[class*="stat"], [class*="posted-by"]')).map((el) => el.textContent).join(" | ")
    ) || "";
    const bodySlice = (doc.body?.innerText || "").slice(0, 2500);
    const source = `${blob}
${bodySlice}`;
    const postedAt = cleanText(source.match(/Posted\s*:\s*([^\n|]+)/i)?.[1]) || cleanText(source.match(/(\d+\s*(?:day|days|hour|hours|minute|minutes)\s*ago)/i)?.[1]);
    const openings = cleanText(source.match(/Openings?\s*:\s*([^\n|]+)/i)?.[1]);
    const applicants = cleanText(source.match(/Applicants?\s*:\s*([^\n|]+)/i)?.[1]);
    return { postedAt, openings, applicants };
  }
  function parseRatingReviews(doc) {
    const ratingNode = doc.querySelector(
      '.rating .main-2, [class*="amb-rating"] .main-2, [class*="rating"] .main-2'
    );
    let rating = cleanText(ratingNode?.textContent)?.match(/(\d+(?:\.\d+)?)/)?.[1];
    const headerComp = doc.querySelector(
      '[class*="jd-header-comp-name"], .jd-header-comp-name, a[href*="ambitionbox"]'
    );
    const headerText = cleanText(headerComp?.textContent) || "";
    const reviewsMatch = headerText.match(/([\d,.]+[kKmM]?\+?)\s*Reviews?/i);
    let reviews = reviewsMatch ? `${reviewsMatch[1]} Reviews` : cleanText(
      doc.querySelector(
        'a[href*="ambitionbox"][href*="reviews"], [class*="reviews-count"], [class*="review-count"]'
      )?.textContent
    );
    if (!rating) {
      rating = headerText.match(/^(\d+(?:\.\d+)?)/)?.[1];
    }
    const reviewsNum = cleanText(reviews)?.match(/^(\d+(?:\.\d+)?)$/)?.[1];
    if (rating && reviewsNum && reviewsNum === rating) {
      reviews = void 0;
    }
    if (rating && reviews && reviews.replace(/\s+/g, "") === rating) {
      reviews = void 0;
    }
    return { rating, reviews };
  }
  function scrapeHighlights(doc) {
    const roots = Array.from(
      doc.querySelectorAll(
        '[class*="highlight"], [class*="job-highlight"], [class*="styles_highlight"]'
      )
    );
    const items = [];
    for (const root of roots) {
      const lis = root.querySelectorAll('li, p, [class*="chip"], span');
      for (const li of Array.from(lis)) {
        const text = cleanText(li.textContent);
        if (text && text.length > 12 && !/^job highlights$/i.test(text) && !/^keyskills$/i.test(text)) {
          items.push(text);
        }
      }
    }
    if (!items.length) {
      const body = doc.body?.innerText || "";
      const block = body.match(
        /Job highlights\s*([\s\S]{20,900}?)(?=\n(?:Job match|Keyskills|Location|Work Experience|Job description|Role)|$)/i
      )?.[1];
      if (block) {
        for (const line of block.split("\n")) {
          const text = cleanText(line);
          if (text && text.length > 12) items.push(text);
        }
      }
    }
    return uniqueStrings(items, 12);
  }
  function scrapeSkills(doc) {
    const fromChips = Array.from(
      doc.querySelectorAll(
        '[class*="key-skill"] a, [class*="key-skill"] span, [class*="chip"] span, .chip, [class*="skills"] a, [class*="tag-li"], [class*="styles_chip"] span, [class*="styles_key-skill"] span'
      )
    ).map((el) => cleanText(el.textContent));
    const filtered = fromChips.filter((s) => {
      if (!s) return false;
      if (/^skills?$/i.test(s)) return false;
      if (/preferred keyskills/i.test(s)) return false;
      if (/highlighted with/i.test(s)) return false;
      if (s.length > 60) return false;
      return true;
    });
    return uniqueStrings(filtered, 60);
  }
  function expandJobDetailSections(doc = document) {
    const buttons = Array.from(
      doc.querySelectorAll('button, a, span, div[role="button"]')
    );
    for (const el of buttons) {
      const text = cleanText(el.textContent) || "";
      if (!/^(read more|view more|see more|show more|\+?\s*\d+\s*more)$/i.test(text) && !/read more|view more|see more/i.test(text)) {
        continue;
      }
      if (text.length > 40) continue;
      if (el instanceof HTMLAnchorElement) {
        const href = el.getAttribute("href") || "";
        if (el.target === "_blank" || /^https?:/i.test(href) && !/naukri\.com/i.test(href)) {
          continue;
        }
      }
      try {
        clickInSameTab(el);
      } catch {
      }
    }
  }
  function clickInSameTab(el) {
    if (el instanceof HTMLAnchorElement || el.tagName.toLowerCase() === "a") {
      el.setAttribute("target", "_self");
    }
    const win = el.ownerDocument?.defaultView ?? window;
    const previousOpen = win.open.bind(win);
    win.open = (url) => {
      if (url != null && String(url) && String(url) !== "about:blank") {
        win.location.assign(String(url));
      }
      return win;
    };
    try {
      dispatchPointerClick(el);
    } finally {
      win.open = previousOpen;
    }
  }
  function scrapeFullDescription(doc) {
    expandJobDetailSections(doc);
    const sections = [
      sectionByHeading(doc, /^role\s*&\s*responsibilities$/i, 8e3),
      sectionByHeading(doc, /^preferred candidate profile$/i, 6e3),
      sectionByHeading(doc, /^job description$/i, 1e4),
      sectionByHeading(doc, /^what you('ll| will) (do|bring)$/i, 6e3),
      sectionByHeading(doc, /^requirements?$/i, 6e3)
    ].filter(Boolean);
    if (sections.length) {
      return uniqueStrings(sections, 8).join("\n\n").slice(0, 12e3);
    }
    const selectors = [
      '[class*="job-desc"]',
      '[class*="styles_job-desc"]',
      "#job-description",
      '[class*="jd-description"]',
      ".dang-inner-html",
      '[class*="description"]'
    ];
    let best;
    for (const selector of selectors) {
      for (const el of Array.from(doc.querySelectorAll(selector))) {
        const text = cleanText(el.textContent);
        if (text && text.length > 80 && (!best || text.length > best.length)) {
          best = text;
        }
      }
    }
    if (best) return best.slice(0, 12e3);
    const body = doc.body?.innerText || "";
    const block = body.match(
      /Job description\s*([\s\S]{80,12000}?)(?=\n(?:About (?:the )?company|Education|Role|Industry Type|Department|Employment Type|Keyskills|Report this job)\b|$)/i
    )?.[1];
    return cleanText(block)?.slice(0, 12e3);
  }
  function scrapeAboutCompany(doc) {
    expandJobDetailSections(doc);
    return sectionByHeading(doc, /^about (the )?company$/i, 4e3) || cleanText(
      doc.querySelector(
        '[class*="about-company"], [class*="comp-detail"], [class*="company-info"]'
      )?.textContent
    )?.slice(0, 4e3);
  }
  var COMPANY_SITE_APPLY_RE = /apply\s+(on|to)\s+(the\s+)?company(\s+web)?\s*site|company[- ]site|apply\s+on\s+company\s+website|external\s+apply|apply\s+externally|continue\s+to\s+company/i;
  function isCompanySiteApplyLabel(label) {
    return COMPANY_SITE_APPLY_RE.test(label.replace(/\s+/g, " ").trim());
  }
  function detectCompanySiteApply(root) {
    const scope = root instanceof Document ? root.querySelector(
      '[class*="jd-header"], [class*="styles_jhc"], [class*="apply-button"], .jd-header, header'
    ) ?? root.body ?? root.documentElement : root;
    const controls = Array.from(
      scope.querySelectorAll('button, a, [role="button"], [class*="apply"]')
    );
    let sawCompanySite = false;
    let sawEasyApply = false;
    for (const el of controls) {
      const label = cleanText(el.textContent) || "";
      if (!label || label.length > 80) continue;
      if (isCompanySiteApplyLabel(label)) {
        sawCompanySite = true;
        continue;
      }
      const lower = label.toLowerCase();
      if (lower === "apply" || lower.includes("easy apply") || lower.includes("apply") && !/login|register|company|external|site|website/.test(lower)) {
        sawEasyApply = true;
      }
    }
    if (sawCompanySite && !sawEasyApply) return true;
    if (!(root instanceof Document)) {
      const blob = cleanText(root.innerText?.slice(0, 1500));
      if (blob && /apply\s+(on|to)\s+(the\s+)?company(\s+web)?\s*site/i.test(blob) && !/\beasy apply\b/i.test(blob) && !/(^|\n)\s*apply\s*(\n|$)/i.test(blob)) {
        return true;
      }
    }
    return false;
  }
  function buildSearchKeyword(prefs, titleOverride) {
    const title = titleOverride?.trim() || prefs.titles.map((t) => t.trim()).find(Boolean);
    if (title) return title;
    const keyword = prefs.keywords.map((k) => k.trim()).filter(Boolean).slice(0, 2).join(" ");
    return keyword || "software developer";
  }
  function preferenceSearchTitles(prefs) {
    const titles = prefs.titles.map((t) => t.trim()).filter(Boolean);
    if (titles.length) return titles;
    const kw = buildSearchKeyword(prefs);
    return kw ? [kw] : ["software developer"];
  }
  function preferenceSearchLocations(prefs) {
    const locs = prefs.locations.map((l) => l.trim()).filter(Boolean);
    return locs.length ? locs : [""];
  }
  function pushUniqueQuery(plan, seen, prefs, entry) {
    const url = buildNaukriSearchUrl(prefs, {
      title: entry.keyword,
      location: entry.location
    });
    if (seen.has(url)) return;
    seen.add(url);
    plan.push({ ...entry, url });
  }
  function buildNaukriSearchQueryPlan(prefs) {
    const titles = preferenceSearchTitles(prefs);
    const locations = preferenceSearchLocations(prefs);
    const skillKeywords = prefs.keywords.map((k) => k.trim()).filter(Boolean).slice(0, 6);
    const plan = [];
    const seen = /* @__PURE__ */ new Set();
    const titleLocPairs = [];
    for (let offset = 0; offset < locations.length; offset++) {
      for (let ti = 0; ti < titles.length; ti++) {
        const location = locations[(ti + offset) % locations.length];
        const title = titles[ti];
        titleLocPairs.push({ title, location });
      }
    }
    const seenPairs = /* @__PURE__ */ new Set();
    for (const pair of titleLocPairs) {
      const key = `${pair.title.toLowerCase()}::${pair.location.toLowerCase()}`;
      if (seenPairs.has(key)) continue;
      seenPairs.add(key);
      pushUniqueQuery(plan, seen, prefs, {
        title: pair.title,
        location: pair.location,
        keyword: pair.title,
        kind: "title"
      });
    }
    for (const title of titles) {
      for (const location of locations) {
        pushUniqueQuery(plan, seen, prefs, {
          title,
          location,
          keyword: title,
          kind: "title"
        });
      }
    }
    for (const title of titles) {
      for (const skill of skillKeywords.slice(0, 4)) {
        const keyword = `${title} ${skill}`;
        for (const location of locations) {
          pushUniqueQuery(plan, seen, prefs, {
            title,
            location,
            keyword,
            kind: "title_keyword"
          });
        }
      }
    }
    for (const skill of skillKeywords) {
      for (const location of locations) {
        pushUniqueQuery(plan, seen, prefs, {
          title: skill,
          location,
          keyword: skill,
          kind: "keyword"
        });
      }
    }
    const hasCity = locations.some((l) => Boolean(l));
    if (hasCity) {
      for (const title of titles) {
        pushUniqueQuery(plan, seen, prefs, {
          title,
          location: "",
          keyword: title,
          kind: "nationwide"
        });
      }
    }
    return plan;
  }
  var NAUKRI_CTC_BUCKETS = [
    { id: "0to3", min: 0, max: 3, label: "0-3 Lakhs" },
    { id: "3to6", min: 3, max: 6, label: "3-6 Lakhs" },
    { id: "6to10", min: 6, max: 10, label: "6-10 Lakhs" },
    { id: "10to15", min: 10, max: 15, label: "10-15 Lakhs" },
    { id: "15to25", min: 15, max: 25, label: "15-25 Lakhs" },
    { id: "25to50", min: 25, max: 50, label: "25-50 Lakhs" },
    { id: "50to75", min: 50, max: 75, label: "50-75 Lakhs" },
    { id: "75to100", min: 75, max: 100, label: "75-100 Lakhs" },
    { id: "100to500", min: 100, max: 500, label: "100+ Lakhs" }
  ];
  function ctcFiltersForMinSalary(minSalaryLpa) {
    if (!(minSalaryLpa > 0)) return [];
    return NAUKRI_CTC_BUCKETS.filter(
      (b) => b.min >= minSalaryLpa || b.min < minSalaryLpa && b.max > minSalaryLpa
    ).map((b) => b.id);
  }
  function locationLabelVariants(city) {
    const raw = city.trim();
    if (!raw) return [];
    const variants = /* @__PURE__ */ new Set([raw]);
    const lower = raw.toLowerCase();
    const groups = [
      ["Hyderabad", "Hyderabad/Secunderabad", "Hyderabad Secunderabad", "Secunderabad"],
      ["Bangalore", "Bengaluru", "Bengaluru/Bangalore", "Bangalore/Bengaluru"],
      ["Chennai", "Chennai/Madras", "Madras"],
      ["Mumbai", "Mumbai/Bombay", "Bombay", "Navi Mumbai"],
      ["Delhi", "Delhi/NCR", "New Delhi", "Noida", "Gurgaon", "Gurugram"],
      ["Pune"],
      ["Kolkata", "Calcutta"],
      ["Ahmedabad"],
      ["Remote"]
    ];
    for (const group of groups) {
      if (group.some((g) => lower.includes(g.toLowerCase()) || g.toLowerCase().includes(lower))) {
        for (const g of group) variants.add(g);
      }
    }
    return [...variants];
  }
  function wfhTypeForWorkMode(workMode) {
    if (workMode === "office") return "0";
    if (workMode === "remote") return "2";
    if (workMode === "hybrid") return "3";
    return null;
  }
  function parseSalaryLpaRange(salaryText) {
    if (!salaryText?.trim()) return null;
    const sal = salaryText.toLowerCase().trim();
    if (/not\s*disclosed|undisclosed|unpaid|hidden|n\/a/.test(sal)) return null;
    const rangeLpa = sal.match(
      /(\d+(?:\.\d+)?)\s*(?:[-–]|to)\s*(\d+(?:\.\d+)?)/i
    );
    if (rangeLpa) {
      const low = Number(rangeLpa[1]);
      const high = Number(rangeLpa[2]);
      if (Number.isFinite(low) && Number.isFinite(high) && high >= low && high <= 500) {
        return { min: low, max: high };
      }
    }
    const singleLpa = sal.match(/(\d+(?:\.\d+)?)\s*(?:lpa|lacs?|lakhs?)\b/i);
    if (singleLpa) {
      const n = Number(singleLpa[1]);
      if (Number.isFinite(n) && n > 0 && n <= 500) return { min: n, max: n };
    }
    const inr = sal.replace(/,/g, "");
    const amounts = [...inr.matchAll(/(\d+(?:\.\d+)?)/g)].map((m) => Number(m[1])).filter((n) => Number.isFinite(n) && n >= 1e5);
    if (amounts.length) {
      const lpas = amounts.map((a) => a / 1e5);
      return { min: Math.min(...lpas), max: Math.max(...lpas) };
    }
    const nums = [...sal.matchAll(/(\d+(?:\.\d+)?)/g)].map((m) => Number(m[1])).filter((n) => Number.isFinite(n) && n > 0 && n <= 500);
    if (!nums.length) return null;
    return { min: Math.min(...nums), max: Math.max(...nums) };
  }
  function buildNaukriSearchUrl(prefs, overrides) {
    const keyword = buildSearchKeyword(prefs, overrides?.title);
    const location = overrides?.location !== void 0 && overrides?.location !== null ? overrides.location.trim() : prefs.locations[0] ?? "";
    const params = new URLSearchParams();
    params.set("k", keyword);
    if (location) params.set("l", location);
    if (prefs.experienceMin > 0 || prefs.experienceMax < 30) {
      params.set("experience", String(prefs.experienceMin));
    }
    if (prefs.minSalaryLpa != null && prefs.minSalaryLpa > 0) {
      for (const bucket of ctcFiltersForMinSalary(prefs.minSalaryLpa)) {
        params.append("ctcFilter", bucket);
      }
    }
    const wfh = wfhTypeForWorkMode(prefs.workMode);
    if (wfh != null) {
      params.set("wfhType", wfh);
    }
    const slug = keyword.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
    const locSlug = location.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
    const path = locSlug ? `${slug}-jobs-in-${locSlug}` : `${slug}-jobs`;
    return `https://www.naukri.com/${path}?${params.toString()}`;
  }
  function dispatchPointerClick(el) {
    const doc = el.ownerDocument;
    const view = doc.defaultView ?? window;
    const rect = el.getBoundingClientRect();
    const clientX = rect.left + Math.min(Math.max(rect.width / 2, 4), 24);
    const clientY = rect.top + Math.min(Math.max(rect.height / 2, 4), 24);
    const common = {
      bubbles: true,
      cancelable: true,
      view,
      clientX,
      clientY,
      button: 0,
      buttons: 1,
      pointerId: 1,
      pointerType: "mouse",
      isPrimary: true
    };
    const PointerCtor = typeof PointerEvent !== "undefined" ? PointerEvent : typeof view.PointerEvent !== "undefined" ? view.PointerEvent : null;
    for (const type of [
      "pointerover",
      "pointerenter",
      "mouseover",
      "mouseenter",
      "pointerdown",
      "mousedown",
      "pointerup",
      "mouseup",
      "click"
    ]) {
      if (type.startsWith("pointer")) {
        if (PointerCtor) {
          el.dispatchEvent(new PointerCtor(type, common));
        }
        continue;
      }
      el.dispatchEvent(new MouseEvent(type, common));
    }
    try {
      el.click();
    } catch {
    }
  }
  function urlHasPreferredLocation(href, cities) {
    if (!cities.length) return true;
    try {
      const u = new URL(href);
      const l = (u.searchParams.get("l") || "").toLowerCase();
      const path = u.pathname.toLowerCase();
      const cityParams = u.searchParams.getAll("cityTypeGid");
      for (const city of cities) {
        for (const variant of locationLabelVariants(city)) {
          const v = variant.toLowerCase();
          const slug = v.replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
          if (l.includes(v) || path.includes(slug) || path.includes(v.replace(/\s+/g, "-"))) {
            return true;
          }
        }
      }
      if (cityParams.length > 0) return true;
    } catch {
    }
    return false;
  }
  function searchUrlHasPreferenceFilters(url, prefs) {
    try {
      const u = new URL(url);
      const needsSalary = prefs.minSalaryLpa != null && prefs.minSalaryLpa > 0;
      const needsWfh = wfhTypeForWorkMode(prefs.workMode) != null;
      const cities = prefs.locations.map((l) => l.trim()).filter(Boolean);
      const needsLocation = cities.length > 0;
      if (!needsSalary && !needsWfh && !needsLocation) return true;
      if (needsSalary && !u.searchParams.getAll("ctcFilter").length) return false;
      if (needsWfh) {
        const want = wfhTypeForWorkMode(prefs.workMode);
        if (u.searchParams.get("wfhType") !== want) return false;
      }
      if (needsLocation && !urlHasPreferredLocation(url, cities)) return false;
      return true;
    } catch {
      return false;
    }
  }
  var NaukriAdapter = class {
    platform = "naukri";
    matches(url) {
      try {
        const u = new URL(url);
        if (u.hostname !== "www.naukri.com" && u.hostname !== "naukri.com") {
          return false;
        }
        return u.pathname.includes("/job-listings") || u.pathname.includes("/jobdescription") || /-\d+$/.test(u.pathname) || u.pathname.includes("/jobs") || /-jobs(?:\/|$)/.test(u.pathname);
      } catch {
        return false;
      }
    }
    isSearchResultsPage(url = window.location.href) {
      try {
        const u = new URL(url);
        return /-jobs(?:\/|$)/.test(u.pathname) || u.pathname.includes("/jobs-in-") || u.searchParams.has("k");
      } catch {
        return false;
      }
    }
    getLoginStatus(doc = document) {
      return resolveLoginStatus(doc);
    }
    isLoggedIn(doc = document) {
      return resolveLoginStatus(doc) === "loggedIn";
    }
    readJob(doc = document) {
      const title = textOf(naukriSelectors.title, doc);
      const company = textOf(naukriSelectors.company, doc);
      if (!title || !company) return null;
      const location = textOf(naukriSelectors.location, doc) || firstMatchingText(doc, [
        ".locWdth",
        '[class*="location"] span',
        '[class*="jhc__location"]'
      ]);
      const href = doc.location?.href ?? "";
      const externalJobId = doc.querySelector("[data-job-id]")?.getAttribute("data-job-id") ?? jobIdFromUrl(href);
      const logoEl = doc.querySelector(
        'img.logoImage, img[alt="companyLogo"], img[alt*="Company Logo" i], [class*="jd-header"] img, [class*="company-logo"] img, [class*="comp-logo"] img'
      ) ?? null;
      const companyLogo = absoluteUrl(logoEl?.getAttribute("src") || logoEl?.src);
      const experience = firstMatchingText(doc, [
        ".expwdth",
        '[class*="jhc__exp"]',
        '[class*="experience"] span',
        '[title*="experience" i]'
      ]) || void 0;
      let salary = firstMatchingText(doc, [
        ".sal",
        '[class*="jhc__salary"]',
        '[class*="salary"] span',
        '[title*="salary" i]',
        '[class*="sal-wrap"]'
      ]) || void 0;
      if (!salary) {
        const headerBlob = cleanText(
          doc.querySelector(
            '[class*="jhc__"], [class*="jd-header"], .jd-header'
          )?.textContent
        );
        const salMatch = headerBlob?.match(
          /(?:₹|Rs\.?\s*)?([\d,.]+\s*[-–to]+\s*[\d,.]+\s*(?:LPA|Lacs?|Lakhs?)|Not\s*Disclosed)/i
        );
        salary = cleanText(salMatch?.[1] || salMatch?.[0]);
      }
      if (!salary) {
        const bodyTop = (doc.body?.innerText || "").slice(0, 2e3);
        if (/not\s*disclosed/i.test(bodyTop)) salary = "Not Disclosed";
      }
      const { rating, reviews } = parseRatingReviews(doc);
      const { postedAt, openings, applicants } = parseHeaderStats(doc);
      const highlights = scrapeHighlights(doc);
      const skills = scrapeSkills(doc);
      const description = scrapeFullDescription(doc);
      const aboutCompany = scrapeAboutCompany(doc);
      const role = labeledDetail(doc, ["Role"]);
      const industry = labeledDetail(doc, ["Industry Type", "Industry"]);
      const department = labeledDetail(doc, ["Department"]);
      const employmentType = labeledDetail(doc, ["Employment Type"]);
      const roleCategory = labeledDetail(doc, ["Role Category"]);
      const education = labeledDetail(doc, ["Education"]) || sectionByHeading(doc, /^education$/i, 500);
      const roleClean = role && !/^role category$/i.test(role) && !/technology \/ it -/i.test(role) ? role : role && !/category/i.test(role) ? role : void 0;
      const sanitized = sanitizeJobMetaFields({
        experience: cleanText(experience),
        salary: cleanText(salary),
        postedAt,
        openings,
        applicants,
        role: roleClean || (role && !/category/i.test(role) ? role : void 0),
        industry,
        department,
        employmentType,
        roleCategory,
        education
      });
      return {
        platform: this.platform,
        title: cleanText(title) || title,
        company: cleanCompany(company),
        location: cleanText(location),
        externalJobId,
        url: href,
        companyLogo,
        description,
        experience: sanitized.experience,
        salary: sanitized.salary,
        skills: skills.length ? skills : void 0,
        rating,
        reviews,
        postedAt: sanitized.postedAt,
        openings: sanitized.openings,
        applicants: sanitized.applicants,
        highlights: highlights.length ? highlights : void 0,
        role: sanitized.role,
        industry: sanitized.industry,
        department: sanitized.department,
        employmentType: sanitized.employmentType,
        roleCategory: sanitized.roleCategory,
        education: sanitized.education,
        aboutCompany,
        status: "detected"
      };
    }
    readSearchResults(doc = document) {
      const cards = Array.from(
        doc.querySelectorAll(
          ".srp-jobtuple-wrapper, .cust-job-tuple, article.jobTuple, div.row[data-job-id], .tuple-title-wrapper, a.title"
        )
      );
      const seen = /* @__PURE__ */ new Set();
      const results = [];
      for (const card of cards) {
        const root = card.closest(
          '.srp-jobtuple-wrapper, .cust-job-tuple, article.jobTuple, div.row[data-job-id], [class*="jobTuple"]'
        ) ?? card;
        const titleEl = root.querySelector("a.title") ?? (card.tagName === "A" ? card : null);
        const title = cleanText(titleEl?.textContent);
        const href = titleEl?.href;
        if (!title || !href || !href.includes("job-listings")) continue;
        if (seen.has(href)) continue;
        seen.add(href);
        const company = cleanCompany(
          root.querySelector('a.comp-name, .comp-name, [class*="comp-name"]')?.textContent
        ) || "Unknown";
        const location = cleanText(
          root.querySelector('.locWdth, .location, [class*="location"]')?.textContent
        ) || void 0;
        const experienceText = cleanText(
          root.querySelector('.expwdth, .experience, [class*="experience"]')?.textContent
        ) || void 0;
        const salaryText = cleanText(
          root.querySelector('.sal, .salary, [class*="salary"]')?.textContent
        ) || void 0;
        const description = cleanText(root.querySelector('.job-desc, [class*="job-desc"]')?.textContent)?.slice(
          0,
          2e3
        ) || void 0;
        const logoEl = root.querySelector(
          'img.logoImage, img[alt="companyLogo"], .imagewrap img'
        );
        const companyLogo = absoluteUrl(logoEl?.src);
        const rating = cleanText(root.querySelector(".rating .main-2")?.textContent) || void 0;
        const reviews = cleanText(
          root.querySelector('[class*="review"], a[href*="reviews"]')?.textContent
        ) || void 0;
        const postedAt = cleanText(
          root.querySelector(
            '.job-post-day, [class*="job-post-day"], [class*="posted"]'
          )?.textContent
        ) || void 0;
        const skills = Array.from(root.querySelectorAll('.tag-li, .tag, [class*="skill"] span, [class*="chip"] span')).map((el) => cleanText(el.textContent)).filter((s) => Boolean(s)).slice(0, 30);
        if (detectCompanySiteApply(root)) {
          continue;
        }
        results.push({
          title,
          company,
          location,
          url: href.split("?")[0],
          externalJobId: root.getAttribute("data-job-id") ?? jobIdFromUrl(href),
          experienceText,
          salaryText,
          companyLogo,
          description,
          skills: skills.length ? skills : void 0,
          rating,
          reviews,
          postedAt,
          companySiteApply: false
        });
      }
      return results;
    }
    /** Job detail page only offers apply on the company website. */
    isCompanySiteApply(doc = document) {
      return detectCompanySiteApply(doc);
    }
    /** True when Naukri says this job was applied earlier (not a fresh apply). */
    isAlreadyApplied(doc = document) {
      const text = (doc.body?.innerText || "").toLowerCase();
      return /you have already applied/.test(text) || /already applied for this job/.test(text) || /already applied to this/.test(text) || /you had already applied/.test(text);
    }
    /**
     * Confirm Naukri shows a real apply success / already-applied state.
     * Never guess — used before Cosmo marks a job as applied.
     */
    detectApplicationStatus(doc = document) {
      const href = doc.location?.href ?? "";
      if (/\/myapply\/saveApply/i.test(href) || /\/myapply\//i.test(href) || /appliedSuccessfully|applySuccess|applicationSuccess/i.test(href)) {
        return "applied";
      }
      if (queryFirst(naukriSelectors.applySuccess, doc)) {
        return "applied";
      }
      const text = (doc.body?.innerText || "").slice(0, 12e3).toLowerCase();
      if (/you have successfully applied/.test(text) || /successfully applied to/.test(text) || /application (has been )?submitted/.test(text) || /your application (has been |was )?submitted/.test(text) || /application sent successfully/.test(text) || /applied successfully/.test(text) || /you have applied (to|for)/.test(text) || /you have already applied/.test(text) || /already applied for this job/.test(text) || /already applied to this/.test(text) || /you had already applied/.test(text)) {
        return "applied";
      }
      const ctas = Array.from(
        doc.querySelectorAll('button, a, [role="button"]')
      );
      for (const el of ctas) {
        const label = (el.textContent || "").replace(/\s+/g, " ").trim().toLowerCase();
        if (!label || label.length > 40) continue;
        if (label === "applied" || label === "applied successfully" || label === "already applied" || /^applied\b/.test(label)) {
          const cls = String(el.getAttribute("class") || "").toLowerCase();
          if (cls.includes("apply") || el.closest('[class*="jd-header"], [class*="styles_jhc"], [class*="apply"]')) {
            return "applied";
          }
        }
      }
      return null;
    }
    findEasyApplyButton(doc = document) {
      if (this.isCompanySiteApply(doc)) return null;
      const isVisiblyHidden = (el) => {
        if (el.hasAttribute("hidden") || el.getAttribute("aria-hidden") === "true") {
          return true;
        }
        const style = el.ownerDocument.defaultView?.getComputedStyle(el);
        if (!style) return false;
        if (style.display === "none" || style.visibility === "hidden") return true;
        const opacity = parseFloat(style.opacity);
        return Number.isFinite(opacity) && opacity === 0;
      };
      const buttons = Array.from(
        doc.querySelectorAll('button, a, [role="button"]')
      );
      const candidates = [];
      for (const btn of buttons) {
        if (isVisiblyHidden(btn)) continue;
        const label = (btn.textContent || "").replace(/\s+/g, " ").trim().toLowerCase();
        if (!label || label.length > 48) continue;
        if (isCompanySiteApplyLabel(label)) continue;
        if (/company site|external|login|register|\bsave\b|\bshare\b/.test(label)) {
          continue;
        }
        const exact = label === "apply" || label === "easy apply";
        const soft = label.includes("easy apply") || /\bapply\b/.test(label) && !/login|register/.test(label);
        if (!exact && !soft) continue;
        const cls = String(btn.getAttribute("class") || "").toLowerCase();
        const rect = btn.getBoundingClientRect();
        let score = 0;
        if (exact) score += 50;
        if (label === "apply") score += 15;
        if (cls.includes("apply")) score += 30;
        if (rect.width >= 2 && rect.height >= 2) score += 20;
        if (btn.closest(
          '[class*="jd-header"], [class*="styles_jhc"], [class*="apply-button"], [class*="styles_apply"]'
        )) {
          score += 25;
        }
        candidates.push({ el: btn, score });
      }
      candidates.sort((a, b) => b.score - a.score);
      if (candidates[0]) return candidates[0].el;
      const fallback = queryFirst(naukriSelectors.easyApply, doc);
      if (fallback && !isVisiblyHidden(fallback)) return fallback;
      return null;
    }
    /**
     * Naukri often opens a chat/Q&A drawer or shows incomplete-info banners
     * that require the user to answer before apply can succeed.
     */
    detectNeedsUserQuestions(doc = document) {
      if (this.detectApplicationStatus(doc) === "applied") {
        return null;
      }
      const text = (doc.body?.innerText || "").toLowerCase();
      if (/incomplete information/.test(text) || /answer all mandatory questions/.test(text) || /mandatory questions when reapplying/.test(text) || /please answer all mandatory/.test(text) || /application was not accepted/.test(text)) {
        return "Naukri needs mandatory questions answered";
      }
      const questionUi = doc.querySelector(
        [
          '[class*="questionnaire"]',
          '[class*="screening"]',
          '[class*="chatbot"]',
          '[class*="botContainer"]',
          '[class*="apply-form"]',
          '[class*="applyForm"]',
          '[class*="sa-container"]',
          'iframe[src*="chat"]',
          '[data-testid*="question"]'
        ].join(", ")
      );
      if (questionUi) {
        const visible = questionUi.offsetParent !== null || questionUi.getClientRects().length > 0;
        if (visible) {
          return "Naukri opened an apply questionnaire";
        }
      }
      const drawers = Array.from(
        doc.querySelectorAll(
          '[class*="drawer"], [class*="modal"], [role="dialog"], [class*="sidebar"]'
        )
      );
      for (const drawer of drawers) {
        if (drawer.offsetParent === null) continue;
        const inputs = drawer.querySelectorAll(
          'input[type="radio"], input[type="checkbox"], input[type="text"], textarea, select'
        );
        const asks = /question|experience|notice period|current ctc|expected ctc|are you/i.test(
          drawer.innerText || ""
        );
        if (inputs.length >= 2 && asks) {
          return "Naukri is asking apply questions \u2014 please answer them";
        }
      }
      return null;
    }
    hasBlockingApplyFlow(doc = document) {
      const block = this.detectNaukriBlockPage(doc);
      if (block) return block;
      const text = (doc.body?.innerText || "").toLowerCase();
      if (text.includes("login to apply") || text.includes("register to apply")) {
        return "Naukri login required";
      }
      return this.detectNeedsUserQuestions(doc);
    }
    detectNaukriBlockPage(doc = document) {
      const title = (doc.title || "").toLowerCase();
      const text = (doc.body?.innerText || "").slice(0, 8e3).toLowerCase();
      const blockPatterns = [
        /captcha/,
        /verify you are human/,
        /unusual activity/,
        /access denied/,
        /security check/,
        /challenge-page/,
        /robot check/,
        /temporarily blocked/,
        /suspicious activity/
      ];
      if (blockPatterns.some((p) => p.test(title) || p.test(text))) {
        return "Naukri verification or block page detected";
      }
      const challengeSelectors = [
        'iframe[src*="captcha"]',
        'iframe[src*="challenge"]',
        '[class*="captcha"]',
        '[id*="captcha"]',
        "#challenge-form",
        ".cf-browser-verification",
        '[data-testid*="captcha"]'
      ].join(", ");
      const challenge = doc.querySelector(challengeSelectors);
      if (challenge) {
        const el = challenge;
        if (el.offsetParent !== null || el.getClientRects().length > 0) {
          return "Naukri verification or block page detected";
        }
      }
      return null;
    }
    clickNextSearchPage(doc = document) {
      const nodes = Array.from(
        doc.querySelectorAll(
          [
            '[class*="pagination"] a',
            '[class*="Pagination"] a',
            '[class*="styles_pagination"] a',
            '[class*="styles_pages"] a',
            'a[aria-label*="next" i]',
            'button[aria-label*="next" i]',
            'a, button, [role="button"]'
          ].join(", ")
        )
      );
      const next = nodes.find((el) => {
        const text = (el.textContent || "").replace(/\s+/g, " ").trim();
        const aria = (el.getAttribute("aria-label") || "").toLowerCase();
        const title = (el.getAttribute("title") || "").toLowerCase();
        const rel = (el.getAttribute("rel") || "").toLowerCase();
        if (rel === "next") return true;
        if (/^next$/i.test(text) || /^›$|^>$|^»$/.test(text)) return true;
        if (aria.includes("next") || title.includes("next")) return true;
        if (/^next\b/i.test(text) && text.length < 12) return true;
        return false;
      });
      if (!next) {
        return { ok: false, reason: "Next page control not found" };
      }
      const disabled = next.getAttribute("disabled") != null || next.getAttribute("aria-disabled") === "true" || /disabled|inactive/i.test(next.className);
      if (disabled) {
        return { ok: false, reason: "Already on the last page" };
      }
      clickInSameTab(next);
      return { ok: true };
    }
    /** Bump Naukri search URL to the next results page when Next click fails. */
    nextSearchPageUrl(currentUrl) {
      try {
        const u = new URL(currentUrl);
        for (const key of ["page", "pageNo", "startPage"]) {
          const pageQ = u.searchParams.get(key);
          if (pageQ && /^\d+$/.test(pageQ)) {
            u.searchParams.set(key, String(Number(pageQ) + 1));
            return u.toString();
          }
        }
        const m = u.pathname.match(/^(.*?-jobs)(?:-(\d+))?\/?$/i);
        if (m) {
          const base = m[1];
          const n = m[2] ? Number(m[2]) : 1;
          u.pathname = `${base}-${n + 1}`;
          return u.toString();
        }
        const loose = u.pathname.match(/^(.*?)(?:-(\d+))?\/?$/);
        if (loose) {
          const base = loose[1];
          const n = loose[2] ? Number(loose[2]) : 1;
          if (base.length > 1) {
            u.pathname = `${base}-${n + 1}`;
            return u.toString();
          }
        }
        return null;
      } catch {
        return null;
      }
    }
  };
  function matchesPreferences(job, prefs, options) {
    return preferenceSkipReason(job, prefs, options) == null;
  }
  function matchesListCandidate(job, prefs) {
    return preferenceSkipReason(job, prefs, { requireDisclosedSalary: false }) == null;
  }
  function normalizeMatchText(value) {
    return value.toLowerCase().replace(/[^a-z0-9+#.]/g, " ").replace(/\s+/g, " ").trim();
  }
  function titleMatchesPreference(jobTitle, prefTitle) {
    const jt = normalizeMatchText(jobTitle);
    const pt = normalizeMatchText(prefTitle);
    if (!jt || !pt) return false;
    if (jt.includes(pt) || pt.includes(jt)) return true;
    const tokens = pt.split(" ").filter((t) => t.length > 1);
    if (!tokens.length) return false;
    const hits = tokens.filter((t) => jt.includes(t)).length;
    return hits >= Math.ceil(tokens.length * 0.6);
  }
  function preferenceSkipReason(job, prefs, options) {
    const requireSalary = options?.requireDisclosedSalary !== false;
    if (prefs.experienceMin > 0 || prefs.experienceMax < 50) {
      const exp = job.experienceText ?? "";
      const nums = [...exp.matchAll(/(\d+(?:\.\d+)?)/g)].map(
        (m) => Number(m[1])
      );
      if (nums.length >= 1) {
        const low = nums[0];
        const high = nums[1] ?? low;
        if (high < prefs.experienceMin || low > prefs.experienceMax) {
          return `Experience ${exp || "out of range"} outside ${prefs.experienceMin}\u2013${prefs.experienceMax} yrs`;
        }
      }
    }
    const salaryRange = parseSalaryLpaRange(job.salaryText);
    const rawSalary = job.salaryText?.trim() || "";
    if (salaryRange) {
      if (prefs.minSalaryLpa != null && prefs.minSalaryLpa > 0 && salaryRange.max < prefs.minSalaryLpa) {
        return `Salary below minimum (${rawSalary || `${salaryRange.max} LPA`} < ${prefs.minSalaryLpa} LPA)`;
      }
    } else if (requireSalary) {
      if (rawSalary && /not\s*disclosed|undisclosed/i.test(rawSalary)) {
        return "Salary not disclosed";
      }
      return rawSalary ? `Salary not usable (${rawSalary})` : "Salary not disclosed";
    }
    const titles = prefs.titles.map((t) => t.trim()).filter(Boolean);
    const keywords = prefs.keywords.map((k) => k.trim()).filter(Boolean);
    if (!titles.length && !keywords.length) {
      return "No titles or keywords in preferences";
    }
    const titleHit = titles.some((t) => titleMatchesPreference(job.title ?? "", t));
    const haystack = [
      job.title,
      job.company,
      job.location,
      ...job.skills ?? [],
      job.description ?? ""
    ].filter(Boolean).join(" ");
    const keywordHit = keywords.some(
      (k) => normalizeMatchText(haystack).includes(normalizeMatchText(k))
    );
    if (titles.length && keywords.length) {
      if (!titleHit && !keywordHit) {
        return "Title and keywords did not match preferences";
      }
      if (!titleHit) return "Job title did not match preferred titles";
      if (!keywordHit) return "Keywords did not match job skills/description";
    } else if (titles.length && !titleHit) {
      return "Job title did not match preferred titles";
    } else if (keywords.length && !keywordHit) {
      return "Keywords did not match job skills/description";
    }
    return null;
  }

  // src/core/scanSessionReporter.ts
  var QUEUE_KEY = "scanSessionQueue";
  var MAX_PENDING = 50;
  var PROGRESS_INTERVAL_MS = 2e4;
  var PERMANENT_ERROR_CODES = /* @__PURE__ */ new Set(["VALIDATION_ERROR", "NOT_FOUND"]);
  var queueWriteChain = Promise.resolve();
  var lastProgressReportAt = 0;
  async function getPending() {
    const data = await chrome.storage.local.get(QUEUE_KEY);
    return data[QUEUE_KEY] ?? [];
  }
  async function commitPending(updater) {
    const run = async () => {
      const next = updater(await getPending()).slice(-MAX_PENDING);
      await chrome.storage.local.set({ [QUEUE_KEY]: next });
    };
    const result = queueWriteChain.then(run, run);
    queueWriteChain = result.then(
      () => void 0,
      () => void 0
    );
    return result;
  }
  async function queueScanSession(input) {
    await commitPending((pending) => [
      ...pending.filter((item) => item.sessionId !== input.sessionId),
      input
    ]);
  }
  async function flushScanSessions() {
    const pending = await getPending();
    if (pending.length === 0) return;
    const { accessToken } = await getAuthState();
    if (!accessToken) return;
    const delivered = /* @__PURE__ */ new Set();
    for (const item of pending) {
      try {
        const res = await postScanSession(item);
        if (res.success) {
          delivered.add(JSON.stringify(item));
          continue;
        }
        const code = res.error?.code;
        if (code && PERMANENT_ERROR_CODES.has(code)) {
          delivered.add(JSON.stringify(item));
          logger.warn("Scan session rejected", { code, message: res.message });
        }
      } catch (error) {
        logger.warn("Scan session sync failed", {
          error: error instanceof Error ? error.message : String(error)
        });
      }
    }
    if (delivered.size === 0) return;
    await commitPending(
      (current) => current.filter((item) => !delivered.has(JSON.stringify(item)))
    );
  }
  async function beginScanSession() {
    const sessionId = v4_default();
    await setCopilotState({
      sessionId,
      sessionStartedAt: (/* @__PURE__ */ new Date()).toISOString(),
      pagesScanned: 0
    });
    lastProgressReportAt = 0;
    return sessionId;
  }
  async function reportScanSession(status) {
    const state = await getCopilotState();
    if (!state.sessionId || !state.sessionStartedAt) return;
    const isTerminal = status !== "running";
    if (!isTerminal) {
      const now = Date.now();
      if (now - lastProgressReportAt < PROGRESS_INTERVAL_MS) return;
      lastProgressReportAt = now;
    }
    await queueScanSession({
      sessionId: state.sessionId,
      platform: "naukri",
      keyword: state.keyword ?? "",
      startedAt: state.sessionStartedAt,
      ...isTerminal ? { endedAt: (/* @__PURE__ */ new Date()).toISOString() } : {},
      status,
      scanned: state.scanned ?? 0,
      matched: state.matched ?? 0,
      applied: state.applied ?? 0,
      skipped: state.skipped ?? 0,
      pagesScanned: state.pagesScanned ?? 0
    });
    await flushScanSessions();
    if (isTerminal) {
      await setCopilotState({ sessionId: null, sessionStartedAt: null });
    }
  }

  // src/core/jobFields.ts
  function preferText(primary, fallback) {
    const a = primary?.trim();
    const b = fallback?.trim();
    if (a && b) return a.length >= b.length ? a : b;
    return a || b || void 0;
  }
  function preferList(primary, fallback) {
    if (primary?.length && fallback?.length) {
      return primary.length >= fallback.length ? primary : fallback;
    }
    if (primary?.length) return primary;
    if (fallback?.length) return fallback;
    return void 0;
  }
  function mergeJobFields(primary, fallback, extras = {}) {
    const title = primary?.title || fallback?.title || "Unknown";
    const company = primary?.company || fallback?.company || "Unknown";
    return {
      platform: "naukri",
      title,
      company,
      location: preferText(primary?.location, fallback?.location),
      url: primary?.url || fallback?.url,
      externalJobId: primary?.externalJobId || fallback?.externalJobId,
      companyLogo: primary?.companyLogo || fallback?.companyLogo,
      description: preferText(primary?.description, fallback?.description),
      experience: preferText(
        primary?.experience,
        fallback?.experience || fallback?.experienceText
      ),
      salary: preferText(
        primary?.salary,
        fallback?.salary || fallback?.salaryText
      ),
      skills: preferList(primary?.skills, fallback?.skills),
      rating: preferText(primary?.rating, fallback?.rating),
      reviews: preferText(primary?.reviews, fallback?.reviews),
      postedAt: preferText(primary?.postedAt, fallback?.postedAt),
      openings: preferText(primary?.openings, fallback?.openings),
      applicants: preferText(primary?.applicants, fallback?.applicants),
      highlights: preferList(primary?.highlights, fallback?.highlights),
      role: preferText(primary?.role, fallback?.role),
      industry: preferText(primary?.industry, fallback?.industry),
      department: preferText(primary?.department, fallback?.department),
      employmentType: preferText(
        primary?.employmentType,
        fallback?.employmentType
      ),
      roleCategory: preferText(primary?.roleCategory, fallback?.roleCategory),
      education: preferText(primary?.education, fallback?.education),
      aboutCompany: preferText(primary?.aboutCompany, fallback?.aboutCompany),
      status: "detected",
      ...extras
    };
  }
  function jobDetailRichness(job) {
    if (!job) return 0;
    let score = 0;
    if (job.title) score += 1;
    if (job.company) score += 1;
    if (job.location) score += 1;
    if (job.experience) score += 1;
    if (job.salary) score += 2;
    if (job.description && job.description.length > 200) score += 3;
    else if (job.description && job.description.length > 80) score += 1;
    if (job.skills && job.skills.length >= 3) score += 2;
    else if (job.skills?.length) score += 1;
    if (job.role) score += 1;
    if (job.industry) score += 1;
    if (job.department) score += 1;
    if (job.employmentType) score += 1;
    if (job.education) score += 1;
    if (job.aboutCompany && job.aboutCompany.length > 40) score += 1;
    if (job.highlights?.length) score += 1;
    if (job.openings) score += 1;
    if (job.applicants) score += 1;
    if (job.postedAt) score += 1;
    return score;
  }

  // src/core/planApplyQuota.ts
  function noteLocalApply() {
    noteLocalApplySuccess();
  }

  // src/core/safetyStorage.ts
  var SAFETY_KEY = "applySafetyMeta";
  async function getSafetyMeta() {
    const data = await chrome.storage.local.get(SAFETY_KEY);
    return data[SAFETY_KEY] ?? {};
  }
  async function setSafetyMeta(partial) {
    const current = await getSafetyMeta();
    await chrome.storage.local.set({
      [SAFETY_KEY]: { ...current, ...partial }
    });
  }
  async function isBlocked() {
    const meta = await getSafetyMeta();
    if (!meta.blockedUntil) return false;
    return Date.parse(meta.blockedUntil) > Date.now();
  }
  async function setBlockedCooldown(until) {
    await setSafetyMeta({ blockedUntil: until.toISOString() });
  }
  async function isStealthCooldownActive() {
    const meta = await getSafetyMeta();
    if (!meta.stealthCooldownUntil) return false;
    return Date.parse(meta.stealthCooldownUntil) > Date.now();
  }
  async function setStealthCooldown(until) {
    await setSafetyMeta({ stealthCooldownUntil: until.toISOString() });
  }

  // src/core/humanPace.ts
  function wait(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
  function paceModeFromStealth(stealth) {
    return stealth ? "stealth" : "assisted";
  }
  var PHASE_LABELS = {
    nav: "Loading page",
    scroll: "Scrolling list",
    dwell: "Reading job details",
    betweenJobs: "Slowing down before next job",
    read: "Extra pause \u2014 human pacing"
  };
  async function clearPaceUi() {
    await setCopilotState({ paceLabel: null, paceRemainingMs: null });
  }
  async function pacedWait(mode, phase, options) {
    const raw = paceDelayMs(mode, phase);
    const ms = options?.maxMs != null ? Math.min(raw, Math.max(0, options.maxMs)) : raw;
    const label = options?.label || PHASE_LABELS[phase];
    const secs = Math.max(1, Math.round(ms / 1e3));
    const jobBit = options?.jobTitle ? ` \u2014 ${options.jobTitle}` : "";
    if (ms <= 0) {
      await clearPaceUi();
      return true;
    }
    if (!options?.silent) {
      await setCopilotState({
        paceLabel: label,
        paceRemainingMs: ms
      });
      await appendCopilotLog(
        `${label} (~${secs}s)${jobBit}`,
        "info"
      );
    }
    const end = Date.now() + ms;
    while (Date.now() < end) {
      const state = await getCopilotState();
      if (!state.running) {
        await clearPaceUi();
        return false;
      }
      if (state.paused && !state.sessionBreakUntil) {
        await wait(400);
        continue;
      }
      const remaining = Math.max(0, end - Date.now());
      await setCopilotState({
        paceLabel: label,
        paceRemainingMs: remaining
      });
      await wait(Math.min(1e3, remaining || 1e3));
    }
    await clearPaceUi();
    return true;
  }
  async function runReadPauseIfNeeded(mode, appliesThisSession, jobTitle) {
    if (!shouldTakeReadPause(appliesThisSession)) return true;
    return pacedWait(mode, "read", { jobTitle });
  }
  async function runSessionBreakIfNeeded(appliesThisSession) {
    if (!shouldTakeSessionBreak(appliesThisSession)) return true;
    await clearPaceUi();
    const until = Date.now() + SESSION_BREAK_MS;
    await setCopilotState({
      paused: true,
      sessionBreakUntil: new Date(until).toISOString(),
      sessionBreakRemainingMs: SESSION_BREAK_MS
    });
    await appendCopilotLog("Taking a 2-minute break \u2014 safer pacing.", "warn");
    while (Date.now() < until) {
      const state = await getCopilotState();
      if (!state.running) {
        await setCopilotState({
          sessionBreakUntil: null,
          sessionBreakRemainingMs: null
        });
        return false;
      }
      await setCopilotState({ sessionBreakRemainingMs: until - Date.now() });
      await wait(1e3);
    }
    await setCopilotState({
      paused: false,
      sessionBreakUntil: null,
      sessionBreakRemainingMs: null
    });
    await appendCopilotLog("Break complete \u2014 continuing co-pilot session.", "success");
    return true;
  }
  async function handleBlockedPage(reason) {
    const until = new Date(Date.now() + BLOCK_COOLDOWN_MS);
    await setBlockedCooldown(until);
    await clearPaceUi();
    await raiseCopilotAlert(
      `Naukri asked for verification \u2014 co-pilot stopped. Solve it in your browser, wait, then Start a new session. (${reason})`,
      "error",
      "blocked"
    );
    await setCopilotState({
      running: false,
      paused: false,
      currentTitle: "",
      sessionBreakUntil: null,
      sessionBreakRemainingMs: null
    });
    await appendCopilotLog(
      "Stopped \u2014 Naukri verification/block page detected. No retries.",
      "error"
    );
  }
  async function enforceStealthSessionCap() {
    const state = await getCopilotState();
    if (!state.runInBackground) return true;
    const startedAt = state.stealthStartedAt ? Date.parse(state.stealthStartedAt) : Date.now();
    const elapsed = Date.now() - startedAt;
    const overApplies = state.stealthAppliesThisSession >= STEALTH_MAX_APPLIES;
    const overTime = elapsed >= STEALTH_MAX_MS;
    if (!overApplies && !overTime) return true;
    await setStealthCooldown(new Date(Date.now() + STEALTH_COOLDOWN_MS));
    await clearPaceUi();
    await setCopilotState({
      runInBackground: false,
      paused: true
    });
    await appendCopilotLog(
      "Stealth session cap reached \u2014 switched to foreground. Press Resume to continue.",
      "warn"
    );
    return false;
  }
  async function noteStealthApply() {
    const state = await getCopilotState();
    if (!state.runInBackground) return;
    const stealthAppliesThisSession = state.stealthAppliesThisSession + 1;
    await setCopilotState({
      stealthAppliesThisSession,
      stealthStartedAt: state.stealthStartedAt ?? (/* @__PURE__ */ new Date()).toISOString()
    });
    await enforceStealthSessionCap();
  }

  // src/core/singleTab.ts
  var activeWorkTabId = null;
  var allowedExtraTabIds = /* @__PURE__ */ new Set();
  var guardInstalled = false;
  function setActiveWorkTabId(tabId) {
    activeWorkTabId = tabId;
  }
  function allowExtraTab(tabId) {
    allowedExtraTabIds.add(tabId);
  }
  function clearAllowedExtraTab(tabId) {
    allowedExtraTabIds.delete(tabId);
  }
  var NAUKRI_TAB_URLS = ["https://www.naukri.com/*", "https://naukri.com/*"];
  async function ensureNaukriWorkTab(opts) {
    installTabSpamGuard();
    if (activeWorkTabId != null) {
      try {
        const existing = await chrome.tabs.get(activeWorkTabId);
        if (existing.id != null) {
          await chrome.tabs.update(existing.id, {
            url: opts.url,
            active: opts.active
          });
          return chrome.tabs.get(existing.id);
        }
      } catch {
        activeWorkTabId = null;
      }
    }
    const naukriTabs = await chrome.tabs.query({ url: NAUKRI_TAB_URLS });
    const reusable = naukriTabs.find((t) => t.id != null);
    if (reusable?.id != null) {
      activeWorkTabId = reusable.id;
      await chrome.tabs.update(reusable.id, {
        url: opts.url,
        active: opts.active
      });
      return chrome.tabs.get(reusable.id);
    }
    const created = await chrome.tabs.create({
      url: opts.url,
      active: opts.active
    });
    activeWorkTabId = created.id ?? null;
    return created;
  }
  async function closeIfSpamTab(tabId) {
    if (allowedExtraTabIds.has(tabId)) return;
    if (tabId === activeWorkTabId) return;
    try {
      await chrome.tabs.remove(tabId);
    } catch {
    }
  }
  function onTabCreated(tab) {
    void (async () => {
      if (tab.id == null) return;
      if (allowedExtraTabIds.has(tab.id)) return;
      const state = await getCopilotState();
      if (!state.running || activeWorkTabId == null) return;
      if (tab.openerTabId === activeWorkTabId) {
        await closeIfSpamTab(tab.id);
        return;
      }
      const id = tab.id;
      setTimeout(() => {
        void (async () => {
          if (allowedExtraTabIds.has(id) || id === activeWorkTabId) return;
          try {
            const fresh = await chrome.tabs.get(id);
            if (fresh.openerTabId === activeWorkTabId) {
              await closeIfSpamTab(id);
            }
          } catch {
          }
        })();
      }, 400);
    })();
  }
  function installTabSpamGuard() {
    if (guardInstalled) return;
    guardInstalled = true;
    chrome.tabs.onCreated.addListener(onTabCreated);
  }

  // src/core/botRunner.ts
  function normalizeUrl(url) {
    try {
      const u = new URL(url);
      return `${u.origin}${u.pathname}`.replace(/\/$/, "");
    } catch {
      return url.split("?")[0]?.replace(/\/$/, "") || url;
    }
  }
  async function waitForTabComplete(tabId, timeoutMs = 3e4) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      const tab = await chrome.tabs.get(tabId);
      if (tab.status === "complete") return tab;
      await wait(400);
    }
    return chrome.tabs.get(tabId);
  }
  async function sendToTab(tabId, message, attempts = 12) {
    let lastError;
    for (let i = 0; i < attempts; i++) {
      try {
        return await chrome.tabs.sendMessage(tabId, message);
      } catch (error) {
        lastError = error;
        await wait(500);
      }
    }
    throw lastError instanceof Error ? lastError : new Error("Failed to message content script");
  }
  async function applyNaukriPreferenceFilters(tabId, prefs, stealth, searchUrl, options) {
    const forceNavigate = options?.forceNavigate !== false;
    const focusLocation = options?.focusLocation ?? null;
    const needsSalary = prefs.minSalaryLpa != null && prefs.minSalaryLpa > 0;
    const needsWork = prefs.workMode !== "any" && prefs.workMode != null;
    const needsLocation = prefs.locations.some((l) => Boolean(l?.trim()));
    const needsFilters = needsSalary || needsWork || needsLocation;
    if (!needsFilters) {
      await appendCopilotLog(
        "No salary/location/work-mode in preferences \u2014 keyword search only.",
        "warn"
      );
      return true;
    }
    await appendCopilotLog(
      `Applying Naukri All Filters \u2014 salary\u2265${prefs.minSalaryLpa ?? "any"} LPA, location=${focusLocation || prefs.locations.filter(Boolean).join("/") || "any"}, work=${prefs.workMode}`,
      "info"
    );
    if (forceNavigate) {
      await appendCopilotLog(`Filter search URL: ${searchUrl}`, "info");
      await chrome.tabs.update(tabId, {
        url: searchUrl,
        active: !stealth
      });
      await waitForTabComplete(tabId);
      await wait(2500);
      if (!await ensureNaukriLoggedIn(tabId)) return false;
      for (let i = 0; i < 2; i++) {
        const tab = await chrome.tabs.get(tabId);
        if (searchUrlHasPreferenceFilters(tab.url || "", prefs)) break;
        await appendCopilotLog(
          "Naukri dropped filter params \u2014 reloading filtered URL\u2026",
          "warn"
        );
        await chrome.tabs.update(tabId, {
          url: searchUrl,
          active: !stealth
        });
        await waitForTabComplete(tabId);
        await wait(2e3);
      }
    }
    await appendCopilotLog(
      "Opening Naukri All Filters, then applying salary/location/work-mode\u2026",
      "info"
    );
    let confirmed = false;
    let lastDetails = [];
    for (let attempt = 0; attempt < 5; attempt++) {
      if (!await waitWhilePaused()) return false;
      try {
        const result = await sendToTab(
          tabId,
          { type: "APPLY_PREFERENCE_FILTERS", prefs, focusLocation },
          10
        );
        if (result.openedAllFilters) {
          await appendCopilotLog("All Filters panel is open", "success");
        }
        lastDetails = result.confirmDetails ?? [];
        if (result.confirmed || result.alreadyApplied || (result.applied?.length ?? 0) > 0) {
          if (result.confirmed || result.alreadyApplied) {
            confirmed = true;
          }
          if (result.alreadyApplied && !result.applied?.length) {
            await appendCopilotLog(
              "Naukri All Filters already match preferences",
              "success"
            );
          } else if (result.applied?.length) {
            await appendCopilotLog(
              `All Filters applied: ${result.applied.join(", ")}`,
              "success"
            );
          }
          if (result.confirmed || result.alreadyApplied) {
            await appendCopilotLog(
              `Filters reconfirmed${lastDetails.length ? `: ${lastDetails.join("; ")}` : ""}`,
              "success"
            );
            break;
          }
        }
        await appendCopilotLog(
          `All Filters attempt ${attempt + 1}: ${(result.skipped ?? []).join("; ") || "panel not ready"}`,
          "warn"
        );
        await wait(1500);
      } catch (error) {
        await appendCopilotLog(
          `All Filters click error: ${error instanceof Error ? error.message : String(error)}`,
          "warn"
        );
        await wait(1200);
      }
    }
    if (!confirmed) {
      try {
        const verify = await sendToTab(
          tabId,
          { type: "CONFIRM_PREFERENCE_FILTERS", prefs, focusLocation },
          4
        );
        confirmed = Boolean(verify.confirmed);
        lastDetails = verify.details ?? lastDetails;
        if (confirmed) {
          await appendCopilotLog(
            `Filters reconfirmed: ${(lastDetails || []).join("; ") || "ok"}`,
            "success"
          );
        }
      } catch {
      }
    }
    const tabAfter = await chrome.tabs.get(tabId);
    const urlOk = searchUrlHasPreferenceFilters(tabAfter.url || "", prefs);
    if (!confirmed && !urlOk) {
      await appendCopilotLog(
        `Could not confirm Naukri filters (salary/location/work). ${lastDetails.join("; ")}`,
        "error"
      );
      return false;
    }
    if (!confirmed && urlOk) {
      await appendCopilotLog(
        "URL filters active \u2014 sidebar ticks incomplete, continuing with URL filters",
        "warn"
      );
    }
    await wait(2e3);
    await waitForTabComplete(tabId);
    return true;
  }
  async function waitWhilePaused() {
    while (true) {
      const state = await getCopilotState();
      if (!state.running) return false;
      if (!state.paused) return true;
      await wait(500);
    }
  }
  async function waitWhilePausedForQuestions(tabId) {
    while (true) {
      const state = await getCopilotState();
      if (!state.running) return "stopped";
      if (!state.paused) return "resumed";
      try {
        const status = await sendToTab(tabId, { type: "CHECK_APPLY_STATUS" }, 2);
        if (status.applied) {
          await setCopilotState({ paused: false, needsLogin: false, loginPauseReason: null });
          await clearCopilotAlert();
          await appendCopilotLog(
            "Apply success detected after your answers \u2014 continuing",
            "success"
          );
          return "applied";
        }
        if (status.needsQuestions === false) {
          await setCopilotState({ paused: false, needsLogin: false, loginPauseReason: null });
          await clearCopilotAlert();
          await appendCopilotLog(
            "Questions cleared \u2014 retrying apply",
            "success"
          );
          return "resumed";
        }
      } catch {
      }
      await wait(1200);
    }
  }
  async function ensureNaukriLoggedIn(tabId) {
    for (let attempt = 0; attempt < 8; attempt++) {
      if (!await waitWhilePaused()) return false;
      await wait(attempt === 0 ? 1500 : 700);
      const login2 = await sendToTab(tabId, {
        type: "CHECK_LOGIN"
      });
      if (login2.loggedIn) {
        await setCopilotState({ needsLogin: false, loginPauseReason: null });
        if (attempt > 0) {
          await appendCopilotLog("Naukri login detected \u2014 continuing", "success");
        }
        return true;
      }
      const state = await getCopilotState();
      if (state.loginUserConfirmed && login2.status !== "loggedOut") {
        await setCopilotState({ needsLogin: false, loginPauseReason: null });
        await appendCopilotLog(
          "Using your confirmed Naukri login \u2014 continuing",
          "success"
        );
        return true;
      }
      const reason = login2.status === "loggedOut" ? "loggedOut" : "uncertain";
      await setCopilotState({
        paused: true,
        needsLogin: true,
        loginPauseReason: reason
      });
      await appendCopilotLog(
        reason === "uncertain" ? "Paused \u2014 confirm you\u2019re logged into Naukri, then press Confirm." : "Paused \u2014 please log into Naukri to continue. Open login in a new tab, then press Confirm.",
        "warn"
      );
      await sendToTab(tabId, {
        type: "SHOW_LOGIN_PROMPT",
        reason
      }).catch(() => void 0);
      if (!await waitWhilePaused()) return false;
      const after = await getCopilotState();
      if (after.loginUserConfirmed) {
        await setCopilotState({ needsLogin: false, loginPauseReason: null });
        await appendCopilotLog(
          "Login confirmed \u2014 continuing co-pilot",
          "success"
        );
        return true;
      }
      await appendCopilotLog("Resumed \u2014 checking Naukri login again\u2026");
      await wait(2e3);
    }
    await appendCopilotLog(
      "Still not logged into Naukri. Stopping co-pilot.",
      "error"
    );
    await setCopilotState({
      running: false,
      paused: false,
      needsLogin: false,
      loginPauseReason: null
    });
    return false;
  }
  async function checkBlockOnTab(tabId) {
    try {
      const res = await sendToTab(
        tabId,
        { type: "CHECK_BLOCK_PAGE" },
        3
      );
      if (res.blocked) {
        await handleBlockedPage(res.reason || "verification page");
        return true;
      }
    } catch {
    }
    return false;
  }
  async function goBackToList(tabId, searchUrl, stealth, options) {
    const mode = paceModeFromStealth(stealth);
    await chrome.tabs.update(tabId, {
      url: searchUrl,
      active: !stealth
    });
    await waitForTabComplete(tabId);
    await pacedWait(mode, "nav", {
      jobTitle: "search list",
      maxMs: options?.maxNavMs,
      label: options?.maxNavMs != null ? "Back to list" : void 0
    });
  }
  async function tryEasyApply(tabId) {
    return sendToTab(tabId, { type: "RUN_EASY_APPLY" });
  }
  async function reconfirmAppliedOnTab(tabId) {
    try {
      const res = await sendToTab(tabId, { type: "CHECK_APPLY_STATUS" }, 4);
      return {
        applied: Boolean(res.applied),
        needsQuestions: Boolean(res.needsQuestions)
      };
    } catch {
      return { applied: false, needsQuestions: false };
    }
  }
  async function probeApplyReady(tabId) {
    try {
      const res = await sendToTab(
        tabId,
        { type: "PROBE_APPLY_READY" },
        3
      );
      return Boolean(res.ready);
    } catch {
      return false;
    }
  }
  async function waitForApplyReady(tabId, timeoutMs = 4e3) {
    const end = Date.now() + timeoutMs;
    while (Date.now() < end) {
      if (await probeApplyReady(tabId)) return true;
      await wait(350);
    }
    return probeApplyReady(tabId);
  }
  async function markApplied(handlers, base, id, alreadyApplied) {
    if (alreadyApplied) {
      await handlers.persistApplicationRecorded({
        ...base,
        status: "applied",
        appliedAt: (/* @__PURE__ */ new Date()).toISOString(),
        metadata: { source: "auto_apply", alreadyApplied: true }
      });
      await updateScannedJob(id, { status: "already_applied" });
      await appendCopilotLog(`Already applied \u2014 skipped: ${base.title}`, "info");
      await raiseCopilotToast(
        "Already applied \u2014 skipped",
        base.company ? `${base.title} \xB7 ${base.company}` : base.title
      );
      return;
    }
    await handlers.persistApplicationRecorded({
      ...base,
      status: "applied",
      appliedAt: (/* @__PURE__ */ new Date()).toISOString(),
      metadata: { source: "auto_apply" }
    });
    await noteLocalApply();
    const state = await getCopilotState();
    const appliesThisSession = state.appliesThisSession + 1;
    await setCopilotState({ appliesThisSession });
    await noteStealthApply();
    await updateScannedJob(id, { status: "applied" });
    await appendCopilotLog(`Applied: ${base.title}`, "success");
    await raiseCopilotToast(
      "Job applied successfully",
      base.company ? `${base.title} \xB7 ${base.company}` : base.title
    );
  }
  async function markSkipped(handlers, base, id, reason) {
    if (/company site|external/i.test(reason)) {
      await markCompanySite(handlers, base, id);
      return;
    }
    await handlers.persistJobDetected({
      ...base,
      metadata: {
        source: "auto_scan",
        skipped: true,
        skipReason: reason
      }
    });
    await updateScannedJob(id, { status: "skipped", skipReason: reason });
    await appendCopilotLog(`Skipped: ${base.title} \u2014 ${reason}`, "warn");
    await raiseCopilotToast(
      "Job skipped",
      base.company ? `${base.title} \xB7 ${base.company}` : `${base.title} \u2014 ${reason}`
    );
  }
  async function markCompanySite(handlers, base, id) {
    const reason = "Apply on company site \u2014 needs manual apply";
    await handlers.persistJobDetected({
      ...base,
      metadata: {
        source: "auto_scan",
        skipped: true,
        companySiteApply: true,
        skipReason: reason
      }
    });
    await updateScannedJob(id, {
      status: "skipped",
      skipReason: reason
    });
    await appendCopilotLog(
      `Company site \u2014 saved for manual apply: ${base.title}`,
      "info"
    );
    await raiseCopilotToast(
      "Saved for manual apply",
      base.company ? `${base.title} \xB7 ${base.company}` : base.title
    );
  }
  async function applyOneJob(tabId, job, prefs, handlers, searchUrl, stealth) {
    const id = jobKey(job);
    const mode = paceModeFromStealth(stealth);
    const detectPayload = mergeJobFields(void 0, job, {
      status: "detected",
      metadata: { source: "auto_scan" }
    });
    await handlers.persistJobDetected(detectPayload);
    await updateScannedJob(id, { status: "applying" });
    await setCopilotState({ currentTitle: job.title });
    await appendCopilotLog(`Opening: ${job.title}`);
    const state = await getCopilotState();
    await chrome.tabs.update(tabId, {
      url: job.url,
      active: !state.runInBackground
    });
    await waitForTabComplete(tabId);
    await setCopilotState({
      paceLabel: "Opening job",
      paceRemainingMs: null
    });
    const applyReadyEarly = await waitForApplyReady(tabId, 3500);
    if (!await pacedWait(mode, "nav", {
      jobTitle: job.title,
      maxMs: applyReadyEarly ? 400 : void 0,
      label: applyReadyEarly ? "Apply ready \u2014 clicking soon" : "Loading page"
    })) {
      return "stop";
    }
    if (await checkBlockOnTab(tabId)) return "stop";
    if (!await waitWhilePaused()) return "stop";
    if (!await ensureNaukriLoggedIn(tabId)) return "stop";
    let detailJob;
    let companySiteApply = Boolean(job.companySiteApply);
    const detailAttempts = applyReadyEarly ? 2 : 4;
    for (let attempt = 0; attempt < detailAttempts; attempt++) {
      try {
        const detail = await sendToTab(tabId, { type: "READ_JOB_DETAIL" }, 4);
        detailJob = detail.job ?? detailJob;
        if (detail.companySiteApply) companySiteApply = true;
        if (jobDetailRichness(detailJob) >= 8) break;
      } catch {
      }
      await wait(applyReadyEarly ? 300 : 700 + attempt * 400);
    }
    const enriched = mergeJobFields(detailJob, job, {
      status: "detected",
      metadata: { source: "auto_scan" }
    });
    await handlers.persistJobDetected(enriched);
    await appendCopilotLog(
      `Captured details for ${enriched.title} (${jobDetailRichness(enriched)} fields)`,
      jobDetailRichness(enriched) >= 8 ? "success" : "warn"
    );
    const detailCandidate = {
      ...job,
      title: enriched.title || job.title,
      company: enriched.company || job.company,
      location: enriched.location || job.location,
      salaryText: enriched.salary || job.salaryText,
      experienceText: enriched.experience || job.experienceText,
      skills: enriched.skills || job.skills,
      description: enriched.description || job.description
    };
    if (!matchesPreferences(detailCandidate, prefs, {
      requireDisclosedSalary: false
    })) {
      const reason = preferenceSkipReason(detailCandidate, prefs, {
        requireDisclosedSalary: false
      }) || "Did not match job preferences";
      await markSkipped(handlers, enriched, id, reason);
      await goBackToList(tabId, searchUrl, stealth, { maxNavMs: 800 });
      return "continue";
    }
    if (companySiteApply) {
      await markCompanySite(handlers, enriched, id);
      await goBackToList(tabId, searchUrl, stealth, { maxNavMs: 800 });
      return "continue";
    }
    if (!prefs.autoApplyEnabled) {
      await markSkipped(handlers, enriched, id, "Auto-apply is off");
      await goBackToList(tabId, searchUrl, stealth, { maxNavMs: 800 });
      return "continue";
    }
    let quota;
    try {
      quota = await getApplyQuotaSnapshot();
    } catch (error) {
      await appendCopilotLog(
        `Could not verify apply limits: ${error instanceof Error ? error.message : String(error)}`,
        "warn"
      );
      await goBackToList(tabId, searchUrl, stealth, { maxNavMs: 800 });
      return "stop";
    }
    const blockReason = getApplyQuotaBlock(quota);
    if (blockReason) {
      await updateScannedJob(id, { status: "pending" });
      const msg = quotaBlockMessage(quota, blockReason);
      await raiseCopilotAlert(
        msg,
        "warn",
        blockReason === "month" ? "plan_limit" : "rate_limit"
      );
      await appendCopilotLog(msg, "warn");
      await goBackToList(tabId, searchUrl, stealth, { maxNavMs: 800 });
      return "limit";
    }
    const applyReady = applyReadyEarly || await probeApplyReady(tabId);
    if (!await pacedWait(mode, "dwell", {
      jobTitle: job.title,
      // Apply on screen → click almost immediately; don't burn 3–8s dwell.
      maxMs: applyReady ? 350 : void 0,
      label: applyReady ? "About to apply" : "Reading job details"
    })) {
      return "stop";
    }
    if (await checkBlockOnTab(tabId)) return "stop";
    if (!await ensureNaukriLoggedIn(tabId)) return "stop";
    if (!applyReady && !await waitForApplyReady(tabId, 2500)) {
      await appendCopilotLog(
        `Apply button not found yet for "${job.title}" \u2014 trying Easy Apply anyway`,
        "warn"
      );
    }
    await setCopilotState({
      paceLabel: "Clicking Apply",
      paceRemainingMs: null,
      currentTitle: job.title
    });
    await appendCopilotLog(`Clicking Apply: ${job.title}`);
    let result = await tryEasyApply(tabId);
    if (result.blocked) {
      await handleBlockedPage(result.reason || "verification page");
      return "stop";
    }
    if (result.ok && !result.needsUserInput) {
      await setCopilotState({
        paceLabel: "Confirming apply",
        paceRemainingMs: null
      });
      await wait(700);
      let confirm = await reconfirmAppliedOnTab(tabId);
      if (confirm.needsQuestions) {
        result = {
          ...result,
          ok: false,
          needsUserInput: true,
          reason: "Naukri is asking apply questions"
        };
      } else if (!confirm.applied) {
        await appendCopilotLog(
          `Apply not confirmed yet for "${job.title}" \u2014 retrying click`,
          "warn"
        );
        await wait(500);
        const retry = await tryEasyApply(tabId);
        if (retry.blocked) {
          await handleBlockedPage(retry.reason || "verification page");
          return "stop";
        }
        if (retry.needsUserInput) {
          result = {
            ...retry,
            ok: false,
            needsUserInput: true,
            reason: retry.reason || "Naukri is asking apply questions"
          };
        } else if (retry.ok) {
          await wait(700);
          confirm = await reconfirmAppliedOnTab(tabId);
          if (confirm.needsQuestions) {
            result = {
              ...retry,
              ok: false,
              needsUserInput: true,
              reason: "Naukri is asking apply questions"
            };
          } else if (confirm.applied) {
            result = retry;
            await appendCopilotLog(
              `Confirmed applied on Naukri: ${job.title}`,
              "success"
            );
          } else {
            result = {
              ...retry,
              ok: false,
              skipped: true,
              reason: "Apply not confirmed on Naukri"
            };
          }
        } else {
          result = {
            ...retry,
            ok: false,
            skipped: true,
            reason: retry.reason || "Apply not confirmed on Naukri"
          };
        }
      } else {
        await appendCopilotLog(`Confirmed applied on Naukri: ${job.title}`, "success");
      }
    }
    const base = mergeJobFields(result.job, enriched, {
      url: job.url,
      status: "detected",
      metadata: { source: "auto_apply" }
    });
    if (result.needsUserInput) {
      await setCopilotState({ paused: true, currentTitle: base.title });
      await appendCopilotLog(
        `Paused \u2014 Naukri is asking questions for "${base.title}". Answer them on the page; Cosmo will continue when you save, or press Resume.`,
        "warn"
      );
      const pauseOutcome = await waitWhilePausedForQuestions(tabId);
      if (pauseOutcome === "stopped") return "stop";
      if (pauseOutcome === "applied") {
        await markApplied(handlers, base, id, false);
        const after = await getCopilotState();
        if (!await runSessionBreakIfNeeded(after.appliesThisSession)) return "stop";
        if (!await pacedWait(mode, "betweenJobs", { jobTitle: base.title })) {
          return "stop";
        }
        await goBackToList(tabId, searchUrl, stealth, { maxNavMs: 900 });
        return "continue";
      }
      await appendCopilotLog(
        `Resumed \u2014 retrying apply for "${base.title}"`,
        "success"
      );
      if (!await pacedWait(mode, "nav", { jobTitle: base.title })) return "stop";
      if (!await ensureNaukriLoggedIn(tabId)) return "stop";
      result = await tryEasyApply(tabId);
      if (result.blocked) {
        await handleBlockedPage(result.reason || "verification page");
        return "stop";
      }
      if (result.needsUserInput) {
        await setCopilotState({ paused: true });
        await appendCopilotLog(
          "Still waiting on Naukri questions. Finish them \u2014 Cosmo will continue when saved, or press Resume.",
          "warn"
        );
        const pause2 = await waitWhilePausedForQuestions(tabId);
        if (pause2 === "stopped") return "stop";
        if (pause2 === "applied") {
          await markApplied(handlers, base, id, false);
        } else {
          if (!await ensureNaukriLoggedIn(tabId)) return "stop";
          result = await tryEasyApply(tabId);
          if (result.blocked) {
            await handleBlockedPage(result.reason || "verification page");
            return "stop";
          }
          if (result.ok) {
            await markApplied(
              handlers,
              {
                ...base,
                title: result.job?.title || base.title,
                company: result.job?.company || base.company
              },
              id,
              Boolean(result.alreadyApplied)
            );
          } else if (result.needsUserInput) {
            await markSkipped(
              handlers,
              base,
              id,
              "User questions not completed"
            );
          } else {
            await markSkipped(
              handlers,
              base,
              id,
              result.reason || "Easy Apply unavailable"
            );
          }
        }
      } else if (result.ok) {
        await markApplied(
          handlers,
          {
            ...base,
            title: result.job?.title || base.title,
            company: result.job?.company || base.company
          },
          id,
          Boolean(result.alreadyApplied)
        );
      } else {
        await markSkipped(
          handlers,
          base,
          id,
          result.reason || "Easy Apply unavailable"
        );
      }
    } else if (result.ok) {
      await markApplied(handlers, base, id, Boolean(result.alreadyApplied));
    } else {
      await markSkipped(
        handlers,
        base,
        id,
        result.reason || "Easy Apply unavailable"
      );
    }
    const afterApply = await getCopilotState();
    if (afterApply.appliesThisSession > 0) {
      if (!await runReadPauseIfNeeded(
        mode,
        afterApply.appliesThisSession,
        job.title
      )) {
        return "stop";
      }
      if (!await runSessionBreakIfNeeded(afterApply.appliesThisSession)) {
        return "stop";
      }
    }
    if (!await pacedWait(mode, "betweenJobs", { jobTitle: job.title })) {
      return "stop";
    }
    await goBackToList(tabId, searchUrl, stealth, { maxNavMs: 900 });
    if (!await ensureNaukriLoggedIn(tabId)) return "stop";
    return "continue";
  }
  async function fetchAppliedSet(jobs) {
    const externalJobIds = jobs.map((j) => j.externalJobId).filter((id) => Boolean(id));
    const urls = jobs.map((j) => normalizeUrl(j.url));
    const res = await lookupAppliedJobs({ externalJobIds, urls });
    if (!res.success) {
      return { ids: /* @__PURE__ */ new Set(), urls: /* @__PURE__ */ new Set() };
    }
    return {
      ids: new Set(res.data.externalJobIds),
      urls: new Set(res.data.urls.map(normalizeUrl))
    };
  }
  function isAlreadyInDb(job, applied) {
    if (job.externalJobId && applied.ids.has(job.externalJobId)) return true;
    return applied.urls.has(normalizeUrl(job.url));
  }
  var botRunning = false;
  var lastSession = null;
  var MAX_SCROLL_ROUNDS = 20;
  var SCAN_BATCH_SIZE = 30;
  var MAX_SCAN_PAGES = 40;
  var MAX_EMPTY_PAGES = 3;
  var naukriPager = new NaukriAdapter();
  async function goToNextSearchPage(tabId) {
    const before = (await chrome.tabs.get(tabId)).url || "";
    const clicked = await sendToTab(
      tabId,
      { type: "CLICK_NEXT_PAGE" },
      4
    ).catch(() => ({ ok: false, reason: "Could not open next page" }));
    await waitForTabComplete(tabId).catch(() => void 0);
    await wait(1800);
    let after = (await chrome.tabs.get(tabId)).url || "";
    if (clicked.ok && after !== before) {
      return { ok: true };
    }
    const nextUrl = naukriPager.nextSearchPageUrl(after || before);
    if (!nextUrl || nextUrl === after || nextUrl === before) {
      return {
        ok: false,
        reason: clicked.reason || "Already on the last page"
      };
    }
    await chrome.tabs.update(tabId, { url: nextUrl, active: true });
    await waitForTabComplete(tabId);
    await wait(2e3);
    after = (await chrome.tabs.get(tabId)).url || "";
    if (after === before) {
      return { ok: false, reason: "Next page navigation did not stick" };
    }
    return { ok: true };
  }
  async function collectPreferenceMatches(opts) {
    const { tabId, searchUrl, stealth, prefs, seenKeys, scannedKeys } = opts;
    const prefix = opts.logPrefix ?? "Scan";
    const mode = paceModeFromStealth(stealth);
    const batch = opts.into ?? [];
    await appendCopilotLog(
      `${prefix}: collecting matched jobs (${batch.length}/${SCAN_BATCH_SIZE}) \u2014 no apply until ${SCAN_BATCH_SIZE}\u2026`,
      "info"
    );
    for (let round = 0; round < MAX_SCROLL_ROUNDS && batch.length < SCAN_BATCH_SIZE; round++) {
      if (!await waitWhilePaused()) break;
      if (!await ensureNaukriLoggedIn(tabId)) break;
      const tabInfo = await chrome.tabs.get(tabId);
      if (!tabInfo.url || !/naukri\.com/i.test(tabInfo.url) || /job-listings/i.test(tabInfo.url)) {
        await goBackToList(tabId, searchUrl, stealth);
        if (!await ensureNaukriLoggedIn(tabId)) break;
      }
      await appendCopilotLog(
        round === 0 ? `${prefix}: scanning job list` : `${prefix}: scrolling list (round ${round + 1})`
      );
      if (round > 0) {
        await sendToTab(tabId, { type: "SCROLL_SEARCH_RESULTS" }).catch(
          () => void 0
        );
        await pacedWait(mode, "scroll", { jobTitle: "job list" });
      }
      const scrape = await sendToTab(tabId, {
        type: "RUN_SCAN_SCRAPE"
      });
      const allJobs = scrape.jobs ?? [];
      const scannedTotal = await noteJobsScanned(allJobs, scannedKeys);
      const visible = allJobs.filter((job) => matchesListCandidate(job, prefs));
      const appliedSet = await fetchAppliedSet(visible);
      let addedThisRound = 0;
      for (const job of visible) {
        if (batch.length >= SCAN_BATCH_SIZE) break;
        const id = jobKey(job);
        if (seenKeys.has(id)) continue;
        seenKeys.add(id);
        if (isAlreadyInDb(job, appliedSet)) {
          await upsertScannedJobs(
            [
              {
                id,
                title: job.title,
                company: job.company,
                url: job.url,
                externalJobId: job.externalJobId
              }
            ],
            "already_applied"
          );
          await appendCopilotLog(
            `Already applied (Cosmo) \u2014 skipped: ${job.title}`,
            "info"
          );
          continue;
        }
        await upsertScannedJobs([
          {
            id,
            title: job.title,
            company: job.company,
            url: job.url,
            externalJobId: job.externalJobId
          }
        ]);
        batch.push(job);
        addedThisRound += 1;
      }
      await appendCopilotLog(
        `${prefix} round ${round + 1}: scanned ${scannedTotal} \xB7 +${addedThisRound} match \u2192 ${batch.length}/${SCAN_BATCH_SIZE}`,
        addedThisRound ? "success" : "warn"
      );
      if (batch.length >= SCAN_BATCH_SIZE) break;
      if (round > 0 && addedThisRound === 0) {
        await appendCopilotLog(
          `${prefix}: no more new matching jobs on this page`,
          "info"
        );
        break;
      }
    }
    return batch;
  }
  async function collectUntilMatchedBatch(opts) {
    const batch = [...opts.pending ?? []];
    const prefix = opts.logPrefix ?? "Scan";
    let emptyPages = 0;
    for (let page = 0; page < MAX_SCAN_PAGES && batch.length < SCAN_BATCH_SIZE; page++) {
      if (!await waitWhilePaused()) break;
      if (!await ensureNaukriLoggedIn(opts.tabId)) break;
      if (page > 0) {
        await appendCopilotLog(
          `${prefix}: ${batch.length}/${SCAN_BATCH_SIZE} matched \u2014 auto next page (no ask)\u2026`,
          "info"
        );
        const next = await goToNextSearchPage(opts.tabId);
        if (!next.ok) {
          await appendCopilotLog(
            next.reason || `No more pages \u2014 still at ${batch.length}/${SCAN_BATCH_SIZE}`,
            "warn"
          );
          break;
        }
      }
      const before = batch.length;
      await collectPreferenceMatches({
        tabId: opts.tabId,
        searchUrl: opts.searchUrl,
        stealth: opts.stealth,
        prefs: opts.prefs,
        seenKeys: opts.seenKeys,
        scannedKeys: opts.scannedKeys,
        into: batch,
        logPrefix: `${prefix} p${page + 1}`
      });
      await notePageScanned();
      await reportScanSession("running");
      if (batch.length >= SCAN_BATCH_SIZE) break;
      if (batch.length === before) {
        emptyPages += 1;
        await appendCopilotLog(
          `${prefix}: page added 0 new matches (${emptyPages}/${MAX_EMPTY_PAGES} empty)`,
          "warn"
        );
        if (emptyPages >= MAX_EMPTY_PAGES) {
          await appendCopilotLog(
            `${prefix}: stopping after ${MAX_EMPTY_PAGES} empty pages \u2014 ${batch.length}/${SCAN_BATCH_SIZE}`,
            "warn"
          );
          break;
        }
      } else {
        emptyPages = 0;
      }
    }
    const ready = batch.slice(0, SCAN_BATCH_SIZE);
    const scannedTotal = (await getCopilotState()).scanned;
    if (ready.length >= SCAN_BATCH_SIZE) {
      await appendCopilotLog(
        `Matched batch ready \u2014 scanned ${scannedTotal} jobs, matched ${ready.length}/${SCAN_BATCH_SIZE}. Starting applies\u2026`,
        "success"
      );
    } else {
      await appendCopilotLog(
        `Only ${ready.length}/${SCAN_BATCH_SIZE} matched after scanning ${scannedTotal} jobs \u2014 will NOT apply under ${SCAN_BATCH_SIZE}.`,
        "warn"
      );
    }
    return ready;
  }
  async function applyCollectedJobs(opts) {
    const { tabId, jobs, prefs, handlers, searchUrl, stealth } = opts;
    if (jobs.length < SCAN_BATCH_SIZE) {
      await appendCopilotLog(
        `Apply blocked \u2014 need ${SCAN_BATCH_SIZE} matched jobs, have ${jobs.length}`,
        "warn"
      );
      return "waiting";
    }
    await appendCopilotLog(
      `Applying ${jobs.length} matched job(s) one by one (slowdown on)\u2026`,
      "success"
    );
    for (let i = 0; i < jobs.length; i++) {
      const job = jobs[i];
      if (!await waitWhilePaused()) return "stop";
      await appendCopilotLog(
        `Apply ${i + 1}/${jobs.length}: ${job.title}`,
        "info"
      );
      const outcome = await applyOneJob(
        tabId,
        job,
        prefs,
        handlers,
        searchUrl,
        stealth
      );
      if (outcome === "stop") return "stop";
      if (outcome === "limit") return "limit";
    }
    return "ok";
  }
  async function stopBot() {
    lastSession = null;
    setActiveWorkTabId(null);
    await reportScanSession("stopped");
    await setCopilotState({
      running: false,
      paused: false,
      needsLogin: false,
      loginPauseReason: null,
      currentTitle: "",
      sessionBreakUntil: null,
      sessionBreakRemainingMs: null,
      paceLabel: null,
      paceRemainingMs: null,
      sessionComplete: null
    });
    await appendCopilotLog("Co-pilot stopped", "warn");
  }
  async function pauseBot() {
    await setCopilotState({ paused: true });
    await appendCopilotLog("Co-pilot paused", "warn");
  }
  async function resumeBot() {
    const state = await getCopilotState();
    if (state.sessionBreakUntil && Date.parse(state.sessionBreakUntil) > Date.now()) {
      return;
    }
    await setCopilotState({ paused: false });
    if (!state.needsLogin) {
      await clearCopilotAlert();
    }
    await appendCopilotLog(
      state.needsLogin ? "Resumed \u2014 re-checking Naukri login\u2026" : "Co-pilot resumed",
      "success"
    );
  }
  async function runBot(handlers) {
    if (botRunning) {
      return { ok: false, message: "Co-pilot is already running." };
    }
    if (await isBlocked()) {
      await raiseCopilotAlert(
        "Naukri verification cooldown active \u2014 wait before starting a new session.",
        "error",
        "blocked"
      );
      return { ok: false, message: "Blocked cooldown active." };
    }
    botRunning = true;
    try {
      const prefsRes = await fetchPreferences();
      const prefs = prefsRes.success ? prefsRes.data : await getCachedPreferences();
      const keyword = buildSearchKeyword(prefs);
      if (!prefs.titles.length && !prefs.keywords.length) {
        await appendCopilotLog(
          "Add at least 3 job titles and 4 keywords in preferences first",
          "error"
        );
        return { ok: false, message: "Preferences incomplete." };
      }
      if (prefs.titles.length < 3 || prefs.keywords.length < 4) {
        await appendCopilotLog(
          "Preferences need at least 3 job titles and 4 keywords",
          "error"
        );
        return { ok: false, message: "Preferences incomplete." };
      }
      const existing = await getCopilotState();
      await setCopilotState({
        running: true,
        paused: false,
        needsLogin: false,
        loginUserConfirmed: false,
        loginPauseReason: null,
        keyword,
        scanned: 0,
        matched: 0,
        applied: 0,
        skipped: 0,
        pagesScanned: 0,
        appliesThisSession: 0,
        stealthAppliesThisSession: 0,
        stealthStartedAt: existing.runInBackground ? (/* @__PURE__ */ new Date()).toISOString() : null,
        sessionBreakUntil: null,
        sessionBreakRemainingMs: null,
        sessionComplete: null,
        currentTitle: "",
        scannedJobs: [],
        runInBackground: existing.runInBackground
      });
      await beginScanSession();
      const stealth = (await getCopilotState()).runInBackground;
      const mode = paceModeFromStealth(stealth);
      await appendCopilotLog(
        stealth ? "Stealth ON (background tabs) \u2014 higher account risk" : "Assisted mode (foreground)"
      );
      await appendCopilotLog(
        `Co-pilot session started \u2014 searching for "${keyword}"`,
        "success"
      );
      await broadcastCopilotToNaukriTabs({ type: "COPILOT_EXPAND" });
      const searchPlan = buildNaukriSearchQueryPlan(prefs);
      const firstQuery = searchPlan[0];
      let searchUrl = firstQuery.url;
      installTabSpamGuard();
      const tab = await ensureNaukriWorkTab({
        url: searchUrl,
        active: !stealth
      });
      if (!tab.id) {
        await appendCopilotLog("Could not open Naukri tab", "error");
        await setCopilotState({ running: false });
        return { ok: false, message: "No tab." };
      }
      setActiveWorkTabId(tab.id);
      await waitForTabComplete(tab.id);
      if (!await pacedWait(mode, "nav", { jobTitle: "search list" })) {
        return { ok: true, message: "Stopped." };
      }
      if (await checkBlockOnTab(tab.id)) {
        return { ok: false, message: "Naukri block detected." };
      }
      if (!await waitWhilePaused()) {
        return { ok: true, message: "Stopped." };
      }
      if (!await ensureNaukriLoggedIn(tab.id)) {
        return { ok: false, message: "Not logged into Naukri." };
      }
      const seenKeys = /* @__PURE__ */ new Set();
      const scannedKeys = /* @__PURE__ */ new Set();
      let hitLimit = false;
      let batch = [];
      await appendCopilotLog(
        `Will try up to ${searchPlan.length} search combinations (titles \xD7 cities \xD7 skills) until ${SCAN_BATCH_SIZE} matches\u2026`,
        "info"
      );
      for (let qi = 0; qi < searchPlan.length && batch.length < SCAN_BATCH_SIZE; qi++) {
        const query = searchPlan[qi];
        searchUrl = query.url;
        await setCopilotState({ keyword: query.keyword });
        await appendCopilotLog(
          `Search ${qi + 1}/${searchPlan.length} [${query.kind}]: "${query.keyword}"${query.location ? ` in ${query.location}` : " (India-wide)"} (${batch.length}/${SCAN_BATCH_SIZE} so far)`,
          "success"
        );
        if (qi > 0) {
          await chrome.tabs.update(tab.id, { url: searchUrl, active: !stealth });
          await waitForTabComplete(tab.id);
          await wait(1500);
          if (!await ensureNaukriLoggedIn(tab.id)) break;
        }
        if (!await applyNaukriPreferenceFilters(tab.id, prefs, stealth, searchUrl, {
          focusLocation: query.location || null
        })) {
          return { ok: false, message: "Stopped while applying Naukri filters." };
        }
        const before = batch.length;
        batch = await collectUntilMatchedBatch({
          tabId: tab.id,
          searchUrl,
          stealth,
          prefs,
          seenKeys,
          scannedKeys,
          pending: batch,
          logPrefix: `Scan \u201C${query.keyword}\u201D`
        });
        if (batch.length >= SCAN_BATCH_SIZE) break;
        if (batch.length === before) {
          await appendCopilotLog(
            `No new matches for "${query.keyword}"${query.location ? ` / ${query.location}` : ""} \u2014 trying next title/location\u2026`,
            "warn"
          );
        } else {
          await appendCopilotLog(
            `Still ${batch.length}/${SCAN_BATCH_SIZE} \u2014 switching to next title/location\u2026`,
            "info"
          );
        }
      }
      if (batch.length >= SCAN_BATCH_SIZE) {
        const applyOutcome = await applyCollectedJobs({
          tabId: tab.id,
          jobs: batch,
          prefs,
          handlers,
          searchUrl,
          stealth
        });
        if (applyOutcome === "stop" || applyOutcome === "limit") {
          hitLimit = true;
        }
      } else {
        await raiseCopilotToast(
          `Only ${batch.length}/${SCAN_BATCH_SIZE} matches`,
          `Tried ${searchPlan.length} title/location search(es). Apply starts only at ${SCAN_BATCH_SIZE}.`
        );
      }
      const finalState = await getCopilotState();
      const allApplied = batch.length >= SCAN_BATCH_SIZE && finalState.applied >= SCAN_BATCH_SIZE && !hitLimit;
      await appendCopilotLog(
        allApplied ? `All ${SCAN_BATCH_SIZE} matched jobs applied \u2014 scanned ${finalState.scanned}, matched ${finalState.matched}, applied ${finalState.applied}, skipped ${finalState.skipped}` : `Done \u2014 scanned ${finalState.scanned}, matched ${finalState.matched}, applied ${finalState.applied}, skipped ${finalState.skipped}`,
        "success"
      );
      await raiseCopilotToast(
        allApplied || finalState.applied > 0 ? "All jobs matched and applied" : batch.length >= SCAN_BATCH_SIZE ? "Session finished" : `Only ${batch.length}/${SCAN_BATCH_SIZE} matches`,
        allApplied || finalState.applied > 0 ? `Matched and applied ${finalState.applied} job(s). Review them on your Cosmo dashboard.` : batch.length >= SCAN_BATCH_SIZE ? `Matched ${finalState.matched}, no new applies this round.` : `Auto page scan found ${batch.length}/${SCAN_BATCH_SIZE} \u2014 apply not started.`
      );
      if (!hitLimit || finalState.applied > 0 || finalState.matched > 0 || batch.length > 0) {
        lastSession = {
          handlers,
          searchUrl,
          tabId: tab.id,
          stealth,
          prefs,
          seenKeys,
          scannedKeys,
          pendingBatch: batch.length >= SCAN_BATCH_SIZE ? [] : batch
        };
        await setCopilotState({
          running: false,
          paused: false,
          currentTitle: "",
          paceLabel: null,
          paceRemainingMs: null,
          sessionComplete: {
            applied: finalState.applied,
            matched: finalState.matched,
            skipped: finalState.skipped,
            at: (/* @__PURE__ */ new Date()).toISOString(),
            offerNextPage: false,
            allApplied: allApplied || finalState.applied > 0
          }
        });
      } else {
        lastSession = null;
        await setCopilotState({
          running: false,
          paused: false,
          currentTitle: "",
          sessionComplete: null
        });
      }
      await reportScanSession("completed");
      return { ok: true, message: "Co-pilot session finished." };
    } catch (error) {
      logger.warn("Co-pilot failed", {
        error: error instanceof Error ? error.message : String(error)
      });
      await appendCopilotLog(
        `Co-pilot error: ${error instanceof Error ? error.message : String(error)}`,
        "error"
      );
      await reportScanSession("failed");
      await setCopilotState({ running: false, paused: false });
      return { ok: false, message: "Co-pilot failed." };
    } finally {
      const leftover = await getCopilotState();
      if (leftover.sessionId) {
        await reportScanSession("stopped");
      }
      botRunning = false;
    }
  }
  async function closeSessionComplete() {
    lastSession = null;
    await setCopilotState({
      sessionComplete: null,
      running: false,
      paused: false,
      currentTitle: "",
      paceLabel: null,
      paceRemainingMs: null
    });
    await raiseCopilotToast(
      "Visit your dashboard",
      "Review applications in Cosmo \u2014 co-pilot is closed."
    );
    await appendCopilotLog(
      "Session closed \u2014 visit Cosmo dashboard to review applications.",
      "success"
    );
    await broadcastCopilotToNaukriTabs({ type: "COPILOT_COLLAPSE" });
  }
  async function continueNextPage() {
    const ctx = lastSession;
    if (!ctx) {
      return { ok: false, message: "No session to continue." };
    }
    if (botRunning) {
      return { ok: false, message: "Co-pilot is already running." };
    }
    await setCopilotState({ sessionComplete: null, running: true, paused: false });
    botRunning = true;
    try {
      const existingSession = await getCopilotState();
      if (!existingSession.sessionId) {
        await beginScanSession();
      }
      const mode = paceModeFromStealth(ctx.stealth);
      await appendCopilotLog(
        "Taking a short read pause before the next page\u2026",
        "info"
      );
      if (!await pacedWait(mode, "read", { jobTitle: "next page" })) {
        return { ok: true, message: "Stopped." };
      }
      await goBackToList(ctx.tabId, ctx.searchUrl, ctx.stealth);
      if (!await ensureNaukriLoggedIn(ctx.tabId)) {
        return { ok: false, message: "Not logged into Naukri." };
      }
      const next = await goToNextSearchPage(ctx.tabId);
      if (!next.ok) {
        await appendCopilotLog(
          next.reason || "No next page available",
          "warn"
        );
        await raiseCopilotToast(
          "No more pages",
          "Visit your Cosmo dashboard to review applications."
        );
        await setCopilotState({
          running: false,
          sessionComplete: null
        });
        lastSession = null;
        return { ok: false, message: next.reason || "No next page." };
      }
      if (!await pacedWait(mode, "nav", { jobTitle: "next page" })) {
        return { ok: true, message: "Stopped." };
      }
      await appendCopilotLog("Next page loaded \u2014 scanning jobs", "success");
      const seenKeys = ctx.seenKeys;
      const scannedKeys = ctx.scannedKeys ?? /* @__PURE__ */ new Set();
      let hitLimit = false;
      const prefs = ctx.prefs;
      const handlers = ctx.handlers;
      const stealth = ctx.stealth;
      const searchUrl = ctx.searchUrl;
      const tabId = ctx.tabId;
      if (!await applyNaukriPreferenceFilters(tabId, prefs, stealth, searchUrl, {
        forceNavigate: false
      })) {
        return { ok: false, message: "Stopped while applying Naukri filters." };
      }
      const batch = await collectUntilMatchedBatch({
        tabId,
        searchUrl,
        stealth,
        prefs,
        seenKeys,
        scannedKeys,
        pending: ctx.pendingBatch ?? [],
        logPrefix: "Next-page scan"
      });
      if (batch.length >= SCAN_BATCH_SIZE) {
        const applyOutcome = await applyCollectedJobs({
          tabId,
          jobs: batch,
          prefs,
          handlers,
          searchUrl,
          stealth
        });
        if (applyOutcome === "stop" || applyOutcome === "limit") {
          hitLimit = true;
        }
      } else {
        await raiseCopilotToast(
          `Only ${batch.length}/${SCAN_BATCH_SIZE} matches`,
          `Auto-scanned pages \u2014 apply starts only at ${SCAN_BATCH_SIZE}.`
        );
      }
      const finalState = await getCopilotState();
      const allApplied = batch.length >= SCAN_BATCH_SIZE && finalState.applied >= SCAN_BATCH_SIZE && !hitLimit;
      await appendCopilotLog(
        allApplied ? `All ${SCAN_BATCH_SIZE} matched jobs applied \u2014 scanned ${finalState.scanned}, matched ${finalState.matched}, applied ${finalState.applied}, skipped ${finalState.skipped}` : `Done \u2014 scanned ${finalState.scanned}, matched ${finalState.matched}, applied ${finalState.applied}, skipped ${finalState.skipped}`,
        "success"
      );
      await raiseCopilotToast(
        allApplied || finalState.applied > 0 ? "All jobs matched and applied" : `Only ${batch.length}/${SCAN_BATCH_SIZE} matches`,
        allApplied || finalState.applied > 0 ? `Matched and applied ${finalState.applied} job(s). Review them on your Cosmo dashboard.` : `Auto page scan found ${batch.length}/${SCAN_BATCH_SIZE}.`
      );
      lastSession = {
        handlers,
        searchUrl,
        tabId,
        stealth,
        prefs,
        seenKeys,
        scannedKeys,
        pendingBatch: batch.length >= SCAN_BATCH_SIZE ? [] : batch
      };
      await setCopilotState({
        running: false,
        paused: false,
        currentTitle: "",
        paceLabel: null,
        paceRemainingMs: null,
        sessionComplete: {
          applied: finalState.applied,
          matched: finalState.matched,
          skipped: finalState.skipped,
          at: (/* @__PURE__ */ new Date()).toISOString(),
          offerNextPage: false,
          allApplied: allApplied || finalState.applied > 0
        }
      });
      await reportScanSession("completed");
      return { ok: true, message: hitLimit ? "Stopped during apply." : "Continued to next page." };
    } catch (error) {
      logger.warn("Continue next page failed", {
        error: error instanceof Error ? error.message : String(error)
      });
      await reportScanSession("failed");
      await setCopilotState({ running: false });
      return { ok: false, message: "Could not open next page." };
    } finally {
      const leftover = await getCopilotState();
      if (leftover.sessionId) {
        await reportScanSession("stopped");
      }
      botRunning = false;
    }
  }

  // src/core/syncManager.ts
  var APPLY_CAP_CODES = /* @__PURE__ */ new Set([
    "APPLY_HOUR_CAP",
    "APPLY_DAY_CAP",
    "APPLY_PLAN_CAP"
  ]);
  function applyCapKind(code) {
    return code === "APPLY_PLAN_CAP" ? "plan_limit" : "rate_limit";
  }
  var syncing = false;
  async function scheduleRetries(events) {
    for (const event of events) {
      const nextRetry = (event.retryCount ?? 0) + 1;
      await updateRetry(event.eventId, nextRetry);
      chrome.alarms.create(`retry-${event.eventId}`, {
        when: Date.now() + backoffMs(nextRetry)
      });
    }
  }
  async function handleApplyCap(capCode, message, cappedApplyCount) {
    for (let i = 0; i < cappedApplyCount; i++) {
      rollbackLocalApplySuccess();
    }
    await raiseCopilotAlert(message, "warn", applyCapKind(capCode));
    await stopBot();
    logger.warn("Sync blocked by apply safety cap", { code: capCode });
  }
  async function flushQueue() {
    if (syncing) return;
    syncing = true;
    try {
      await eventBus.emit("SyncStarted", {});
      const queue = await getQueue();
      if (queue.length === 0) {
        await eventBus.emit("SyncCompleted", { processed: 0 });
        return;
      }
      const batch = queue.slice(0, 50).map((e) => ({
        ...e,
        syncStatus: "syncing"
      }));
      const result = await syncEvents(batch);
      if (result.success) {
        const synced = result.data?.syncedEventIds ?? batch.map((e) => e.eventId);
        const failedIds = new Set(result.data?.failedEventIds ?? []);
        const failed = batch.filter((e) => failedIds.has(e.eventId));
        const invalid = result.data?.invalidEventIds ?? [];
        await removeFromQueue(synced);
        await scheduleRetries(failed);
        if (invalid.length > 0) {
          logger.error("Server rejected job payloads as invalid", {
            count: invalid.length,
            eventIds: invalid
          });
          await raiseCopilotAlert(
            `${invalid.length} job${invalid.length === 1 ? "" : "s"} could not be saved to your dashboard (invalid data).`,
            "error",
            "error"
          );
        }
        const capError = result.data?.capError;
        if (capError) {
          await handleApplyCap(
            capError.code,
            capError.message,
            failed.filter((e) => e.type === "ApplicationRecorded").length
          );
          await eventBus.emit("SyncFailed", { message: capError.message });
          return;
        }
        await eventBus.emit("SyncCompleted", { processed: synced.length });
        logger.info("Sync completed", {
          processed: synced.length,
          retrying: failed.length
        });
      } else {
        const capCode = result.error?.code;
        if (capCode && APPLY_CAP_CODES.has(capCode)) {
          await handleApplyCap(
            capCode,
            result.message,
            batch.filter((e) => e.type === "ApplicationRecorded").length
          );
          await scheduleRetries(batch);
          await eventBus.emit("SyncFailed", { message: result.message });
          return;
        }
        await scheduleRetries(batch);
        await eventBus.emit("SyncFailed", { message: result.message });
        logger.warn("Sync failed", { message: result.message });
      }
    } catch (error) {
      handleError(error, "flushQueue");
      await eventBus.emit("SyncFailed", {
        message: error instanceof Error ? error.message : "Sync error"
      });
    } finally {
      syncing = false;
    }
  }

  // src/core/healthMonitor.ts
  async function reportHealth() {
    const auth = await getAuthState();
    const queue = await getQueue();
    const apiReachable = await healthCheck();
    const status = {
      apiReachable,
      authenticated: Boolean(auth.accessToken),
      queueDepth: queue.length,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    logger.debug("Health status", status);
    return status;
  }

  // src/core/applyQueue.ts
  function normalizeUrl2(url) {
    try {
      const u = new URL(url);
      return `${u.origin}${u.pathname}`.replace(/\/$/, "");
    } catch {
      return url.split("?")[0]?.replace(/\/$/, "") || url;
    }
  }
  async function waitForTabComplete2(tabId, timeoutMs = 25e3) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      const tab = await chrome.tabs.get(tabId);
      if (tab.status === "complete") return tab;
      await wait(400);
    }
    return chrome.tabs.get(tabId);
  }
  async function sendToTab2(tabId, message, attempts = 10) {
    let lastError;
    for (let i = 0; i < attempts; i++) {
      try {
        return await chrome.tabs.sendMessage(tabId, message);
      } catch (error) {
        lastError = error;
        await wait(500);
      }
    }
    throw lastError instanceof Error ? lastError : new Error("Failed to message content script");
  }
  var processing = false;
  async function enqueueApplyJobs(items) {
    let remaining = 0;
    try {
      remaining = (await getApplyQuotaSnapshot()).monthRemaining;
    } catch (error) {
      logger.warn("Could not load plan apply quota", {
        error: error instanceof Error ? error.message : String(error)
      });
      return 0;
    }
    if (remaining === 0) return 0;
    const queue = await getApplyQueue();
    const existing = new Set(queue.map((q) => q.url));
    const candidates = items.filter((i) => i.url && !existing.has(i.url));
    const lookup = await lookupAppliedJobs({
      externalJobIds: candidates.map((c) => c.externalJobId).filter((id) => Boolean(id)),
      urls: candidates.map((c) => c.url)
    });
    const appliedIds = new Set(
      lookup.success ? lookup.data.externalJobIds : []
    );
    const appliedUrls = new Set(
      lookup.success ? lookup.data.urls.map(normalizeUrl2) : []
    );
    const toAdd = candidates.filter((i) => {
      if (i.externalJobId && appliedIds.has(i.externalJobId)) return false;
      if (appliedUrls.has(normalizeUrl2(i.url))) return false;
      return true;
    }).slice(0, remaining);
    if (toAdd.length === 0) return 0;
    await setApplyQueue([...queue, ...toAdd]);
    return toAdd.length;
  }
  async function processApplyQueue(handlers, tabId) {
    if (processing) {
      return { processed: 0, message: "Apply already running." };
    }
    processing = true;
    try {
      const prefs = await getCachedPreferences();
      if (!prefs.autoApplyEnabled) {
        return { processed: 0, message: "Auto-apply is disabled." };
      }
      let queue = await getApplyQueue();
      if (queue.length === 0) {
        return { processed: 0, message: "Apply queue is empty." };
      }
      let processed = 0;
      let activeTabId = tabId;
      while (queue.length > 0) {
        let quota;
        try {
          quota = await getApplyQuotaSnapshot();
        } catch (error) {
          await appendCopilotLog(
            `Could not verify apply limits: ${error instanceof Error ? error.message : String(error)}`,
            "warn"
          );
          break;
        }
        const blockReason = getApplyQuotaBlock(quota);
        if (blockReason) {
          const msg = quotaBlockMessage(quota, blockReason);
          await raiseCopilotAlert(
            msg,
            "warn",
            blockReason === "month" ? "plan_limit" : "rate_limit"
          );
          await appendCopilotLog(msg, "warn");
          break;
        }
        const item = queue[0];
        queue = queue.slice(1);
        await setApplyQueue(queue);
        try {
          const appliedLookup = await lookupAppliedJobs({
            externalJobIds: item.externalJobId ? [item.externalJobId] : [],
            urls: [item.url]
          });
          if (appliedLookup.success) {
            const already = item.externalJobId && appliedLookup.data.externalJobIds.includes(item.externalJobId) || appliedLookup.data.urls.map(normalizeUrl2).includes(normalizeUrl2(item.url));
            if (already) {
              await appendCopilotLog(
                `Already applied \u2014 skipped: ${item.title}`,
                "info"
              );
              continue;
            }
          }
          if (activeTabId == null) {
            installTabSpamGuard();
            const tab = await ensureNaukriWorkTab({
              url: item.url,
              active: true
            });
            activeTabId = tab.id ?? null;
            if (activeTabId != null) setActiveWorkTabId(activeTabId);
          } else {
            await chrome.tabs.update(activeTabId, { url: item.url, active: true });
            setActiveWorkTabId(activeTabId);
          }
          if (activeTabId == null) continue;
          await waitForTabComplete2(activeTabId);
          const mode = paceModeFromStealth(false);
          await pacedWait(mode, "nav", { jobTitle: item.title });
          await pacedWait(mode, "dwell", { jobTitle: item.title });
          const block = await sendToTab2(
            activeTabId,
            { type: "CHECK_BLOCK_PAGE" },
            3
          );
          if (block.blocked) {
            await handleBlockedPage(block.reason || "verification page");
            await setApplyQueue([item, ...queue]);
            return {
              processed,
              message: "Stopped \u2014 Naukri verification page detected."
            };
          }
          let loggedIn = false;
          for (let attempt = 0; attempt < 5; attempt++) {
            const login2 = await sendToTab2(activeTabId, {
              type: "CHECK_LOGIN"
            });
            if (login2.loggedIn) {
              loggedIn = true;
              await setCopilotState({ needsLogin: false, loginPauseReason: null });
              break;
            }
            const st0 = await getCopilotState();
            if (st0.loginUserConfirmed && login2.status !== "loggedOut") {
              loggedIn = true;
              await setCopilotState({ needsLogin: false, loginPauseReason: null });
              break;
            }
            const reason = login2.status === "loggedOut" ? "loggedOut" : "uncertain";
            await setCopilotState({
              paused: true,
              running: true,
              needsLogin: true,
              loginPauseReason: reason
            });
            await appendCopilotLog(
              reason === "uncertain" ? "Paused \u2014 confirm you\u2019re logged into Naukri, then press Confirm." : "Paused \u2014 you are not logged into Naukri. Log in, then press Confirm.",
              "warn"
            );
            await sendToTab2(activeTabId, {
              type: "SHOW_LOGIN_PROMPT",
              reason
            }).catch(() => void 0);
            const start = Date.now();
            while (Date.now() - start < 12e4) {
              const st = await getCopilotState();
              if (st.loginUserConfirmed) {
                loggedIn = true;
                await setCopilotState({
                  needsLogin: false,
                  loginPauseReason: null,
                  paused: false
                });
                break;
              }
              if (!st.paused) break;
              if (!st.running) {
                await setApplyQueue([item, ...queue]);
                return {
                  processed,
                  message: "Stopped while waiting for Naukri login."
                };
              }
              await wait(500);
            }
            if (loggedIn) break;
            await wait(1e3);
          }
          if (!loggedIn) {
            await setApplyQueue([item, ...queue]);
            return {
              processed,
              message: "Confirm you\u2019re logged into Naukri, then retry apply."
            };
          }
          const result = await sendToTab2(activeTabId, { type: "RUN_EASY_APPLY" });
          if (result.blocked) {
            await handleBlockedPage(result.reason || "verification page");
            await setApplyQueue([item, ...queue]);
            return {
              processed,
              message: "Stopped \u2014 Naukri verification page detected."
            };
          }
          const base = mergeJobFields(result.job, item, {
            url: item.url,
            status: "detected",
            metadata: { source: "auto_apply" }
          });
          if (result.ok) {
            if (result.alreadyApplied) {
              await handlers.persistApplicationRecorded({
                ...base,
                status: "applied",
                appliedAt: (/* @__PURE__ */ new Date()).toISOString(),
                metadata: { source: "auto_apply", alreadyApplied: true }
              });
              await appendCopilotLog(
                `Already applied \u2014 skipped: ${base.title}`,
                "info"
              );
            } else {
              await handlers.persistApplicationRecorded({
                ...base,
                status: "applied",
                appliedAt: (/* @__PURE__ */ new Date()).toISOString(),
                metadata: { source: "auto_apply" }
              });
              noteLocalApply();
              processed += 1;
              await raiseCopilotToast(
                "Job applied successfully",
                base.company ? `${base.title} \xB7 ${base.company}` : base.title
              );
            }
          } else {
            await handlers.persistJobDetected({
              ...base,
              metadata: {
                source: "auto_scan",
                skipped: true,
                skipReason: result.reason || "Easy Apply unavailable"
              }
            });
          }
        } catch (error) {
          logger.warn("Apply item failed", {
            url: item.url,
            error: error instanceof Error ? error.message : String(error)
          });
          await handlers.persistJobDetected(
            mergeJobFields(void 0, item, {
              status: "detected",
              metadata: {
                source: "auto_scan",
                skipped: true,
                skipReason: "Apply failed"
              }
            })
          );
        }
        await pacedWait(paceModeFromStealth(false), "betweenJobs", {
          jobTitle: item.title
        });
        queue = await getApplyQueue();
      }
      return {
        processed,
        message: processed > 0 ? `Applied to ${processed} job(s).` : "No Easy Apply jobs processed."
      };
    } finally {
      processing = false;
    }
  }
  async function getApplyQueueDepth() {
    const queue = await getApplyQueue();
    return queue.length;
  }

  // src/core/scanManager.ts
  function wait2(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
  async function waitForTabComplete3(tabId, timeoutMs = 25e3) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      const tab = await chrome.tabs.get(tabId);
      if (tab.status === "complete") return tab;
      await wait2(400);
    }
    return chrome.tabs.get(tabId);
  }
  async function sendToTab3(tabId, message, attempts = 8) {
    let lastError;
    for (let i = 0; i < attempts; i++) {
      try {
        return await chrome.tabs.sendMessage(tabId, message);
      } catch (error) {
        lastError = error;
        await wait2(500);
      }
    }
    throw lastError instanceof Error ? lastError : new Error("Failed to message content script");
  }
  async function runScan(options) {
    const prefsRes = await fetchPreferences();
    const prefs = prefsRes.success ? prefsRes.data : await getCachedPreferences();
    if (!prefs.titles.length && !prefs.keywords.length) {
      return {
        ok: false,
        message: "Add at least 3 job titles and 4 keywords in preferences first.",
        matched: 0,
        queuedForApply: 0
      };
    }
    if (prefs.titles.length < 3 || prefs.keywords.length < 4) {
      return {
        ok: false,
        message: "Preferences need at least 3 job titles and 4 keywords.",
        matched: 0,
        queuedForApply: 0
      };
    }
    if (!prefs.autoScanEnabled) {
      return {
        ok: false,
        message: "Auto-scan is disabled in preferences.",
        matched: 0,
        queuedForApply: 0
      };
    }
    const searchUrl = buildNaukriSearchUrl(prefs);
    logger.info("Starting Naukri scan", { searchUrl });
    installTabSpamGuard();
    const tab = await ensureNaukriWorkTab({ url: searchUrl, active: true });
    if (!tab.id) {
      return {
        ok: false,
        message: "Could not open Naukri tab.",
        matched: 0,
        queuedForApply: 0
      };
    }
    setActiveWorkTabId(tab.id);
    await waitForTabComplete3(tab.id);
    await wait2(2500);
    const login2 = await sendToTab3(tab.id, {
      type: "CHECK_LOGIN"
    });
    if (!login2.loggedIn) {
      const hint = login2.status === "uncertain" ? "Confirm you\u2019re logged into Naukri in this browser, then Scan again." : "Log into Naukri in this browser, then Scan again.";
      return {
        ok: false,
        message: hint,
        matched: 0,
        queuedForApply: 0,
        loggedIn: false,
        tabId: tab.id
      };
    }
    try {
      const tabInfo = await chrome.tabs.get(tab.id);
      if (!searchUrlHasPreferenceFilters(tabInfo.url || "", prefs)) {
        await chrome.tabs.update(tab.id, { url: searchUrl, active: true });
        await waitForTabComplete3(tab.id);
        await wait2(1500);
      }
      await sendToTab3(tab.id, { type: "APPLY_PREFERENCE_FILTERS", prefs });
      await wait2(1800);
      await waitForTabComplete3(tab.id);
    } catch {
    }
    const scrape = await sendToTab3(tab.id, {
      type: "RUN_SCAN_SCRAPE"
    });
    const matched = (scrape.jobs ?? []).filter(
      (job) => matchesListCandidate(job, prefs)
    );
    for (const job of matched) {
      const payload = mergeJobFields(void 0, job, {
        status: "detected",
        metadata: job.companySiteApply ? { source: "auto_scan", companySiteApply: true } : { source: "auto_scan" }
      });
      await options.persistAndSync(
        "JobDetected",
        payload
      );
    }
    const easyApply = matched.filter((job) => !job.companySiteApply);
    let queuedForApply = 0;
    if (prefs.autoApplyEnabled && easyApply.length > 0) {
      queuedForApply = await enqueueApplyJobs(
        easyApply.map((j) => ({
          url: j.url,
          title: j.title,
          company: j.company,
          externalJobId: j.externalJobId,
          location: j.location,
          companyLogo: j.companyLogo,
          description: j.description,
          experience: j.experienceText,
          salary: j.salaryText,
          skills: j.skills,
          rating: j.rating,
          reviews: j.reviews,
          postedAt: j.postedAt
        }))
      );
    }
    return {
      ok: true,
      message: `Matched ${matched.length} jobs${queuedForApply ? `, queued ${queuedForApply} to apply` : ""}.`,
      matched: matched.length,
      queuedForApply,
      loggedIn: true,
      tabId: tab.id
    };
  }

  // src/background/index.ts
  var pendingNaukriLogin = null;
  function waitMs(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
  async function reverifyAfterLoginTabClosed(naukriTabId) {
    await waitMs(1500);
    let login2 = {};
    try {
      login2 = await chrome.tabs.sendMessage(naukriTabId, { type: "CHECK_LOGIN" });
    } catch {
      try {
        await chrome.tabs.reload(naukriTabId);
        await waitMs(2500);
        login2 = await chrome.tabs.sendMessage(naukriTabId, { type: "CHECK_LOGIN" });
      } catch {
        login2 = {};
      }
    }
    if (login2.loggedIn) {
      await setCopilotState({
        needsLogin: false,
        loginPauseReason: null,
        paused: false
      });
      await clearCopilotAlert();
      try {
        await chrome.tabs.sendMessage(naukriTabId, {
          type: "LOGIN_REVERIFIED",
          loggedIn: true
        });
      } catch {
      }
      return;
    }
    const reason = login2.status === "loggedOut" ? "loggedOut" : "uncertain";
    await setCopilotState({
      paused: true,
      needsLogin: true,
      loginPauseReason: reason
    });
    try {
      await chrome.tabs.sendMessage(naukriTabId, {
        type: "SHOW_LOGIN_PROMPT",
        reason
      });
    } catch {
    }
  }
  chrome.tabs.onRemoved.addListener((tabId) => {
    clearAllowedExtraTab(tabId);
    if (!pendingNaukriLogin || pendingNaukriLogin.loginTabId !== tabId) return;
    const naukriTabId = pendingNaukriLogin.naukriTabId;
    pendingNaukriLogin = null;
    void reverifyAfterLoginTabClosed(naukriTabId);
  });
  installTabSpamGuard();
  async function persistAndSync(type, payload) {
    const event = {
      eventId: v4_default(),
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      type,
      payload,
      retryCount: 0,
      syncStatus: "pending"
    };
    await enqueue(event);
    await flushQueue();
  }
  async function sendExtensionConnected() {
    const auth = await getAuthState();
    if (!auth.accessToken) return;
    await persistAndSync("ExtensionConnected", {
      version: chrome.runtime.getManifest().version,
      connectedAt: (/* @__PURE__ */ new Date()).toISOString()
    });
  }
  var DASHBOARD_TAB_URLS = [
    .../* @__PURE__ */ new Set([
      "http://localhost:5173/*",
      "http://127.0.0.1:5173/*",
      ...injectedWebOrigins().map((origin) => `${origin}/*`)
    ])
  ];
  async function reloadOpenDashboardTabs() {
    try {
      const tabs = await chrome.tabs.query({ url: DASHBOARD_TAB_URLS });
      await Promise.all(
        tabs.map(async (tab) => {
          if (tab.id == null) return;
          try {
            await chrome.tabs.reload(tab.id);
          } catch (error) {
            logger.warn("Failed to reload dashboard tab for auth sync", {
              tabId: tab.id,
              error: error instanceof Error ? error.message : String(error)
            });
          }
        })
      );
    } catch (error) {
      logger.warn("Could not query dashboard tabs for auth sync", {
        error: error instanceof Error ? error.message : String(error)
      });
    }
  }
  chrome.runtime.onInstalled.addListener(() => {
    logger.info("Extension installed");
    chrome.alarms.create("sync-flush", { periodInMinutes: 1 });
    chrome.alarms.create("health-ping", { periodInMinutes: 5 });
    void reloadOpenDashboardTabs().then(() => sendExtensionConnected());
  });
  chrome.runtime.onStartup.addListener(() => {
    void sendExtensionConnected();
  });
  chrome.alarms.onAlarm.addListener(async (alarm) => {
    if (alarm.name === "sync-flush" || alarm.name.startsWith("retry-")) {
      await flushQueue();
      await flushScanSessions();
    }
    if (alarm.name === "health-ping") {
      await reportHealth();
    }
  });
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    (async () => {
      try {
        switch (message?.type) {
          case "JOB_DETECTED": {
            const job = message.payload;
            await persistAndSync(
              "JobDetected",
              job
            );
            sendResponse({ ok: true });
            break;
          }
          case "APPLICATION_RECORDED": {
            const job = message.payload;
            await persistAndSync(
              "ApplicationRecorded",
              job
            );
            sendResponse({ ok: true });
            break;
          }
          case "LOGIN": {
            const result = await login(message.email, message.password);
            if (result.success) {
              await sendExtensionConnected();
              await fetchPreferences();
            }
            sendResponse(result);
            break;
          }
          case "OPEN_GOOGLE_LOGIN": {
            try {
              const auth = await getAuthState();
              const url = googleLoginUrl(auth.apiBaseUrl);
              const existing = await chrome.tabs.query({
                url: DASHBOARD_TAB_URLS
              });
              const preferred = existing.find(
                (tab) => Boolean(tab.url && /\/login(?:\?|$)/.test(tab.url))
              ) ?? existing[0];
              if (preferred?.id != null) {
                await chrome.tabs.update(preferred.id, { url, active: true });
                if (preferred.windowId != null) {
                  await chrome.windows.update(preferred.windowId, {
                    focused: true
                  });
                }
              } else {
                await chrome.tabs.create({ url, active: true });
              }
              sendResponse({ ok: true });
            } catch (error) {
              sendResponse({
                ok: false,
                message: error instanceof Error ? error.message : "Could not open Cosmo login"
              });
            }
            break;
          }
          case "LOGOUT": {
            const auth = await getAuthState();
            if (auth.refreshToken || auth.accessToken) {
              try {
                const headers = {
                  "Content-Type": "application/json"
                };
                if (auth.accessToken) {
                  headers.Authorization = `Bearer ${auth.accessToken}`;
                }
                await fetch(`${auth.apiBaseUrl}/api/v1/auth/logout`, {
                  method: "POST",
                  headers,
                  body: JSON.stringify({
                    refreshToken: auth.refreshToken ?? void 0
                  })
                });
              } catch {
              }
            }
            await clearAuth();
            sendResponse({ ok: true });
            break;
          }
          case "SYNC_AUTH_FROM_WEB": {
            if (message.cleared) {
              await clearAuth();
              sendResponse({ ok: true });
              break;
            }
            const accessToken = typeof message.accessToken === "string" ? message.accessToken : null;
            const refreshToken = typeof message.refreshToken === "string" ? message.refreshToken : null;
            const apiBaseUrl = resolveApiBase(
              typeof message.apiBaseUrl === "string" ? message.apiBaseUrl : "",
              DEFAULT_API
            );
            if (!accessToken || !refreshToken) {
              sendResponse({ ok: false, error: "Missing tokens" });
              break;
            }
            const current = await getAuthState();
            const unchanged = current.accessToken === accessToken && current.refreshToken === refreshToken && current.apiBaseUrl === apiBaseUrl;
            if (!unchanged) {
              await setAuthState({ accessToken, refreshToken, apiBaseUrl });
              await sendExtensionConnected();
              await fetchPreferences();
            }
            sendResponse({ ok: true, synced: !unchanged });
            break;
          }
          case "GET_STATUS": {
            const auth = await getAuthState();
            const health = await reportHealth();
            const remotePrefs = auth.accessToken ? await fetchPreferences() : null;
            const prefs = remotePrefs?.success ? remotePrefs.data : await getCachedPreferences();
            const applyQueueDepth = await getApplyQueueDepth();
            const copilot = await getCopilotState();
            sendResponse({
              auth,
              health: { ...health, applyQueueDepth },
              preferences: prefs,
              copilot
            });
            break;
          }
          case "GET_PREFERENCES": {
            const remote = await fetchPreferences();
            if (remote.success) {
              sendResponse({ success: true, data: remote.data });
            } else {
              sendResponse({
                success: true,
                data: await getCachedPreferences()
              });
            }
            break;
          }
          case "SAVE_PREFERENCES": {
            const prefs = message.preferences;
            const result = await savePreferences(prefs);
            sendResponse(result);
            break;
          }
          case "FLUSH_QUEUE": {
            await flushQueue();
            await flushScanSessions();
            sendResponse({ ok: true });
            break;
          }
          case "START_SCAN": {
            const result = await runScan({
              persistAndSync: async (type, payload) => {
                await persistAndSync(type, payload);
              }
            });
            if (result.queuedForApply > 0) {
              await raiseCopilotAlert(
                `${result.queuedForApply} job(s) ready \u2014 open co-pilot and press Start to apply with consent.`,
                "info",
                "generic"
              );
            }
            sendResponse(result);
            break;
          }
          case "GET_APPLY_QUOTA": {
            try {
              const quota = await getApplyQuotaSnapshot(Boolean(message.force));
              sendResponse({ ok: true, quota });
            } catch (error) {
              sendResponse({
                ok: false,
                message: error instanceof Error ? error.message : "Could not load quota"
              });
            }
            break;
          }
          case "GET_SAFETY_STATUS": {
            const state = await getCopilotState();
            sendResponse({
              ok: true,
              blocked: await isBlocked(),
              stealthCooldown: await isStealthCooldownActive(),
              runInBackground: state.runInBackground
            });
            break;
          }
          case "START_APPLY_QUEUE": {
            const result = await processApplyQueue({
              persistJobDetected: async (payload) => {
                await persistAndSync(
                  "JobDetected",
                  payload
                );
              },
              persistApplicationRecorded: async (payload) => {
                await persistAndSync(
                  "ApplicationRecorded",
                  payload
                );
              }
            });
            sendResponse({ ok: true, ...result });
            break;
          }
          case "COPILOT_START": {
            const auth = await getAuthState();
            if (!auth.accessToken) {
              sendResponse({
                ok: false,
                message: "Sign in to Cosmo from the extension popup first."
              });
              break;
            }
            if (!message.consentAccepted || message.consentVersion !== CONSENT_VERSION) {
              sendResponse({
                ok: false,
                message: "Consent required before starting co-pilot."
              });
              break;
            }
            if (await isBlocked()) {
              sendResponse({
                ok: false,
                message: "Naukri verification cooldown active \u2014 wait before starting again."
              });
              break;
            }
            await clearCopilotLogs();
            await clearCopilotAlert();
            void runBot({
              persistJobDetected: async (payload) => {
                await persistAndSync(
                  "JobDetected",
                  payload
                );
              },
              persistApplicationRecorded: async (payload) => {
                await persistAndSync(
                  "ApplicationRecorded",
                  payload
                );
              }
            }).then(async () => {
            });
            void broadcastCopilotToNaukriTabs({ type: "COPILOT_EXPAND" });
            setTimeout(() => {
              void broadcastCopilotToNaukriTabs({ type: "COPILOT_EXPAND" });
            }, 2500);
            setTimeout(() => {
              void broadcastCopilotToNaukriTabs({ type: "COPILOT_EXPAND" });
            }, 5e3);
            sendResponse({ ok: true });
            break;
          }
          case "COPILOT_DISMISS_ALERT": {
            await clearCopilotAlert();
            sendResponse({ ok: true });
            break;
          }
          case "COPILOT_PAUSE": {
            await pauseBot();
            sendResponse({ ok: true });
            break;
          }
          case "COPILOT_RESUME": {
            await resumeBot();
            sendResponse({ ok: true });
            break;
          }
          case "COPILOT_CONFIRM_LOGIN": {
            await setCopilotState({
              loginUserConfirmed: true,
              needsLogin: false,
              loginPauseReason: null,
              paused: false
            });
            await resumeBot();
            sendResponse({ ok: true });
            break;
          }
          case "COPILOT_STOP": {
            await stopBot();
            sendResponse({ ok: true });
            break;
          }
          case "COPILOT_NEXT_PAGE": {
            const result = await continueNextPage();
            sendResponse(result);
            break;
          }
          case "COPILOT_SESSION_CLOSE": {
            await closeSessionComplete();
            sendResponse({ ok: true });
            break;
          }
          case "COPILOT_SET_BACKGROUND": {
            if (Boolean(message.runInBackground)) {
              if (await isStealthCooldownActive()) {
                sendResponse({
                  ok: false,
                  message: "Stealth cooldown active \u2014 use foreground mode for safer pacing."
                });
                break;
              }
            }
            await setCopilotState({
              runInBackground: Boolean(message.runInBackground),
              stealthStartedAt: Boolean(message.runInBackground) ? (/* @__PURE__ */ new Date()).toISOString() : null,
              stealthAppliesThisSession: 0
            });
            sendResponse({ ok: true });
            break;
          }
          case "OPEN_NAUKRI_LOGIN": {
            const loginUrl = typeof message.loginUrl === "string" && message.loginUrl ? message.loginUrl : "https://www.naukri.com/nlogin/login";
            const naukriTabId = typeof message.naukriTabId === "number" ? message.naukriTabId : sender.tab?.id;
            const created = await chrome.tabs.create({
              url: loginUrl,
              active: true
            });
            if (created.id != null) {
              allowExtraTab(created.id);
            }
            if (created.id != null && naukriTabId != null) {
              pendingNaukriLogin = {
                loginTabId: created.id,
                naukriTabId
              };
            }
            sendResponse({ ok: true, loginTabId: created.id });
            break;
          }
          default:
            sendResponse({ ok: false, error: "Unknown message" });
        }
      } catch (error) {
        sendResponse({ ok: false, error: handleError(error, "onMessage") });
      }
    })();
    return true;
  });
  logger.info("Background service worker ready");
})();
//# sourceMappingURL=background.js.map
