"use strict";
(() => {
  var __defProp = Object.defineProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };

  // ../node_modules/zod/v3/external.js
  var external_exports = {};
  __export(external_exports, {
    BRAND: () => BRAND,
    DIRTY: () => DIRTY,
    EMPTY_PATH: () => EMPTY_PATH,
    INVALID: () => INVALID,
    NEVER: () => NEVER,
    OK: () => OK,
    ParseStatus: () => ParseStatus,
    Schema: () => ZodType,
    ZodAny: () => ZodAny,
    ZodArray: () => ZodArray,
    ZodBigInt: () => ZodBigInt,
    ZodBoolean: () => ZodBoolean,
    ZodBranded: () => ZodBranded,
    ZodCatch: () => ZodCatch,
    ZodDate: () => ZodDate,
    ZodDefault: () => ZodDefault,
    ZodDiscriminatedUnion: () => ZodDiscriminatedUnion,
    ZodEffects: () => ZodEffects,
    ZodEnum: () => ZodEnum,
    ZodError: () => ZodError,
    ZodFirstPartyTypeKind: () => ZodFirstPartyTypeKind,
    ZodFunction: () => ZodFunction,
    ZodIntersection: () => ZodIntersection,
    ZodIssueCode: () => ZodIssueCode,
    ZodLazy: () => ZodLazy,
    ZodLiteral: () => ZodLiteral,
    ZodMap: () => ZodMap,
    ZodNaN: () => ZodNaN,
    ZodNativeEnum: () => ZodNativeEnum,
    ZodNever: () => ZodNever,
    ZodNull: () => ZodNull,
    ZodNullable: () => ZodNullable,
    ZodNumber: () => ZodNumber,
    ZodObject: () => ZodObject,
    ZodOptional: () => ZodOptional,
    ZodParsedType: () => ZodParsedType,
    ZodPipeline: () => ZodPipeline,
    ZodPromise: () => ZodPromise,
    ZodReadonly: () => ZodReadonly,
    ZodRecord: () => ZodRecord,
    ZodSchema: () => ZodType,
    ZodSet: () => ZodSet,
    ZodString: () => ZodString,
    ZodSymbol: () => ZodSymbol,
    ZodTransformer: () => ZodEffects,
    ZodTuple: () => ZodTuple,
    ZodType: () => ZodType,
    ZodUndefined: () => ZodUndefined,
    ZodUnion: () => ZodUnion,
    ZodUnknown: () => ZodUnknown,
    ZodVoid: () => ZodVoid,
    addIssueToContext: () => addIssueToContext,
    any: () => anyType,
    array: () => arrayType,
    bigint: () => bigIntType,
    boolean: () => booleanType,
    coerce: () => coerce,
    custom: () => custom,
    date: () => dateType,
    datetimeRegex: () => datetimeRegex,
    defaultErrorMap: () => en_default,
    discriminatedUnion: () => discriminatedUnionType,
    effect: () => effectsType,
    enum: () => enumType,
    function: () => functionType,
    getErrorMap: () => getErrorMap,
    getParsedType: () => getParsedType,
    instanceof: () => instanceOfType,
    intersection: () => intersectionType,
    isAborted: () => isAborted,
    isAsync: () => isAsync,
    isDirty: () => isDirty,
    isValid: () => isValid,
    late: () => late,
    lazy: () => lazyType,
    literal: () => literalType,
    makeIssue: () => makeIssue,
    map: () => mapType,
    nan: () => nanType,
    nativeEnum: () => nativeEnumType,
    never: () => neverType,
    null: () => nullType,
    nullable: () => nullableType,
    number: () => numberType,
    object: () => objectType,
    objectUtil: () => objectUtil,
    oboolean: () => oboolean,
    onumber: () => onumber,
    optional: () => optionalType,
    ostring: () => ostring,
    pipeline: () => pipelineType,
    preprocess: () => preprocessType,
    promise: () => promiseType,
    quotelessJson: () => quotelessJson,
    record: () => recordType,
    set: () => setType,
    setErrorMap: () => setErrorMap,
    strictObject: () => strictObjectType,
    string: () => stringType,
    symbol: () => symbolType,
    transformer: () => effectsType,
    tuple: () => tupleType,
    undefined: () => undefinedType,
    union: () => unionType,
    unknown: () => unknownType,
    util: () => util,
    void: () => voidType
  });

  // ../node_modules/zod/v3/helpers/util.js
  var util;
  (function(util2) {
    util2.assertEqual = (_) => {
    };
    function assertIs(_arg) {
    }
    util2.assertIs = assertIs;
    function assertNever(_x) {
      throw new Error();
    }
    util2.assertNever = assertNever;
    util2.arrayToEnum = (items) => {
      const obj = {};
      for (const item of items) {
        obj[item] = item;
      }
      return obj;
    };
    util2.getValidEnumValues = (obj) => {
      const validKeys = util2.objectKeys(obj).filter((k) => typeof obj[obj[k]] !== "number");
      const filtered = {};
      for (const k of validKeys) {
        filtered[k] = obj[k];
      }
      return util2.objectValues(filtered);
    };
    util2.objectValues = (obj) => {
      return util2.objectKeys(obj).map(function(e) {
        return obj[e];
      });
    };
    util2.objectKeys = typeof Object.keys === "function" ? (obj) => Object.keys(obj) : (object) => {
      const keys = [];
      for (const key in object) {
        if (Object.prototype.hasOwnProperty.call(object, key)) {
          keys.push(key);
        }
      }
      return keys;
    };
    util2.find = (arr, checker) => {
      for (const item of arr) {
        if (checker(item))
          return item;
      }
      return void 0;
    };
    util2.isInteger = typeof Number.isInteger === "function" ? (val) => Number.isInteger(val) : (val) => typeof val === "number" && Number.isFinite(val) && Math.floor(val) === val;
    function joinValues(array, separator = " | ") {
      return array.map((val) => typeof val === "string" ? `'${val}'` : val).join(separator);
    }
    util2.joinValues = joinValues;
    util2.jsonStringifyReplacer = (_, value) => {
      if (typeof value === "bigint") {
        return value.toString();
      }
      return value;
    };
  })(util || (util = {}));
  var objectUtil;
  (function(objectUtil2) {
    objectUtil2.mergeShapes = (first, second) => {
      return {
        ...first,
        ...second
        // second overwrites first
      };
    };
  })(objectUtil || (objectUtil = {}));
  var ZodParsedType = util.arrayToEnum([
    "string",
    "nan",
    "number",
    "integer",
    "float",
    "boolean",
    "date",
    "bigint",
    "symbol",
    "function",
    "undefined",
    "null",
    "array",
    "object",
    "unknown",
    "promise",
    "void",
    "never",
    "map",
    "set"
  ]);
  var getParsedType = (data) => {
    const t = typeof data;
    switch (t) {
      case "undefined":
        return ZodParsedType.undefined;
      case "string":
        return ZodParsedType.string;
      case "number":
        return Number.isNaN(data) ? ZodParsedType.nan : ZodParsedType.number;
      case "boolean":
        return ZodParsedType.boolean;
      case "function":
        return ZodParsedType.function;
      case "bigint":
        return ZodParsedType.bigint;
      case "symbol":
        return ZodParsedType.symbol;
      case "object":
        if (Array.isArray(data)) {
          return ZodParsedType.array;
        }
        if (data === null) {
          return ZodParsedType.null;
        }
        if (data.then && typeof data.then === "function" && data.catch && typeof data.catch === "function") {
          return ZodParsedType.promise;
        }
        if (typeof Map !== "undefined" && data instanceof Map) {
          return ZodParsedType.map;
        }
        if (typeof Set !== "undefined" && data instanceof Set) {
          return ZodParsedType.set;
        }
        if (typeof Date !== "undefined" && data instanceof Date) {
          return ZodParsedType.date;
        }
        return ZodParsedType.object;
      default:
        return ZodParsedType.unknown;
    }
  };

  // ../node_modules/zod/v3/ZodError.js
  var ZodIssueCode = util.arrayToEnum([
    "invalid_type",
    "invalid_literal",
    "custom",
    "invalid_union",
    "invalid_union_discriminator",
    "invalid_enum_value",
    "unrecognized_keys",
    "invalid_arguments",
    "invalid_return_type",
    "invalid_date",
    "invalid_string",
    "too_small",
    "too_big",
    "invalid_intersection_types",
    "not_multiple_of",
    "not_finite"
  ]);
  var quotelessJson = (obj) => {
    const json = JSON.stringify(obj, null, 2);
    return json.replace(/"([^"]+)":/g, "$1:");
  };
  var ZodError = class _ZodError extends Error {
    get errors() {
      return this.issues;
    }
    constructor(issues) {
      super();
      this.issues = [];
      this.addIssue = (sub) => {
        this.issues = [...this.issues, sub];
      };
      this.addIssues = (subs = []) => {
        this.issues = [...this.issues, ...subs];
      };
      const actualProto = new.target.prototype;
      if (Object.setPrototypeOf) {
        Object.setPrototypeOf(this, actualProto);
      } else {
        this.__proto__ = actualProto;
      }
      this.name = "ZodError";
      this.issues = issues;
    }
    format(_mapper) {
      const mapper = _mapper || function(issue) {
        return issue.message;
      };
      const fieldErrors = { _errors: [] };
      const processError = (error) => {
        for (const issue of error.issues) {
          if (issue.code === "invalid_union") {
            issue.unionErrors.map(processError);
          } else if (issue.code === "invalid_return_type") {
            processError(issue.returnTypeError);
          } else if (issue.code === "invalid_arguments") {
            processError(issue.argumentsError);
          } else if (issue.path.length === 0) {
            fieldErrors._errors.push(mapper(issue));
          } else {
            let curr = fieldErrors;
            let i = 0;
            while (i < issue.path.length) {
              const el = issue.path[i];
              const terminal = i === issue.path.length - 1;
              if (!terminal) {
                curr[el] = curr[el] || { _errors: [] };
              } else {
                curr[el] = curr[el] || { _errors: [] };
                curr[el]._errors.push(mapper(issue));
              }
              curr = curr[el];
              i++;
            }
          }
        }
      };
      processError(this);
      return fieldErrors;
    }
    static assert(value) {
      if (!(value instanceof _ZodError)) {
        throw new Error(`Not a ZodError: ${value}`);
      }
    }
    toString() {
      return this.message;
    }
    get message() {
      return JSON.stringify(this.issues, util.jsonStringifyReplacer, 2);
    }
    get isEmpty() {
      return this.issues.length === 0;
    }
    flatten(mapper = (issue) => issue.message) {
      const fieldErrors = {};
      const formErrors = [];
      for (const sub of this.issues) {
        if (sub.path.length > 0) {
          const firstEl = sub.path[0];
          fieldErrors[firstEl] = fieldErrors[firstEl] || [];
          fieldErrors[firstEl].push(mapper(sub));
        } else {
          formErrors.push(mapper(sub));
        }
      }
      return { formErrors, fieldErrors };
    }
    get formErrors() {
      return this.flatten();
    }
  };
  ZodError.create = (issues) => {
    const error = new ZodError(issues);
    return error;
  };

  // ../node_modules/zod/v3/locales/en.js
  var errorMap = (issue, _ctx) => {
    let message;
    switch (issue.code) {
      case ZodIssueCode.invalid_type:
        if (issue.received === ZodParsedType.undefined) {
          message = "Required";
        } else {
          message = `Expected ${issue.expected}, received ${issue.received}`;
        }
        break;
      case ZodIssueCode.invalid_literal:
        message = `Invalid literal value, expected ${JSON.stringify(issue.expected, util.jsonStringifyReplacer)}`;
        break;
      case ZodIssueCode.unrecognized_keys:
        message = `Unrecognized key(s) in object: ${util.joinValues(issue.keys, ", ")}`;
        break;
      case ZodIssueCode.invalid_union:
        message = `Invalid input`;
        break;
      case ZodIssueCode.invalid_union_discriminator:
        message = `Invalid discriminator value. Expected ${util.joinValues(issue.options)}`;
        break;
      case ZodIssueCode.invalid_enum_value:
        message = `Invalid enum value. Expected ${util.joinValues(issue.options)}, received '${issue.received}'`;
        break;
      case ZodIssueCode.invalid_arguments:
        message = `Invalid function arguments`;
        break;
      case ZodIssueCode.invalid_return_type:
        message = `Invalid function return type`;
        break;
      case ZodIssueCode.invalid_date:
        message = `Invalid date`;
        break;
      case ZodIssueCode.invalid_string:
        if (typeof issue.validation === "object") {
          if ("includes" in issue.validation) {
            message = `Invalid input: must include "${issue.validation.includes}"`;
            if (typeof issue.validation.position === "number") {
              message = `${message} at one or more positions greater than or equal to ${issue.validation.position}`;
            }
          } else if ("startsWith" in issue.validation) {
            message = `Invalid input: must start with "${issue.validation.startsWith}"`;
          } else if ("endsWith" in issue.validation) {
            message = `Invalid input: must end with "${issue.validation.endsWith}"`;
          } else {
            util.assertNever(issue.validation);
          }
        } else if (issue.validation !== "regex") {
          message = `Invalid ${issue.validation}`;
        } else {
          message = "Invalid";
        }
        break;
      case ZodIssueCode.too_small:
        if (issue.type === "array")
          message = `Array must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `more than`} ${issue.minimum} element(s)`;
        else if (issue.type === "string")
          message = `String must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `over`} ${issue.minimum} character(s)`;
        else if (issue.type === "number")
          message = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
        else if (issue.type === "bigint")
          message = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
        else if (issue.type === "date")
          message = `Date must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${new Date(Number(issue.minimum))}`;
        else
          message = "Invalid input";
        break;
      case ZodIssueCode.too_big:
        if (issue.type === "array")
          message = `Array must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `less than`} ${issue.maximum} element(s)`;
        else if (issue.type === "string")
          message = `String must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `under`} ${issue.maximum} character(s)`;
        else if (issue.type === "number")
          message = `Number must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
        else if (issue.type === "bigint")
          message = `BigInt must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
        else if (issue.type === "date")
          message = `Date must be ${issue.exact ? `exactly` : issue.inclusive ? `smaller than or equal to` : `smaller than`} ${new Date(Number(issue.maximum))}`;
        else
          message = "Invalid input";
        break;
      case ZodIssueCode.custom:
        message = `Invalid input`;
        break;
      case ZodIssueCode.invalid_intersection_types:
        message = `Intersection results could not be merged`;
        break;
      case ZodIssueCode.not_multiple_of:
        message = `Number must be a multiple of ${issue.multipleOf}`;
        break;
      case ZodIssueCode.not_finite:
        message = "Number must be finite";
        break;
      default:
        message = _ctx.defaultError;
        util.assertNever(issue);
    }
    return { message };
  };
  var en_default = errorMap;

  // ../node_modules/zod/v3/errors.js
  var overrideErrorMap = en_default;
  function setErrorMap(map) {
    overrideErrorMap = map;
  }
  function getErrorMap() {
    return overrideErrorMap;
  }

  // ../node_modules/zod/v3/helpers/parseUtil.js
  var makeIssue = (params) => {
    const { data, path, errorMaps, issueData } = params;
    const fullPath = [...path, ...issueData.path || []];
    const fullIssue = {
      ...issueData,
      path: fullPath
    };
    if (issueData.message !== void 0) {
      return {
        ...issueData,
        path: fullPath,
        message: issueData.message
      };
    }
    let errorMessage = "";
    const maps = errorMaps.filter((m) => !!m).slice().reverse();
    for (const map of maps) {
      errorMessage = map(fullIssue, { data, defaultError: errorMessage }).message;
    }
    return {
      ...issueData,
      path: fullPath,
      message: errorMessage
    };
  };
  var EMPTY_PATH = [];
  function addIssueToContext(ctx, issueData) {
    const overrideMap = getErrorMap();
    const issue = makeIssue({
      issueData,
      data: ctx.data,
      path: ctx.path,
      errorMaps: [
        ctx.common.contextualErrorMap,
        // contextual error map is first priority
        ctx.schemaErrorMap,
        // then schema-bound map if available
        overrideMap,
        // then global override map
        overrideMap === en_default ? void 0 : en_default
        // then global default map
      ].filter((x) => !!x)
    });
    ctx.common.issues.push(issue);
  }
  var ParseStatus = class _ParseStatus {
    constructor() {
      this.value = "valid";
    }
    dirty() {
      if (this.value === "valid")
        this.value = "dirty";
    }
    abort() {
      if (this.value !== "aborted")
        this.value = "aborted";
    }
    static mergeArray(status, results) {
      const arrayValue = [];
      for (const s of results) {
        if (s.status === "aborted")
          return INVALID;
        if (s.status === "dirty")
          status.dirty();
        arrayValue.push(s.value);
      }
      return { status: status.value, value: arrayValue };
    }
    static async mergeObjectAsync(status, pairs) {
      const syncPairs = [];
      for (const pair of pairs) {
        const key = await pair.key;
        const value = await pair.value;
        syncPairs.push({
          key,
          value
        });
      }
      return _ParseStatus.mergeObjectSync(status, syncPairs);
    }
    static mergeObjectSync(status, pairs) {
      const finalObject = {};
      for (const pair of pairs) {
        const { key, value } = pair;
        if (key.status === "aborted")
          return INVALID;
        if (value.status === "aborted")
          return INVALID;
        if (key.status === "dirty")
          status.dirty();
        if (value.status === "dirty")
          status.dirty();
        if (key.value !== "__proto__" && (typeof value.value !== "undefined" || pair.alwaysSet)) {
          finalObject[key.value] = value.value;
        }
      }
      return { status: status.value, value: finalObject };
    }
  };
  var INVALID = Object.freeze({
    status: "aborted"
  });
  var DIRTY = (value) => ({ status: "dirty", value });
  var OK = (value) => ({ status: "valid", value });
  var isAborted = (x) => x.status === "aborted";
  var isDirty = (x) => x.status === "dirty";
  var isValid = (x) => x.status === "valid";
  var isAsync = (x) => typeof Promise !== "undefined" && x instanceof Promise;

  // ../node_modules/zod/v3/helpers/errorUtil.js
  var errorUtil;
  (function(errorUtil2) {
    errorUtil2.errToObj = (message) => typeof message === "string" ? { message } : message || {};
    errorUtil2.toString = (message) => typeof message === "string" ? message : message?.message;
  })(errorUtil || (errorUtil = {}));

  // ../node_modules/zod/v3/types.js
  var ParseInputLazyPath = class {
    constructor(parent, value, path, key) {
      this._cachedPath = [];
      this.parent = parent;
      this.data = value;
      this._path = path;
      this._key = key;
    }
    get path() {
      if (!this._cachedPath.length) {
        if (Array.isArray(this._key)) {
          this._cachedPath.push(...this._path, ...this._key);
        } else {
          this._cachedPath.push(...this._path, this._key);
        }
      }
      return this._cachedPath;
    }
  };
  var handleResult = (ctx, result) => {
    if (isValid(result)) {
      return { success: true, data: result.value };
    } else {
      if (!ctx.common.issues.length) {
        throw new Error("Validation failed but no issues detected.");
      }
      return {
        success: false,
        get error() {
          if (this._error)
            return this._error;
          const error = new ZodError(ctx.common.issues);
          this._error = error;
          return this._error;
        }
      };
    }
  };
  function processCreateParams(params) {
    if (!params)
      return {};
    const { errorMap: errorMap2, invalid_type_error, required_error, description } = params;
    if (errorMap2 && (invalid_type_error || required_error)) {
      throw new Error(`Can't use "invalid_type_error" or "required_error" in conjunction with custom error map.`);
    }
    if (errorMap2)
      return { errorMap: errorMap2, description };
    const customMap = (iss, ctx) => {
      const { message } = params;
      if (iss.code === "invalid_enum_value") {
        return { message: message ?? ctx.defaultError };
      }
      if (typeof ctx.data === "undefined") {
        return { message: message ?? required_error ?? ctx.defaultError };
      }
      if (iss.code !== "invalid_type")
        return { message: ctx.defaultError };
      return { message: message ?? invalid_type_error ?? ctx.defaultError };
    };
    return { errorMap: customMap, description };
  }
  var ZodType = class {
    get description() {
      return this._def.description;
    }
    _getType(input) {
      return getParsedType(input.data);
    }
    _getOrReturnCtx(input, ctx) {
      return ctx || {
        common: input.parent.common,
        data: input.data,
        parsedType: getParsedType(input.data),
        schemaErrorMap: this._def.errorMap,
        path: input.path,
        parent: input.parent
      };
    }
    _processInputParams(input) {
      return {
        status: new ParseStatus(),
        ctx: {
          common: input.parent.common,
          data: input.data,
          parsedType: getParsedType(input.data),
          schemaErrorMap: this._def.errorMap,
          path: input.path,
          parent: input.parent
        }
      };
    }
    _parseSync(input) {
      const result = this._parse(input);
      if (isAsync(result)) {
        throw new Error("Synchronous parse encountered promise.");
      }
      return result;
    }
    _parseAsync(input) {
      const result = this._parse(input);
      return Promise.resolve(result);
    }
    parse(data, params) {
      const result = this.safeParse(data, params);
      if (result.success)
        return result.data;
      throw result.error;
    }
    safeParse(data, params) {
      const ctx = {
        common: {
          issues: [],
          async: params?.async ?? false,
          contextualErrorMap: params?.errorMap
        },
        path: params?.path || [],
        schemaErrorMap: this._def.errorMap,
        parent: null,
        data,
        parsedType: getParsedType(data)
      };
      const result = this._parseSync({ data, path: ctx.path, parent: ctx });
      return handleResult(ctx, result);
    }
    "~validate"(data) {
      const ctx = {
        common: {
          issues: [],
          async: !!this["~standard"].async
        },
        path: [],
        schemaErrorMap: this._def.errorMap,
        parent: null,
        data,
        parsedType: getParsedType(data)
      };
      if (!this["~standard"].async) {
        try {
          const result = this._parseSync({ data, path: [], parent: ctx });
          return isValid(result) ? {
            value: result.value
          } : {
            issues: ctx.common.issues
          };
        } catch (err) {
          if (err?.message?.toLowerCase()?.includes("encountered")) {
            this["~standard"].async = true;
          }
          ctx.common = {
            issues: [],
            async: true
          };
        }
      }
      return this._parseAsync({ data, path: [], parent: ctx }).then((result) => isValid(result) ? {
        value: result.value
      } : {
        issues: ctx.common.issues
      });
    }
    async parseAsync(data, params) {
      const result = await this.safeParseAsync(data, params);
      if (result.success)
        return result.data;
      throw result.error;
    }
    async safeParseAsync(data, params) {
      const ctx = {
        common: {
          issues: [],
          contextualErrorMap: params?.errorMap,
          async: true
        },
        path: params?.path || [],
        schemaErrorMap: this._def.errorMap,
        parent: null,
        data,
        parsedType: getParsedType(data)
      };
      const maybeAsyncResult = this._parse({ data, path: ctx.path, parent: ctx });
      const result = await (isAsync(maybeAsyncResult) ? maybeAsyncResult : Promise.resolve(maybeAsyncResult));
      return handleResult(ctx, result);
    }
    refine(check, message) {
      const getIssueProperties = (val) => {
        if (typeof message === "string" || typeof message === "undefined") {
          return { message };
        } else if (typeof message === "function") {
          return message(val);
        } else {
          return message;
        }
      };
      return this._refinement((val, ctx) => {
        const result = check(val);
        const setError = () => ctx.addIssue({
          code: ZodIssueCode.custom,
          ...getIssueProperties(val)
        });
        if (typeof Promise !== "undefined" && result instanceof Promise) {
          return result.then((data) => {
            if (!data) {
              setError();
              return false;
            } else {
              return true;
            }
          });
        }
        if (!result) {
          setError();
          return false;
        } else {
          return true;
        }
      });
    }
    refinement(check, refinementData) {
      return this._refinement((val, ctx) => {
        if (!check(val)) {
          ctx.addIssue(typeof refinementData === "function" ? refinementData(val, ctx) : refinementData);
          return false;
        } else {
          return true;
        }
      });
    }
    _refinement(refinement) {
      return new ZodEffects({
        schema: this,
        typeName: ZodFirstPartyTypeKind.ZodEffects,
        effect: { type: "refinement", refinement }
      });
    }
    superRefine(refinement) {
      return this._refinement(refinement);
    }
    constructor(def) {
      this.spa = this.safeParseAsync;
      this._def = def;
      this.parse = this.parse.bind(this);
      this.safeParse = this.safeParse.bind(this);
      this.parseAsync = this.parseAsync.bind(this);
      this.safeParseAsync = this.safeParseAsync.bind(this);
      this.spa = this.spa.bind(this);
      this.refine = this.refine.bind(this);
      this.refinement = this.refinement.bind(this);
      this.superRefine = this.superRefine.bind(this);
      this.optional = this.optional.bind(this);
      this.nullable = this.nullable.bind(this);
      this.nullish = this.nullish.bind(this);
      this.array = this.array.bind(this);
      this.promise = this.promise.bind(this);
      this.or = this.or.bind(this);
      this.and = this.and.bind(this);
      this.transform = this.transform.bind(this);
      this.brand = this.brand.bind(this);
      this.default = this.default.bind(this);
      this.catch = this.catch.bind(this);
      this.describe = this.describe.bind(this);
      this.pipe = this.pipe.bind(this);
      this.readonly = this.readonly.bind(this);
      this.isNullable = this.isNullable.bind(this);
      this.isOptional = this.isOptional.bind(this);
      this["~standard"] = {
        version: 1,
        vendor: "zod",
        validate: (data) => this["~validate"](data)
      };
    }
    optional() {
      return ZodOptional.create(this, this._def);
    }
    nullable() {
      return ZodNullable.create(this, this._def);
    }
    nullish() {
      return this.nullable().optional();
    }
    array() {
      return ZodArray.create(this);
    }
    promise() {
      return ZodPromise.create(this, this._def);
    }
    or(option) {
      return ZodUnion.create([this, option], this._def);
    }
    and(incoming) {
      return ZodIntersection.create(this, incoming, this._def);
    }
    transform(transform) {
      return new ZodEffects({
        ...processCreateParams(this._def),
        schema: this,
        typeName: ZodFirstPartyTypeKind.ZodEffects,
        effect: { type: "transform", transform }
      });
    }
    default(def) {
      const defaultValueFunc = typeof def === "function" ? def : () => def;
      return new ZodDefault({
        ...processCreateParams(this._def),
        innerType: this,
        defaultValue: defaultValueFunc,
        typeName: ZodFirstPartyTypeKind.ZodDefault
      });
    }
    brand() {
      return new ZodBranded({
        typeName: ZodFirstPartyTypeKind.ZodBranded,
        type: this,
        ...processCreateParams(this._def)
      });
    }
    catch(def) {
      const catchValueFunc = typeof def === "function" ? def : () => def;
      return new ZodCatch({
        ...processCreateParams(this._def),
        innerType: this,
        catchValue: catchValueFunc,
        typeName: ZodFirstPartyTypeKind.ZodCatch
      });
    }
    describe(description) {
      const This = this.constructor;
      return new This({
        ...this._def,
        description
      });
    }
    pipe(target) {
      return ZodPipeline.create(this, target);
    }
    readonly() {
      return ZodReadonly.create(this);
    }
    isOptional() {
      return this.safeParse(void 0).success;
    }
    isNullable() {
      return this.safeParse(null).success;
    }
  };
  var cuidRegex = /^c[^\s-]{8,}$/i;
  var cuid2Regex = /^[0-9a-z]+$/;
  var ulidRegex = /^[0-9A-HJKMNP-TV-Z]{26}$/i;
  var uuidRegex = /^[0-9a-fA-F]{8}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{12}$/i;
  var nanoidRegex = /^[a-z0-9_-]{21}$/i;
  var jwtRegex = /^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]*$/;
  var durationRegex = /^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/;
  var emailRegex = /^(?!\.)(?!.*\.\.)([A-Z0-9_'+\-\.]*)[A-Z0-9_+-]@([A-Z0-9][A-Z0-9\-]*\.)+[A-Z]{2,}$/i;
  var _emojiRegex = `^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$`;
  var emojiRegex;
  var ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/;
  var ipv4CidrRegex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/(3[0-2]|[12]?[0-9])$/;
  var ipv6Regex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))$/;
  var ipv6CidrRegex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/;
  var base64Regex = /^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/;
  var base64urlRegex = /^([0-9a-zA-Z-_]{4})*(([0-9a-zA-Z-_]{2}(==)?)|([0-9a-zA-Z-_]{3}(=)?))?$/;
  var dateRegexSource = `((\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-((0[13578]|1[02])-(0[1-9]|[12]\\d|3[01])|(0[469]|11)-(0[1-9]|[12]\\d|30)|(02)-(0[1-9]|1\\d|2[0-8])))`;
  var dateRegex = new RegExp(`^${dateRegexSource}$`);
  function timeRegexSource(args) {
    let secondsRegexSource = `[0-5]\\d`;
    if (args.precision) {
      secondsRegexSource = `${secondsRegexSource}\\.\\d{${args.precision}}`;
    } else if (args.precision == null) {
      secondsRegexSource = `${secondsRegexSource}(\\.\\d+)?`;
    }
    const secondsQuantifier = args.precision ? "+" : "?";
    return `([01]\\d|2[0-3]):[0-5]\\d(:${secondsRegexSource})${secondsQuantifier}`;
  }
  function timeRegex(args) {
    return new RegExp(`^${timeRegexSource(args)}$`);
  }
  function datetimeRegex(args) {
    let regex = `${dateRegexSource}T${timeRegexSource(args)}`;
    const opts = [];
    opts.push(args.local ? `Z?` : `Z`);
    if (args.offset)
      opts.push(`([+-]\\d{2}:?\\d{2})`);
    regex = `${regex}(${opts.join("|")})`;
    return new RegExp(`^${regex}$`);
  }
  function isValidIP(ip, version) {
    if ((version === "v4" || !version) && ipv4Regex.test(ip)) {
      return true;
    }
    if ((version === "v6" || !version) && ipv6Regex.test(ip)) {
      return true;
    }
    return false;
  }
  function isValidJWT(jwt, alg) {
    if (!jwtRegex.test(jwt))
      return false;
    try {
      const [header] = jwt.split(".");
      if (!header)
        return false;
      const base64 = header.replace(/-/g, "+").replace(/_/g, "/").padEnd(header.length + (4 - header.length % 4) % 4, "=");
      const decoded = JSON.parse(atob(base64));
      if (typeof decoded !== "object" || decoded === null)
        return false;
      if ("typ" in decoded && decoded?.typ !== "JWT")
        return false;
      if (!decoded.alg)
        return false;
      if (alg && decoded.alg !== alg)
        return false;
      return true;
    } catch {
      return false;
    }
  }
  function isValidCidr(ip, version) {
    if ((version === "v4" || !version) && ipv4CidrRegex.test(ip)) {
      return true;
    }
    if ((version === "v6" || !version) && ipv6CidrRegex.test(ip)) {
      return true;
    }
    return false;
  }
  var ZodString = class _ZodString extends ZodType {
    _parse(input) {
      if (this._def.coerce) {
        input.data = String(input.data);
      }
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.string) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.string,
          received: ctx2.parsedType
        });
        return INVALID;
      }
      const status = new ParseStatus();
      let ctx = void 0;
      for (const check of this._def.checks) {
        if (check.kind === "min") {
          if (input.data.length < check.value) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              minimum: check.value,
              type: "string",
              inclusive: true,
              exact: false,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "max") {
          if (input.data.length > check.value) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              maximum: check.value,
              type: "string",
              inclusive: true,
              exact: false,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "length") {
          const tooBig = input.data.length > check.value;
          const tooSmall = input.data.length < check.value;
          if (tooBig || tooSmall) {
            ctx = this._getOrReturnCtx(input, ctx);
            if (tooBig) {
              addIssueToContext(ctx, {
                code: ZodIssueCode.too_big,
                maximum: check.value,
                type: "string",
                inclusive: true,
                exact: true,
                message: check.message
              });
            } else if (tooSmall) {
              addIssueToContext(ctx, {
                code: ZodIssueCode.too_small,
                minimum: check.value,
                type: "string",
                inclusive: true,
                exact: true,
                message: check.message
              });
            }
            status.dirty();
          }
        } else if (check.kind === "email") {
          if (!emailRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "email",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "emoji") {
          if (!emojiRegex) {
            emojiRegex = new RegExp(_emojiRegex, "u");
          }
          if (!emojiRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "emoji",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "uuid") {
          if (!uuidRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "uuid",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "nanoid") {
          if (!nanoidRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "nanoid",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "cuid") {
          if (!cuidRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "cuid",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "cuid2") {
          if (!cuid2Regex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "cuid2",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "ulid") {
          if (!ulidRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "ulid",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "url") {
          try {
            new URL(input.data);
          } catch {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "url",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "regex") {
          check.regex.lastIndex = 0;
          const testResult = check.regex.test(input.data);
          if (!testResult) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "regex",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "trim") {
          input.data = input.data.trim();
        } else if (check.kind === "includes") {
          if (!input.data.includes(check.value, check.position)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: { includes: check.value, position: check.position },
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "toLowerCase") {
          input.data = input.data.toLowerCase();
        } else if (check.kind === "toUpperCase") {
          input.data = input.data.toUpperCase();
        } else if (check.kind === "startsWith") {
          if (!input.data.startsWith(check.value)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: { startsWith: check.value },
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "endsWith") {
          if (!input.data.endsWith(check.value)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: { endsWith: check.value },
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "datetime") {
          const regex = datetimeRegex(check);
          if (!regex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: "datetime",
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "date") {
          const regex = dateRegex;
          if (!regex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: "date",
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "time") {
          const regex = timeRegex(check);
          if (!regex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: "time",
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "duration") {
          if (!durationRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "duration",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "ip") {
          if (!isValidIP(input.data, check.version)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "ip",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "jwt") {
          if (!isValidJWT(input.data, check.alg)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "jwt",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "cidr") {
          if (!isValidCidr(input.data, check.version)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "cidr",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "base64") {
          if (!base64Regex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "base64",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "base64url") {
          if (!base64urlRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "base64url",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else {
          util.assertNever(check);
        }
      }
      return { status: status.value, value: input.data };
    }
    _regex(regex, validation, message) {
      return this.refinement((data) => regex.test(data), {
        validation,
        code: ZodIssueCode.invalid_string,
        ...errorUtil.errToObj(message)
      });
    }
    _addCheck(check) {
      return new _ZodString({
        ...this._def,
        checks: [...this._def.checks, check]
      });
    }
    email(message) {
      return this._addCheck({ kind: "email", ...errorUtil.errToObj(message) });
    }
    url(message) {
      return this._addCheck({ kind: "url", ...errorUtil.errToObj(message) });
    }
    emoji(message) {
      return this._addCheck({ kind: "emoji", ...errorUtil.errToObj(message) });
    }
    uuid(message) {
      return this._addCheck({ kind: "uuid", ...errorUtil.errToObj(message) });
    }
    nanoid(message) {
      return this._addCheck({ kind: "nanoid", ...errorUtil.errToObj(message) });
    }
    cuid(message) {
      return this._addCheck({ kind: "cuid", ...errorUtil.errToObj(message) });
    }
    cuid2(message) {
      return this._addCheck({ kind: "cuid2", ...errorUtil.errToObj(message) });
    }
    ulid(message) {
      return this._addCheck({ kind: "ulid", ...errorUtil.errToObj(message) });
    }
    base64(message) {
      return this._addCheck({ kind: "base64", ...errorUtil.errToObj(message) });
    }
    base64url(message) {
      return this._addCheck({
        kind: "base64url",
        ...errorUtil.errToObj(message)
      });
    }
    jwt(options) {
      return this._addCheck({ kind: "jwt", ...errorUtil.errToObj(options) });
    }
    ip(options) {
      return this._addCheck({ kind: "ip", ...errorUtil.errToObj(options) });
    }
    cidr(options) {
      return this._addCheck({ kind: "cidr", ...errorUtil.errToObj(options) });
    }
    datetime(options) {
      if (typeof options === "string") {
        return this._addCheck({
          kind: "datetime",
          precision: null,
          offset: false,
          local: false,
          message: options
        });
      }
      return this._addCheck({
        kind: "datetime",
        precision: typeof options?.precision === "undefined" ? null : options?.precision,
        offset: options?.offset ?? false,
        local: options?.local ?? false,
        ...errorUtil.errToObj(options?.message)
      });
    }
    date(message) {
      return this._addCheck({ kind: "date", message });
    }
    time(options) {
      if (typeof options === "string") {
        return this._addCheck({
          kind: "time",
          precision: null,
          message: options
        });
      }
      return this._addCheck({
        kind: "time",
        precision: typeof options?.precision === "undefined" ? null : options?.precision,
        ...errorUtil.errToObj(options?.message)
      });
    }
    duration(message) {
      return this._addCheck({ kind: "duration", ...errorUtil.errToObj(message) });
    }
    regex(regex, message) {
      return this._addCheck({
        kind: "regex",
        regex,
        ...errorUtil.errToObj(message)
      });
    }
    includes(value, options) {
      return this._addCheck({
        kind: "includes",
        value,
        position: options?.position,
        ...errorUtil.errToObj(options?.message)
      });
    }
    startsWith(value, message) {
      return this._addCheck({
        kind: "startsWith",
        value,
        ...errorUtil.errToObj(message)
      });
    }
    endsWith(value, message) {
      return this._addCheck({
        kind: "endsWith",
        value,
        ...errorUtil.errToObj(message)
      });
    }
    min(minLength, message) {
      return this._addCheck({
        kind: "min",
        value: minLength,
        ...errorUtil.errToObj(message)
      });
    }
    max(maxLength, message) {
      return this._addCheck({
        kind: "max",
        value: maxLength,
        ...errorUtil.errToObj(message)
      });
    }
    length(len, message) {
      return this._addCheck({
        kind: "length",
        value: len,
        ...errorUtil.errToObj(message)
      });
    }
    /**
     * Equivalent to `.min(1)`
     */
    nonempty(message) {
      return this.min(1, errorUtil.errToObj(message));
    }
    trim() {
      return new _ZodString({
        ...this._def,
        checks: [...this._def.checks, { kind: "trim" }]
      });
    }
    toLowerCase() {
      return new _ZodString({
        ...this._def,
        checks: [...this._def.checks, { kind: "toLowerCase" }]
      });
    }
    toUpperCase() {
      return new _ZodString({
        ...this._def,
        checks: [...this._def.checks, { kind: "toUpperCase" }]
      });
    }
    get isDatetime() {
      return !!this._def.checks.find((ch) => ch.kind === "datetime");
    }
    get isDate() {
      return !!this._def.checks.find((ch) => ch.kind === "date");
    }
    get isTime() {
      return !!this._def.checks.find((ch) => ch.kind === "time");
    }
    get isDuration() {
      return !!this._def.checks.find((ch) => ch.kind === "duration");
    }
    get isEmail() {
      return !!this._def.checks.find((ch) => ch.kind === "email");
    }
    get isURL() {
      return !!this._def.checks.find((ch) => ch.kind === "url");
    }
    get isEmoji() {
      return !!this._def.checks.find((ch) => ch.kind === "emoji");
    }
    get isUUID() {
      return !!this._def.checks.find((ch) => ch.kind === "uuid");
    }
    get isNANOID() {
      return !!this._def.checks.find((ch) => ch.kind === "nanoid");
    }
    get isCUID() {
      return !!this._def.checks.find((ch) => ch.kind === "cuid");
    }
    get isCUID2() {
      return !!this._def.checks.find((ch) => ch.kind === "cuid2");
    }
    get isULID() {
      return !!this._def.checks.find((ch) => ch.kind === "ulid");
    }
    get isIP() {
      return !!this._def.checks.find((ch) => ch.kind === "ip");
    }
    get isCIDR() {
      return !!this._def.checks.find((ch) => ch.kind === "cidr");
    }
    get isBase64() {
      return !!this._def.checks.find((ch) => ch.kind === "base64");
    }
    get isBase64url() {
      return !!this._def.checks.find((ch) => ch.kind === "base64url");
    }
    get minLength() {
      let min = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "min") {
          if (min === null || ch.value > min)
            min = ch.value;
        }
      }
      return min;
    }
    get maxLength() {
      let max = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "max") {
          if (max === null || ch.value < max)
            max = ch.value;
        }
      }
      return max;
    }
  };
  ZodString.create = (params) => {
    return new ZodString({
      checks: [],
      typeName: ZodFirstPartyTypeKind.ZodString,
      coerce: params?.coerce ?? false,
      ...processCreateParams(params)
    });
  };
  function floatSafeRemainder(val, step) {
    const valDecCount = (val.toString().split(".")[1] || "").length;
    const stepDecCount = (step.toString().split(".")[1] || "").length;
    const decCount = valDecCount > stepDecCount ? valDecCount : stepDecCount;
    const valInt = Number.parseInt(val.toFixed(decCount).replace(".", ""));
    const stepInt = Number.parseInt(step.toFixed(decCount).replace(".", ""));
    return valInt % stepInt / 10 ** decCount;
  }
  var ZodNumber = class _ZodNumber extends ZodType {
    constructor() {
      super(...arguments);
      this.min = this.gte;
      this.max = this.lte;
      this.step = this.multipleOf;
    }
    _parse(input) {
      if (this._def.coerce) {
        input.data = Number(input.data);
      }
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.number) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.number,
          received: ctx2.parsedType
        });
        return INVALID;
      }
      let ctx = void 0;
      const status = new ParseStatus();
      for (const check of this._def.checks) {
        if (check.kind === "int") {
          if (!util.isInteger(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_type,
              expected: "integer",
              received: "float",
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "min") {
          const tooSmall = check.inclusive ? input.data < check.value : input.data <= check.value;
          if (tooSmall) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              minimum: check.value,
              type: "number",
              inclusive: check.inclusive,
              exact: false,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "max") {
          const tooBig = check.inclusive ? input.data > check.value : input.data >= check.value;
          if (tooBig) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              maximum: check.value,
              type: "number",
              inclusive: check.inclusive,
              exact: false,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "multipleOf") {
          if (floatSafeRemainder(input.data, check.value) !== 0) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.not_multiple_of,
              multipleOf: check.value,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "finite") {
          if (!Number.isFinite(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.not_finite,
              message: check.message
            });
            status.dirty();
          }
        } else {
          util.assertNever(check);
        }
      }
      return { status: status.value, value: input.data };
    }
    gte(value, message) {
      return this.setLimit("min", value, true, errorUtil.toString(message));
    }
    gt(value, message) {
      return this.setLimit("min", value, false, errorUtil.toString(message));
    }
    lte(value, message) {
      return this.setLimit("max", value, true, errorUtil.toString(message));
    }
    lt(value, message) {
      return this.setLimit("max", value, false, errorUtil.toString(message));
    }
    setLimit(kind, value, inclusive, message) {
      return new _ZodNumber({
        ...this._def,
        checks: [
          ...this._def.checks,
          {
            kind,
            value,
            inclusive,
            message: errorUtil.toString(message)
          }
        ]
      });
    }
    _addCheck(check) {
      return new _ZodNumber({
        ...this._def,
        checks: [...this._def.checks, check]
      });
    }
    int(message) {
      return this._addCheck({
        kind: "int",
        message: errorUtil.toString(message)
      });
    }
    positive(message) {
      return this._addCheck({
        kind: "min",
        value: 0,
        inclusive: false,
        message: errorUtil.toString(message)
      });
    }
    negative(message) {
      return this._addCheck({
        kind: "max",
        value: 0,
        inclusive: false,
        message: errorUtil.toString(message)
      });
    }
    nonpositive(message) {
      return this._addCheck({
        kind: "max",
        value: 0,
        inclusive: true,
        message: errorUtil.toString(message)
      });
    }
    nonnegative(message) {
      return this._addCheck({
        kind: "min",
        value: 0,
        inclusive: true,
        message: errorUtil.toString(message)
      });
    }
    multipleOf(value, message) {
      return this._addCheck({
        kind: "multipleOf",
        value,
        message: errorUtil.toString(message)
      });
    }
    finite(message) {
      return this._addCheck({
        kind: "finite",
        message: errorUtil.toString(message)
      });
    }
    safe(message) {
      return this._addCheck({
        kind: "min",
        inclusive: true,
        value: Number.MIN_SAFE_INTEGER,
        message: errorUtil.toString(message)
      })._addCheck({
        kind: "max",
        inclusive: true,
        value: Number.MAX_SAFE_INTEGER,
        message: errorUtil.toString(message)
      });
    }
    get minValue() {
      let min = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "min") {
          if (min === null || ch.value > min)
            min = ch.value;
        }
      }
      return min;
    }
    get maxValue() {
      let max = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "max") {
          if (max === null || ch.value < max)
            max = ch.value;
        }
      }
      return max;
    }
    get isInt() {
      return !!this._def.checks.find((ch) => ch.kind === "int" || ch.kind === "multipleOf" && util.isInteger(ch.value));
    }
    get isFinite() {
      let max = null;
      let min = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "finite" || ch.kind === "int" || ch.kind === "multipleOf") {
          return true;
        } else if (ch.kind === "min") {
          if (min === null || ch.value > min)
            min = ch.value;
        } else if (ch.kind === "max") {
          if (max === null || ch.value < max)
            max = ch.value;
        }
      }
      return Number.isFinite(min) && Number.isFinite(max);
    }
  };
  ZodNumber.create = (params) => {
    return new ZodNumber({
      checks: [],
      typeName: ZodFirstPartyTypeKind.ZodNumber,
      coerce: params?.coerce || false,
      ...processCreateParams(params)
    });
  };
  var ZodBigInt = class _ZodBigInt extends ZodType {
    constructor() {
      super(...arguments);
      this.min = this.gte;
      this.max = this.lte;
    }
    _parse(input) {
      if (this._def.coerce) {
        try {
          input.data = BigInt(input.data);
        } catch {
          return this._getInvalidInput(input);
        }
      }
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.bigint) {
        return this._getInvalidInput(input);
      }
      let ctx = void 0;
      const status = new ParseStatus();
      for (const check of this._def.checks) {
        if (check.kind === "min") {
          const tooSmall = check.inclusive ? input.data < check.value : input.data <= check.value;
          if (tooSmall) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              type: "bigint",
              minimum: check.value,
              inclusive: check.inclusive,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "max") {
          const tooBig = check.inclusive ? input.data > check.value : input.data >= check.value;
          if (tooBig) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              type: "bigint",
              maximum: check.value,
              inclusive: check.inclusive,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "multipleOf") {
          if (input.data % check.value !== BigInt(0)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.not_multiple_of,
              multipleOf: check.value,
              message: check.message
            });
            status.dirty();
          }
        } else {
          util.assertNever(check);
        }
      }
      return { status: status.value, value: input.data };
    }
    _getInvalidInput(input) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.bigint,
        received: ctx.parsedType
      });
      return INVALID;
    }
    gte(value, message) {
      return this.setLimit("min", value, true, errorUtil.toString(message));
    }
    gt(value, message) {
      return this.setLimit("min", value, false, errorUtil.toString(message));
    }
    lte(value, message) {
      return this.setLimit("max", value, true, errorUtil.toString(message));
    }
    lt(value, message) {
      return this.setLimit("max", value, false, errorUtil.toString(message));
    }
    setLimit(kind, value, inclusive, message) {
      return new _ZodBigInt({
        ...this._def,
        checks: [
          ...this._def.checks,
          {
            kind,
            value,
            inclusive,
            message: errorUtil.toString(message)
          }
        ]
      });
    }
    _addCheck(check) {
      return new _ZodBigInt({
        ...this._def,
        checks: [...this._def.checks, check]
      });
    }
    positive(message) {
      return this._addCheck({
        kind: "min",
        value: BigInt(0),
        inclusive: false,
        message: errorUtil.toString(message)
      });
    }
    negative(message) {
      return this._addCheck({
        kind: "max",
        value: BigInt(0),
        inclusive: false,
        message: errorUtil.toString(message)
      });
    }
    nonpositive(message) {
      return this._addCheck({
        kind: "max",
        value: BigInt(0),
        inclusive: true,
        message: errorUtil.toString(message)
      });
    }
    nonnegative(message) {
      return this._addCheck({
        kind: "min",
        value: BigInt(0),
        inclusive: true,
        message: errorUtil.toString(message)
      });
    }
    multipleOf(value, message) {
      return this._addCheck({
        kind: "multipleOf",
        value,
        message: errorUtil.toString(message)
      });
    }
    get minValue() {
      let min = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "min") {
          if (min === null || ch.value > min)
            min = ch.value;
        }
      }
      return min;
    }
    get maxValue() {
      let max = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "max") {
          if (max === null || ch.value < max)
            max = ch.value;
        }
      }
      return max;
    }
  };
  ZodBigInt.create = (params) => {
    return new ZodBigInt({
      checks: [],
      typeName: ZodFirstPartyTypeKind.ZodBigInt,
      coerce: params?.coerce ?? false,
      ...processCreateParams(params)
    });
  };
  var ZodBoolean = class extends ZodType {
    _parse(input) {
      if (this._def.coerce) {
        input.data = Boolean(input.data);
      }
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.boolean) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.boolean,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return OK(input.data);
    }
  };
  ZodBoolean.create = (params) => {
    return new ZodBoolean({
      typeName: ZodFirstPartyTypeKind.ZodBoolean,
      coerce: params?.coerce || false,
      ...processCreateParams(params)
    });
  };
  var ZodDate = class _ZodDate extends ZodType {
    _parse(input) {
      if (this._def.coerce) {
        input.data = new Date(input.data);
      }
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.date) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.date,
          received: ctx2.parsedType
        });
        return INVALID;
      }
      if (Number.isNaN(input.data.getTime())) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_date
        });
        return INVALID;
      }
      const status = new ParseStatus();
      let ctx = void 0;
      for (const check of this._def.checks) {
        if (check.kind === "min") {
          if (input.data.getTime() < check.value) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              message: check.message,
              inclusive: true,
              exact: false,
              minimum: check.value,
              type: "date"
            });
            status.dirty();
          }
        } else if (check.kind === "max") {
          if (input.data.getTime() > check.value) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              message: check.message,
              inclusive: true,
              exact: false,
              maximum: check.value,
              type: "date"
            });
            status.dirty();
          }
        } else {
          util.assertNever(check);
        }
      }
      return {
        status: status.value,
        value: new Date(input.data.getTime())
      };
    }
    _addCheck(check) {
      return new _ZodDate({
        ...this._def,
        checks: [...this._def.checks, check]
      });
    }
    min(minDate, message) {
      return this._addCheck({
        kind: "min",
        value: minDate.getTime(),
        message: errorUtil.toString(message)
      });
    }
    max(maxDate, message) {
      return this._addCheck({
        kind: "max",
        value: maxDate.getTime(),
        message: errorUtil.toString(message)
      });
    }
    get minDate() {
      let min = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "min") {
          if (min === null || ch.value > min)
            min = ch.value;
        }
      }
      return min != null ? new Date(min) : null;
    }
    get maxDate() {
      let max = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "max") {
          if (max === null || ch.value < max)
            max = ch.value;
        }
      }
      return max != null ? new Date(max) : null;
    }
  };
  ZodDate.create = (params) => {
    return new ZodDate({
      checks: [],
      coerce: params?.coerce || false,
      typeName: ZodFirstPartyTypeKind.ZodDate,
      ...processCreateParams(params)
    });
  };
  var ZodSymbol = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.symbol) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.symbol,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return OK(input.data);
    }
  };
  ZodSymbol.create = (params) => {
    return new ZodSymbol({
      typeName: ZodFirstPartyTypeKind.ZodSymbol,
      ...processCreateParams(params)
    });
  };
  var ZodUndefined = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.undefined) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.undefined,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return OK(input.data);
    }
  };
  ZodUndefined.create = (params) => {
    return new ZodUndefined({
      typeName: ZodFirstPartyTypeKind.ZodUndefined,
      ...processCreateParams(params)
    });
  };
  var ZodNull = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.null) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.null,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return OK(input.data);
    }
  };
  ZodNull.create = (params) => {
    return new ZodNull({
      typeName: ZodFirstPartyTypeKind.ZodNull,
      ...processCreateParams(params)
    });
  };
  var ZodAny = class extends ZodType {
    constructor() {
      super(...arguments);
      this._any = true;
    }
    _parse(input) {
      return OK(input.data);
    }
  };
  ZodAny.create = (params) => {
    return new ZodAny({
      typeName: ZodFirstPartyTypeKind.ZodAny,
      ...processCreateParams(params)
    });
  };
  var ZodUnknown = class extends ZodType {
    constructor() {
      super(...arguments);
      this._unknown = true;
    }
    _parse(input) {
      return OK(input.data);
    }
  };
  ZodUnknown.create = (params) => {
    return new ZodUnknown({
      typeName: ZodFirstPartyTypeKind.ZodUnknown,
      ...processCreateParams(params)
    });
  };
  var ZodNever = class extends ZodType {
    _parse(input) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.never,
        received: ctx.parsedType
      });
      return INVALID;
    }
  };
  ZodNever.create = (params) => {
    return new ZodNever({
      typeName: ZodFirstPartyTypeKind.ZodNever,
      ...processCreateParams(params)
    });
  };
  var ZodVoid = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.undefined) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.void,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return OK(input.data);
    }
  };
  ZodVoid.create = (params) => {
    return new ZodVoid({
      typeName: ZodFirstPartyTypeKind.ZodVoid,
      ...processCreateParams(params)
    });
  };
  var ZodArray = class _ZodArray extends ZodType {
    _parse(input) {
      const { ctx, status } = this._processInputParams(input);
      const def = this._def;
      if (ctx.parsedType !== ZodParsedType.array) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.array,
          received: ctx.parsedType
        });
        return INVALID;
      }
      if (def.exactLength !== null) {
        const tooBig = ctx.data.length > def.exactLength.value;
        const tooSmall = ctx.data.length < def.exactLength.value;
        if (tooBig || tooSmall) {
          addIssueToContext(ctx, {
            code: tooBig ? ZodIssueCode.too_big : ZodIssueCode.too_small,
            minimum: tooSmall ? def.exactLength.value : void 0,
            maximum: tooBig ? def.exactLength.value : void 0,
            type: "array",
            inclusive: true,
            exact: true,
            message: def.exactLength.message
          });
          status.dirty();
        }
      }
      if (def.minLength !== null) {
        if (ctx.data.length < def.minLength.value) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            minimum: def.minLength.value,
            type: "array",
            inclusive: true,
            exact: false,
            message: def.minLength.message
          });
          status.dirty();
        }
      }
      if (def.maxLength !== null) {
        if (ctx.data.length > def.maxLength.value) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            maximum: def.maxLength.value,
            type: "array",
            inclusive: true,
            exact: false,
            message: def.maxLength.message
          });
          status.dirty();
        }
      }
      if (ctx.common.async) {
        return Promise.all([...ctx.data].map((item, i) => {
          return def.type._parseAsync(new ParseInputLazyPath(ctx, item, ctx.path, i));
        })).then((result2) => {
          return ParseStatus.mergeArray(status, result2);
        });
      }
      const result = [...ctx.data].map((item, i) => {
        return def.type._parseSync(new ParseInputLazyPath(ctx, item, ctx.path, i));
      });
      return ParseStatus.mergeArray(status, result);
    }
    get element() {
      return this._def.type;
    }
    min(minLength, message) {
      return new _ZodArray({
        ...this._def,
        minLength: { value: minLength, message: errorUtil.toString(message) }
      });
    }
    max(maxLength, message) {
      return new _ZodArray({
        ...this._def,
        maxLength: { value: maxLength, message: errorUtil.toString(message) }
      });
    }
    length(len, message) {
      return new _ZodArray({
        ...this._def,
        exactLength: { value: len, message: errorUtil.toString(message) }
      });
    }
    nonempty(message) {
      return this.min(1, message);
    }
  };
  ZodArray.create = (schema, params) => {
    return new ZodArray({
      type: schema,
      minLength: null,
      maxLength: null,
      exactLength: null,
      typeName: ZodFirstPartyTypeKind.ZodArray,
      ...processCreateParams(params)
    });
  };
  function deepPartialify(schema) {
    if (schema instanceof ZodObject) {
      const newShape = {};
      for (const key in schema.shape) {
        const fieldSchema = schema.shape[key];
        newShape[key] = ZodOptional.create(deepPartialify(fieldSchema));
      }
      return new ZodObject({
        ...schema._def,
        shape: () => newShape
      });
    } else if (schema instanceof ZodArray) {
      return new ZodArray({
        ...schema._def,
        type: deepPartialify(schema.element)
      });
    } else if (schema instanceof ZodOptional) {
      return ZodOptional.create(deepPartialify(schema.unwrap()));
    } else if (schema instanceof ZodNullable) {
      return ZodNullable.create(deepPartialify(schema.unwrap()));
    } else if (schema instanceof ZodTuple) {
      return ZodTuple.create(schema.items.map((item) => deepPartialify(item)));
    } else {
      return schema;
    }
  }
  var ZodObject = class _ZodObject extends ZodType {
    constructor() {
      super(...arguments);
      this._cached = null;
      this.nonstrict = this.passthrough;
      this.augment = this.extend;
    }
    _getCached() {
      if (this._cached !== null)
        return this._cached;
      const shape = this._def.shape();
      const keys = util.objectKeys(shape);
      this._cached = { shape, keys };
      return this._cached;
    }
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.object) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.object,
          received: ctx2.parsedType
        });
        return INVALID;
      }
      const { status, ctx } = this._processInputParams(input);
      const { shape, keys: shapeKeys } = this._getCached();
      const extraKeys = [];
      if (!(this._def.catchall instanceof ZodNever && this._def.unknownKeys === "strip")) {
        for (const key in ctx.data) {
          if (!shapeKeys.includes(key)) {
            extraKeys.push(key);
          }
        }
      }
      const pairs = [];
      for (const key of shapeKeys) {
        const keyValidator = shape[key];
        const value = ctx.data[key];
        pairs.push({
          key: { status: "valid", value: key },
          value: keyValidator._parse(new ParseInputLazyPath(ctx, value, ctx.path, key)),
          alwaysSet: key in ctx.data
        });
      }
      if (this._def.catchall instanceof ZodNever) {
        const unknownKeys = this._def.unknownKeys;
        if (unknownKeys === "passthrough") {
          for (const key of extraKeys) {
            pairs.push({
              key: { status: "valid", value: key },
              value: { status: "valid", value: ctx.data[key] }
            });
          }
        } else if (unknownKeys === "strict") {
          if (extraKeys.length > 0) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.unrecognized_keys,
              keys: extraKeys
            });
            status.dirty();
          }
        } else if (unknownKeys === "strip") {
        } else {
          throw new Error(`Internal ZodObject error: invalid unknownKeys value.`);
        }
      } else {
        const catchall = this._def.catchall;
        for (const key of extraKeys) {
          const value = ctx.data[key];
          pairs.push({
            key: { status: "valid", value: key },
            value: catchall._parse(
              new ParseInputLazyPath(ctx, value, ctx.path, key)
              //, ctx.child(key), value, getParsedType(value)
            ),
            alwaysSet: key in ctx.data
          });
        }
      }
      if (ctx.common.async) {
        return Promise.resolve().then(async () => {
          const syncPairs = [];
          for (const pair of pairs) {
            const key = await pair.key;
            const value = await pair.value;
            syncPairs.push({
              key,
              value,
              alwaysSet: pair.alwaysSet
            });
          }
          return syncPairs;
        }).then((syncPairs) => {
          return ParseStatus.mergeObjectSync(status, syncPairs);
        });
      } else {
        return ParseStatus.mergeObjectSync(status, pairs);
      }
    }
    get shape() {
      return this._def.shape();
    }
    strict(message) {
      errorUtil.errToObj;
      return new _ZodObject({
        ...this._def,
        unknownKeys: "strict",
        ...message !== void 0 ? {
          errorMap: (issue, ctx) => {
            const defaultError = this._def.errorMap?.(issue, ctx).message ?? ctx.defaultError;
            if (issue.code === "unrecognized_keys")
              return {
                message: errorUtil.errToObj(message).message ?? defaultError
              };
            return {
              message: defaultError
            };
          }
        } : {}
      });
    }
    strip() {
      return new _ZodObject({
        ...this._def,
        unknownKeys: "strip"
      });
    }
    passthrough() {
      return new _ZodObject({
        ...this._def,
        unknownKeys: "passthrough"
      });
    }
    // const AugmentFactory =
    //   <Def extends ZodObjectDef>(def: Def) =>
    //   <Augmentation extends ZodRawShape>(
    //     augmentation: Augmentation
    //   ): ZodObject<
    //     extendShape<ReturnType<Def["shape"]>, Augmentation>,
    //     Def["unknownKeys"],
    //     Def["catchall"]
    //   > => {
    //     return new ZodObject({
    //       ...def,
    //       shape: () => ({
    //         ...def.shape(),
    //         ...augmentation,
    //       }),
    //     }) as any;
    //   };
    extend(augmentation) {
      return new _ZodObject({
        ...this._def,
        shape: () => ({
          ...this._def.shape(),
          ...augmentation
        })
      });
    }
    /**
     * Prior to zod@1.0.12 there was a bug in the
     * inferred type of merged objects. Please
     * upgrade if you are experiencing issues.
     */
    merge(merging) {
      const merged = new _ZodObject({
        unknownKeys: merging._def.unknownKeys,
        catchall: merging._def.catchall,
        shape: () => ({
          ...this._def.shape(),
          ...merging._def.shape()
        }),
        typeName: ZodFirstPartyTypeKind.ZodObject
      });
      return merged;
    }
    // merge<
    //   Incoming extends AnyZodObject,
    //   Augmentation extends Incoming["shape"],
    //   NewOutput extends {
    //     [k in keyof Augmentation | keyof Output]: k extends keyof Augmentation
    //       ? Augmentation[k]["_output"]
    //       : k extends keyof Output
    //       ? Output[k]
    //       : never;
    //   },
    //   NewInput extends {
    //     [k in keyof Augmentation | keyof Input]: k extends keyof Augmentation
    //       ? Augmentation[k]["_input"]
    //       : k extends keyof Input
    //       ? Input[k]
    //       : never;
    //   }
    // >(
    //   merging: Incoming
    // ): ZodObject<
    //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
    //   Incoming["_def"]["unknownKeys"],
    //   Incoming["_def"]["catchall"],
    //   NewOutput,
    //   NewInput
    // > {
    //   const merged: any = new ZodObject({
    //     unknownKeys: merging._def.unknownKeys,
    //     catchall: merging._def.catchall,
    //     shape: () =>
    //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
    //     typeName: ZodFirstPartyTypeKind.ZodObject,
    //   }) as any;
    //   return merged;
    // }
    setKey(key, schema) {
      return this.augment({ [key]: schema });
    }
    // merge<Incoming extends AnyZodObject>(
    //   merging: Incoming
    // ): //ZodObject<T & Incoming["_shape"], UnknownKeys, Catchall> = (merging) => {
    // ZodObject<
    //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
    //   Incoming["_def"]["unknownKeys"],
    //   Incoming["_def"]["catchall"]
    // > {
    //   // const mergedShape = objectUtil.mergeShapes(
    //   //   this._def.shape(),
    //   //   merging._def.shape()
    //   // );
    //   const merged: any = new ZodObject({
    //     unknownKeys: merging._def.unknownKeys,
    //     catchall: merging._def.catchall,
    //     shape: () =>
    //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
    //     typeName: ZodFirstPartyTypeKind.ZodObject,
    //   }) as any;
    //   return merged;
    // }
    catchall(index) {
      return new _ZodObject({
        ...this._def,
        catchall: index
      });
    }
    pick(mask) {
      const shape = {};
      for (const key of util.objectKeys(mask)) {
        if (mask[key] && this.shape[key]) {
          shape[key] = this.shape[key];
        }
      }
      return new _ZodObject({
        ...this._def,
        shape: () => shape
      });
    }
    omit(mask) {
      const shape = {};
      for (const key of util.objectKeys(this.shape)) {
        if (!mask[key]) {
          shape[key] = this.shape[key];
        }
      }
      return new _ZodObject({
        ...this._def,
        shape: () => shape
      });
    }
    /**
     * @deprecated
     */
    deepPartial() {
      return deepPartialify(this);
    }
    partial(mask) {
      const newShape = {};
      for (const key of util.objectKeys(this.shape)) {
        const fieldSchema = this.shape[key];
        if (mask && !mask[key]) {
          newShape[key] = fieldSchema;
        } else {
          newShape[key] = fieldSchema.optional();
        }
      }
      return new _ZodObject({
        ...this._def,
        shape: () => newShape
      });
    }
    required(mask) {
      const newShape = {};
      for (const key of util.objectKeys(this.shape)) {
        if (mask && !mask[key]) {
          newShape[key] = this.shape[key];
        } else {
          const fieldSchema = this.shape[key];
          let newField = fieldSchema;
          while (newField instanceof ZodOptional) {
            newField = newField._def.innerType;
          }
          newShape[key] = newField;
        }
      }
      return new _ZodObject({
        ...this._def,
        shape: () => newShape
      });
    }
    keyof() {
      return createZodEnum(util.objectKeys(this.shape));
    }
  };
  ZodObject.create = (shape, params) => {
    return new ZodObject({
      shape: () => shape,
      unknownKeys: "strip",
      catchall: ZodNever.create(),
      typeName: ZodFirstPartyTypeKind.ZodObject,
      ...processCreateParams(params)
    });
  };
  ZodObject.strictCreate = (shape, params) => {
    return new ZodObject({
      shape: () => shape,
      unknownKeys: "strict",
      catchall: ZodNever.create(),
      typeName: ZodFirstPartyTypeKind.ZodObject,
      ...processCreateParams(params)
    });
  };
  ZodObject.lazycreate = (shape, params) => {
    return new ZodObject({
      shape,
      unknownKeys: "strip",
      catchall: ZodNever.create(),
      typeName: ZodFirstPartyTypeKind.ZodObject,
      ...processCreateParams(params)
    });
  };
  var ZodUnion = class extends ZodType {
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      const options = this._def.options;
      function handleResults(results) {
        for (const result of results) {
          if (result.result.status === "valid") {
            return result.result;
          }
        }
        for (const result of results) {
          if (result.result.status === "dirty") {
            ctx.common.issues.push(...result.ctx.common.issues);
            return result.result;
          }
        }
        const unionErrors = results.map((result) => new ZodError(result.ctx.common.issues));
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_union,
          unionErrors
        });
        return INVALID;
      }
      if (ctx.common.async) {
        return Promise.all(options.map(async (option) => {
          const childCtx = {
            ...ctx,
            common: {
              ...ctx.common,
              issues: []
            },
            parent: null
          };
          return {
            result: await option._parseAsync({
              data: ctx.data,
              path: ctx.path,
              parent: childCtx
            }),
            ctx: childCtx
          };
        })).then(handleResults);
      } else {
        let dirty = void 0;
        const issues = [];
        for (const option of options) {
          const childCtx = {
            ...ctx,
            common: {
              ...ctx.common,
              issues: []
            },
            parent: null
          };
          const result = option._parseSync({
            data: ctx.data,
            path: ctx.path,
            parent: childCtx
          });
          if (result.status === "valid") {
            return result;
          } else if (result.status === "dirty" && !dirty) {
            dirty = { result, ctx: childCtx };
          }
          if (childCtx.common.issues.length) {
            issues.push(childCtx.common.issues);
          }
        }
        if (dirty) {
          ctx.common.issues.push(...dirty.ctx.common.issues);
          return dirty.result;
        }
        const unionErrors = issues.map((issues2) => new ZodError(issues2));
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_union,
          unionErrors
        });
        return INVALID;
      }
    }
    get options() {
      return this._def.options;
    }
  };
  ZodUnion.create = (types, params) => {
    return new ZodUnion({
      options: types,
      typeName: ZodFirstPartyTypeKind.ZodUnion,
      ...processCreateParams(params)
    });
  };
  var getDiscriminator = (type) => {
    if (type instanceof ZodLazy) {
      return getDiscriminator(type.schema);
    } else if (type instanceof ZodEffects) {
      return getDiscriminator(type.innerType());
    } else if (type instanceof ZodLiteral) {
      return [type.value];
    } else if (type instanceof ZodEnum) {
      return type.options;
    } else if (type instanceof ZodNativeEnum) {
      return util.objectValues(type.enum);
    } else if (type instanceof ZodDefault) {
      return getDiscriminator(type._def.innerType);
    } else if (type instanceof ZodUndefined) {
      return [void 0];
    } else if (type instanceof ZodNull) {
      return [null];
    } else if (type instanceof ZodOptional) {
      return [void 0, ...getDiscriminator(type.unwrap())];
    } else if (type instanceof ZodNullable) {
      return [null, ...getDiscriminator(type.unwrap())];
    } else if (type instanceof ZodBranded) {
      return getDiscriminator(type.unwrap());
    } else if (type instanceof ZodReadonly) {
      return getDiscriminator(type.unwrap());
    } else if (type instanceof ZodCatch) {
      return getDiscriminator(type._def.innerType);
    } else {
      return [];
    }
  };
  var ZodDiscriminatedUnion = class _ZodDiscriminatedUnion extends ZodType {
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.object) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.object,
          received: ctx.parsedType
        });
        return INVALID;
      }
      const discriminator = this.discriminator;
      const discriminatorValue = ctx.data[discriminator];
      const option = this.optionsMap.get(discriminatorValue);
      if (!option) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_union_discriminator,
          options: Array.from(this.optionsMap.keys()),
          path: [discriminator]
        });
        return INVALID;
      }
      if (ctx.common.async) {
        return option._parseAsync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
      } else {
        return option._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
      }
    }
    get discriminator() {
      return this._def.discriminator;
    }
    get options() {
      return this._def.options;
    }
    get optionsMap() {
      return this._def.optionsMap;
    }
    /**
     * The constructor of the discriminated union schema. Its behaviour is very similar to that of the normal z.union() constructor.
     * However, it only allows a union of objects, all of which need to share a discriminator property. This property must
     * have a different value for each object in the union.
     * @param discriminator the name of the discriminator property
     * @param types an array of object schemas
     * @param params
     */
    static create(discriminator, options, params) {
      const optionsMap = /* @__PURE__ */ new Map();
      for (const type of options) {
        const discriminatorValues = getDiscriminator(type.shape[discriminator]);
        if (!discriminatorValues.length) {
          throw new Error(`A discriminator value for key \`${discriminator}\` could not be extracted from all schema options`);
        }
        for (const value of discriminatorValues) {
          if (optionsMap.has(value)) {
            throw new Error(`Discriminator property ${String(discriminator)} has duplicate value ${String(value)}`);
          }
          optionsMap.set(value, type);
        }
      }
      return new _ZodDiscriminatedUnion({
        typeName: ZodFirstPartyTypeKind.ZodDiscriminatedUnion,
        discriminator,
        options,
        optionsMap,
        ...processCreateParams(params)
      });
    }
  };
  function mergeValues(a, b) {
    const aType = getParsedType(a);
    const bType = getParsedType(b);
    if (a === b) {
      return { valid: true, data: a };
    } else if (aType === ZodParsedType.object && bType === ZodParsedType.object) {
      const bKeys = util.objectKeys(b);
      const sharedKeys = util.objectKeys(a).filter((key) => bKeys.indexOf(key) !== -1);
      const newObj = { ...a, ...b };
      for (const key of sharedKeys) {
        const sharedValue = mergeValues(a[key], b[key]);
        if (!sharedValue.valid) {
          return { valid: false };
        }
        newObj[key] = sharedValue.data;
      }
      return { valid: true, data: newObj };
    } else if (aType === ZodParsedType.array && bType === ZodParsedType.array) {
      if (a.length !== b.length) {
        return { valid: false };
      }
      const newArray = [];
      for (let index = 0; index < a.length; index++) {
        const itemA = a[index];
        const itemB = b[index];
        const sharedValue = mergeValues(itemA, itemB);
        if (!sharedValue.valid) {
          return { valid: false };
        }
        newArray.push(sharedValue.data);
      }
      return { valid: true, data: newArray };
    } else if (aType === ZodParsedType.date && bType === ZodParsedType.date && +a === +b) {
      return { valid: true, data: a };
    } else {
      return { valid: false };
    }
  }
  var ZodIntersection = class extends ZodType {
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      const handleParsed = (parsedLeft, parsedRight) => {
        if (isAborted(parsedLeft) || isAborted(parsedRight)) {
          return INVALID;
        }
        const merged = mergeValues(parsedLeft.value, parsedRight.value);
        if (!merged.valid) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_intersection_types
          });
          return INVALID;
        }
        if (isDirty(parsedLeft) || isDirty(parsedRight)) {
          status.dirty();
        }
        return { status: status.value, value: merged.data };
      };
      if (ctx.common.async) {
        return Promise.all([
          this._def.left._parseAsync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          }),
          this._def.right._parseAsync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          })
        ]).then(([left, right]) => handleParsed(left, right));
      } else {
        return handleParsed(this._def.left._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        }), this._def.right._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        }));
      }
    }
  };
  ZodIntersection.create = (left, right, params) => {
    return new ZodIntersection({
      left,
      right,
      typeName: ZodFirstPartyTypeKind.ZodIntersection,
      ...processCreateParams(params)
    });
  };
  var ZodTuple = class _ZodTuple extends ZodType {
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.array) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.array,
          received: ctx.parsedType
        });
        return INVALID;
      }
      if (ctx.data.length < this._def.items.length) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_small,
          minimum: this._def.items.length,
          inclusive: true,
          exact: false,
          type: "array"
        });
        return INVALID;
      }
      const rest = this._def.rest;
      if (!rest && ctx.data.length > this._def.items.length) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_big,
          maximum: this._def.items.length,
          inclusive: true,
          exact: false,
          type: "array"
        });
        status.dirty();
      }
      const items = [...ctx.data].map((item, itemIndex) => {
        const schema = this._def.items[itemIndex] || this._def.rest;
        if (!schema)
          return null;
        return schema._parse(new ParseInputLazyPath(ctx, item, ctx.path, itemIndex));
      }).filter((x) => !!x);
      if (ctx.common.async) {
        return Promise.all(items).then((results) => {
          return ParseStatus.mergeArray(status, results);
        });
      } else {
        return ParseStatus.mergeArray(status, items);
      }
    }
    get items() {
      return this._def.items;
    }
    rest(rest) {
      return new _ZodTuple({
        ...this._def,
        rest
      });
    }
  };
  ZodTuple.create = (schemas, params) => {
    if (!Array.isArray(schemas)) {
      throw new Error("You must pass an array of schemas to z.tuple([ ... ])");
    }
    return new ZodTuple({
      items: schemas,
      typeName: ZodFirstPartyTypeKind.ZodTuple,
      rest: null,
      ...processCreateParams(params)
    });
  };
  var ZodRecord = class _ZodRecord extends ZodType {
    get keySchema() {
      return this._def.keyType;
    }
    get valueSchema() {
      return this._def.valueType;
    }
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.object) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.object,
          received: ctx.parsedType
        });
        return INVALID;
      }
      const pairs = [];
      const keyType = this._def.keyType;
      const valueType = this._def.valueType;
      for (const key in ctx.data) {
        pairs.push({
          key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, key)),
          value: valueType._parse(new ParseInputLazyPath(ctx, ctx.data[key], ctx.path, key)),
          alwaysSet: key in ctx.data
        });
      }
      if (ctx.common.async) {
        return ParseStatus.mergeObjectAsync(status, pairs);
      } else {
        return ParseStatus.mergeObjectSync(status, pairs);
      }
    }
    get element() {
      return this._def.valueType;
    }
    static create(first, second, third) {
      if (second instanceof ZodType) {
        return new _ZodRecord({
          keyType: first,
          valueType: second,
          typeName: ZodFirstPartyTypeKind.ZodRecord,
          ...processCreateParams(third)
        });
      }
      return new _ZodRecord({
        keyType: ZodString.create(),
        valueType: first,
        typeName: ZodFirstPartyTypeKind.ZodRecord,
        ...processCreateParams(second)
      });
    }
  };
  var ZodMap = class extends ZodType {
    get keySchema() {
      return this._def.keyType;
    }
    get valueSchema() {
      return this._def.valueType;
    }
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.map) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.map,
          received: ctx.parsedType
        });
        return INVALID;
      }
      const keyType = this._def.keyType;
      const valueType = this._def.valueType;
      const pairs = [...ctx.data.entries()].map(([key, value], index) => {
        return {
          key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, [index, "key"])),
          value: valueType._parse(new ParseInputLazyPath(ctx, value, ctx.path, [index, "value"]))
        };
      });
      if (ctx.common.async) {
        const finalMap = /* @__PURE__ */ new Map();
        return Promise.resolve().then(async () => {
          for (const pair of pairs) {
            const key = await pair.key;
            const value = await pair.value;
            if (key.status === "aborted" || value.status === "aborted") {
              return INVALID;
            }
            if (key.status === "dirty" || value.status === "dirty") {
              status.dirty();
            }
            finalMap.set(key.value, value.value);
          }
          return { status: status.value, value: finalMap };
        });
      } else {
        const finalMap = /* @__PURE__ */ new Map();
        for (const pair of pairs) {
          const key = pair.key;
          const value = pair.value;
          if (key.status === "aborted" || value.status === "aborted") {
            return INVALID;
          }
          if (key.status === "dirty" || value.status === "dirty") {
            status.dirty();
          }
          finalMap.set(key.value, value.value);
        }
        return { status: status.value, value: finalMap };
      }
    }
  };
  ZodMap.create = (keyType, valueType, params) => {
    return new ZodMap({
      valueType,
      keyType,
      typeName: ZodFirstPartyTypeKind.ZodMap,
      ...processCreateParams(params)
    });
  };
  var ZodSet = class _ZodSet extends ZodType {
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.set) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.set,
          received: ctx.parsedType
        });
        return INVALID;
      }
      const def = this._def;
      if (def.minSize !== null) {
        if (ctx.data.size < def.minSize.value) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            minimum: def.minSize.value,
            type: "set",
            inclusive: true,
            exact: false,
            message: def.minSize.message
          });
          status.dirty();
        }
      }
      if (def.maxSize !== null) {
        if (ctx.data.size > def.maxSize.value) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            maximum: def.maxSize.value,
            type: "set",
            inclusive: true,
            exact: false,
            message: def.maxSize.message
          });
          status.dirty();
        }
      }
      const valueType = this._def.valueType;
      function finalizeSet(elements2) {
        const parsedSet = /* @__PURE__ */ new Set();
        for (const element of elements2) {
          if (element.status === "aborted")
            return INVALID;
          if (element.status === "dirty")
            status.dirty();
          parsedSet.add(element.value);
        }
        return { status: status.value, value: parsedSet };
      }
      const elements = [...ctx.data.values()].map((item, i) => valueType._parse(new ParseInputLazyPath(ctx, item, ctx.path, i)));
      if (ctx.common.async) {
        return Promise.all(elements).then((elements2) => finalizeSet(elements2));
      } else {
        return finalizeSet(elements);
      }
    }
    min(minSize, message) {
      return new _ZodSet({
        ...this._def,
        minSize: { value: minSize, message: errorUtil.toString(message) }
      });
    }
    max(maxSize, message) {
      return new _ZodSet({
        ...this._def,
        maxSize: { value: maxSize, message: errorUtil.toString(message) }
      });
    }
    size(size, message) {
      return this.min(size, message).max(size, message);
    }
    nonempty(message) {
      return this.min(1, message);
    }
  };
  ZodSet.create = (valueType, params) => {
    return new ZodSet({
      valueType,
      minSize: null,
      maxSize: null,
      typeName: ZodFirstPartyTypeKind.ZodSet,
      ...processCreateParams(params)
    });
  };
  var ZodFunction = class _ZodFunction extends ZodType {
    constructor() {
      super(...arguments);
      this.validate = this.implement;
    }
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.function) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.function,
          received: ctx.parsedType
        });
        return INVALID;
      }
      function makeArgsIssue(args, error) {
        return makeIssue({
          data: args,
          path: ctx.path,
          errorMaps: [ctx.common.contextualErrorMap, ctx.schemaErrorMap, getErrorMap(), en_default].filter((x) => !!x),
          issueData: {
            code: ZodIssueCode.invalid_arguments,
            argumentsError: error
          }
        });
      }
      function makeReturnsIssue(returns, error) {
        return makeIssue({
          data: returns,
          path: ctx.path,
          errorMaps: [ctx.common.contextualErrorMap, ctx.schemaErrorMap, getErrorMap(), en_default].filter((x) => !!x),
          issueData: {
            code: ZodIssueCode.invalid_return_type,
            returnTypeError: error
          }
        });
      }
      const params = { errorMap: ctx.common.contextualErrorMap };
      const fn = ctx.data;
      if (this._def.returns instanceof ZodPromise) {
        const me = this;
        return OK(async function(...args) {
          const error = new ZodError([]);
          const parsedArgs = await me._def.args.parseAsync(args, params).catch((e) => {
            error.addIssue(makeArgsIssue(args, e));
            throw error;
          });
          const result = await Reflect.apply(fn, this, parsedArgs);
          const parsedReturns = await me._def.returns._def.type.parseAsync(result, params).catch((e) => {
            error.addIssue(makeReturnsIssue(result, e));
            throw error;
          });
          return parsedReturns;
        });
      } else {
        const me = this;
        return OK(function(...args) {
          const parsedArgs = me._def.args.safeParse(args, params);
          if (!parsedArgs.success) {
            throw new ZodError([makeArgsIssue(args, parsedArgs.error)]);
          }
          const result = Reflect.apply(fn, this, parsedArgs.data);
          const parsedReturns = me._def.returns.safeParse(result, params);
          if (!parsedReturns.success) {
            throw new ZodError([makeReturnsIssue(result, parsedReturns.error)]);
          }
          return parsedReturns.data;
        });
      }
    }
    parameters() {
      return this._def.args;
    }
    returnType() {
      return this._def.returns;
    }
    args(...items) {
      return new _ZodFunction({
        ...this._def,
        args: ZodTuple.create(items).rest(ZodUnknown.create())
      });
    }
    returns(returnType) {
      return new _ZodFunction({
        ...this._def,
        returns: returnType
      });
    }
    implement(func) {
      const validatedFunc = this.parse(func);
      return validatedFunc;
    }
    strictImplement(func) {
      const validatedFunc = this.parse(func);
      return validatedFunc;
    }
    static create(args, returns, params) {
      return new _ZodFunction({
        args: args ? args : ZodTuple.create([]).rest(ZodUnknown.create()),
        returns: returns || ZodUnknown.create(),
        typeName: ZodFirstPartyTypeKind.ZodFunction,
        ...processCreateParams(params)
      });
    }
  };
  var ZodLazy = class extends ZodType {
    get schema() {
      return this._def.getter();
    }
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      const lazySchema = this._def.getter();
      return lazySchema._parse({ data: ctx.data, path: ctx.path, parent: ctx });
    }
  };
  ZodLazy.create = (getter, params) => {
    return new ZodLazy({
      getter,
      typeName: ZodFirstPartyTypeKind.ZodLazy,
      ...processCreateParams(params)
    });
  };
  var ZodLiteral = class extends ZodType {
    _parse(input) {
      if (input.data !== this._def.value) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          received: ctx.data,
          code: ZodIssueCode.invalid_literal,
          expected: this._def.value
        });
        return INVALID;
      }
      return { status: "valid", value: input.data };
    }
    get value() {
      return this._def.value;
    }
  };
  ZodLiteral.create = (value, params) => {
    return new ZodLiteral({
      value,
      typeName: ZodFirstPartyTypeKind.ZodLiteral,
      ...processCreateParams(params)
    });
  };
  function createZodEnum(values, params) {
    return new ZodEnum({
      values,
      typeName: ZodFirstPartyTypeKind.ZodEnum,
      ...processCreateParams(params)
    });
  }
  var ZodEnum = class _ZodEnum extends ZodType {
    _parse(input) {
      if (typeof input.data !== "string") {
        const ctx = this._getOrReturnCtx(input);
        const expectedValues = this._def.values;
        addIssueToContext(ctx, {
          expected: util.joinValues(expectedValues),
          received: ctx.parsedType,
          code: ZodIssueCode.invalid_type
        });
        return INVALID;
      }
      if (!this._cache) {
        this._cache = new Set(this._def.values);
      }
      if (!this._cache.has(input.data)) {
        const ctx = this._getOrReturnCtx(input);
        const expectedValues = this._def.values;
        addIssueToContext(ctx, {
          received: ctx.data,
          code: ZodIssueCode.invalid_enum_value,
          options: expectedValues
        });
        return INVALID;
      }
      return OK(input.data);
    }
    get options() {
      return this._def.values;
    }
    get enum() {
      const enumValues = {};
      for (const val of this._def.values) {
        enumValues[val] = val;
      }
      return enumValues;
    }
    get Values() {
      const enumValues = {};
      for (const val of this._def.values) {
        enumValues[val] = val;
      }
      return enumValues;
    }
    get Enum() {
      const enumValues = {};
      for (const val of this._def.values) {
        enumValues[val] = val;
      }
      return enumValues;
    }
    extract(values, newDef = this._def) {
      return _ZodEnum.create(values, {
        ...this._def,
        ...newDef
      });
    }
    exclude(values, newDef = this._def) {
      return _ZodEnum.create(this.options.filter((opt) => !values.includes(opt)), {
        ...this._def,
        ...newDef
      });
    }
  };
  ZodEnum.create = createZodEnum;
  var ZodNativeEnum = class extends ZodType {
    _parse(input) {
      const nativeEnumValues = util.getValidEnumValues(this._def.values);
      const ctx = this._getOrReturnCtx(input);
      if (ctx.parsedType !== ZodParsedType.string && ctx.parsedType !== ZodParsedType.number) {
        const expectedValues = util.objectValues(nativeEnumValues);
        addIssueToContext(ctx, {
          expected: util.joinValues(expectedValues),
          received: ctx.parsedType,
          code: ZodIssueCode.invalid_type
        });
        return INVALID;
      }
      if (!this._cache) {
        this._cache = new Set(util.getValidEnumValues(this._def.values));
      }
      if (!this._cache.has(input.data)) {
        const expectedValues = util.objectValues(nativeEnumValues);
        addIssueToContext(ctx, {
          received: ctx.data,
          code: ZodIssueCode.invalid_enum_value,
          options: expectedValues
        });
        return INVALID;
      }
      return OK(input.data);
    }
    get enum() {
      return this._def.values;
    }
  };
  ZodNativeEnum.create = (values, params) => {
    return new ZodNativeEnum({
      values,
      typeName: ZodFirstPartyTypeKind.ZodNativeEnum,
      ...processCreateParams(params)
    });
  };
  var ZodPromise = class extends ZodType {
    unwrap() {
      return this._def.type;
    }
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.promise && ctx.common.async === false) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.promise,
          received: ctx.parsedType
        });
        return INVALID;
      }
      const promisified = ctx.parsedType === ZodParsedType.promise ? ctx.data : Promise.resolve(ctx.data);
      return OK(promisified.then((data) => {
        return this._def.type.parseAsync(data, {
          path: ctx.path,
          errorMap: ctx.common.contextualErrorMap
        });
      }));
    }
  };
  ZodPromise.create = (schema, params) => {
    return new ZodPromise({
      type: schema,
      typeName: ZodFirstPartyTypeKind.ZodPromise,
      ...processCreateParams(params)
    });
  };
  var ZodEffects = class extends ZodType {
    innerType() {
      return this._def.schema;
    }
    sourceType() {
      return this._def.schema._def.typeName === ZodFirstPartyTypeKind.ZodEffects ? this._def.schema.sourceType() : this._def.schema;
    }
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      const effect = this._def.effect || null;
      const checkCtx = {
        addIssue: (arg) => {
          addIssueToContext(ctx, arg);
          if (arg.fatal) {
            status.abort();
          } else {
            status.dirty();
          }
        },
        get path() {
          return ctx.path;
        }
      };
      checkCtx.addIssue = checkCtx.addIssue.bind(checkCtx);
      if (effect.type === "preprocess") {
        const processed = effect.transform(ctx.data, checkCtx);
        if (ctx.common.async) {
          return Promise.resolve(processed).then(async (processed2) => {
            if (status.value === "aborted")
              return INVALID;
            const result = await this._def.schema._parseAsync({
              data: processed2,
              path: ctx.path,
              parent: ctx
            });
            if (result.status === "aborted")
              return INVALID;
            if (result.status === "dirty")
              return DIRTY(result.value);
            if (status.value === "dirty")
              return DIRTY(result.value);
            return result;
          });
        } else {
          if (status.value === "aborted")
            return INVALID;
          const result = this._def.schema._parseSync({
            data: processed,
            path: ctx.path,
            parent: ctx
          });
          if (result.status === "aborted")
            return INVALID;
          if (result.status === "dirty")
            return DIRTY(result.value);
          if (status.value === "dirty")
            return DIRTY(result.value);
          return result;
        }
      }
      if (effect.type === "refinement") {
        const executeRefinement = (acc) => {
          const result = effect.refinement(acc, checkCtx);
          if (ctx.common.async) {
            return Promise.resolve(result);
          }
          if (result instanceof Promise) {
            throw new Error("Async refinement encountered during synchronous parse operation. Use .parseAsync instead.");
          }
          return acc;
        };
        if (ctx.common.async === false) {
          const inner = this._def.schema._parseSync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          });
          if (inner.status === "aborted")
            return INVALID;
          if (inner.status === "dirty")
            status.dirty();
          executeRefinement(inner.value);
          return { status: status.value, value: inner.value };
        } else {
          return this._def.schema._parseAsync({ data: ctx.data, path: ctx.path, parent: ctx }).then((inner) => {
            if (inner.status === "aborted")
              return INVALID;
            if (inner.status === "dirty")
              status.dirty();
            return executeRefinement(inner.value).then(() => {
              return { status: status.value, value: inner.value };
            });
          });
        }
      }
      if (effect.type === "transform") {
        if (ctx.common.async === false) {
          const base = this._def.schema._parseSync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          });
          if (!isValid(base))
            return INVALID;
          const result = effect.transform(base.value, checkCtx);
          if (result instanceof Promise) {
            throw new Error(`Asynchronous transform encountered during synchronous parse operation. Use .parseAsync instead.`);
          }
          return { status: status.value, value: result };
        } else {
          return this._def.schema._parseAsync({ data: ctx.data, path: ctx.path, parent: ctx }).then((base) => {
            if (!isValid(base))
              return INVALID;
            return Promise.resolve(effect.transform(base.value, checkCtx)).then((result) => ({
              status: status.value,
              value: result
            }));
          });
        }
      }
      util.assertNever(effect);
    }
  };
  ZodEffects.create = (schema, effect, params) => {
    return new ZodEffects({
      schema,
      typeName: ZodFirstPartyTypeKind.ZodEffects,
      effect,
      ...processCreateParams(params)
    });
  };
  ZodEffects.createWithPreprocess = (preprocess, schema, params) => {
    return new ZodEffects({
      schema,
      effect: { type: "preprocess", transform: preprocess },
      typeName: ZodFirstPartyTypeKind.ZodEffects,
      ...processCreateParams(params)
    });
  };
  var ZodOptional = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType === ZodParsedType.undefined) {
        return OK(void 0);
      }
      return this._def.innerType._parse(input);
    }
    unwrap() {
      return this._def.innerType;
    }
  };
  ZodOptional.create = (type, params) => {
    return new ZodOptional({
      innerType: type,
      typeName: ZodFirstPartyTypeKind.ZodOptional,
      ...processCreateParams(params)
    });
  };
  var ZodNullable = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType === ZodParsedType.null) {
        return OK(null);
      }
      return this._def.innerType._parse(input);
    }
    unwrap() {
      return this._def.innerType;
    }
  };
  ZodNullable.create = (type, params) => {
    return new ZodNullable({
      innerType: type,
      typeName: ZodFirstPartyTypeKind.ZodNullable,
      ...processCreateParams(params)
    });
  };
  var ZodDefault = class extends ZodType {
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      let data = ctx.data;
      if (ctx.parsedType === ZodParsedType.undefined) {
        data = this._def.defaultValue();
      }
      return this._def.innerType._parse({
        data,
        path: ctx.path,
        parent: ctx
      });
    }
    removeDefault() {
      return this._def.innerType;
    }
  };
  ZodDefault.create = (type, params) => {
    return new ZodDefault({
      innerType: type,
      typeName: ZodFirstPartyTypeKind.ZodDefault,
      defaultValue: typeof params.default === "function" ? params.default : () => params.default,
      ...processCreateParams(params)
    });
  };
  var ZodCatch = class extends ZodType {
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      const newCtx = {
        ...ctx,
        common: {
          ...ctx.common,
          issues: []
        }
      };
      const result = this._def.innerType._parse({
        data: newCtx.data,
        path: newCtx.path,
        parent: {
          ...newCtx
        }
      });
      if (isAsync(result)) {
        return result.then((result2) => {
          return {
            status: "valid",
            value: result2.status === "valid" ? result2.value : this._def.catchValue({
              get error() {
                return new ZodError(newCtx.common.issues);
              },
              input: newCtx.data
            })
          };
        });
      } else {
        return {
          status: "valid",
          value: result.status === "valid" ? result.value : this._def.catchValue({
            get error() {
              return new ZodError(newCtx.common.issues);
            },
            input: newCtx.data
          })
        };
      }
    }
    removeCatch() {
      return this._def.innerType;
    }
  };
  ZodCatch.create = (type, params) => {
    return new ZodCatch({
      innerType: type,
      typeName: ZodFirstPartyTypeKind.ZodCatch,
      catchValue: typeof params.catch === "function" ? params.catch : () => params.catch,
      ...processCreateParams(params)
    });
  };
  var ZodNaN = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.nan) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.nan,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return { status: "valid", value: input.data };
    }
  };
  ZodNaN.create = (params) => {
    return new ZodNaN({
      typeName: ZodFirstPartyTypeKind.ZodNaN,
      ...processCreateParams(params)
    });
  };
  var BRAND = Symbol("zod_brand");
  var ZodBranded = class extends ZodType {
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      const data = ctx.data;
      return this._def.type._parse({
        data,
        path: ctx.path,
        parent: ctx
      });
    }
    unwrap() {
      return this._def.type;
    }
  };
  var ZodPipeline = class _ZodPipeline extends ZodType {
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      if (ctx.common.async) {
        const handleAsync = async () => {
          const inResult = await this._def.in._parseAsync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          });
          if (inResult.status === "aborted")
            return INVALID;
          if (inResult.status === "dirty") {
            status.dirty();
            return DIRTY(inResult.value);
          } else {
            return this._def.out._parseAsync({
              data: inResult.value,
              path: ctx.path,
              parent: ctx
            });
          }
        };
        return handleAsync();
      } else {
        const inResult = this._def.in._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
        if (inResult.status === "aborted")
          return INVALID;
        if (inResult.status === "dirty") {
          status.dirty();
          return {
            status: "dirty",
            value: inResult.value
          };
        } else {
          return this._def.out._parseSync({
            data: inResult.value,
            path: ctx.path,
            parent: ctx
          });
        }
      }
    }
    static create(a, b) {
      return new _ZodPipeline({
        in: a,
        out: b,
        typeName: ZodFirstPartyTypeKind.ZodPipeline
      });
    }
  };
  var ZodReadonly = class extends ZodType {
    _parse(input) {
      const result = this._def.innerType._parse(input);
      const freeze = (data) => {
        if (isValid(data)) {
          data.value = Object.freeze(data.value);
        }
        return data;
      };
      return isAsync(result) ? result.then((data) => freeze(data)) : freeze(result);
    }
    unwrap() {
      return this._def.innerType;
    }
  };
  ZodReadonly.create = (type, params) => {
    return new ZodReadonly({
      innerType: type,
      typeName: ZodFirstPartyTypeKind.ZodReadonly,
      ...processCreateParams(params)
    });
  };
  function cleanParams(params, data) {
    const p = typeof params === "function" ? params(data) : typeof params === "string" ? { message: params } : params;
    const p2 = typeof p === "string" ? { message: p } : p;
    return p2;
  }
  function custom(check, _params = {}, fatal) {
    if (check)
      return ZodAny.create().superRefine((data, ctx) => {
        const r = check(data);
        if (r instanceof Promise) {
          return r.then((r2) => {
            if (!r2) {
              const params = cleanParams(_params, data);
              const _fatal = params.fatal ?? fatal ?? true;
              ctx.addIssue({ code: "custom", ...params, fatal: _fatal });
            }
          });
        }
        if (!r) {
          const params = cleanParams(_params, data);
          const _fatal = params.fatal ?? fatal ?? true;
          ctx.addIssue({ code: "custom", ...params, fatal: _fatal });
        }
        return;
      });
    return ZodAny.create();
  }
  var late = {
    object: ZodObject.lazycreate
  };
  var ZodFirstPartyTypeKind;
  (function(ZodFirstPartyTypeKind2) {
    ZodFirstPartyTypeKind2["ZodString"] = "ZodString";
    ZodFirstPartyTypeKind2["ZodNumber"] = "ZodNumber";
    ZodFirstPartyTypeKind2["ZodNaN"] = "ZodNaN";
    ZodFirstPartyTypeKind2["ZodBigInt"] = "ZodBigInt";
    ZodFirstPartyTypeKind2["ZodBoolean"] = "ZodBoolean";
    ZodFirstPartyTypeKind2["ZodDate"] = "ZodDate";
    ZodFirstPartyTypeKind2["ZodSymbol"] = "ZodSymbol";
    ZodFirstPartyTypeKind2["ZodUndefined"] = "ZodUndefined";
    ZodFirstPartyTypeKind2["ZodNull"] = "ZodNull";
    ZodFirstPartyTypeKind2["ZodAny"] = "ZodAny";
    ZodFirstPartyTypeKind2["ZodUnknown"] = "ZodUnknown";
    ZodFirstPartyTypeKind2["ZodNever"] = "ZodNever";
    ZodFirstPartyTypeKind2["ZodVoid"] = "ZodVoid";
    ZodFirstPartyTypeKind2["ZodArray"] = "ZodArray";
    ZodFirstPartyTypeKind2["ZodObject"] = "ZodObject";
    ZodFirstPartyTypeKind2["ZodUnion"] = "ZodUnion";
    ZodFirstPartyTypeKind2["ZodDiscriminatedUnion"] = "ZodDiscriminatedUnion";
    ZodFirstPartyTypeKind2["ZodIntersection"] = "ZodIntersection";
    ZodFirstPartyTypeKind2["ZodTuple"] = "ZodTuple";
    ZodFirstPartyTypeKind2["ZodRecord"] = "ZodRecord";
    ZodFirstPartyTypeKind2["ZodMap"] = "ZodMap";
    ZodFirstPartyTypeKind2["ZodSet"] = "ZodSet";
    ZodFirstPartyTypeKind2["ZodFunction"] = "ZodFunction";
    ZodFirstPartyTypeKind2["ZodLazy"] = "ZodLazy";
    ZodFirstPartyTypeKind2["ZodLiteral"] = "ZodLiteral";
    ZodFirstPartyTypeKind2["ZodEnum"] = "ZodEnum";
    ZodFirstPartyTypeKind2["ZodEffects"] = "ZodEffects";
    ZodFirstPartyTypeKind2["ZodNativeEnum"] = "ZodNativeEnum";
    ZodFirstPartyTypeKind2["ZodOptional"] = "ZodOptional";
    ZodFirstPartyTypeKind2["ZodNullable"] = "ZodNullable";
    ZodFirstPartyTypeKind2["ZodDefault"] = "ZodDefault";
    ZodFirstPartyTypeKind2["ZodCatch"] = "ZodCatch";
    ZodFirstPartyTypeKind2["ZodPromise"] = "ZodPromise";
    ZodFirstPartyTypeKind2["ZodBranded"] = "ZodBranded";
    ZodFirstPartyTypeKind2["ZodPipeline"] = "ZodPipeline";
    ZodFirstPartyTypeKind2["ZodReadonly"] = "ZodReadonly";
  })(ZodFirstPartyTypeKind || (ZodFirstPartyTypeKind = {}));
  var instanceOfType = (cls, params = {
    message: `Input not instance of ${cls.name}`
  }) => custom((data) => data instanceof cls, params);
  var stringType = ZodString.create;
  var numberType = ZodNumber.create;
  var nanType = ZodNaN.create;
  var bigIntType = ZodBigInt.create;
  var booleanType = ZodBoolean.create;
  var dateType = ZodDate.create;
  var symbolType = ZodSymbol.create;
  var undefinedType = ZodUndefined.create;
  var nullType = ZodNull.create;
  var anyType = ZodAny.create;
  var unknownType = ZodUnknown.create;
  var neverType = ZodNever.create;
  var voidType = ZodVoid.create;
  var arrayType = ZodArray.create;
  var objectType = ZodObject.create;
  var strictObjectType = ZodObject.strictCreate;
  var unionType = ZodUnion.create;
  var discriminatedUnionType = ZodDiscriminatedUnion.create;
  var intersectionType = ZodIntersection.create;
  var tupleType = ZodTuple.create;
  var recordType = ZodRecord.create;
  var mapType = ZodMap.create;
  var setType = ZodSet.create;
  var functionType = ZodFunction.create;
  var lazyType = ZodLazy.create;
  var literalType = ZodLiteral.create;
  var enumType = ZodEnum.create;
  var nativeEnumType = ZodNativeEnum.create;
  var promiseType = ZodPromise.create;
  var effectsType = ZodEffects.create;
  var optionalType = ZodOptional.create;
  var nullableType = ZodNullable.create;
  var preprocessType = ZodEffects.createWithPreprocess;
  var pipelineType = ZodPipeline.create;
  var ostring = () => stringType().optional();
  var onumber = () => numberType().optional();
  var oboolean = () => booleanType().optional();
  var coerce = {
    string: (arg) => ZodString.create({ ...arg, coerce: true }),
    number: (arg) => ZodNumber.create({ ...arg, coerce: true }),
    boolean: (arg) => ZodBoolean.create({
      ...arg,
      coerce: true
    }),
    bigint: (arg) => ZodBigInt.create({ ...arg, coerce: true }),
    date: (arg) => ZodDate.create({ ...arg, coerce: true })
  };
  var NEVER = INVALID;

  // ../shared/src/events.ts
  var eventTypeSchema = external_exports.enum([
    "ExtensionConnected",
    "LoginDetected",
    "JobDetected",
    "ApplicationRecorded",
    "SyncStarted",
    "SyncCompleted",
    "SyncFailed",
    "NotificationCreated"
  ]);
  var syncStatusSchema = external_exports.enum(["pending", "syncing", "synced", "failed"]);
  var platformSchema = external_exports.enum([
    "naukri",
    "linkedin",
    "foundit",
    "indeed",
    "wellfound",
    "internshala",
    "unknown"
  ]);
  var jobPayloadSchema = external_exports.object({
    platform: platformSchema,
    externalJobId: external_exports.string().optional(),
    title: external_exports.string().min(1),
    company: external_exports.string().min(1),
    location: external_exports.string().optional(),
    url: external_exports.string().url().optional(),
    companyLogo: external_exports.string().min(1).optional(),
    description: external_exports.string().max(12e3).optional(),
    experience: external_exports.string().optional(),
    salary: external_exports.string().optional(),
    skills: external_exports.array(external_exports.string()).max(60).optional(),
    rating: external_exports.string().optional(),
    reviews: external_exports.string().optional(),
    postedAt: external_exports.string().optional(),
    openings: external_exports.string().optional(),
    applicants: external_exports.string().optional(),
    highlights: external_exports.array(external_exports.string()).max(20).optional(),
    role: external_exports.string().optional(),
    industry: external_exports.string().optional(),
    department: external_exports.string().optional(),
    employmentType: external_exports.string().optional(),
    roleCategory: external_exports.string().optional(),
    education: external_exports.string().optional(),
    aboutCompany: external_exports.string().max(4e3).optional(),
    appliedAt: external_exports.string().datetime().optional(),
    status: external_exports.enum(["detected", "applied", "viewed", "saved"]).default("detected"),
    metadata: external_exports.record(external_exports.unknown()).optional()
  });
  var eventEnvelopeSchema = external_exports.object({
    eventId: external_exports.string().uuid(),
    timestamp: external_exports.string().datetime(),
    type: eventTypeSchema,
    payload: external_exports.record(external_exports.unknown()),
    retryCount: external_exports.number().int().nonnegative().default(0),
    syncStatus: syncStatusSchema.default("pending")
  });
  var syncEventsRequestSchema = external_exports.object({
    events: external_exports.array(eventEnvelopeSchema).min(1).max(100)
  });

  // ../shared/src/models.ts
  var registerSchema = external_exports.object({
    email: external_exports.string().email(),
    password: external_exports.string().min(8),
    name: external_exports.string().min(1).max(120)
  });
  var loginSchema = external_exports.object({
    email: external_exports.string().email(),
    password: external_exports.string().min(1)
  });
  var googleAuthSchema = external_exports.object({
    code: external_exports.string().min(1)
  });
  var planTierSchema = external_exports.enum(["free", "pro", "max"]);
  var userRoleSchema = external_exports.enum(["user", "admin"]);
  var userStatusSchema = external_exports.enum(["active", "suspended"]);
  var userSchema = external_exports.object({
    id: external_exports.string(),
    email: external_exports.string().email(),
    name: external_exports.string(),
    role: userRoleSchema.optional(),
    status: userStatusSchema.optional(),
    plan: planTierSchema.optional(),
    planExpiresAt: external_exports.string().datetime().optional(),
    createdAt: external_exports.string().datetime().optional(),
    extensionConnectedAt: external_exports.string().datetime().optional()
  });
  var paidPlanSchema = external_exports.enum(["pro", "max"]);
  var createBillingOrderSchema = external_exports.object({
    plan: paidPlanSchema
  });
  var verifyBillingPaymentSchema = external_exports.object({
    razorpay_order_id: external_exports.string().min(1),
    razorpay_payment_id: external_exports.string().min(1),
    razorpay_signature: external_exports.string().min(1),
    plan: paidPlanSchema
  });
  var billingFrequencySchema = external_exports.enum(["monthly", "yearly"]);
  var createSubscriptionSchema = external_exports.object({
    plan: paidPlanSchema,
    couponCode: external_exports.string().min(1).max(40).optional(),
    billingFrequency: billingFrequencySchema.optional().default("monthly")
  });
  var verifySubscriptionSchema = external_exports.object({
    razorpay_payment_id: external_exports.string().min(1),
    razorpay_subscription_id: external_exports.string().min(1),
    razorpay_signature: external_exports.string().min(1),
    plan: paidPlanSchema
  });
  var cancelSubscriptionSchema = external_exports.object({
    immediate: external_exports.boolean().optional().default(false)
  });
  var subscriptionStatusSchema = external_exports.enum([
    "created",
    "authenticated",
    "active",
    "pending",
    "halted",
    "cancelled",
    "completed",
    "expired"
  ]);
  var workModeSchema = external_exports.enum(["any", "office", "hybrid", "remote"]);
  var jobPreferencesSchema = external_exports.object({
    titles: external_exports.array(external_exports.string().min(1).max(120)).max(20).default([]),
    keywords: external_exports.array(external_exports.string().min(1).max(80)).max(30).default([]),
    locations: external_exports.array(external_exports.string().min(1).max(120)).max(20).default([]),
    experienceMin: external_exports.number().int().min(0).max(50).default(0),
    experienceMax: external_exports.number().int().min(0).max(50).default(5),
    minSalaryLpa: external_exports.number().min(0).max(500).optional(),
    workMode: workModeSchema.default("any"),
    autoScanEnabled: external_exports.boolean().default(true),
    autoApplyEnabled: external_exports.boolean().default(true)
  });
  var MIN_PREF_TITLES = 3;
  var MIN_PREF_KEYWORDS = 4;
  var jobPreferencesUpdateSchema = jobPreferencesSchema.superRefine(
    (prefs, ctx) => {
      if (prefs.titles.length < MIN_PREF_TITLES) {
        ctx.addIssue({
          code: external_exports.ZodIssueCode.custom,
          path: ["titles"],
          message: `Add at least ${MIN_PREF_TITLES} job titles`
        });
      }
      if (prefs.keywords.length < MIN_PREF_KEYWORDS) {
        ctx.addIssue({
          code: external_exports.ZodIssueCode.custom,
          path: ["keywords"],
          message: `Add at least ${MIN_PREF_KEYWORDS} keywords`
        });
      }
    }
  );
  var onboardingStatusSchema = external_exports.object({
    accountCreated: external_exports.boolean(),
    extensionConnected: external_exports.boolean(),
    preferencesCompleted: external_exports.boolean(),
    hasApplications: external_exports.boolean(),
    extensionConnectedAt: external_exports.string().datetime().optional()
  });
  var authTokensSchema = external_exports.object({
    accessToken: external_exports.string(),
    refreshToken: external_exports.string(),
    user: userSchema
  });
  var refreshTokenSchema = external_exports.object({
    refreshToken: external_exports.string().min(1)
  });
  var applicationStatusSchema = external_exports.enum([
    "detected",
    "applied",
    "viewed",
    "saved",
    "interview",
    "offer",
    "rejected"
  ]);
  var applicationMetadataSchema = external_exports.object({
    source: external_exports.enum(["manual", "auto_scan", "auto_apply"]).optional(),
    skipReason: external_exports.string().optional(),
    skipped: external_exports.boolean().optional(),
    companySiteApply: external_exports.boolean().optional()
  }).passthrough();
  var applicationSchema = external_exports.object({
    id: external_exports.string(),
    eventId: external_exports.string(),
    userId: external_exports.string(),
    platform: platformSchema,
    externalJobId: external_exports.string().optional(),
    title: external_exports.string(),
    company: external_exports.string(),
    location: external_exports.string().optional(),
    url: external_exports.string().optional(),
    companyLogo: external_exports.string().optional(),
    description: external_exports.string().optional(),
    experience: external_exports.string().optional(),
    salary: external_exports.string().optional(),
    skills: external_exports.array(external_exports.string()).optional(),
    rating: external_exports.string().optional(),
    reviews: external_exports.string().optional(),
    postedAt: external_exports.string().optional(),
    openings: external_exports.string().optional(),
    applicants: external_exports.string().optional(),
    highlights: external_exports.array(external_exports.string()).optional(),
    role: external_exports.string().optional(),
    industry: external_exports.string().optional(),
    department: external_exports.string().optional(),
    employmentType: external_exports.string().optional(),
    roleCategory: external_exports.string().optional(),
    education: external_exports.string().optional(),
    aboutCompany: external_exports.string().optional(),
    status: applicationStatusSchema,
    appliedAt: external_exports.string().datetime().optional(),
    metadata: applicationMetadataSchema.optional(),
    createdAt: external_exports.string().datetime(),
    updatedAt: external_exports.string().datetime()
  });

  // ../shared/src/admin.ts
  var dayKeySchema = external_exports.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Use YYYY-MM-DD");
  var adminUsersQuerySchema = external_exports.object({
    q: external_exports.string().optional(),
    plan: planTierSchema.optional(),
    role: external_exports.enum(["user", "admin"]).optional(),
    status: external_exports.enum(["active", "suspended"]).optional(),
    /** Inclusive UTC signup day (YYYY-MM-DD). */
    from: dayKeySchema.optional(),
    /** Inclusive UTC signup day (YYYY-MM-DD). */
    to: dayKeySchema.optional(),
    page: external_exports.coerce.number().int().min(1).default(1),
    limit: external_exports.coerce.number().int().min(1).max(100).default(10)
  });
  var adminPatchUserSchema = external_exports.object({
    name: external_exports.string().min(1).max(120).optional(),
    email: external_exports.string().email().optional(),
    role: external_exports.enum(["user", "admin"]).optional(),
    status: external_exports.enum(["active", "suspended"]).optional()
  });
  var adminSetPlanSchema = external_exports.object({
    action: external_exports.enum(["grant", "extend", "revoke"]),
    plan: paidPlanSchema.optional(),
    days: external_exports.number().int().min(1).max(3650).optional()
  });
  var adminSubscriptionsQuerySchema = external_exports.object({
    status: external_exports.string().optional(),
    tier: paidPlanSchema.optional(),
    page: external_exports.coerce.number().int().min(1).default(1),
    limit: external_exports.coerce.number().int().min(1).max(100).default(20)
  });
  var adminExtendSubscriptionSchema = external_exports.object({
    days: external_exports.number().int().min(1).max(3650)
  });
  var adminPaymentsQuerySchema = external_exports.object({
    status: external_exports.enum(["created", "paid", "failed"]).optional(),
    plan: paidPlanSchema.optional(),
    from: external_exports.string().datetime().optional(),
    to: external_exports.string().datetime().optional(),
    page: external_exports.coerce.number().int().min(1).default(1),
    limit: external_exports.coerce.number().int().min(1).max(100).default(20)
  });
  var adminUpdatePlanSchema = external_exports.object({
    name: external_exports.string().min(1).max(80).optional(),
    description: external_exports.string().max(500).optional(),
    amountPaise: external_exports.number().int().min(0).optional(),
    compareAtPaise: external_exports.number().int().min(0).nullable().optional(),
    features: external_exports.array(external_exports.string().min(1).max(160)).max(20).optional(),
    badge: external_exports.string().max(40).nullable().optional(),
    highlighted: external_exports.boolean().optional(),
    lockNote: external_exports.string().max(160).nullable().optional(),
    active: external_exports.boolean().optional(),
    limits: external_exports.object({
      monthlyApplies: external_exports.number().int().min(0),
      monthlyScans: external_exports.number().int().min(0),
      appliesPerHour: external_exports.number().int().min(0),
      appliesPerDay: external_exports.number().int().min(0)
    }).optional()
  });
  var adminAuditQuerySchema = external_exports.object({
    page: external_exports.coerce.number().int().min(1).default(1),
    limit: external_exports.coerce.number().int().min(1).max(100).default(40)
  });
  var adminMetricsQuerySchema = external_exports.object({
    /** Preset window or calendar month/year. `days` kept for backward compatibility. */
    range: external_exports.enum(["7d", "30d", "90d", "month", "year", "all"]).optional(),
    days: external_exports.coerce.number().int().min(7).max(90).optional(),
    year: external_exports.coerce.number().int().min(2020).max(2100).optional(),
    month: external_exports.coerce.number().int().min(1).max(12).optional()
  });
  var adminImpersonateResultSchema = external_exports.object({
    accessToken: external_exports.string(),
    expiresInSeconds: external_exports.number().int().positive(),
    user: external_exports.object({
      id: external_exports.string(),
      email: external_exports.string().email(),
      name: external_exports.string(),
      role: external_exports.enum(["user", "admin"]),
      status: external_exports.enum(["active", "suspended"]),
      plan: external_exports.enum(["free", "pro", "max"]),
      planExpiresAt: external_exports.string().optional(),
      createdAt: external_exports.string().optional(),
      extensionConnectedAt: external_exports.string().optional()
    })
  });

  // ../shared/src/api.ts
  var apiErrorSchema = external_exports.object({
    success: external_exports.literal(false),
    message: external_exports.string(),
    data: external_exports.null(),
    error: external_exports.object({
      code: external_exports.string().optional(),
      details: external_exports.unknown().optional()
    }).nullable()
  });

  // ../shared/src/applySafety.ts
  var CONSENT_VERSION = 1;
  var SESSION_BREAK_MS = 2 * 60 * 1e3;
  var STEALTH_MAX_MS = 20 * 60 * 1e3;
  var STEALTH_COOLDOWN_MS = 30 * 60 * 1e3;
  var BLOCK_COOLDOWN_MS = 60 * 60 * 1e3;

  // ../shared/src/catalog.ts
  var planLimitsSchema = external_exports.object({
    monthlyApplies: external_exports.number().int().min(0),
    monthlyScans: external_exports.number().int().min(0),
    appliesPerHour: external_exports.number().int().min(0),
    appliesPerDay: external_exports.number().int().min(0)
  });
  var publicPlanSchema = external_exports.object({
    tier: planTierSchema,
    name: external_exports.string(),
    description: external_exports.string(),
    amountPaise: external_exports.number().int().min(0),
    compareAtPaise: external_exports.number().int().min(0).nullable().optional(),
    features: external_exports.array(external_exports.string()).default([]),
    badge: external_exports.string().nullable().optional(),
    highlighted: external_exports.boolean().optional(),
    lockNote: external_exports.string().nullable().optional(),
    limits: planLimitsSchema,
    active: external_exports.boolean()
  });
  var offerImageUrlSchema = external_exports.string().max(35e4).nullable().optional().refine(
    (v) => v == null || v === "" || /^https?:\/\//i.test(v) || /^data:image\/(png|jpe?g|webp|gif);base64,/i.test(v),
    { message: "imageUrl must be an http(s) or data:image URL" }
  );
  var siteOfferSchema = external_exports.object({
    offerId: external_exports.string(),
    message: external_exports.string().min(1).max(280),
    couponCode: external_exports.string().max(40).nullable().optional(),
    linkUrl: external_exports.string().url().nullable().optional(),
    /** Custom ticker mark (drag-drop). Falls back to default bird when empty. */
    imageUrl: offerImageUrlSchema,
    /** Show the freedom-bird / custom image mark in the site banner. */
    showBird: external_exports.boolean().default(true),
    /** Show one Indian flag in the site banner. */
    showFlag: external_exports.boolean().default(true),
    active: external_exports.boolean(),
    startsAt: external_exports.string().datetime().nullable().optional(),
    endsAt: external_exports.string().datetime().nullable().optional(),
    priority: external_exports.number().int().default(0),
    createdAt: external_exports.string().optional(),
    updatedAt: external_exports.string().optional()
  });
  var adminCreateSiteOfferSchema = external_exports.object({
    message: external_exports.string().min(1).max(280),
    couponCode: external_exports.string().max(40).optional().nullable(),
    linkUrl: external_exports.union([external_exports.string().url(), external_exports.literal(""), external_exports.null()]).optional().transform((v) => v === "" || v === void 0 ? null : v),
    imageUrl: offerImageUrlSchema.transform(
      (v) => v === "" || v === void 0 ? null : v
    ),
    showBird: external_exports.boolean().default(true),
    showFlag: external_exports.boolean().default(true),
    active: external_exports.boolean().default(true),
    startsAt: external_exports.string().datetime().optional().nullable(),
    endsAt: external_exports.string().datetime().optional().nullable(),
    priority: external_exports.number().int().default(0)
  });
  var adminUpdateSiteOfferSchema = adminCreateSiteOfferSchema.partial();
  var bannerLinkUrlSchema = external_exports.union([
    external_exports.string().url(),
    external_exports.string().regex(/^\/[\w#?&=./%-]*$/, "Must be a URL or path starting with /"),
    external_exports.literal(""),
    external_exports.null()
  ]).optional().transform((v) => v === "" || v === void 0 ? null : v);
  var siteBannerSchema = external_exports.object({
    bannerId: external_exports.string(),
    imageUrl: external_exports.string().min(1).max(35e4).refine(
      (v) => /^https?:\/\//i.test(v) || /^data:image\/(png|jpe?g|webp|gif);base64,/i.test(v),
      { message: "imageUrl must be an http(s) or data:image URL" }
    ),
    linkUrl: external_exports.string().nullable().optional().refine(
      (v) => v == null || v === "" || /^https?:\/\//i.test(v) || /^\//.test(v),
      { message: "linkUrl must be http(s) or a path starting with /" }
    ),
    altText: external_exports.string().max(160).nullable().optional(),
    active: external_exports.boolean(),
    priority: external_exports.number().int().default(0),
    createdAt: external_exports.string().optional(),
    updatedAt: external_exports.string().optional()
  });
  var adminCreateSiteBannerSchema = external_exports.object({
    imageUrl: external_exports.string().min(1).max(35e4).refine(
      (v) => /^https?:\/\//i.test(v) || /^data:image\/(png|jpe?g|webp|gif);base64,/i.test(v),
      { message: "imageUrl must be an http(s) or data:image URL" }
    ),
    linkUrl: bannerLinkUrlSchema,
    altText: external_exports.string().max(160).optional().nullable(),
    active: external_exports.boolean().default(true),
    priority: external_exports.number().int().default(0)
  });
  var adminUpdateSiteBannerSchema = adminCreateSiteBannerSchema.partial();
  var couponTypeSchema = external_exports.enum(["percent", "fixedPaise"]);
  var couponSchema = external_exports.object({
    code: external_exports.string().min(2).max(40),
    type: couponTypeSchema,
    value: external_exports.number().int().positive(),
    applicablePlans: external_exports.array(paidPlanSchema).min(1),
    maxRedemptions: external_exports.number().int().positive().nullable().optional(),
    redemptionCount: external_exports.number().int().min(0).default(0),
    perUserLimit: external_exports.number().int().positive().default(1),
    active: external_exports.boolean(),
    startsAt: external_exports.string().datetime().nullable().optional(),
    endsAt: external_exports.string().datetime().nullable().optional(),
    description: external_exports.string().max(500).optional().nullable(),
    createdAt: external_exports.string().optional(),
    updatedAt: external_exports.string().optional()
  });
  var adminCreateCouponSchema = external_exports.object({
    code: external_exports.string().min(2).max(40).transform((s) => s.trim().toUpperCase()),
    type: couponTypeSchema,
    value: external_exports.number().int().positive(),
    applicablePlans: external_exports.array(paidPlanSchema).min(1).default(["pro", "max"]),
    maxRedemptions: external_exports.number().int().positive().optional().nullable(),
    perUserLimit: external_exports.number().int().positive().default(1),
    active: external_exports.boolean().default(true),
    startsAt: external_exports.string().datetime().optional().nullable(),
    endsAt: external_exports.string().datetime().optional().nullable(),
    description: external_exports.string().max(500).optional().nullable()
  });
  var adminUpdateCouponSchema = external_exports.object({
    type: couponTypeSchema.optional(),
    value: external_exports.number().int().positive().optional(),
    applicablePlans: external_exports.array(paidPlanSchema).min(1).optional(),
    maxRedemptions: external_exports.number().int().positive().optional().nullable(),
    perUserLimit: external_exports.number().int().positive().optional(),
    active: external_exports.boolean().optional(),
    startsAt: external_exports.string().datetime().optional().nullable(),
    endsAt: external_exports.string().datetime().optional().nullable(),
    description: external_exports.string().max(500).optional().nullable()
  });
  var validateCouponSchema = external_exports.object({
    code: external_exports.string().min(1).max(40),
    plan: paidPlanSchema,
    billingFrequency: billingFrequencySchema.optional().default("monthly")
  });
  var validateCouponResultSchema = external_exports.object({
    code: external_exports.string(),
    plan: paidPlanSchema,
    originalAmountPaise: external_exports.number().int().min(0),
    discountPaise: external_exports.number().int().min(0),
    finalAmountPaise: external_exports.number().int().min(0),
    label: external_exports.string()
  });

  // ../shared/src/companies.ts
  var companySummarySchema = external_exports.object({
    key: external_exports.string(),
    name: external_exports.string(),
    companyLogo: external_exports.string().optional(),
    aboutCompany: external_exports.string().optional(),
    opportunityCount: external_exports.number().int().nonnegative()
  });
  var companyDetailSchema = companySummarySchema;
  var companyJobSchema = external_exports.object({
    id: external_exports.string(),
    platform: platformSchema,
    externalJobId: external_exports.string().optional(),
    title: external_exports.string(),
    company: external_exports.string(),
    companyLogo: external_exports.string().optional(),
    location: external_exports.string().optional(),
    url: external_exports.string().optional(),
    description: external_exports.string().optional(),
    snippet: external_exports.string().optional(),
    experience: external_exports.string().optional(),
    salary: external_exports.string().optional(),
    postedAt: external_exports.string().optional(),
    role: external_exports.string().optional(),
    department: external_exports.string().optional(),
    industry: external_exports.string().optional(),
    employmentType: external_exports.string().optional()
  });
  var companiesListResponseSchema = external_exports.object({
    items: external_exports.array(companySummarySchema),
    total: external_exports.number().int().nonnegative(),
    page: external_exports.number().int().positive(),
    limit: external_exports.number().int().positive(),
    totalPages: external_exports.number().int().nonnegative()
  });
  var companyJobsListResponseSchema = external_exports.object({
    company: companyDetailSchema,
    items: external_exports.array(companyJobSchema),
    total: external_exports.number().int().nonnegative(),
    page: external_exports.number().int().positive(),
    limit: external_exports.number().int().positive(),
    totalPages: external_exports.number().int().nonnegative()
  });

  // ../shared/src/feedback.ts
  var uninstallReasonSchema = external_exports.enum([
    "not_useful",
    "bugs",
    "too_expensive",
    "privacy",
    "switched",
    "other"
  ]);
  var uninstallFeedbackSubmitSchema = external_exports.object({
    reason: uninstallReasonSchema,
    comment: external_exports.string().trim().max(1e3).optional().or(external_exports.literal("")),
    email: external_exports.string().trim().email().max(200).optional().or(external_exports.literal("")),
    extensionVersion: external_exports.string().trim().max(40).optional().or(external_exports.literal("")),
    browser: external_exports.string().trim().max(40).optional().or(external_exports.literal("")),
    source: external_exports.enum(["chrome", "edge", "firefox", "other"]).optional().default("chrome")
  });
  var adminUninstallFeedbackQuerySchema = external_exports.object({
    page: external_exports.coerce.number().int().min(1).default(1),
    limit: external_exports.coerce.number().int().min(1).max(100).default(40),
    reason: uninstallReasonSchema.optional()
  });

  // ../shared/src/preferenceSuggestions.ts
  var TITLE_SUGGESTIONS = [
    "Software Engineer",
    "Software Developer",
    "Senior Software Engineer",
    "Junior Software Engineer",
    "Full Stack Developer",
    "Full Stack Engineer",
    "Frontend Developer",
    "Frontend Engineer",
    "Backend Developer",
    "Backend Engineer",
    "Java Developer",
    "Java Full Stack Developer",
    "Python Developer",
    "Python Full Stack Developer",
    "React Developer",
    "React.js Developer",
    "Node.js Developer",
    "Angular Developer",
    "Dot Net Developer",
    ".NET Developer",
    "Android Developer",
    "iOS Developer",
    "Mobile App Developer",
    "DevOps Engineer",
    "SRE Engineer",
    "Cloud Engineer",
    "AWS Developer",
    "Data Engineer",
    "Data Scientist",
    "Data Analyst",
    "Machine Learning Engineer",
    "AI Engineer",
    "QA Engineer",
    "SDET",
    "Test Engineer",
    "Automation Test Engineer",
    "Business Analyst",
    "Product Manager",
    "Project Manager",
    "Technical Lead",
    "Tech Lead",
    "Engineering Manager",
    "UI Developer",
    "UI UX Designer",
    "UX Designer",
    "System Engineer",
    "Associate Software Engineer",
    "Graduate Engineer Trainee",
    "Software Development Engineer",
    "SDE",
    "SDE 1",
    "SDE 2",
    "Platform Engineer",
    "Security Engineer",
    "Database Administrator",
    "SQL Developer",
    "ETL Developer",
    "Salesforce Developer",
    "SAP Consultant",
    "Support Engineer",
    "Application Support Engineer",
    "AI ML Engineer",
    "GenAI Engineer",
    "LLM Engineer",
    "MLOps Engineer",
    "Prompt Engineer",
    "Artificial Intelligence Engineer",
    "Deep Learning Engineer",
    "Computer Vision Engineer",
    "NLP Engineer",
    "Search Engineer",
    "Data Architect",
    "Analytics Engineer",
    "BI Developer",
    "Business Intelligence Analyst",
    "Power BI Developer",
    "Tableau Developer",
    "Big Data Engineer",
    "Big Data Architect",
    "Snowflake Developer",
    "Databricks Engineer",
    "Azure Data Engineer",
    "AWS Data Engineer",
    "Cloud Architect",
    "AWS Solutions Architect",
    "Azure Solutions Architect",
    "GCP Cloud Engineer",
    "AWS DevOps Engineer",
    "Azure DevOps Engineer",
    "GCP DevOps Engineer",
    "Site Reliability Engineer",
    "DevSecOps Engineer",
    "Kubernetes Engineer",
    "Terraform Engineer",
    "Infrastructure Engineer",
    "Network Engineer",
    "System Administrator",
    "Systems Engineer",
    "Cybersecurity Analyst",
    "Cyber Security Engineer",
    "Information Security Analyst",
    "Cloud Security Engineer",
    "Application Security Engineer",
    "Penetration Tester",
    "Ethical Hacker",
    "SOC Analyst",
    "Security Architect",
    "Blockchain Developer",
    "Solidity Developer",
    "Web3 Developer",
    "Flutter Developer",
    "React Native Developer",
    "Kotlin Developer",
    "Swift Developer",
    "PHP Developer",
    "Laravel Developer",
    "Ruby on Rails Developer",
    "Go Developer",
    "Golang Developer",
    "C++ Developer",
    "C# Developer",
    "Scala Developer",
    "Rust Developer",
    "Perl Developer",
    "MuleSoft Developer",
    "ServiceNow Developer",
    "SharePoint Developer",
    "WordPress Developer",
    "Web Developer",
    "MERN Stack Developer",
    "MEAN Stack Developer",
    "JavaScript Developer",
    "TypeScript Developer",
    "Next.js Developer",
    "Vue.js Developer",
    "UI Engineer",
    "UX Researcher",
    "Product Designer",
    "Graphic Designer",
    "Visual Designer",
    "Solutions Architect",
    "Software Architect",
    "Enterprise Architect",
    "Technical Architect",
    "Principal Software Engineer",
    "Staff Software Engineer",
    "Lead Software Engineer",
    "Team Lead",
    "Engineering Lead",
    "Delivery Manager",
    "Program Manager",
    "Scrum Master",
    "Agile Coach",
    "Product Owner",
    "Technical Product Manager",
    "Associate Product Manager",
    "Growth Product Manager",
    "IT Project Manager",
    "Technical Project Manager",
    "Quality Analyst",
    "Manual Test Engineer",
    "Performance Test Engineer",
    "QA Lead",
    "Test Lead",
    "Automation Engineer",
    "Selenium Tester",
    "API Test Engineer",
    "Production Support Engineer",
    "L1 Support Engineer",
    "L2 Support Engineer",
    "L3 Support Engineer",
    "IT Support Engineer",
    "Helpdesk Engineer",
    "Desktop Support Engineer",
    "NOC Engineer",
    "Database Developer",
    "Oracle Developer",
    "PL SQL Developer",
    "SQL Server Developer",
    "DBA",
    "Oracle DBA",
    "MySQL DBA",
    "MongoDB Developer",
    "Informatica Developer",
    "Talend Developer",
    "SSIS Developer",
    "Ab Initio Developer",
    "Data Warehouse Developer",
    "SAP ABAP Developer",
    "SAP FICO Consultant",
    "SAP MM Consultant",
    "SAP SD Consultant",
    "SAP Basis Consultant",
    "SAP HANA Consultant",
    "SAP UI5 Developer",
    "SuccessFactors Consultant",
    "Salesforce Administrator",
    "Salesforce Consultant",
    "Apex Developer",
    "Lightning Developer",
    "Workday Consultant",
    "Oracle Cloud Consultant",
    "Dynamics 365 Developer",
    "Power Platform Developer",
    "RPA Developer",
    "UiPath Developer",
    "Automation Anywhere Developer",
    "Blue Prism Developer",
    "Embedded Software Engineer",
    "Firmware Engineer",
    "IoT Engineer",
    "Hardware Engineer",
    "VLSI Engineer",
    "ASIC Design Engineer",
    "FPGA Engineer",
    "Electronics Engineer",
    "Electrical Engineer",
    "Mechanical Engineer",
    "Civil Engineer",
    "BIM Technician",
    "BIM Engineer",
    "Design Engineer",
    "CAD Engineer",
    "Quality Engineer",
    "Manufacturing Engineer",
    "Production Engineer",
    "Process Engineer",
    "Industrial Engineer",
    "Automotive Engineer",
    "Aircraft Maintenance Engineer",
    "Robotics Engineer",
    "Robotics Specialist",
    "Power System Engineer",
    "Instrumentation Engineer",
    "Piping Engineer",
    "Digital Marketing Manager",
    "Digital Marketing Executive",
    "SEO Specialist",
    "SEO Manager",
    "SEM Specialist",
    "PPC Specialist",
    "Content Writer",
    "Content Strategist",
    "Content Manager",
    "Social Media Manager",
    "Social Media Marketing Specialist",
    "Influencer Marketing Specialist",
    "Growth Hacker",
    "Growth Manager",
    "Growth Consultant",
    "Performance Marketing Manager",
    "Brand Manager",
    "Trade Marketing Specialist",
    "Media Buyer",
    "Creative Strategist",
    "Marketing Analyst",
    "Marketing Manager",
    "Email Marketing Specialist",
    "CRM Executive",
    "Business Development Executive",
    "Business Development Manager",
    "Sales Executive",
    "Sales Manager",
    "Inside Sales Executive",
    "Account Executive",
    "Account Manager",
    "Key Account Manager",
    "Customer Success Manager",
    "Client Relationship Manager",
    "Pre Sales Consultant",
    "Solution Consultant",
    "Technical Sales Engineer",
    "HR Executive",
    "HR Manager",
    "HR Business Partner",
    "Talent Acquisition Specialist",
    "Recruiter",
    "Technical Recruiter",
    "Payroll Executive",
    "HR Generalist",
    "Operations Manager",
    "Operations Executive",
    "Operations Analyst",
    "Process Associate",
    "Finance Analyst",
    "Financial Analyst",
    "Accountant",
    "Chartered Accountant",
    "Investment Banking Analyst",
    "Equity Research Analyst",
    "Risk Analyst",
    "Credit Analyst",
    "Compliance Analyst",
    "Audit Associate",
    "Tax Consultant",
    "Company Secretary",
    "Management Consultant",
    "Strategy Consultant",
    "Business Consultant",
    "Management Trainee",
    "Customer Support Executive",
    "Customer Service Representative",
    "Chat Support Executive",
    "Voice Process Executive",
    "BPO Executive",
    "Team Leader BPO",
    "Nurse",
    "Registered Nurse",
    "Pharmacist",
    "Medical Coder",
    "Clinical Research Associate",
    "Behavioral Therapist",
    "School Counsellor",
    "Physiotherapist",
    "Travel Specialist",
    "Travel Consultant",
    "Food and Beverage Manager",
    "Cafe Manager",
    "Hotel Manager",
    "Restaurant Manager",
    "Closing Manager",
    "Real Estate Manager",
    "Sustainability Analyst",
    "Sustainability Consultant",
    "ESG Analyst",
    "Legal Associate",
    "Corporate Lawyer",
    "Paralegal",
    "Company Legal Counsel",
    "Teacher",
    "Lecturer",
    "Corporate Trainer",
    "Instructional Designer",
    "Research Analyst",
    "Market Research Analyst",
    "Operations Research Analyst",
    "Supply Chain Analyst",
    "Logistics Manager",
    "Procurement Manager",
    "Purchase Executive",
    "Warehouse Manager",
    "Inventory Manager",
    "Category Manager",
    "Fresher",
    "Intern",
    "Graduate Trainee",
    "Junior Developer",
    "Junior Data Analyst",
    "Junior Data Scientist",
    "Associate Consultant",
    "Senior Consultant",
    "Lead Consultant",
    "Principal Consultant",
    "Vice President Engineering",
    "Director of Engineering",
    "CTO",
    "CIO",
    "Head of Engineering",
    "Head of Product",
    "VP Product",
    "Application Developer",
    "Application Tech Support Practitioner",
    "IT Architect",
    "Integration Developer",
    "API Developer",
    "Microservices Developer",
    "Middleware Developer",
    "Mainframe Developer",
    "Cobol Developer",
    "PEGA Developer",
    "OutSystems Developer",
    "Low Code Developer",
    "Mendix Developer",
    "PowerApps Developer",
    "Unreal Engine Developer",
    "Unity Developer",
    "Game Developer",
    "AR VR Developer",
    "QA Automation Engineer",
    "Release Engineer",
    "Build and Release Engineer",
    "Configuration Manager",
    "Change Manager",
    "Incident Manager",
    "Problem Manager",
    "ITIL Consultant",
    "Service Desk Analyst",
    "Technical Writer",
    "Documentation Specialist",
    "BI Analyst",
    "Reporting Analyst",
    "MIS Executive",
    "Excel Specialist",
    "SAS Developer",
    "SPSS Analyst",
    "Statistician",
    "Quantitative Analyst",
    "Actuarial Analyst",
    "Underwriter",
    "Claims Analyst",
    "Telecom Engineer",
    "RF Engineer",
    "Network Security Engineer",
    "Wireless Engineer",
    "Voice Engineer",
    "UC Engineer",
    "Collaboration Engineer",
    "Oracle EBS Consultant",
    "PeopleSoft Developer",
    "Workday HCM Consultant",
    "Coupa Consultant",
    "Anaplan Consultant",
    "Adobe Experience Manager Developer",
    "Sitecore Developer",
    "Drupal Developer",
    "Magento Developer",
    "Shopify Developer",
    "E Commerce Manager",
    "Product Analyst",
    "Business Systems Analyst",
    "Functional Analyst",
    "System Analyst",
    "Requirements Analyst",
    "Process Analyst",
    "Lean Six Sigma Consultant",
    "Implementation Consultant",
    "Onboarding Specialist",
    "Customer Experience Manager",
    "Community Manager",
    "Partnership Manager",
    "Affiliate Marketing Manager",
    "PR Executive",
    "Communications Manager",
    "Event Manager",
    "Video Editor",
    "Motion Graphic Designer",
    "3D Artist",
    "Animator",
    "Photographer",
    "Videographer",
    "Senior Data Engineer",
    "Senior Data Scientist",
    "Senior Data Analyst",
    "Senior DevOps Engineer",
    "Senior Cloud Engineer",
    "Senior Frontend Developer",
    "Senior Backend Developer",
    "Senior Full Stack Developer",
    "Senior Java Developer",
    "Senior Python Developer",
    "Senior React Developer",
    "Senior Android Developer",
    "Senior iOS Developer",
    "Senior QA Engineer",
    "Senior Business Analyst",
    "Senior Product Manager",
    "Lead Data Engineer",
    "Lead Data Scientist",
    "Lead DevOps Engineer",
    "Lead QA Engineer",
    "Lead Java Developer",
    "Lead Python Developer",
    "Lead Frontend Engineer",
    "Junior Software Developer",
    "Junior Frontend Developer",
    "Junior Backend Developer",
    "Junior QA Engineer",
    "Junior Business Analyst",
    "Trainee Software Engineer",
    "Intern Software Engineer",
    "Campus Hire",
    "Software Engineer Intern",
    "Member of Technical Staff",
    "MTS",
    "Principal Engineer",
    "Distinguished Engineer",
    "Architect",
    "Solution Engineer",
    "Customer Engineer",
    "Forward Deployed Engineer",
    "Developer Advocate",
    "Developer Relations Engineer",
    "Technical Evangelist",
    "Release Manager",
    "Environment Manager",
    "Capacity Planner",
    "Data Steward",
    "Data Governance Analyst",
    "Master Data Management Specialist",
    "Privacy Analyst",
    "Data Protection Officer",
    "AI Ethics Specialist",
    "AI Product Manager",
    "ML Product Manager",
    "Data Product Manager",
    "Platform Product Manager",
    "API Product Manager",
    "Trust and Safety Analyst",
    "Content Moderator",
    "Fraud Analyst",
    "KYC Analyst",
    "AML Analyst",
    "Transaction Monitoring Analyst",
    "Wealth Manager",
    "Relationship Manager",
    "Branch Manager",
    "Loan Officer",
    "Insurance Advisor",
    "Actuary",
    "Claims Manager",
    "Store Manager",
    "Retail Manager",
    "Merchandiser",
    "Visual Merchandiser",
    "Fashion Designer",
    "Interior Designer",
    "Architect Civil",
    "Quantity Surveyor",
    "Site Engineer",
    "Construction Manager",
    "Project Engineer",
    "HSE Officer",
    "Safety Officer",
    "Quality Control Engineer",
    "Quality Assurance Manager",
    "Lab Technician",
    "Chemist",
    "Biotechnologist",
    "Microbiologist",
    "Clinical Data Manager",
    "Pharmacovigilance Associate",
    "Medical Writer",
    "Radiologist Technician",
    "Lab Assistant",
    "Cabin Crew",
    "Airport Operations Executive",
    "Ground Staff",
    "Fleet Manager",
    "Driver Coordinator",
    "Journalist",
    "Editor",
    "Copywriter",
    "Proofreader",
    "Translator",
    "Librarian",
    "Research Associate",
    "Policy Analyst",
    "NGO Program Manager",
    "Fundraising Manager",
    "Development Officer",
    "Public Policy Associate",
    "Government Affairs Manager"
  ];
  var KEYWORD_SUGGESTIONS = [
    "Java",
    "Spring",
    "Spring Boot",
    "Spring MVC",
    "Spring Security",
    "Spring Batch",
    "Spring Integration",
    "Hibernate",
    "JPA",
    "Microservices",
    "REST",
    "REST API",
    "GraphQL",
    "JavaScript",
    "TypeScript",
    "React.js",
    "React Native",
    "Next.js",
    "Node.js",
    "Express.js",
    "Angular",
    "Vue.js",
    "HTML",
    "CSS",
    "SQL",
    "MySQL",
    "PostgreSQL",
    "MongoDB",
    "Redis",
    "Kafka",
    "RabbitMQ",
    "Docker",
    "Kubernetes",
    "AWS",
    "Amazon Web Services",
    "Google Cloud Platform",
    "Azure",
    "CI/CD",
    "Jenkins",
    "Git",
    "GitHub",
    "GitLab",
    "Python",
    "Django",
    "Flask",
    "FastAPI",
    "C#",
    ".NET",
    ".NET Core",
    "ASP.NET",
    "C++",
    "Go",
    "Golang",
    "Kotlin",
    "Swift",
    "Android",
    "iOS",
    "Selenium",
    "Cypress",
    "Playwright",
    "JUnit",
    "TestNG",
    "Agile",
    "Scrum",
    "Jira",
    "Linux",
    "Unix",
    "Shell Scripting",
    "Data Structures",
    "Algorithms",
    "System Design",
    "Object Oriented Programming",
    "OOP",
    "Design Patterns",
    "Machine Learning",
    "Deep Learning",
    "Artificial Intelligence",
    "NLP",
    "TensorFlow",
    "PyTorch",
    "Power BI",
    "Tableau",
    "ETL",
    "Data Warehousing",
    "Snowflake",
    "Spark",
    "Hadoop",
    "Salesforce",
    "SAP",
    "Oracle",
    "PL/SQL",
    "API Testing",
    "Manual Testing",
    "Automation Testing",
    "Communication Skills",
    "Problem Solving",
    ".NET Framework",
    "Active Directory",
    "ADO.NET",
    "Adobe XD",
    "Airflow",
    "Ajax",
    "AKS",
    "Android Development",
    "AngularJS",
    "Ansible",
    "Apache Airflow",
    "Apex",
    "API",
    "Appium",
    "ArgoCD",
    "AS400",
    "ASP.NET MVC",
    "AutoCAD",
    "Automation Anywhere",
    "AWS Lambda",
    "Azure Data Factory",
    "Azure Data Lake",
    "Azure Databricks",
    "Azure DevOps",
    "Azure ML",
    "Azure Synapse",
    "Bamboo",
    "Bash Scripting",
    "BDD",
    "Big Data",
    "BigQuery",
    "BIM",
    "Bitbucket",
    "Black Box Testing",
    "Blockchain",
    "Blue Prism",
    "Bootstrap",
    "Business Analysis",
    "Business Intelligence",
    "Cassandra",
    "Cloud Computing",
    "Cloud Security",
    "Cloudera",
    "CNN",
    "COBOL",
    "CodeIgniter",
    "Computer Vision",
    "Confluence",
    "Containerization",
    "Core Java",
    "CRM",
    "CSS3",
    "Cucumber",
    "Cybersecurity",
    "Data Engineering",
    "Data Modeling",
    "Data Science",
    "Data Visualization",
    "Database Testing",
    "Databricks",
    "Datadog",
    "DAX",
    "DB2",
    "dbt",
    "DevOps",
    "Drupal",
    "Dynamics 365",
    "DynamoDB",
    "EC2",
    "EKS",
    "Elasticsearch",
    "ELK",
    "Embedded C",
    "Entity Framework",
    "ERP",
    "ES6",
    "Ethical Hacking",
    "Excel",
    "Figma",
    "Firebase",
    "Firewall",
    "Flutter",
    "GCP",
    "GenAI",
    "Generative AI",
    "GitHub Actions",
    "GitOps",
    "GKE",
    "Google Ads",
    "Google Analytics",
    "Gradle",
    "Grafana",
    "gRPC",
    "HDFS",
    "Helm",
    "Hive",
    "HTML5",
    "Hugging Face",
    "IAM",
    "Illustrator",
    "Informatica",
    "Infrastructure as Code",
    "Integration Testing",
    "Ionic",
    "iOS Development",
    "IoT",
    "ITIL",
    "J2EE",
    "Java 8",
    "Java Web Services",
    "Jest",
    "Jetpack Compose",
    "JMeter",
    "jQuery",
    "JSON",
    "JWT",
    "Kanban",
    "Keras",
    "Lambda",
    "LangChain",
    "Laravel",
    "LINQ",
    "LLM",
    "Load Testing",
    "LoadRunner",
    "Looker",
    "Magento",
    "Mainframes",
    "MapReduce",
    "Marketing Cloud",
    "MATLAB",
    "Matplotlib",
    "Maven",
    "MEAN Stack",
    "MERN Stack",
    "MLOps",
    "Mockito",
    "MS Excel",
    "MS Office",
    "MS PowerPoint",
    "MS SQL",
    "MuleSoft",
    "MVC",
    "Neo4j",
    "NestJS",
    "Network Security",
    "New Relic",
    "Nginx",
    "NLTK",
    "NoSQL",
    "NumPy",
    "Nuxt.js",
    "OAuth",
    "OpenAPI",
    "OpenCV",
    "OpenShift",
    "Oracle SQL",
    "Pandas",
    "PEGA",
    "Penetration Testing",
    "Performance Testing",
    "Perl",
    "Photoshop",
    "PHP",
    "PLC",
    "Plotly",
    "PMP",
    "Postman",
    "Power Query",
    "PowerApps",
    "PowerShell",
    "PPC",
    "Prisma",
    "Project Management",
    "Prometheus",
    "Prompt Engineering",
    "Puppet",
    "Pytest",
    "QA Automation",
    "Qlik",
    "RAG",
    "RDBMS",
    "Redshift",
    "Redux",
    "Regression Testing",
    "Requirement Gathering",
    "Responsive Web Design",
    "RESTful Web Services",
    "Revit",
    "RHEL",
    "RNN",
    "Robot Framework",
    "RPA",
    "Ruby",
    "S/4HANA",
    "S3",
    "SAFe",
    "SageMaker",
    "Sales Cloud",
    "Salesforce Aura",
    "Salesforce LWC",
    "SAP ABAP",
    "SAP Basis",
    "SAP FICO",
    "SAP HANA",
    "SAP MM",
    "SAP SD",
    "SAPUI5",
    "Sass",
    "SCADA",
    "Scala",
    "Scikit-learn",
    "Seaborn",
    "Selenium WebDriver",
    "SEM",
    "SEO",
    "Service Cloud",
    "ServiceNow",
    "Servlets",
    "SharePoint",
    "SIEM",
    "Six Sigma",
    "SOAP",
    "SoapUI",
    "Solidity",
    "SolidWorks",
    "Solr",
    "SonarQube",
    "SpaCy",
    "Splunk",
    "Spring Cloud",
    "SQL Server",
    "SQLAlchemy",
    "SSIS",
    "SSRS",
    "Stakeholder Management",
    "Streamlit",
    "Struts",
    "SuccessFactors",
    "Swagger",
    "SwiftUI",
    "T-SQL",
    "Tally",
    "Terraform",
    "Tomcat",
    "TypeORM",
    "UI Automation",
    "UI Development",
    "UiPath",
    "Unit Testing",
    "Unity",
    "Unreal Engine",
    "VB.NET",
    "Vertex AI",
    "Visualforce",
    "VMware",
    "VPN",
    "Vulnerability Assessment",
    "WCF",
    "Web API",
    "Web Development",
    "Windows Server",
    "WordPress",
    "Workday",
    "Xamarin",
    "XML"
  ];
  var LOCATION_SUGGESTIONS = [
    "Hyderabad",
    "Hyderabad/Secunderabad",
    "Bengaluru",
    "Bangalore",
    "Bengaluru/Bangalore",
    "Chennai",
    "Mumbai",
    "Pune",
    "Delhi",
    "Delhi/NCR",
    "Noida",
    "Gurgaon",
    "Gurugram",
    "Kolkata",
    "Ahmedabad",
    "Jaipur",
    "Chandigarh",
    "Kochi",
    "Coimbatore",
    "Indore",
    "Nagpur",
    "Thiruvananthapuram",
    "Visakhapatnam",
    "Mysore",
    "Remote",
    "Work From Home"
  ];
  function compactMatchText(value) {
    return value.toLowerCase().replace(/[^a-z0-9+#]/g, "");
  }
  function canonicalizePreferenceValue(raw, catalog) {
    const trimmed = raw.trim();
    if (!trimmed) return "";
    const compact = compactMatchText(trimmed);
    if (!compact) return "";
    const exact = catalog.find(
      (item) => compactMatchText(item) === compact
    );
    return exact ?? "";
  }
  function suggestPreferenceValues(query, catalog, options = {}) {
    const limit = options.limit ?? 8;
    const q = query.trim().toLowerCase();
    const qCompact = compactMatchText(query);
    const excluded = new Set(
      (options.exclude ?? []).map((v) => v.toLowerCase())
    );
    if (!q && !qCompact) {
      return catalog.filter((item) => !excluded.has(item.toLowerCase())).slice(0, limit);
    }
    const scored = [];
    for (const item of catalog) {
      if (excluded.has(item.toLowerCase())) continue;
      const lower = item.toLowerCase();
      const compact = compactMatchText(item);
      let score = -1;
      if (lower.startsWith(q)) score = 100 - lower.length;
      else if (compact.startsWith(qCompact)) score = 80 - compact.length;
      else if (lower.includes(q)) score = 60 - lower.indexOf(q);
      else if (qCompact.length >= 2 && compact.includes(qCompact)) {
        score = 40 - compact.indexOf(qCompact);
      }
      if (score >= 0) scored.push({ item, score });
    }
    scored.sort((a, b) => b.score - a.score || a.item.localeCompare(b.item));
    return scored.slice(0, limit).map((s) => s.item);
  }

  // ../shared/src/scanSessions.ts
  var scanSessionStatusSchema = external_exports.enum([
    "running",
    "completed",
    "stopped",
    "failed"
  ]);
  var scanSessionUpsertSchema = external_exports.object({
    sessionId: external_exports.string().uuid(),
    platform: platformSchema.default("naukri"),
    keyword: external_exports.string().max(200).default(""),
    startedAt: external_exports.string().datetime(),
    endedAt: external_exports.string().datetime().optional(),
    status: scanSessionStatusSchema.default("running"),
    /** Unique job cards seen on the search list, matched or not. */
    scanned: external_exports.number().int().nonnegative().default(0),
    matched: external_exports.number().int().nonnegative().default(0),
    applied: external_exports.number().int().nonnegative().default(0),
    skipped: external_exports.number().int().nonnegative().default(0),
    pagesScanned: external_exports.number().int().nonnegative().default(0)
  });
  var scanStatsQuerySchema = external_exports.object({
    days: external_exports.coerce.number().int().min(1).max(366).default(30),
    limit: external_exports.coerce.number().int().min(1).max(50).default(10),
    /** Inclusive ISO lower bound. When set with `to`, overrides rolling `days`. */
    from: external_exports.string().datetime().optional(),
    /** Exclusive ISO upper bound. */
    to: external_exports.string().datetime().optional()
  });

  // src/core/defaults.ts
  var DEFAULT_JOB_PREFERENCES = {
    titles: ["Software Engineer", "Software Developer", "Full Stack Developer"],
    keywords: ["Spring Boot", "React.js", "Java", "JavaScript"],
    locations: ["Bengaluru", "Remote"],
    experienceMin: 0,
    experienceMax: 5,
    minSalaryLpa: 2,
    workMode: "any",
    autoScanEnabled: true,
    autoApplyEnabled: true
  };
  function jobPreferencesAreUnset(prefs) {
    if (!prefs) return true;
    return !prefs.titles?.length && !prefs.keywords?.length;
  }
  function resolveAutomationFlags(prefs) {
    const scan = prefs?.autoScanEnabled ?? true;
    const applyRaw = prefs?.autoApplyEnabled;
    const legacyApplyOff = applyRaw === false && scan !== false;
    return {
      autoScanEnabled: scan !== false,
      autoApplyEnabled: applyRaw == null || legacyApplyOff ? true : applyRaw
    };
  }
  function resolveJobPreferences(prefs) {
    if (jobPreferencesAreUnset(prefs)) {
      return { ...DEFAULT_JOB_PREFERENCES };
    }
    return {
      ...DEFAULT_JOB_PREFERENCES,
      titles: prefs.titles ?? [],
      keywords: prefs.keywords ?? [],
      locations: prefs.locations ?? [],
      experienceMin: prefs.experienceMin ?? DEFAULT_JOB_PREFERENCES.experienceMin,
      experienceMax: prefs.experienceMax ?? DEFAULT_JOB_PREFERENCES.experienceMax,
      minSalaryLpa: prefs.minSalaryLpa ?? DEFAULT_JOB_PREFERENCES.minSalaryLpa,
      workMode: prefs.workMode ?? DEFAULT_JOB_PREFERENCES.workMode,
      ...resolveAutomationFlags(prefs)
    };
  }

  // src/shared/browser.ts
  function getExtensionApi() {
    const root = globalThis;
    if (root.chrome?.runtime?.id != null || typeof root.chrome?.runtime?.sendMessage === "function") {
      return root.chrome;
    }
    if (root.browser?.runtime) {
      return root.browser;
    }
    if (root.chrome) return root.chrome;
    throw new Error("WebExtensions API (chrome/browser) is not available");
  }
  function ensureChromeNamespace() {
    const root = globalThis;
    if (!root.chrome?.runtime) {
      root.chrome = getExtensionApi();
    }
    return root.chrome;
  }

  // src/shared/dom.ts
  function clearChildren(el) {
    el.replaceChildren();
  }
  function setTrustedHtml(el, html) {
    const doc = new DOMParser().parseFromString(html, "text/html");
    const nodes = [
      ...Array.from(doc.head.querySelectorAll("style, link")),
      ...Array.from(doc.body.childNodes)
    ].map((node) => el.ownerDocument.importNode(node, true));
    el.replaceChildren(...nodes);
  }

  // src/shared/chipSuggestField.ts
  function mountChipSuggestField(options) {
    const { root, catalog, placeholder, minCount } = options;
    const box = root.querySelector(".chip-suggest__box");
    const chipsEl = root.querySelector(".chip-suggest__chips");
    const input = root.querySelector(
      ".chip-suggest__input"
    );
    const menu = root.querySelector(".chip-suggest__menu");
    const countEl = root.querySelector(
      ".chip-suggest__count"
    );
    let values = [];
    let activeIndex = -1;
    let suggestions = [];
    input.placeholder = placeholder;
    function updateCount() {
      if (!countEl || typeof minCount !== "number") return;
      countEl.textContent = `${values.length}/${minCount}`;
      countEl.classList.toggle("is-short", values.length < minCount);
      box.classList.toggle("is-incomplete", values.length < minCount);
    }
    function hideMenu() {
      menu.classList.add("hidden");
      clearChildren(menu);
      suggestions = [];
      activeIndex = -1;
    }
    function renderChips() {
      clearChildren(chipsEl);
      for (const value of values) {
        const chip = document.createElement("span");
        chip.className = "chip-suggest__chip";
        const label = document.createElement("span");
        label.textContent = value;
        const remove = document.createElement("button");
        remove.type = "button";
        remove.className = "chip-suggest__remove";
        remove.setAttribute("aria-label", `Remove ${value}`);
        remove.textContent = "\xD7";
        remove.addEventListener("click", () => {
          values = values.filter((v) => v !== value);
          renderChips();
          updateCount();
          refreshSuggestions();
        });
        chip.append(label, remove);
        chipsEl.appendChild(chip);
      }
      input.placeholder = values.length === 0 ? placeholder : "Add another\u2026";
      updateCount();
    }
    function highlightActive() {
      const items = Array.from(
        menu.querySelectorAll(".chip-suggest__option")
      );
      items.forEach((el, i) => {
        el.classList.toggle("is-active", i === activeIndex);
      });
      items[activeIndex]?.scrollIntoView({ block: "nearest" });
    }
    function renderMenu() {
      clearChildren(menu);
      if (!suggestions.length) {
        hideMenu();
        return;
      }
      menu.classList.remove("hidden");
      suggestions.forEach((item, index) => {
        const btn = document.createElement("button");
        btn.type = "button";
        btn.className = "chip-suggest__option";
        btn.textContent = item;
        btn.addEventListener("mousedown", (e) => {
          e.preventDefault();
          commitValue(item);
        });
        if (index === activeIndex) btn.classList.add("is-active");
        menu.appendChild(btn);
      });
    }
    function refreshSuggestions() {
      const draft = input.value;
      if (!draft.trim()) {
        hideMenu();
        return;
      }
      suggestions = suggestPreferenceValues(draft, catalog, {
        exclude: values,
        limit: 8
      });
      activeIndex = suggestions.length ? 0 : -1;
      renderMenu();
    }
    function addValue(raw) {
      const canonical = canonicalizePreferenceValue(raw, catalog);
      if (!canonical) return;
      const key = canonical.toLowerCase();
      if (values.some((v) => v.toLowerCase() === key)) return;
      values = [...values, canonical];
      renderChips();
    }
    function commitValue(raw) {
      addValue(raw);
      input.value = "";
      hideMenu();
      input.focus();
    }
    function flushDraft() {
      const raw = input.value;
      if (raw.trim()) {
        addValue(raw);
        input.value = "";
        hideMenu();
      }
    }
    input.addEventListener("input", () => {
      refreshSuggestions();
    });
    input.addEventListener("keydown", (e) => {
      if (e.key === "ArrowDown" && suggestions.length) {
        e.preventDefault();
        activeIndex = (activeIndex + 1) % suggestions.length;
        highlightActive();
        return;
      }
      if (e.key === "ArrowUp" && suggestions.length) {
        e.preventDefault();
        activeIndex = activeIndex <= 0 ? suggestions.length - 1 : activeIndex - 1;
        highlightActive();
        return;
      }
      if (e.key === "Enter" || e.key === ",") {
        e.preventDefault();
        if (activeIndex >= 0 && suggestions[activeIndex]) {
          commitValue(suggestions[activeIndex]);
          return;
        }
        const exact = canonicalizePreferenceValue(input.value, catalog);
        if (exact) {
          commitValue(exact);
          return;
        }
        if (suggestions[0]) commitValue(suggestions[0]);
        return;
      }
      if (e.key === "Escape") {
        hideMenu();
        return;
      }
      if (e.key === "Backspace" && input.value === "" && values.length > 0) {
        values = values.slice(0, -1);
        renderChips();
      }
    });
    input.addEventListener("blur", () => {
      window.setTimeout(() => {
        if (input.value.trim()) flushDraft();
        else hideMenu();
      }, 120);
    });
    box.addEventListener("click", (e) => {
      if (e.target === box || e.target === chipsEl) input.focus();
    });
    hideMenu();
    renderChips();
    return {
      getValues: () => [...values],
      setValues: (next) => {
        values = [...next];
        input.value = "";
        hideMenu();
        renderChips();
      },
      flushDraft
    };
  }

  // src/popup/index.ts
  ensureChromeNamespace();
  var authStateEl = document.getElementById("auth-state");
  var healthStateEl = document.getElementById("health-state");
  var scanStateEl = document.getElementById("scan-state");
  var loginPanel = document.getElementById("login-panel");
  var authedSection = document.getElementById("authed");
  var formError = document.getElementById("form-error");
  var prefsMsg = document.getElementById("prefs-msg");
  var prefsRetryEl = document.getElementById("prefs-retry");
  var prefsRetryMsg = document.getElementById("prefs-retry-msg");
  var prefsRetryBtn = document.getElementById(
    "prefs-retry-btn"
  );
  var toastHost = document.getElementById("popup-toast-host");
  var googleSignInBtn = document.getElementById(
    "google-sign-in"
  );
  var alertEl = document.getElementById("copilot-alert");
  var alertTitleEl = document.getElementById("copilot-alert-title");
  var alertMsgEl = document.getElementById("copilot-alert-msg");
  var alertDismissBtn = document.getElementById("copilot-alert-dismiss");
  var titlesField = mountChipSuggestField({
    root: document.querySelector('.chip-suggest[data-pref="titles"]'),
    catalog: TITLE_SUGGESTIONS,
    placeholder: "Software Engineer",
    minCount: MIN_PREF_TITLES
  });
  var keywordsField = mountChipSuggestField({
    root: document.querySelector(
      '.chip-suggest[data-pref="keywords"]'
    ),
    catalog: KEYWORD_SUGGESTIONS,
    placeholder: "Spring Boot, React.js",
    minCount: MIN_PREF_KEYWORDS
  });
  var locationsField = mountChipSuggestField({
    root: document.querySelector(
      '.chip-suggest[data-pref="locations"]'
    ),
    catalog: LOCATION_SUGGESTIONS,
    placeholder: "Hyderabad, Bengaluru"
  });
  var toastHideTimer = null;
  var waitingForGoogle = false;
  var prefsFetchFailed = false;
  var prefsRetrying = false;
  function showToast(title, message, variant = "success") {
    clearChildren(toastHost);
    const el = document.createElement("div");
    el.className = `popup-toast${variant === "error" ? " is-error" : ""}`;
    el.setAttribute("role", "status");
    setTrustedHtml(
      el,
      `
    <div class="popup-toast-icon" aria-hidden="true">${variant === "error" ? "!" : "\u2713"}</div>
    <div class="popup-toast-copy">
      <p class="popup-toast-title"></p>
      <p class="popup-toast-msg"></p>
    </div>
    <button type="button" class="popup-toast-close" aria-label="Dismiss">\xD7</button>
  `
    );
    el.querySelector(".popup-toast-title").textContent = title;
    el.querySelector(".popup-toast-msg").textContent = message;
    const closeBtn = el.querySelector(".popup-toast-close");
    const dismiss = () => {
      el.classList.add("is-out");
      window.setTimeout(() => {
        if (el.parentElement === toastHost) el.remove();
      }, 220);
    };
    closeBtn.addEventListener("click", dismiss);
    toastHost.appendChild(el);
    if (toastHideTimer) clearTimeout(toastHideTimer);
    toastHideTimer = setTimeout(dismiss, 2800);
  }
  function alertTitle(alert) {
    switch (alert.kind) {
      case "plan_limit":
        return "Plan apply limit reached";
      case "rate_limit":
        return "Safety limit reached";
      case "blocked":
        return "Naukri verification";
      case "login":
        return "Naukri login needed";
      case "questions":
        return "Answer Naukri questions";
      case "error":
        return "Co-pilot error";
      default:
        return "Co-pilot alert";
    }
  }
  function renderAlert(alert) {
    if (!alert?.message) {
      alertEl.classList.add("hidden");
      alertEl.classList.remove("is-error", "flash");
      return;
    }
    alertEl.classList.remove("hidden");
    alertEl.classList.toggle("is-error", alert.level === "error");
    alertEl.classList.remove("flash");
    void alertEl.offsetWidth;
    alertEl.classList.add("flash");
    alertTitleEl.textContent = alertTitle(alert);
    alertMsgEl.textContent = alert.message;
  }
  function send(message) {
    return new Promise((resolve, reject) => {
      try {
        chrome.runtime.sendMessage(message, (response) => {
          const err = chrome.runtime.lastError;
          if (err) {
            reject(new Error(err.message));
            return;
          }
          resolve(response);
        });
      } catch (error) {
        reject(error instanceof Error ? error : new Error(String(error)));
      }
    });
  }
  function showStatusError(message) {
    authStateEl.textContent = "Not signed in";
    authStateEl.classList.remove("is-ok");
    authStateEl.classList.add("is-bad");
    healthStateEl.textContent = "Extension offline";
    healthStateEl.classList.remove("is-ok");
    healthStateEl.classList.add("is-bad");
    scanStateEl.textContent = message;
    loginPanel.classList.remove("hidden");
    authedSection.classList.add("hidden");
  }
  function setPrefsRetryVisible(failed, message) {
    prefsFetchFailed = failed;
    prefsRetryEl.classList.toggle("hidden", !failed);
    if (failed) {
      prefsRetryMsg.textContent = message?.trim() ? `${message.trim().replace(/\.$/, "")}. Retry to sync from Cosmo.` : "Using last saved settings. Retry to sync from Cosmo.";
    }
    if (!prefsRetrying) {
      prefsRetryBtn.disabled = false;
      prefsRetryBtn.textContent = "Retry";
    }
  }
  function fillPrefsForm(prefs) {
    titlesField.setValues(prefs.titles);
    keywordsField.setValues(prefs.keywords);
    locationsField.setValues(prefs.locations);
    document.getElementById("pref-exp-min").value = String(
      prefs.experienceMin
    );
    document.getElementById("pref-exp-max").value = String(
      prefs.experienceMax
    );
    document.getElementById("pref-salary").value = prefs.minSalaryLpa != null ? String(prefs.minSalaryLpa) : "";
    document.getElementById("pref-work-mode").value = prefs.workMode;
    document.getElementById("pref-auto-scan").checked = prefs.autoScanEnabled !== false;
    document.getElementById("pref-auto-apply").checked = prefs.autoApplyEnabled !== false;
  }
  function readPrefsForm() {
    titlesField.flushDraft();
    keywordsField.flushDraft();
    locationsField.flushDraft();
    const salaryRaw = document.getElementById("pref-salary").value;
    return {
      ...DEFAULT_JOB_PREFERENCES,
      titles: titlesField.getValues(),
      keywords: keywordsField.getValues(),
      locations: locationsField.getValues(),
      experienceMin: Number(
        document.getElementById("pref-exp-min").value
      ),
      experienceMax: Number(
        document.getElementById("pref-exp-max").value
      ),
      minSalaryLpa: salaryRaw === "" ? void 0 : Number(salaryRaw),
      workMode: document.getElementById("pref-work-mode").value,
      autoScanEnabled: document.getElementById("pref-auto-scan").checked,
      autoApplyEnabled: document.getElementById("pref-auto-apply").checked
    };
  }
  async function refreshUi() {
    let status;
    try {
      status = await send({ type: "GET_STATUS" });
      if (!status?.auth || !status?.health) {
        throw new Error("No status from background \u2014 reload the extension.");
      }
    } catch (error) {
      showStatusError(
        error instanceof Error ? error.message : "Could not reach extension background. Reload Cosmo from chrome://extensions."
      );
      return;
    }
    const signedIn = Boolean(status.auth.accessToken);
    authStateEl.textContent = signedIn ? "Signed in" : "Not signed in";
    authStateEl.classList.toggle("is-ok", signedIn);
    authStateEl.classList.toggle("is-bad", !signedIn);
    const apiOnline = status.health.apiReachable;
    healthStateEl.textContent = `API ${apiOnline ? "online" : "offline"} \xB7 Queue ${status.health.queueDepth}${status.health.applyQueueDepth ? ` \xB7 Apply ${status.health.applyQueueDepth}` : ""}`;
    healthStateEl.classList.toggle("is-ok", apiOnline);
    healthStateEl.classList.toggle("is-bad", !apiOnline);
    renderAlert(status.copilot?.alert);
    if (status.copilot?.running) {
      const onBreak = status.copilot.sessionBreakUntil && Date.parse(status.copilot.sessionBreakUntil) > Date.now();
      if (onBreak) {
        const ms = status.copilot.sessionBreakRemainingMs ?? 0;
        const sec = Math.max(0, Math.ceil(ms / 1e3));
        const min = Math.floor(sec / 60);
        const rem = sec % 60;
        scanStateEl.textContent = `Co-pilot break \u2014 resumes in ${min}:${String(rem).padStart(2, "0")}`;
      } else if (status.copilot.paceLabel) {
        const remaining = status.copilot.paceRemainingMs ?? 0;
        scanStateEl.textContent = remaining > 0 ? `${status.copilot.paceLabel} \u2014 ${Math.max(0, Math.ceil(remaining / 1e3))}s` : status.copilot.paceLabel;
      } else {
        const phase = status.copilot.runPhase === "apply" ? "applying" : status.copilot.runPhase === "scan" ? "scanning" : "running";
        scanStateEl.textContent = status.copilot.paused ? `Co-pilot paused \xB7 matched ${status.copilot.matched}, applied ${status.copilot.applied}` : `Co-pilot ${phase} \xB7 matched ${status.copilot.matched}, applied ${status.copilot.applied}`;
      }
    } else if (waitingForGoogle && !signedIn) {
      scanStateEl.textContent = "Waiting for Google sign-in\u2026";
    } else {
      scanStateEl.textContent = "";
    }
    loginPanel.classList.toggle("hidden", signedIn);
    authedSection.classList.toggle("hidden", !signedIn);
    if (signedIn) {
      if (waitingForGoogle) {
        waitingForGoogle = false;
        googleSignInBtn.disabled = false;
        formError.textContent = "";
        showToast("Signed in", "Google session synced to Cosmo.");
      }
      if (status.preferences) {
        fillPrefsForm(resolveJobPreferences(status.preferences));
      }
      if (!prefsRetrying) {
        setPrefsRetryVisible(
          status.preferencesSource != null && status.preferencesSource !== "remote",
          status.preferencesError
        );
      }
    } else {
      setPrefsRetryVisible(false);
    }
  }
  alertDismissBtn.addEventListener("click", async () => {
    await send({ type: "COPILOT_DISMISS_ALERT" });
    renderAlert(null);
  });
  prefsRetryBtn.addEventListener("click", async () => {
    if (prefsRetrying) return;
    prefsRetrying = true;
    prefsRetryBtn.disabled = true;
    prefsRetryBtn.textContent = "Retrying\u2026";
    prefsRetryMsg.textContent = "Fetching job preferences from Cosmo\u2026";
    try {
      const result = await send({ type: "GET_PREFERENCES" });
      if (result?.data) {
        fillPrefsForm(resolveJobPreferences(result.data));
      }
      if (result?.success || result?.source === "remote") {
        setPrefsRetryVisible(false);
        showToast("Preferences synced", "Job preferences loaded from Cosmo.");
        return;
      }
      setPrefsRetryVisible(
        true,
        result?.message ?? "Still unable to load job preferences"
      );
    } catch (error) {
      setPrefsRetryVisible(
        true,
        error instanceof Error ? error.message : "Still unable to load job preferences"
      );
    } finally {
      prefsRetrying = false;
      if (prefsFetchFailed) {
        prefsRetryBtn.disabled = false;
        prefsRetryBtn.textContent = "Retry";
      }
    }
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes.copilotState) {
      const next = changes.copilotState.newValue;
      renderAlert(next?.alert);
    }
    if (changes.accessToken || changes.refreshToken) {
      void refreshUi();
    }
    if (changes.preferences?.newValue) {
      fillPrefsForm(resolveJobPreferences(changes.preferences.newValue));
    }
  });
  googleSignInBtn.addEventListener("click", async () => {
    formError.textContent = "";
    googleSignInBtn.disabled = true;
    waitingForGoogle = true;
    scanStateEl.textContent = "Waiting for Google sign-in\u2026";
    const result = await send({
      type: "OPEN_GOOGLE_LOGIN"
    });
    if (!result?.ok) {
      waitingForGoogle = false;
      googleSignInBtn.disabled = false;
      scanStateEl.textContent = "";
      formError.textContent = result?.message ?? "Could not open Google sign-in.";
      showToast(
        "Sign-in failed",
        result?.message ?? "Could not open Cosmo login.",
        "error"
      );
      return;
    }
    showToast(
      "Continue in Cosmo",
      "Finish Google sign-in in the Cosmo tab \u2014 this popup updates automatically."
    );
    googleSignInBtn.disabled = false;
  });
  document.getElementById("prefs-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    prefsMsg.textContent = "Saving\u2026";
    const preferences = readPrefsForm();
    if (preferences.titles.length < 3) {
      prefsMsg.textContent = "Add at least 3 job titles.";
      showToast("Missing titles", "Add at least 3 job titles.", "error");
      return;
    }
    if (preferences.keywords.length < 4) {
      prefsMsg.textContent = "Add at least 4 keywords.";
      showToast("Missing keywords", "Add at least 4 keywords.", "error");
      return;
    }
    const result = await send({
      type: "SAVE_PREFERENCES",
      preferences
    });
    if (!result.success) {
      prefsMsg.textContent = result.message ?? "Save failed";
      showToast("Save failed", result.message ?? "Could not save preferences.", "error");
      return;
    }
    prefsMsg.textContent = "";
    showToast("Preferences saved", "Your Cosmo settings are up to date.");
  });
  document.getElementById("logout").addEventListener("click", async () => {
    waitingForGoogle = false;
    await send({ type: "LOGOUT" });
    await refreshUi();
  });
  var scanConsentEl = document.getElementById(
    "scan-consent"
  );
  var scanNowBtn = document.getElementById("scan-now");
  scanConsentEl.addEventListener("change", () => {
    scanNowBtn.disabled = !scanConsentEl.checked;
  });
  document.getElementById("scan-now").addEventListener("click", async () => {
    if (!scanConsentEl.checked) {
      scanStateEl.textContent = "Accept the co-pilot consent checkbox to start.";
      showToast(
        "Consent required",
        "Confirm the assisted co-pilot notice before scanning.",
        "error"
      );
      return;
    }
    scanStateEl.textContent = "Starting co-pilot on Naukri\u2026";
    const result = await send({
      type: "COPILOT_START",
      consentAccepted: true,
      consentVersion: CONSENT_VERSION
    });
    scanStateEl.textContent = result.ok ? "Co-pilot started \u2014 watch the panel on Naukri." : result.message ?? "Could not start";
    await refreshUi();
  });
  refreshUi();
})();
